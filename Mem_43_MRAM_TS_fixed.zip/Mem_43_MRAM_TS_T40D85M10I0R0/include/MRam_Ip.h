/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : MRAM
*   Dependencies         : None
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
*   Copyright 2024 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef MRAM_IP_H
#define MRAM_IP_H

/**
*   @file MRam_Ip.h
*
*   @addtogroup MRAM_IP
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "MRam_Ip_Types.h"
#include "MRam_Ip_Cfg.h"
/*==================================================================================================
*                                 SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define MRAM_IP_VENDOR_ID_H                    43
#define MRAM_IP_AR_RELEASE_MAJOR_VERSION_H     4
#define MRAM_IP_AR_RELEASE_MINOR_VERSION_H     9
#define MRAM_IP_AR_RELEASE_REVISION_VERSION_H  0
#define MRAM_IP_SW_MAJOR_VERSION_H             1
#define MRAM_IP_SW_MINOR_VERSION_H             0
#define MRAM_IP_SW_PATCH_VERSION_H             0

/*==================================================================================================
*                                       FILE VERSION CHECKS
==================================================================================================*/
/* Check if current file and MRAM_Ip_Types header file are of the same vendor */
#if (MRAM_IP_VENDOR_ID_H != MRAM_IP_TYPES_VENDOR_ID)
    #error "MRam_Ip.h and MRAM_Ip_Types.h have different vendor ids"
#endif
/* Check if current file and MRAM_Ip_Types header file are of the same Autosar version */
#if ((MRAM_IP_AR_RELEASE_MAJOR_VERSION_H    != MRAM_IP_TYPES_AR_RELEASE_MAJOR_VERSION) || \
     (MRAM_IP_AR_RELEASE_MINOR_VERSION_H    != MRAM_IP_TYPES_AR_RELEASE_MINOR_VERSION) || \
     (MRAM_IP_AR_RELEASE_REVISION_VERSION_H != MRAM_IP_TYPES_AR_RELEASE_REVISION_VERSION) \
    )
    #error "AutoSar Version Numbers of MRam_Ip.h and MRAM_Ip_Types.h are different"
#endif
/* Check if current file and MRAM_Ip_Types header file are of the same Software version */
#if ((MRAM_IP_SW_MAJOR_VERSION_H != MRAM_IP_TYPES_SW_MAJOR_VERSION) || \
     (MRAM_IP_SW_MINOR_VERSION_H != MRAM_IP_TYPES_SW_MINOR_VERSION) || \
     (MRAM_IP_SW_PATCH_VERSION_H != MRAM_IP_TYPES_SW_PATCH_VERSION) \
    )
    #error "Software Version Numbers of MRam_Ip.h and MRAM_Ip_Types.h are different"
#endif

/* Check if current file and MRam_Ip_Cfg.h header file are of the same vendor */
#if (MRAM_IP_VENDOR_ID_H != MRAM_IP_VENDOR_ID_CFG)
    #error "MRam_Ip.h and MRam_Ip_Cfg.h have different vendor ids"
#endif
/* Check if current file and MRam_Ip_Cfg.h header file are of the same Autosar version */
#if ((MRAM_IP_AR_RELEASE_MAJOR_VERSION_H    != MRAM_IP_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (MRAM_IP_AR_RELEASE_MINOR_VERSION_H    != MRAM_IP_AR_RELEASE_MINOR_VERSION_CFG) || \
     (MRAM_IP_AR_RELEASE_REVISION_VERSION_H != MRAM_IP_AR_RELEASE_REVISION_VERSION_CFG) \
    )
    #error "AutoSar Version Numbers of MRam_Ip.h and MRam_Ip_Cfg.h are different"
#endif
/* Check if current file and MRam_Ip_Cfg.h header file are of the same Software version */
#if ((MRAM_IP_SW_MAJOR_VERSION_H != MRAM_IP_SW_MAJOR_VERSION_CFG) || \
     (MRAM_IP_SW_MINOR_VERSION_H != MRAM_IP_SW_MINOR_VERSION_CFG) || \
     (MRAM_IP_SW_PATCH_VERSION_H != MRAM_IP_SW_PATCH_VERSION_CFG) \
    )
    #error "Software Version Numbers of MRam_Ip.h and MRam_Ip_Cfg.h are different"
#endif
/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/
/**
 * @brief   Delay execution by approximately the specified number of CPU cycles
 * @details This macro implements a simple delay loop that consumes approximately
 *          the specified number of CPU cycles. The actual delay may vary based
 *          on compiler optimization, CPU architecture, and cache effects.
 *
 *          The counter variable is declared as volatile to prevent the compiler
 *          from optimizing away the delay loop.
 *
 * @param[in] cycles  Approximate number of CPU cycles to delay
 */
#ifndef MRAM_IP_DELAY_CYCLES
    #define MRAM_IP_DELAY_CYCLES(cycles) \
        do { \
            uint32 delayCounter; \
            for (delayCounter = 0U; delayCounter < (cycles); delayCounter++) { \
                ASM_KEYWORD("nop"); \
            } \
        } while(0)
#endif /* MRAM_IP_DELAY_CYCLES */


#define MRAM_IP_WORD_SIZE                               4u /* 1 word has 4 bytes*/
#define MRAM_IP_SINGLE_WRITE_PAGE_NUM_WPE_REG_VALUE     1u /*0001*/
#define MRAM_IP_SINGLE_WRITE_PAGE_SIZE                  32u /*1 page size is 32 bytes */
#define MRAM_IP_FOUR_WRITE_PAGE_NUM_WPE_REG_VALUE       4u /*0100*/
#define MRAM_IP_FOUR_WRITE_PAGE_SIZE                    (MRAM_IP_FOUR_WRITE_PAGE_NUM_WPE_REG_VALUE * MRAM_IP_SINGLE_WRITE_PAGE_SIZE)
#define MRAM_IP_EIGHT_WRITE_PAGE_NUM_WPE_REG_VALUE      8u /*1000*/
#define MRAM_IP_EIGHT_WRITE_PAGE_SIZE                   (MRAM_IP_EIGHT_WRITE_PAGE_NUM_WPE_REG_VALUE * MRAM_IP_SINGLE_WRITE_PAGE_SIZE)

/* Code MRAM - Large Partitions (16 partitions in 8 pairs) */

/* Overall Code MRAM region */
#define MRAM_IP_CODE_START                   0x08000000U
/* Code MRAM total size: 32 MB (0x02000000) */

/* Individual large partition size: 2 MB (0x00200000) */

/* Large Partition Pair size (upper + lower) */
#define MRAM_IP_LARGE_PAIR_SIZE              0x00400000U /* 4 MB each pair */

/* Large Partition Pairs (interleaved on 32B boundaries) */
#define MRAM_IP_LARGE_PAIR0_START            MRAM_IP_CODE_START
#define MRAM_IP_LARGE_PAIR0_END              (MRAM_IP_LARGE_PAIR0_START + MRAM_IP_LARGE_PAIR_SIZE - 1U)

/* Pair 0 Lower and Upper partitions are interleaved in hardware on 32-byte boundaries */

#define MRAM_IP_LARGE_PAIR1_START            (MRAM_IP_LARGE_PAIR0_END + 1U)
#define MRAM_IP_LARGE_PAIR1_END              (MRAM_IP_LARGE_PAIR1_START + MRAM_IP_LARGE_PAIR_SIZE - 1U)

/* Pair 1 Lower and Upper partitions are interleaved in hardware on 32-byte boundaries */
#define MRAM_IP_LARGE_PAIR2_START            (MRAM_IP_LARGE_PAIR1_END + 1U)
#define MRAM_IP_LARGE_PAIR2_END              (MRAM_IP_LARGE_PAIR2_START + MRAM_IP_LARGE_PAIR_SIZE - 1U)

/* Pair 2 Lower and Upper partitions are interleaved in hardware on 32-byte boundaries */

#define MRAM_IP_LARGE_PAIR3_START            (MRAM_IP_LARGE_PAIR2_END + 1U)
#define MRAM_IP_LARGE_PAIR3_END              (MRAM_IP_LARGE_PAIR3_START + MRAM_IP_LARGE_PAIR_SIZE - 1U)

/* Pair 3 Lower and Upper partitions are interleaved in hardware on 32-byte boundaries */

#define MRAM_IP_LARGE_PAIR4_START            (MRAM_IP_LARGE_PAIR3_END + 1U)
#define MRAM_IP_LARGE_PAIR4_END              (MRAM_IP_LARGE_PAIR4_START + MRAM_IP_LARGE_PAIR_SIZE - 1U)

/* Pair 4 Lower and Upper partitions are interleaved in hardware on 32-byte boundaries */

#define MRAM_IP_LARGE_PAIR5_START            (MRAM_IP_LARGE_PAIR4_END + 1U)
#define MRAM_IP_LARGE_PAIR5_END              (MRAM_IP_LARGE_PAIR5_START + MRAM_IP_LARGE_PAIR_SIZE - 1U)

/* Pair 5 Lower and Upper partitions are interleaved in hardware on 32-byte boundaries */

#define MRAM_IP_LARGE_PAIR6_START            (MRAM_IP_LARGE_PAIR5_END + 1U)
#define MRAM_IP_LARGE_PAIR6_END              (MRAM_IP_LARGE_PAIR6_START + MRAM_IP_LARGE_PAIR_SIZE - 1U)

/* Pair 6 Lower and Upper partitions are interleaved in hardware on 32-byte boundaries */

#define MRAM_IP_LARGE_PAIR7_START            (MRAM_IP_LARGE_PAIR6_END + 1U)
#define MRAM_IP_LARGE_PAIR7_END              (MRAM_IP_LARGE_PAIR7_START + MRAM_IP_LARGE_PAIR_SIZE - 1U)

/* Pair 7 Lower and Upper partitions are interleaved in hardware on 32-byte boundaries */

/* Small Partitions - Data MRAM (4 small partitions) */

/* Overall Data MRAM region */
#define MRAM_IP_DATA_START                   0x0C800000U
/* Data MRAM total size: 256KB (0x00040000) */
/* Data MRAM end address: DATA_START + DATA_SIZE - 1 */

/* Individual small partition size */
#define MRAM_IP_SMALL_PARTITION_SIZE         0x00010000U   /* 64KB */

/* Lower Bank Small Partitions */
#define MRAM_IP_SMALL_LOWER0_START           MRAM_IP_DATA_START
#define MRAM_IP_SMALL_LOWER0_END             (MRAM_IP_SMALL_LOWER0_START + MRAM_IP_SMALL_PARTITION_SIZE - 1U)

#define MRAM_IP_SMALL_LOWER1_START           (MRAM_IP_SMALL_LOWER0_END + 1U)
#define MRAM_IP_SMALL_LOWER1_END             (MRAM_IP_SMALL_LOWER1_START + MRAM_IP_SMALL_PARTITION_SIZE - 1U)

/* Upper Bank Small Partitions */
#define MRAM_IP_SMALL_UPPER0_START           (MRAM_IP_SMALL_LOWER1_END + 1U)
#define MRAM_IP_SMALL_UPPER0_END             (MRAM_IP_SMALL_UPPER0_START + MRAM_IP_SMALL_PARTITION_SIZE - 1U)

#define MRAM_IP_SMALL_UPPER1_START           (MRAM_IP_SMALL_UPPER0_END + 1U)
#define MRAM_IP_SMALL_UPPER1_END             (MRAM_IP_SMALL_UPPER1_START + MRAM_IP_SMALL_PARTITION_SIZE - 1U)

/* OTP Space */

/* OTP space from lower large partitions 4 to 7 */
#define MRAM_IP_OTP_LOWER_LARGE_START        0x0C404000U
#define MRAM_IP_OTP_LOWER_LARGE_END          0x0C407FFFU
/* OTP Lower Large size: 16 KB (0x00004000) */

/* OTP space from upper large partitions 0 to 7 */
#define MRAM_IP_OTP_UPPER_LARGE_START        0x0C408000U
#define MRAM_IP_OTP_UPPER_LARGE_END          0x0C40FFFFU
/* OTP Upper Large size: 32 KB (0x00008000) */

/* Total OTP Space */
/* Total OTP address range: 0x0C404000 to 0x0C40FFFF */
/* Total OTP size: 48 KB (0x0000C000) */

/* UTEST Space */
#define MRAM_IP_UTEST_START                  0x0C8FE000U
#define MRAM_IP_UTEST_END                    0x0C907FFFU
/* UTEST size: 40 KB (0x0000A000) */



/*==================================================================================================
*                                              ENUMS
==================================================================================================*/

/*==================================================================================================
*                                STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/

#if (STD_ON == MRAM_IP_PARTITION_SET_LOCK_API)
/**
 * Function Name    MRam_Ip_SetLock
 * Description      Locks the selected partition for the requesting core if possible
 *
 * @implements      MRam_Ip_SetLock_Activity
 */
MRam_Ip_StatusType MRam_Ip_SetLock(MRam_Ip_AddressType Address,
                                 uint8 DomainIdValue,
                                 MRam_Ip_InstanceIdType InstanceId
                                );
#endif

/**
 * Function Name    MRam_Ip_GetLock
 * Description      Returns the locking status of the selected partition
 *
 * @note            The prototype is intentionally kept outside the
 *                  MRAM_IP_PARTITION_SET_LOCK_API guard: the definition in
 *                  MRam_Ip.c is always compiled and is called internally by
 *                  MRam_Ip_ClearLock, so the prototype must always be visible
 *                  (otherwise IAR reports Pa045 no-prototype when the Set Lock
 *                  API is disabled). This mirrors MRam_Ip_ClearLock below.
 *
 * @implements      MRam_Ip_GetLock_Activity
 */
MRam_Ip_StatusType MRam_Ip_GetLock(MRam_Ip_AddressType Address, MRam_Ip_InstanceIdType InstanceId);

/**
 * Function Name    MRam_Ip_ClearLock
 * Description      Unlocks the selected partition for the requesting core if possible
 *
 * @implements      MRam_Ip_ClearLock_Activity
 */
MRam_Ip_StatusType MRam_Ip_ClearLock(MRam_Ip_AddressType Address,
                                     uint8 DomainIdValue,
                                     MRam_Ip_InstanceIdType InstanceId
                                     );

/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * @brief   Initialize the MRAMC and MRAM.
 * @details
 *
 * @param[in]  pConfig pointer to configuration
 *
 * @implements MRam_Ip_Init_Activity
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
void MRam_Ip_Init(MRam_Ip_ConfigType const * pConfig, MRam_Ip_InstanceIdType InstanceId);

/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * @brief   DeInitialize the MRAMC and MRAM.
 * @details
 *
 * @implements MRam_Ip_DeInit_Activity
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
void MRam_Ip_DeInit(MRam_Ip_InstanceIdType InstanceId);


/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * @brief   Write @p SizeInBytes bytes from @p pu8SrcAddress buffer to MRAM at @p DestAddress
 *
 * @param[out] DestAddress MRAM Address
 * @param[in]  pu8SrcAddress buffer containing the data to be written
 * @param[in]  SizeInBytes number of bytes to be written
 * @param[in]  InstanceId Hw ip instance id
 *
 * @implements MRam_Ip_Write_Activity
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
MRam_Ip_StatusType MRam_Ip_Write(MRam_Ip_AddressType DestAddress,
                                 const uint8 *SourceAddressPtr,
                                 MRam_Ip_LengthType SizeInBytes,
                                 MRam_Ip_InstanceIdType InstanceId);

/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * @brief   Write @p SizeInBytes bytes from @p pu8SrcAddress buffer to MRAM at @p DestAddress
 *
 * @param[out] DestAddress MRAM Address
 * @param[in]  pu8SrcAddress buffer containing the data to be written
 * @param[in]  SizeInBytes number of bytes to be written
 * @param[in]  InstanceId Hw ip instance id
 *
 * @implements MRam_Ip_Write_AXI_Activity
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
MRam_Ip_StatusType MRam_Ip_Write_AXI (MRam_Ip_AddressType DestAddress,
                        uint8 const * pu8SrcAddress,
                        MRam_Ip_LengthType SizeInBytes,
                        MRam_Ip_InstanceIdType InstanceId
                        );

/**
 * @brief      This function fills data to DestAddressPtr with data from the specified address
 *
 * @param[in] SrcAddress MRAM Sources physical address
 * @param[out]  DestAddressPtr buffer where the data will be written
 * @param[in]  SizeInBytes number of bytes to be read
 * @param[in]  InstanceId Hw ip instance id
 *
 * @implements      MRam_Ip_Read_Activity
 */
MRam_Ip_StatusType MRam_Ip_Read(MRam_Ip_AddressType SrcAddress,
                                uint8 *DestAddressPtr,
                                MRam_Ip_LengthType SizeInBytes,
                                MRam_Ip_InstanceIdType InstanceId
                                );

/**
 * @brief      Erase @p SizeInBytes bytes from @p DestAddress
 *
 * @param[in]  DestAddress buffer where the data will be written
 * @param[in]  SizeInBytes number of bytes to be read
 * @param[in]  InstanceId Hw ip instance id
 *
 * @implements      MRam_Ip_Erase_Activity
 */
MRam_Ip_StatusType MRam_Ip_Erase(MRam_Ip_AddressType DestAddress,
                                 MRam_Ip_LengthType SizeInBytes,
                                 MRam_Ip_InstanceIdType InstanceId
                                );

/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * @brief   Erase @p SizeInBytes bytes from @p DestAddress
 *
 * @param[in]  DestAddress buffer where the data will be written
 * @param[in]  SizeInBytes number of bytes to be read
 * @param[in]  InstanceId Hw ip instance id
 *
 * @implements MRam_Ip_Erase_AXI_Activity
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
MRam_Ip_StatusType MRam_Ip_Erase_AXI(MRam_Ip_AddressType DestAddress,
                       MRam_Ip_LengthType SizeInBytes,
                       MRam_Ip_InstanceIdType InstanceId);

/**
 * @brief   Process MRAM controller interrupts.
 * @details Processes MRAM controller interrupt by identifying active error conditions,
 *          notifying registered callbacks, and clearing interrupt flags. This function
 *          should be called from the interrupt service routine when an MRAM error
 *          interrupt is triggered.
 *
 * @param[in]  InstanceId  Hardware instance ID of the MRAM controller generating the interrupt
 *
 * @implements MRam_Ip_ProcessIrq_Activity
 */
void MRam_Ip_ProcessIrq(MRam_Ip_InstanceIdType InstanceId);

/**
 * @brief   Compare data between source buffer and MRAM memory
 * @details This function compares the contents of a source buffer with data in MRAM memory.
 *          It reads MRAM data in chunks and performs byte-by-byte comparison, with
 *          optimization for word-aligned addresses.
 *
 *          The comparison is done efficiently by:
 *          1. Reading MRAM data in chunks (up to 32 bytes at a time)
 *          2. Using word-by-word (4 bytes) comparison when addresses are aligned
 *          3. Falling back to byte-by-byte comparison otherwise
 *          4. Stopping at the first mismatch and reporting its exact location
 *
 *          Example:
 *          When comparing 100 bytes starting at MRAM address 0x08001000 with a RAM buffer:
 *          - The function will read 32 bytes at a time from MRAM
 *          - If both addresses are word-aligned, it compares 4 bytes at once (8x faster)
 *          - If a mismatch is found at offset 50, it returns with address 0x08001032
 *            (0x08001000 + 50 = 0x08001032)
 *
 * @param[in]  MRamSrcAddress    Address in MRAM memory to compare from
 * @param[in]  pu8SrcAddress     Pointer to source buffer to compare with
 * @param[in]  SizeInBytes       Number of bytes to compare
 * @param[in]  InstanceId        MRAM controller instance identifier
 *
 * @return     MRam_Ip_StatusType
 * @retval     MRAM_IP_STATUS_SUCCESS         Comparison successful, data matches
 * @retval     MRAM_IP_STATUS_COMPARE_MISMATCH Data does not match
 * @retval     MRAM_IP_STATUS_READ_ERROR      Failed to read from MRAM
 * @retval     MRAM_IP_STATUS_ERROR_INPUT_PARAM Invalid input parameters
 * @retval     Other error codes from MRam_Ip_Read
 *
 * @implements MRam_Ip_Compare_Activity
 */
MRam_Ip_StatusType MRam_Ip_Compare(MRam_Ip_AddressType MRamSrcAddress,
    uint8 const * pu8SrcAddress,
    MRam_Ip_LengthType SizeInBytes,
    MRam_Ip_InstanceIdType InstanceId);

/**
 * @brief      Performs an array integrity self-check on MRAM memory
 *
 * This function implements the 10-step array integrity self-check procedure as specified
 * in the hardware reference manual. It reads data from a selected memory partition
 * and calculates a Multiple Input Signature Register (MISR) value, which can be used
 * to verify memory integrity and detect incorrect reads or ECC events.
 *
 * The procedure follows these steps:
 * 1. Enter UTest mode
 * 2. Select the partition to check (by writing to RADR)
 * 3. Optionally enable sequential addressing (by setting AIS bit)
 * 4. Optionally seed MISR with initial values
 * 5. Optionally enable breakpoints for error detection
 * 6. Start the array-integrity check (by setting AIE bit)
 * 7. Wait for completion (until AID bit becomes 1)
 * 8. Process breakpoints if enabled and detected
 * 9. Read the resulting MISR values for verification
 * 10. End the array-integrity check (by clearing AIE bit)
 *
 * @param[in]  Address               First address of the partition to check
 * @param[in]  SequentialAddressing  TRUE to enable sequential addressing mode, FALSE for default addressing
 * @param[in]  ArrayValuesMISR       Pointer to array of initial MISR seed values (can be NULL)
 * @param[in]  ArrayLengthMISR       Length of the ArrayValuesMISR array (should be ≤ 10)
 * @param[in]  EnableBreakpoints     TRUE to enable breakpoints on ECC errors, FALSE to disable
 * @param[in]  InstanceId            Instance identifier for the MRAM module
 *
 * @return     MRam_Ip_ArrayIntegrityCheckType  Structure containing:
 *             - Error flags (FLAG_ERR, FLAG_TBC, FLAG_DBC, FLAG_SBC) if breakpoints were detected
 *             - Address (RADDR) where error occurred if applicable
 *             - MISR values for signature verification
 *
 * @note       This function requires proper system frequency configuration
 *             by setting appropriate RWSC and RWSL fields in the MCR register.
 *
 * @note       For UMISR9, only bit 0 is available in hardware.
 *
 * @implements MRam_Ip_UTestArrayIntegrityCheck_Activity
 */
MRam_Ip_ArrayIntegrityCheckType MRam_Ip_UTestArrayIntegrityCheck(MRam_Ip_AddressType Address, boolean SequentialAddressing, const uint32 * ArrayValuesMISR, uint8 ArrayLengthMISR, boolean EnableBreakpoints, MRam_Ip_InstanceIdType InstanceId);

/**
 * @brief Performs ECC logic check on MRAM.
 *
 * This function follows the steps defined in the reference manual section 36.4.3.3.4:
 * 1. Enter UTest mode
 * 2. Enable the inversion of ECC data
 * 3. Provide data and check-bit values to read
 * 4. Specify the page address to receive data
 * 5. Read the array
 * 6. Determine status of read operation
 * 7. Disable the inversion of ECC data
 *
 * ECC logic check allows you to simulate ECC errors by providing test data.
 * Based on the data provided, different types of errors can be generated:
 * - Single-bit correction
 * - Double-bit correction
 * - Triple-bit correction
 * - Four-bit detection
 *
 * @param[in]   Address       Memory address to test
 * @param[in]   DataValues    Array of data values to use for ECC test (UD0-UD8)
 * @param[in]   DataLength    Length of the data array (max 9)
 * @param[out]  Results       Pointer to structure to store results of the operation
 * @param[in]   InstanceId    Instance ID
 * @return      Operation status (MRAM_IP_STATUS_SUCCESS or error code)
 *
 * @implements MRam_Ip_UTestECCLogicCheck_Activity
 */
MRam_Ip_StatusType MRam_Ip_UTestECCLogicCheck(MRam_Ip_AddressType Address,
    const uint32 * DataValues,
    uint8 DataLength,
    MRam_Ip_ArrayIntegrityCheckType *Results,
    MRam_Ip_InstanceIdType InstanceId);

/**
 * @brief Performs EDC-after-ECC logic check on MRAM.
 *
 * This function follows the steps defined in the reference manual section 36.4.3.3.5:
 * 1. Enter UTest mode
 * 2. Enable the EDC-after-ECC data input
 * 3. Provide data and check-bit values to read
 * 4. Specify the page address to receive data
 * 5. Read the array
 * 6. Determine status of read operation
 * 7. Disable the EDC-after-ECC data input
 *
 * EDC-after-ECC logic check allows you to verify the EDC logic that protects
 * corrected data coming from the ECC logic. This test ensures that the
 * error detection system for the ECC correction logic itself is functioning.
 *
 * @param[in]   Address       Memory address to test
 * @param[in]   DataValues    Array of data values to use for EDC test (UD9-UD17)
 * @param[in]   DataLength    Length of the data array (max 9)
 * @param[out]  ResultEEE     Pointer to store the EEE flag result
 * @param[in]   InstanceId    Instance ID
 * @return      Operation status (MRAM_IP_STATUS_SUCCESS or error code)
 *
 * @implements MRam_Ip_UTestEDCAfterECCLogicCheck_Activity
 */
MRam_Ip_StatusType MRam_Ip_UTestEDCAfterECCLogicCheck(MRam_Ip_AddressType Address,
                                                     const uint32 * DataValues,
                                                     uint8 DataLength,
                                                     boolean *ResultEEE,
                                                     MRam_Ip_InstanceIdType InstanceId);

/**
 * @brief Performs Address-encode logic check on MRAM.
 *
 * This function follows the steps defined in the reference manual Table 133:
 * 1. Enter UTest mode
 * 2. Enable the inversion of the address-encode value
 * 3. Provide the address bit or bits to invert
 * 4. Provide the address bit or bits to invert to the MRAMC
 * 5. Specify the page address to receive the inverted address
 * 6. Read the array
 * 7. Determine the status of the read operation
 * 8. Disable the inversion of the address-encode value
 *
 * @param[in]   Address      Memory address to test
 * @param[in]   AeisValue    Value for UA0[AEIS] - Address-encode invert selector
 * @param[in]   AeiValue     Value for UA0[AEI] - Address-encode invert
 * @param[in]   AeicValue    Value for UA1[AEIC] - Address-encode invert complement
 * @param[in]   AeioValue    Value for UA1[AEIO] - Address-encode invert output
 * @param[out]  ResultAEE    Pointer to store the AEE flag result
 * @param[in]   InstanceId   Instance ID
 * @return      Operation status (MRAM_IP_STATUS_SUCCESS or error code)
 *
 * @implements MRam_Ip_UTestAddressEncodeLogicCheck_Activity
 */
MRam_Ip_StatusType MRam_Ip_UTestAddressEncodeLogicCheck(
    MRam_Ip_AddressType Address,
    uint32 AeisValue,
    uint32 AeiValue,
    uint32 AeicValue,
    uint32 AeioValue,
    boolean *ResultAEE,
    MRam_Ip_InstanceIdType InstanceId);

/**
 * @brief Performs Reference recovery and refresh operation on MRAM.
 *
 * This function follows the steps defined in the reference manual Table 134:
 * 1. Enter UTest mode
 * 2. Enable the operation
 * 3. Start the operation
 * 4. Allow time for F16ASM to complete the operation
 * 5. Disable the operation
 *
 * Reference recovery and refresh can recover MRAM references if a known
 * magnetic overexposure or an array detection corruption event occurs.
 * Reads and writes of the MRAM are not allowed during this operation.
 * This operation cannot be aborted or suspended.
 *
 * @param[in]   InstanceId   Instance ID
 * @return      Operation status (MRAM_IP_STATUS_SUCCESS or error code)
 *
 * @implements MRam_Ip_UTestReferenceRecoveryRefresh_Activity
 */
MRam_Ip_StatusType MRam_Ip_UTestReferenceRecoveryRefresh(MRam_Ip_InstanceIdType InstanceId);

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* MRAM_IP_H */

