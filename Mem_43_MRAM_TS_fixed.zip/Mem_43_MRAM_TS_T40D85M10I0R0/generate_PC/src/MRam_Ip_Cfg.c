
[!NOCODE!][!//
[!//////////////////////////////////////////////////////////////////////////////////////////////////
[!////////////////////////   VARIABLE DEFINE FOR EB TRESOS       ///////////////////////////////////

[!VAR "MemName"      = "'Mem_43_MRAM'"!][!//
[!VAR "MemNameUpper" = "text:toupper($MemName)"!][!//


[!//////////////////////////////////////////////////////////////////////////////////////////////////
[!///////////////////////    FUNCTION (MACRO) FOR EB TRESOS      ///////////////////////////////////

[!// Support line alignment with MACRO PrintAlign
[!VAR "CommentAlignment" = "60"!][!//
[!VAR "PaddingSpaces" = "'                                                                              '"!][!//
[!MACRO "PrintAlign", "Tabs" = "1", "Str" = "''", "Unit" = "''", "Cmt" = "''", "Comma" = "','"!][!//
    [!VAR "StrOut" = "''"!][!// Init the output string
    [!FOR "i" = "1" TO "$Tabs"!][!// Add tabs
        [!VAR "StrOut" = "concat($StrOut, '    ')"!][!//
    [!ENDFOR!][!//
    [!VAR "StrOut" = "concat($StrOut, $Str)"!][!//
    [!VAR "StrOut" = "concat($StrOut, $Unit)"!][!//
    [!VAR "StrOut" = "concat($StrOut, $Comma)"!][!//
    [!VAR "StrOut" = "concat($StrOut, $PaddingSpaces)"!][!// Padding spaces for alignment
    [!VAR "StrOut" = "substring($StrOut, 1, $CommentAlignment)"!][!// Perform the alignment
    [!VAR "StrOut" = "concat($StrOut, $Cmt)"!][!//
    [!CODE!][!"$StrOut"!][!CR!][!ENDCODE!][!// Print the output string
[!ENDMACRO!][!//
[!//

[!MACRO "GetNotif", "NotifId" = "''"!][!//
[!NOCODE!][!//
    [!VAR "Result" = "'NULL_PTR'"!][!//
    [!VAR "NodeNotif" = "concat('MemGeneral/', $NotifId)"!][!//

    [!IF "node:exists($NodeNotif)"!][!//
        [!VAR "Result" = "concat('&', node:value($NodeNotif))"!][!//
    [!ENDIF!][!//

    [!CODE!][!"$Result"!][!ENDCODE!][!// Print the output string
[!ENDNOCODE!][!//
[!ENDMACRO!][!//

[!//////////////////////////////////////////////////////////////////////////////////////////////////
[!ENDNOCODE!][!//
[!AUTOSPACING!][!//
/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : MRAM
*   Dependencies         : None
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
*   Copyright 2024 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
 * @file       MRam_Ip_Cfg.c
 *
 * @addtogroup MRam_IP
 * implement   MRam_Ip_Cfg.c_Artifact
 *
 * @{
 */

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "MRam_Ip_Cfg.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define MRAM_IP_VENDOR_ID_CFG_C                          43
#define MRAM_IP_AR_RELEASE_MAJOR_VERSION_CFG_C           4
#define MRAM_IP_AR_RELEASE_MINOR_VERSION_CFG_C           9
#define MRAM_IP_AR_RELEASE_REVISION_VERSION_CFG_C        0
#define MRAM_IP_SW_MAJOR_VERSION_CFG_C                   1
#define MRAM_IP_SW_MINOR_VERSION_CFG_C                   0
#define MRAM_IP_SW_PATCH_VERSION_CFG_C                   0

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if current file and MRam_Ip_Cfg.h header file are of the same vendor */
#if (MRAM_IP_VENDOR_ID_CFG_C != MRAM_IP_VENDOR_ID_CFG)
    #error "MRam_Ip_Cfg.c and MRam_Ip_Cfg.h have different vendor ids"
#endif
/* Check if current file and MRam_Ip_Cfg.h header file are of the same Autosar version */
#if ((MRAM_IP_AR_RELEASE_MAJOR_VERSION_CFG_C    != MRAM_IP_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (MRAM_IP_AR_RELEASE_MINOR_VERSION_CFG_C    != MRAM_IP_AR_RELEASE_MINOR_VERSION_CFG) || \
     (MRAM_IP_AR_RELEASE_REVISION_VERSION_CFG_C != MRAM_IP_AR_RELEASE_REVISION_VERSION_CFG) \
    )
    #error "AutoSar Version Numbers of MRam_Ip_Cfg.c and MRam_Ip_Cfg.h are different"
#endif
/* Check if current file and MRam_Ip_Cfg.h header file are of the same Software version */
#if ((MRAM_IP_SW_MAJOR_VERSION_CFG_C != MRAM_IP_SW_MAJOR_VERSION_CFG) || \
     (MRAM_IP_SW_MINOR_VERSION_CFG_C != MRAM_IP_SW_MINOR_VERSION_CFG) || \
     (MRAM_IP_SW_PATCH_VERSION_CFG_C != MRAM_IP_SW_PATCH_VERSION_CFG) \
    )
    #error "Software Version Numbers of MRam_Ip_Cfg.c and MRam_Ip_Cfg.h are different"
#endif

/*==================================================================================================
                                     FUNCTION PROTOTYPES
==================================================================================================*/
[!SELECT "MRamGeneral/MRAMControllerCfg"!][!//
    [!IF "node:exists(./InterruptsConfig)"!][!//
#define MEM_43_MRAM_START_SEC_CODE
#include "Mem_43_MRAM_MemMap.h"
[!IF "node:exists(./InterruptsConfig/InterruptErrorCallback)"!] extern void [!"normalize-space(text:join(./InterruptsConfig/InterruptErrorCallback))"!](MRam_Ip_InstanceIdType InstanceId, MRam_Ip_InterruptConfigType ErrorStatus, MRam_Ip_AddressType MemoryErrorAddress); /* InterruptErrorCallback */ [!ENDIF!][!CR!][!//
#define MEM_43_MRAM_STOP_SEC_CODE
#include "Mem_43_MRAM_MemMap.h"
    [!ENDIF!][!//
[!ENDSELECT!][!//
/*==================================================================================================
                                           CONSTANTS
==================================================================================================*/
#define MEM_43_MRAM_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Mem_43_MRAM_MemMap.h"
[!NOCODE!]
[!VAR "PortCnt" = "0"!]
[!SELECT "MRamGeneral/MRAMControllerCfg/PortConfigurationList/*"!][!//
    [!VAR "PortCnt" = "$PortCnt + 1"!]
[!ENDSELECT!]
[!ENDNOCODE!]
static const MRam_Ip_PortConfigType PortConfig[[!"num:i($PortCnt)"!]u] =
{
[!SELECT "MRamGeneral/MRAMControllerCfg/PortConfigurationList/*"!][!//
    /*Configuration of [!"node:name(.)"!]*/
    {
        [!"./PortID"!], /*PortID*/
        (boolean)[!"text:toupper(InvalidateBuffer)"!], /*InvalidateBuffer*/
        (boolean)[!"text:toupper(ReadCodeBuffersEnable)"!], /*ReadCodeBuffersEnable*/
        (boolean)[!"text:toupper(ReadDataBuffersEnable)"!], /*ReadDataBuffersEnable*/
        (boolean)[!"text:toupper(ReadCodePrefetchEnable)"!], /*ReadCodePrefetchEnable*/
        (boolean)[!"text:toupper(ReadDataPrefetchEnable)"!], /*ReadDataPrefetchEnable*/
        (boolean)[!"text:toupper(WriteBufferEnable)"!], /*WriteBufferEnable*/
[!SELECT "node:order(./PortReadIDAssignment/*, 'WordIndex')"!][!//
        /*Configuration of [!"node:name(.)"!]*/
        {
            (boolean)[!"text:toupper(Enable)"!], /*Enable*/
            [!"BufferEntries"!]u, /*BufferEntries*/
            [!WS "12"!][!IF "node:exists(MaskDomainID)"!][!"MaskDomainID"!][!ELSE!]0[!ENDIF!]u /*MaskDomainID*/
        },
[!ENDSELECT!][!//
[!IF "count(./PortReadIDAssignment/*) = 1"!][!//
        /* Dummy configuration for single port read ID assignment */
        {
            (boolean)FALSE, /*Enable*/
            0u, /*BufferEntries*/
            0u /*MaskDomainID*/
        },
[!ENDIF!][!//
    },
[!ENDSELECT!][!//
};

/* Array to store error callback function pointers */
const MRam_Ip_ErrorCallbackType MRam_Ip_ErrorCallbacks =
{
[!SELECT "MRamGeneral/MRAMControllerCfg"!][!//
    [!IF "node:exists(./InterruptsConfig)"!][!//
        [!WS "4"!][!IF "node:exists(./InterruptsConfig/InterruptErrorCallback)"!] &[!"normalize-space(text:join(./InterruptsConfig/InterruptErrorCallback))"!] /* InterruptErrorCallback */[!CR!][!ELSE!] NULL_PTR[!ENDIF!][!//
    [!ELSE!][!//
    NULL_PTR, /* Default error callback if not configured */
    [!ENDIF!][!//
[!ENDSELECT!][!//
};

const MRam_Ip_ConfigType MRam_Ip_InitCfg =
{
    /*MRAMC START*/
    {
        /*Configuration of ports*/
        &PortConfig[0u],
        /*Total number of ports*/
        [!"num:i($PortCnt)"!]u,
        /*LargePartitionLock:*/
        {
[!SELECT "MRamGeneral/MRAMControllerCfg/LargePartitionLock"!][!//
            (boolean)[!"text:toupper(LCK0)"!], /*LCK0*/
            [!"./PLCK0"!]u, /*PLCK0*/
            (boolean)[!"text:toupper(LCK1)"!], /*LCK1*/
            [!"./PLCK1"!]u, /*PLCK1*/
            (boolean)[!"text:toupper(LCK2)"!], /*LCK2*/
            [!"./PLCK2"!]u, /*PLCK2*/
            (boolean)[!"text:toupper(LCK3)"!], /*LCK3*/
            [!"./PLCK3"!]u, /*PLCK3*/
            (boolean)[!"text:toupper(LCK4)"!], /*LCK4*/
            [!"./PLCK4"!]u, /*PLCK4*/
            (boolean)[!"text:toupper(LCK5)"!], /*LCK5*/
            [!"./PLCK5"!]u, /*PLCK5*/
            (boolean)[!"text:toupper(LCK6)"!], /*LCK6*/
            [!"./PLCK6"!]u, /*PLCK6*/
            (boolean)[!"text:toupper(LCK7)"!], /*LCK7*/
            [!"./PLCK7"!]u /*PLCK7*/
[!ENDSELECT!][!//
        },
        /*SmallPartitionLock:*/
        {
[!SELECT "MRamGeneral/MRAMControllerCfg/SmallPartitionLock"!][!//
            (boolean)[!"text:toupper(LCK)"!], /*LCK*/
            [!"./PLCK"!]u /*PLCK*/
[!ENDSELECT!][!//
        },
        /*LargePartitionOTPLock:*/
        {
[!SELECT "MRamGeneral/MRAMControllerCfg/LargePartitionOTPLock"!][!//
            (boolean)[!"text:toupper(LCK)"!], /*LCK*/
            [!"./PLCK"!]u /*PLCK*/
[!ENDSELECT!][!//
        },
        /*WatchdogConfig:*/
        {
[!IF "node:exists(MRamGeneral/MRAMControllerCfg/WatchdogConfig)"!][!//
    [!SELECT "MRamGeneral/MRAMControllerCfg/WatchdogConfig"!][!//
        [!"text:toupper(WatchdogTune)"!],
        (boolean)TRUE
    [!ENDSELECT!][!//
[!ELSE!][!//
        MRAM_IP_WATCHDOG_40000_CLOCKS,
        (boolean)FALSE
[!ENDIF!][!//
        },
[!IF "node:exists(MRamGeneral/MRAMControllerCfg/InterruptsConfig)"!][!//
        (boolean)TRUE, /*Interrupts enabled*/
[!ELSE!][!//
        (boolean)FALSE, /*Interrupts disabled*/
[!ENDIF!][!//
[!IF "node:value(MRamGeneral/MRAMControllerCfg/MRamDataErrorSuppress) = 'true'"!][!//
        (boolean)TRUE /*Data error supperss enabled*/
[!ELSE!][!//
        (boolean)FALSE /*Data error supperss disabled*/
[!ENDIF!][!//
    },
    /*MRAMC END*/
    /*MRAM START*/
    {
[!SELECT "MRamGeneral/MRAMCfg"!][!//
        (boolean)[!"text:toupper(CorrectionVisibilityEnable)"!], /*CorrectionVisibilityEnable*/
        (boolean)[!"text:toupper(WriteWithPowerLeveling)"!], /*WriteWithPowerLeveling*/
        [!"./ReadWaitStateControl"!]u /*ReadWaitStateControl*/
[!ENDSELECT!][!//
    }
};

#define MEM_43_MRAM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Mem_43_MRAM_MemMap.h"


#ifdef __cplusplus
}
#endif

/** @} */

