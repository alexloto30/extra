[!NOCODE!][!//
[!//////////////////////////////////////////////////////////////////////////////////////////////////
[!////////////////////////   VARIABLE DEFINE FOR EB TRESOS       ///////////////////////////////////

[!VAR "IpName" = "'MRam'"!][!//
[!VAR "IpNameUpper" = "text:toupper($IpName)"!][!//

[!//////////////////////////////////////////////////////////////////////////////////////////////////
[!///////////////////////    FUNCTION (MACRO) FOR EB TRESOS      ///////////////////////////////////

[!// Support line alignment with MACRO MacroPrintAlign
[!VAR "CommentAlignment" = "59"!][!//
[!VAR "PaddingSpaces" = "'                                                                                '"!][!// 80 blank characters

[!MACRO "MacroPrintAlign", "Tabs" = "1", "Str" = "''", "Unit" = "''", "Cmt" = "''", "Comma" = "','"!][!//
[!NOCODE!][!//
    [!VAR "StrOut" = "''"!][!// Init the output string

    [!FOR "i" = "1" TO "$Tabs"!][!// Add tabs
        [!VAR "StrOut" = "concat($StrOut, '    ')"!][!//
    [!ENDFOR!][!//

    [!VAR "StrOut" = "concat($StrOut, $Str)"!][!//
    [!VAR "StrOut" = "concat($StrOut, $Unit)"!][!//
    [!VAR "StrOut" = "concat($StrOut, $Comma)"!][!//

    [!IF "string-length($StrOut) < $CommentAlignment"!][!//
        [!VAR "StrOut" = "concat($StrOut, $PaddingSpaces)"!][!//          Padding spaces for alignment
        [!VAR "StrOut" = "substring($StrOut, 1, $CommentAlignment)"!][!// Perform the alignment
    [!ENDIF!][!//

    [!VAR "StrOut" = "concat($StrOut, $Cmt)"!][!//

    [!CODE!][!"$StrOut"!][!CR!][!ENDCODE!][!// Print the output string

[!ENDNOCODE!][!//
[!ENDMACRO!][!// MacroPrintAlign
[!//
[!// CALCULATE CRC FUNCTION
[!//
[!MACRO "MacroCrcCalculate","CrcData32"!][!//
[!NOCODE!][!//
    [!IF "65535 < $CrcData32"!][!//
        [!VAR "VarCrcReminder" = "bit:or(bit:shl($VarCrcReminder,16),bit:shr($CrcData32,16))"!][!//
        [!CALL "MacroCrcCalcRemainder16bit"!][!//
    [!ENDIF!][!//

    [!IF "255 < $CrcData32"!][!//
        [!VAR "VarCrcReminder" = "bit:or(bit:shl($VarCrcReminder,16),bit:and($CrcData32,65535))"!][!//
        [!CALL "MacroCrcCalcRemainder16bit"!][!//
    [!ELSE!][!//
        [!VAR "VarCrcReminder" = "bit:or(bit:shl($VarCrcReminder,8),bit:and($CrcData32,255))"!][!//
        [!CALL "MacroCrcCalcRemainder8bit"!][!//
    [!ENDIF!][!//
[!ENDNOCODE!][!//
[!ENDMACRO!][!// MacroCrcCalculate

[!MACRO "MacroMemCrcFinish"!][!//
[!NOCODE!][!//
    [!VAR "VarCrcReminder" = "bit:shl($VarCrcReminder,16)"!][!//
    [!CALL "MacroCrcCalcRemainder16bit"!][!//
[!ENDNOCODE!][!//
[!ENDMACRO!][!// MacroMemCrcFinish

[!MACRO "MacroCrcCalcRemainder8bit"!][!//
[!NOCODE!][!//
    [!VAR "Rem8CrcPolynomSft" = "8917120"!][!// 0x881080
    [!VAR "Rem8LeadingOne" = "8388608"!][!// 0x800000
    [!FOR "Rem8Counter"="23" TO "16" STEP "-1"!][!//
        [!IF "bit:and($Rem8LeadingOne,$VarCrcReminder) = $Rem8LeadingOne"!][!//
            [!VAR "VarCrcReminder"="bit:xor($VarCrcReminder,$Rem8CrcPolynomSft)"!][!//
        [!ENDIF!][!//
        [!VAR "Rem8CrcPolynomSft"="bit:shr($Rem8CrcPolynomSft,1)"!][!//
        [!VAR "Rem8LeadingOne"="bit:shr($Rem8LeadingOne,1)"!][!//
    [!ENDFOR!][!//
[!ENDNOCODE!][!//
[!ENDMACRO!][!// MacroCrcCalcRemainder8bit

[!MACRO "MacroCrcCalcRemainder16bit"!][!//
[!NOCODE!][!//
    [!VAR "Rem16CrcPolynomSft" = "2282782720"!][!// 0x88108000
    [!VAR "Rem16LeadingOne" = "2147483648"!][!// 0x80000000
    [!FOR "Rem16Counter"="31" TO "16" STEP "-1"!][!//
        [!IF "bit:and($Rem16LeadingOne,$VarCrcReminder) = $Rem16LeadingOne"!][!//
            [!VAR "VarCrcReminder"="bit:xor($VarCrcReminder,$Rem16CrcPolynomSft)"!][!//
        [!ENDIF!][!//
        [!VAR "Rem16CrcPolynomSft"="bit:shr($Rem16CrcPolynomSft,1)"!][!//
        [!VAR "Rem16LeadingOne"="bit:shr($Rem16LeadingOne,1)"!][!//
    [!ENDFOR!][!//
[!ENDNOCODE!][!//
[!ENDMACRO!][!// MacroCrcCalcRemainder16bit

[!MACRO "MacroMemCrcCalculate"!][!//
[!NOCODE!][!//
    [!VAR "VarCrcReminder" = "0"!][!// Reset CRC reminder

    [!LOOP "MemInstance/*"!][!//
        [!CALL "MacroCrcCalculate","CrcData32"="./MemInstanceId"!][!//
        [!CALL "MacroCrcCalculate","CrcData32"="num:i(count(./MemSectorBatch/*))"!][!//
        [!LOOP "./MemSectorBatch/*"!][!//
            [!CALL "MacroCrcCalculate","CrcData32"="./MemStartAddress"!][!//
            [!CALL "MacroCrcCalculate","CrcData32"="num:i(./MemStartAddress + ./MemNumberOfSectors * ./MemEraseSectorSize - 1)"!][!//
            [!CALL "MacroCrcCalculate","CrcData32"="./MemEraseSectorSize"!][!//
            [!CALL "MacroCrcCalculate","CrcData32"="./MemMinReadSize"!][!//
            [!CALL "MacroCrcCalculate","CrcData32"="./MemWritePageSize"!][!//
            [!CALL "MacroCrcCalculate","CrcData32"="node:when(node:exists(./MemBurstSettings), ./MemBurstSettings/MemEraseBurstSize, ./MemEraseSectorSize)"!][!//
            [!CALL "MacroCrcCalculate","CrcData32"="node:when(node:exists(./MemBurstSettings), ./MemBurstSettings/MemMaxReadSize,  ./MemMinReadSize)"!][!//
            [!CALL "MacroCrcCalculate","CrcData32"="node:when(node:exists(./MemBurstSettings), ./MemBurstSettings/MemWriteBurstSize, ./MemWritePageSize)"!][!//
        [!ENDLOOP!][!//
        [!VAR "MemUnitIndex"       = "0"!][!//
        [!CALL "MacroCrcCalculate","CrcData32"="$MemUnitIndex"!][!//
    [!ENDLOOP!][!//
[!ENDNOCODE!][!//
[!ENDMACRO!][!// MacroMemCrcCalculate
[!//////////////////////////////////////////////////////////////////////////////////////////////////
[!ENDNOCODE!][!//
[!AUTOSPACING!][!//
/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : MRAM
*   Dependencies         : None
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
*   Copyright 2024 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/


/**
 * @file        Mem_43_MRAM_Cfg.c
 *
 * @addtogroup  MEM_43_MRAM
 * implement    Mem_43_MRAM_Cfg.c_Artifact
 *
 * @{
 */

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Mem_43_MRAM_Cfg.h"
#include "[!"$IpName"!]_Ip_Cfg.h"

/*==================================================================================================
                               SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define MEM_43_MRAM_VENDOR_ID_CFG_C                          43
#define MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_CFG_C           4
#define MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_CFG_C           9
#define MEM_43_MRAM_AR_RELEASE_REVISION_VERSION_CFG_C        0
#define MEM_43_MRAM_SW_MAJOR_VERSION_CFG_C                   1
#define MEM_43_MRAM_SW_MINOR_VERSION_CFG_C                   0
#define MEM_43_MRAM_SW_PATCH_VERSION_CFG_C                   0

/*==================================================================================================
                                      FILE VERSION CHECKS
==================================================================================================*/

/* Check if current file and Mem_43_MRAM_Cfg.h header file are of the same vendor */
#if (MEM_43_MRAM_VENDOR_ID_CFG_C != MEM_43_MRAM_VENDOR_ID_CFG)
    #error "Mem_43_MRAM_Cfg.c and Mem_43_MRAM_Cfg.h have different vendor ids"
#endif
/* Check if current file and Mem_43_MRAM_Cfg.h header file are of the same Autosar version */
#if ((MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_CFG_C    != MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_CFG_C    != MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_CFG) || \
     (MEM_43_MRAM_AR_RELEASE_REVISION_VERSION_CFG_C != MEM_43_MRAM_AR_RELEASE_REVISION_VERSION_CFG) \
    )
    #error "AutoSar Version Numbers of Mem_43_MRAM_Cfg.c and Mem_43_MRAM_Cfg.h are different"
#endif
/* Check if current file and Mem_43_MRAM_Cfg.h header file are of the same Software version */
#if ((MEM_43_MRAM_SW_MAJOR_VERSION_CFG_C != MEM_43_MRAM_SW_MAJOR_VERSION_CFG) || \
     (MEM_43_MRAM_SW_MINOR_VERSION_CFG_C != MEM_43_MRAM_SW_MINOR_VERSION_CFG) || \
     (MEM_43_MRAM_SW_PATCH_VERSION_CFG_C != MEM_43_MRAM_SW_PATCH_VERSION_CFG) \
    )
    #error "Software Version Numbers of Mem_43_MRAM_Cfg.c and Mem_43_MRAM_Cfg.h are different"
#endif

/* Check if current file and [!"$IpName"!]_Ip_Cfg.h header file are of the same vendor */
#if (MEM_43_MRAM_VENDOR_ID_CFG_C != [!"$IpNameUpper"!]_IP_VENDOR_ID_CFG)
    #error "Mem_43_MRAM_Cfg.c and [!"$IpName"!]_Ip_Cfg.h have different vendor ids"
#endif
/* Check if current file and [!"$IpName"!]_Ip_Cfg.h header file are of the same Autosar version */
#if ((MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_CFG_C    != [!"$IpNameUpper"!]_IP_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_CFG_C    != [!"$IpNameUpper"!]_IP_AR_RELEASE_MINOR_VERSION_CFG) || \
     (MEM_43_MRAM_AR_RELEASE_REVISION_VERSION_CFG_C != [!"$IpNameUpper"!]_IP_AR_RELEASE_REVISION_VERSION_CFG) \
    )
    #error "AutoSar Version Numbers of Mem_43_MRAM_Cfg.c and [!"$IpName"!]_Ip_Cfg.h are different"
#endif
/* Check if current file and [!"$IpName"!]_Ip_Cfg.h header file are of the same Software version */
#if ((MEM_43_MRAM_SW_MAJOR_VERSION_CFG_C != [!"$IpNameUpper"!]_IP_SW_MAJOR_VERSION_CFG) || \
     (MEM_43_MRAM_SW_MINOR_VERSION_CFG_C != [!"$IpNameUpper"!]_IP_SW_MINOR_VERSION_CFG) || \
     (MEM_43_MRAM_SW_PATCH_VERSION_CFG_C != [!"$IpNameUpper"!]_IP_SW_PATCH_VERSION_CFG) \
    )
    #error "Software Version Numbers of Mem_43_MRAM_Cfg.c and [!"$IpName"!]_Ip_Cfg.h are different"
#endif

/*==================================================================================================
                                     FUNCTION PROTOTYPES
==================================================================================================*/
/*==================================================================================================
                                           CONSTANTS
==================================================================================================*/
/*==================================================================================================
                                 GLOBAL CONSTANT DECLARATIONS
==================================================================================================*/

#define MEM_43_MRAM_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Mem_43_MRAM_MemMap.h"

/* Mem Internal Units Configurations */
static const Mem_43_MRAM_InternalUnitType Mem_43_MRAM_InternalUnitsCfg[MEM_43_MRAM_INTERNAL_UNIT_COUNT] =
{
    {
        [!CALL "MacroPrintAlign", "Tabs"="2", "Str"="concat('&', $IpName, '_Ip_InitCfg')", "Cmt"="'/* InternalConfig */'", "Comma" = " '' "!]
    }
};

/* Mem Devices Configurations */
static const Mem_43_MRAM_MemDeviceType Mem_43_MRAM_MemDevices =
{
    [!CALL "MacroPrintAlign", "Str"="'Mem_43_MRAM_InternalUnitsCfg'", "Cmt"="'/* InternalUnits */'", "Comma" = " '' "!]
};


[!LOOP "MemInstance/*"!]
/* Configuration of MemSectorBatch for [!"node:name(.)"!] */
const Mem_43_MRAM_SectorBatchType Mem_43_MRAM_[!"node:name(.)"!]_SectorBatch[[!"num:i(count(./MemSectorBatch/*))"!]U] =
{
    [!VAR "LoopIt" = "count(./MemSectorBatch/*)"!]
    [!LOOP "./MemSectorBatch/*"!]
    [!VAR "LoopIt"            = "$LoopIt - 1"!]
    [!VAR "StartAddress"      = "./MemStartAddress"!]
    [!VAR "EndAddress"        = "num:i(./MemStartAddress + ./MemNumberOfSectors * ./MemEraseSectorSize - 1)"!]
    [!VAR "SectorSize"        = "./MemEraseSectorSize"!]
    [!VAR "ReadPageSize"      = "./MemMinReadSize"!]
    [!VAR "WritePageSize"     = "./MemWritePageSize"!]
    [!VAR "EraseBurstSize"    = "node:when(node:exists(./MemBurstSettings), ./MemBurstSettings/MemEraseBurstSize, ./MemEraseSectorSize)"!]
    [!VAR "ReadBurstSize"     = "node:when(node:exists(./MemBurstSettings), ./MemBurstSettings/MemMaxReadSize,  ./MemMinReadSize)"!]
    [!VAR "WriteBurstSize"    = "node:when(node:exists(./MemBurstSettings), ./MemBurstSettings/MemWriteBurstSize, ./MemWritePageSize)"!]
    {
        /* [!"node:name(.)"!] */
        [!CALL "MacroPrintAlign", "Tabs"="2", "Str"="$StartAddress",   "Unit"="'U'", "Cmt"="'/* StartAddress   */'  "!]
        [!CALL "MacroPrintAlign", "Tabs"="2", "Str"="$EndAddress",     "Unit"="'U'", "Cmt"="'/* EndAddress     */'  "!]
        [!CALL "MacroPrintAlign", "Tabs"="2", "Str"="$SectorSize",     "Unit"="'U'", "Cmt"="'/* SectorSize     */'  "!]
        [!CALL "MacroPrintAlign", "Tabs"="2", "Str"="$ReadPageSize",   "Unit"="'U'", "Cmt"="'/* ReadPageSize   */'  "!]
        [!CALL "MacroPrintAlign", "Tabs"="2", "Str"="$WritePageSize",  "Unit"="'U'", "Cmt"="'/* WritePageSize  */'  "!]
        [!CALL "MacroPrintAlign", "Tabs"="2", "Str"="$EraseBurstSize", "Unit"="'U'", "Cmt"="'/* EraseBurstSize */'  "!]
        [!CALL "MacroPrintAlign", "Tabs"="2", "Str"="$ReadBurstSize",  "Unit"="'U'", "Cmt"="'/* ReadBurstSize  */'  "!]
        [!CALL "MacroPrintAlign", "Tabs"="2", "Str"="$WriteBurstSize", "Unit"="'U'", "Cmt"="'/* WriteBurstSize */'  ", "Comma" = "''"!]
    }[!IF "$LoopIt != 0"!],[!ENDIF!][!CR!][!//
    [!ENDLOOP!]
};

[!ENDLOOP!][!//

/* Configuration of Mem Instances */
static const Mem_43_MRAM_MemInstanceType Mem_43_MRAM_MemInstances[MEM_43_MRAM_INSTANCE_COUNT] =
{
[!VAR "LoopIt" = "count(MemInstance/*)"!]
[!LOOP "MemInstance/*"!][!// Iterate through the index value
    [!VAR "LoopIt"             = "$LoopIt - 1"!]
    [!VAR "InstanceId"         = "concat('MEM_43_MRAM_INSTANCE_', node:pos(.), '_ID')"!]
    [!VAR "SectorBatchCount"   = "num:i(count(./MemSectorBatch/*))"!]
    [!VAR "SectorBatch"        = "concat('Mem_43_MRAM_', node:name(.), '_SectorBatch')"!]
    [!VAR "MemUnitIndex"       = "num:i(0)"!]
    {
        /* [!"node:name(.)"!] */
        [!CALL "MacroPrintAlign", "Tabs"="2", "Str"="$InstanceId",       "Unit"="''",  "Cmt"="'/* InstanceId       */'  "!]
        [!CALL "MacroPrintAlign", "Tabs"="2", "Str"="$SectorBatchCount", "Unit"="'U'", "Cmt"="'/* SectorBatchCount */'  "!]
        [!CALL "MacroPrintAlign", "Tabs"="2", "Str"="$SectorBatch",      "Unit"="''",  "Cmt"="'/* SectorBatches    */'  "!]
        [!CALL "MacroPrintAlign", "Tabs"="2", "Str"="$MemUnitIndex",     "Unit"="'U'", "Cmt"="'/* MemUnitIndex     */'  ", "Comma" = "''"!]
    }[!IF "$LoopIt != 0"!],[!ENDIF!][!CR!][!//
[!ENDLOOP!][!//
};


/* Configuration of Mem_43_MRAM */
const Mem_43_MRAM_ConfigType Mem_43_MRAM_Config =
{
    [!CALL "MacroPrintAlign", "Str"="'Mem_43_MRAM_MemInstances'",            "Cmt"="'/* MemInstances  */'  "!]
    [!CALL "MacroPrintAlign", "Str"="concat('&', 'Mem_43_MRAM_MemDevices')", "Cmt"="'/* MemDevices    */'"!]
#if (STD_ON == MEM_43_MRAM_CHECK_CFG_CRC)
    [!CALL "MacroMemCrcCalculate"!][!//
    [!CALL "MacroMemCrcFinish"!][!//
    [!CALL "MacroPrintAlign", "Str"="concat($VarCrcReminder, 'U')",           "Cmt"="'/* u16ConfigCrc  */'", "Comma" = " '' "!]
#endif
};


#define MEM_43_MRAM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Mem_43_MRAM_MemMap.h"


#ifdef __cplusplus
}
#endif

/** @} */

