[!NOCODE!][!//
[!//////////////////////////////////////////////////////////////////////////////////////////////////
[!////////////////////////   VARIABLE DEFINE FOR EB TRESOS       ///////////////////////////////////


[!//////////////////////////////////////////////////////////////////////////////////////////////////
[!///////////////////////    FUNCTION (MACRO) FOR EB TRESOS      ///////////////////////////////////


[!//////////////////////////////////////////////////////////////////////////////////////////////////
[!ENDNOCODE!][!//
[!AUTOSPACING!][!//
/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : MRAM
*   Dependencies         : None
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
*   Copyright 2024 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef MEM_43_MRAM_CFG_H
#define MEM_43_MRAM_CFG_H

/**
 * @file        Mem_43_MRAM_Cfg.h
 *
 * @addtogroup  MEM_43_MRAM Driver
 * implement    Mem_43_MRAM_Cfg.h_Artifact
 *
 * @{
 */

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Mem_43_MRAM_Types.h"

/*==================================================================================================
                               SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define MEM_43_MRAM_VENDOR_ID_CFG                           43
#define MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_CFG            4
#define MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_CFG            9
#define MEM_43_MRAM_AR_RELEASE_REVISION_VERSION_CFG         0
#define MEM_43_MRAM_SW_MAJOR_VERSION_CFG                    1
#define MEM_43_MRAM_SW_MINOR_VERSION_CFG                    0
#define MEM_43_MRAM_SW_PATCH_VERSION_CFG                    0

/*==================================================================================================
                                      FILE VERSION CHECKS
==================================================================================================*/

/* Check if current file and Mem_43_MRAM_Types.h header file are of the same vendor */
#if (MEM_43_MRAM_VENDOR_ID_CFG != MEM_43_MRAM_TYPES_VENDOR_ID)
    #error "Mem_43_MRAM_Cfg.h and Mem_43_MRAM_Types.h have different vendor ids"
#endif
/* Check if current file and Mem_43_MRAM_Types.h header file are of the same Autosar version */
#if ((MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_CFG    != MEM_43_MRAM_TYPES_AR_RELEASE_MAJOR_VERSION) || \
     (MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_CFG    != MEM_43_MRAM_TYPES_AR_RELEASE_MINOR_VERSION) || \
     (MEM_43_MRAM_AR_RELEASE_REVISION_VERSION_CFG != MEM_43_MRAM_TYPES_AR_RELEASE_REVISION_VERSION) \
    )
    #error "AutoSar Version Numbers of Mem_43_MRAM_Cfg.h and Mem_43_MRAM_Types.h are different"
#endif
/* Check if current file and Mem_43_MRAM_Types.h header file are of the same Software version */
#if ((MEM_43_MRAM_SW_MAJOR_VERSION_CFG != MEM_43_MRAM_TYPES_SW_MAJOR_VERSION) || \
     (MEM_43_MRAM_SW_MINOR_VERSION_CFG != MEM_43_MRAM_TYPES_SW_MINOR_VERSION) || \
     (MEM_43_MRAM_SW_PATCH_VERSION_CFG != MEM_43_MRAM_TYPES_SW_PATCH_VERSION) \
    )
    #error "Software Version Numbers of Mem_43_MRAM_Cfg.h and Mem_43_MRAM_Types.h are different"
#endif

/*==================================================================================================
                                       DEFINES AND MACROS
==================================================================================================*/

/* Mem Instances ID */
[!LOOP "MemInstance/*"!][!//
#define MEM_43_MRAM_INSTANCE_[!"node:pos(.)"!]_ID            ([!"./MemInstanceId"!]U)
[!ENDLOOP!][!//

/* Pre-processor switch to enable and disable using of AXI interface from IP layer */
#define MEM_43_MRAM_USE_AXI_INTERFACE                        ([!IF "MemAutosarExt/MemUseAXIInterfaceEnabled"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])

/*==================================================================================================
                                 GLOBAL CONSTANT DECLARATIONS
==================================================================================================*/

#define MEM_43_MRAM_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Mem_43_MRAM_MemMap.h"


/* Configuration of Mem_43_MRAM */
extern const Mem_43_MRAM_ConfigType Mem_43_MRAM_Config;

/* Configuration of MemSectorBatch */
[!LOOP "MemInstance/*"!][!//
extern const Mem_43_MRAM_SectorBatchType Mem_43_MRAM_[!"node:name(.)"!]_SectorBatch[[!"num:i(count(./MemSectorBatch/*))"!]U];
[!ENDLOOP!][!//


#define MEM_43_MRAM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Mem_43_MRAM_MemMap.h"

/*==================================================================================================
                                     FUNCTION PROTOTYPES
==================================================================================================*/


#ifdef __cplusplus
}
#endif

/** @} */

#endif /* MEM_43_MRAM_CFG_H */

