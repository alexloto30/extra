
[!NOCODE!][!//
[!//////////////////////////////////////////////////////////////////////////////////////////////////
[!////////////////////////   VARIABLE DEFINE FOR EB TRESOS       ///////////////////////////////////

[!VAR "MemName"      = "'Mem_43_MRAM'"!][!//
[!VAR "MemNameUpper" = "text:toupper($MemName)"!][!//

[!VAR "Multicoresupport" = "'STD_OFF'"!][!//
[!IF "node:exists(as:modconf("MemAcc")[1]/AutosarExt/MemAccMulticoreType3Support)"!][!//
[!IF "as:modconf("MemAcc")[1]/AutosarExt/MemAccMulticoreType3Support"!][!//
    [!VAR "Multicoresupport" = "'STD_ON'"!][!//
[!ENDIF!][!//
[!ENDIF!][!//

[!//////////////////////////////////////////////////////////////////////////////////////////////////
[!ENDNOCODE!]
[!AUTOSPACING!]
/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : MRAM
*   Dependencies         : None
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
*   Copyright 2024 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef MRAM_IP_CFG_H
#define MRAM_IP_CFG_H

/**
 * @file       MRam_Ip_Cfg.h
 *
 * @addtogroup MRam_IP
 * implement   MRam_Ip_Cfg.h_Artifact
 *
 * @{
 */

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "OsIf.h"
#include "MRam_Ip_Types.h"

[!IF "MRamGeneral/MRamDevErrorDetect"!]
#include "Devassert.h"
[!ENDIF!][!//

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define MRAM_IP_VENDOR_ID_CFG                          43
#define MRAM_IP_AR_RELEASE_MAJOR_VERSION_CFG           4
#define MRAM_IP_AR_RELEASE_MINOR_VERSION_CFG           9
#define MRAM_IP_AR_RELEASE_REVISION_VERSION_CFG        0
#define MRAM_IP_SW_MAJOR_VERSION_CFG                   1
#define MRAM_IP_SW_MINOR_VERSION_CFG                   0
#define MRAM_IP_SW_PATCH_VERSION_CFG                   0

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and OsIf.h header file are of the same Autosar version */
    #if ((MRAM_IP_AR_RELEASE_MAJOR_VERSION_CFG != OSIF_AR_RELEASE_MAJOR_VERSION) || \
         (MRAM_IP_AR_RELEASE_MINOR_VERSION_CFG != OSIF_AR_RELEASE_MINOR_VERSION) \
        )
        #error "AutoSar Version Numbers of MRam_Ip_Cfg.h and OsIf.h are different"
    #endif
[!IF "MRamGeneral/MRamDevErrorDetect"!][!//
    /* Check if current file and Devassert.h header file are of the same Autosar version */
    #if ((MRAM_IP_AR_RELEASE_MAJOR_VERSION_CFG != DEVASSERT_AR_RELEASE_MAJOR_VERSION) || \
         (MRAM_IP_AR_RELEASE_MINOR_VERSION_CFG != DEVASSERT_AR_RELEASE_MINOR_VERSION) \
        )
        #error "AutoSar Version Numbers of MRam_Ip_Cfg.h and Devassert.h are different"
    #endif
[!ENDIF!][!//
#endif

/* Check if current file and MRAM_Ip_Types header file are of the same vendor */
#if (MRAM_IP_VENDOR_ID_CFG != MRAM_IP_TYPES_VENDOR_ID)
    #error "MRam_Ip_Cfg.h and MRam_Ip_Types.h have different vendor ids"
#endif
/* Check if current file and MRAM_Ip_Types header file are of the same Autosar version */
#if ((MRAM_IP_AR_RELEASE_MAJOR_VERSION_CFG    != MRAM_IP_TYPES_AR_RELEASE_MAJOR_VERSION) || \
     (MRAM_IP_AR_RELEASE_MINOR_VERSION_CFG    != MRAM_IP_TYPES_AR_RELEASE_MINOR_VERSION) || \
     (MRAM_IP_AR_RELEASE_REVISION_VERSION_CFG != MRAM_IP_TYPES_AR_RELEASE_REVISION_VERSION) \
    )
    #error "AutoSar Version Numbers of MRam_Ip_Cfg.h and MRam_Ip_Types.h are different"
#endif
/* Check if current file and MRAM_Ip_Types header file are of the same Software version */
#if ((MRAM_IP_SW_MAJOR_VERSION_CFG != MRAM_IP_TYPES_SW_MAJOR_VERSION) || \
     (MRAM_IP_SW_MINOR_VERSION_CFG != MRAM_IP_TYPES_SW_MINOR_VERSION) || \
     (MRAM_IP_SW_PATCH_VERSION_CFG != MRAM_IP_TYPES_SW_PATCH_VERSION) \
    )
    #error "Software Version Numbers of MRam_Ip_Cfg.h and MRam_Ip_Types.h are different"
#endif


/*==================================================================================================
                                       DEFINES AND MACROS
==================================================================================================*/
/* Get the current DomainID. */
[!IF "node:exists(as:modconf("Rm")[1]/RmGeneral/RmEnableXRDCSupport)"!]
[!IF "as:modconf("Rm")[1]/RmGeneral/RmEnableXRDCSupport"!]
#include "CDD_Rm.h"
#define MRAM_IP_DOMAIN_ID          (Rm_XrdcGetDomainID(0U))
[!ELSE!]
#define MRAM_IP_DOMAIN_ID          (0U)
[!ENDIF!]
[!ELSE!]
#define MRAM_IP_DOMAIN_ID          (0U)
[!ENDIF!]

/*! Development error detection */
#define MRAM_IP_DEV_ERROR_DETECT                ([!IF "MRamGeneral/MRamDevErrorDetect"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])

/*! Enable development error check */
#define MRAM_IP_DEV_ASSERT(x)                   [!WS "19"!][!IF "MRamGeneral/MRamDevErrorDetect"!]DevAssert((x))[!ENDIF!][!CR!]

#define MRAM_IP_PARTITION_SET_LOCK_API          ([!IF "MRamGeneral/MRamSetLockApi"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])

#define MRAM_IP_CACHE_INVALIDATION              ([!IF "MRamGeneral/MRamInvalidateCache"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])

[!NOCODE!][!//
[!VAR "DataInCodeMRam" = "'STD_OFF'"!][!//
[!IF "node:exists(MemAutosarExt/MemDataInCodeMRamEnabled)"!][!//
[!IF "MemAutosarExt/MemDataInCodeMRamEnabled"!][!//
    [!VAR "DataInCodeMRam" = "'STD_ON'"!][!//
[!ENDIF!][!//
[!ENDIF!][!//
[!IF "$DataInCodeMRam = 'STD_ON'"!][!//
[!/* The region is taken from the top of the active (lower) half of the Code MRAM large
     partition space: it ends at 0x08FFFFFF and starts at 0x09000000 - size.
     134217728 = 0x08000000 (Code MRAM base), 16777216 = 0x01000000 (active half). */!][!//
[!VAR "DataInCodeStart" = "num:inttohex(134217728 + 16777216 - MemAutosarExt/MemDataInCodeMRamSize)"!][!//
[!ENDIF!][!//
[!ENDNOCODE!][!//
/*! Declares that a region of the Code MRAM holds data (Fee/NvM) instead of code. The Code MRAM
    large partition space is the only space taking part in the MRAM OTA A/B swap, so the accesses
    inside the region below are rebased at runtime according to the swap state. */
#define MRAM_IP_DATA_IN_CODE_MRAM               ([!"$DataInCodeMRam"!])
[!IF "$DataInCodeMRam = 'STD_ON'"!][!//
/*! First address of the Code MRAM region used to store data instead of code. The region occupies
    the top of the active (lower) half of the Code MRAM large partition space. */
#define MRAM_IP_DATA_IN_CODE_MRAM_START_U32     ([!"$DataInCodeStart"!]U)
/*! Last address (inclusive) of the Code MRAM region used to store data instead of code */
#define MRAM_IP_DATA_IN_CODE_MRAM_END_U32       (0x8ffffffU)
[!ENDIF!][!//

#define MRAM_IP_TIMEOUT_SUPERVISION_ENABLED     ([!IF "MRamGeneral/MRamTimeoutSupervisionEnabled"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])
#if (STD_ON == MRAM_IP_TIMEOUT_SUPERVISION_ENABLED)
#define MRAM_IP_TIMEOUT_TYPE                    ([!"MRamGeneral/MRamTimeoutMethod"!])
#define MRAM_IP_WRITE_TIMEOUT                   ([!"MRamGeneral/MRamTimeout"!]U)
#endif  /*(STD_ON == MRAM_IP_TIMEOUT_SUPERVISION_ENABLED)*/

#define MRAM_IP_ERASED_VALUE_U8                  ([!"num:inttohex(MemPublishedInformation/MemErasedValue)"!]U)
#define MRAM_IP_ERASED_VALUE_U16                 ([!"num:inttohex(bit:or(MemPublishedInformation/MemErasedValue, bit:shl(MemPublishedInformation/MemErasedValue, 8)))"!]U)
#define MRAM_IP_ERASED_VALUE_U32                 ([!"num:inttohex(bit:or(MemPublishedInformation/MemErasedValue, bit:shl(bit:or(MemPublishedInformation/MemErasedValue, bit:shl(bit:or(MemPublishedInformation/MemErasedValue, bit:shl(MemPublishedInformation/MemErasedValue, 8)), 8)), 8)))"!]U)

[!NOCODE!]
[!VAR "PortCnt" = "0"!]
[!SELECT "MRamGeneral/MRAMControllerCfg/PortConfigurationList/*"!][!//
    [!VAR "PortCnt" = "$PortCnt + 1"!]
[!ENDSELECT!]
[!ENDNOCODE!]

#define MRAM_IP_MAX_PORTS_CONFIGURED    ([!"num:integer($PortCnt)"!]U)

/*==================================================================================================
                                 ENUM TYPEDEFS
==================================================================================================*/

/*==================================================================================================
                                 GLOBAL CONSTANT DECLARATIONS
==================================================================================================*/
#define MEM_43_MRAM_START_SEC_CODE
#include "Mem_43_MRAM_MemMap.h"

    /* Extern declarations for interrupt error callback */
extern const MRam_Ip_ErrorCallbackType MRam_Ip_ErrorCallbacks;

#define MEM_43_MRAM_STOP_SEC_CODE
#include "Mem_43_MRAM_MemMap.h"


#define MEM_43_MRAM_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Mem_43_MRAM_MemMap.h"

/* Configuration structure for MRAM IP */
extern const MRam_Ip_ConfigType MRam_Ip_InitCfg;

#define MEM_43_MRAM_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Mem_43_MRAM_MemMap.h"


#ifdef __cplusplus
}
#endif

/** @} */

#endif /* MRam_IP_CFG_H */
