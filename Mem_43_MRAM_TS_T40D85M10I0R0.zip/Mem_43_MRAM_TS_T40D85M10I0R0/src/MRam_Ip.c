/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : MRAM
*   Dependencies         : None
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
*   Copyright 2024 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
*   @file MRam_Ip.c
*
*   @addtogroup MRAM_IP_
*   @{
*/

#ifdef _cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/

#include "OsIf.h"
#include "Mcal.h"
#include "SchM_Mem_43_MRAM.h"
#include "S32K566_MRAMC.h"
#include "S32K566_F16ASM.h"
#include "S32K566_K566_GPR1.h"
#include "MRam_Ip.h"
#if (MRAM_IP_CACHE_INVALIDATION == STD_ON)
#include "Cache_Ip.h"
#endif

/*==================================================================================================
*                                 SOURCE FILE VERSION INFORMATION
==================================================================================================*/

#define MRAM_IP_VENDOR_ID_C                      43
#define MRAM_IP_AR_RELEASE_MAJOR_VERSION_C       4
#define MRAM_IP_AR_RELEASE_MINOR_VERSION_C       9
#define MRAM_IP_AR_RELEASE_REVISION_VERSION_C    0
#define MRAM_IP_SW_MAJOR_VERSION_C               1
#define MRAM_IP_SW_MINOR_VERSION_C               0
#define MRAM_IP_SW_PATCH_VERSION_C               0

/*==================================================================================================
*                                       FILE VERSION CHECKS
==================================================================================================*/
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Version checks for OsIf.h */
#if((MRAM_IP_AR_RELEASE_MAJOR_VERSION_C != OSIF_AR_RELEASE_MAJOR_VERSION) || \
        (MRAM_IP_AR_RELEASE_MINOR_VERSION_C != OSIF_AR_RELEASE_MINOR_VERSION) \
        )
        #error "MRam_Ip.c and OsIf.h are for different AUTOSAR versions!"
#endif

    /* Version checks for Mcal.h */
#if((MRAM_IP_AR_RELEASE_MAJOR_VERSION_C != MCAL_AR_RELEASE_MAJOR_VERSION) || \
        (MRAM_IP_AR_RELEASE_MINOR_VERSION_C != MCAL_AR_RELEASE_MINOR_VERSION) \
        )
        #error "MRam_Ip.c and Mcal.h are for different AUTOSAR versions!"
#endif

#if (MRAM_IP_CACHE_INVALIDATION == STD_ON)
    /* Version checks for Cache_Ip.h */
#if((MRAM_IP_AR_RELEASE_MAJOR_VERSION_C != CACHE_IP_AR_RELEASE_MAJOR_VERSION) || \
        (MRAM_IP_AR_RELEASE_MINOR_VERSION_C != CACHE_IP_AR_RELEASE_MINOR_VERSION) \
        )
        #error "MRam_Ip.c and Cache_Ip.h are for different AUTOSAR versions!"
#endif
#endif

    /* Version checks for "SchM_Mem_43_MRAM.h" */
#if((MRAM_IP_AR_RELEASE_MAJOR_VERSION_C != SCHM_MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION) || \
        (MRAM_IP_AR_RELEASE_MINOR_VERSION_C != SCHM_MEM_43_MRAM_AR_RELEASE_MINOR_VERSION) \
        )
        #error "MRam_Ip.c and "SchM_Mem_43_MRAM.h" are for different AUTOSAR versions!"
#endif
#endif

/* Version checks for MRam_Ip.h */
#if (MRAM_IP_VENDOR_ID_C != MRAM_IP_VENDOR_ID_H)
    #error "MRam_Ip.c and MRam_Ip.h have different vendor IDs!"
#endif
#if ((MRAM_IP_AR_RELEASE_MAJOR_VERSION_C    != MRAM_IP_AR_RELEASE_MAJOR_VERSION_H) || \
     (MRAM_IP_AR_RELEASE_MINOR_VERSION_C    != MRAM_IP_AR_RELEASE_MINOR_VERSION_H) || \
     (MRAM_IP_AR_RELEASE_REVISION_VERSION_C != MRAM_IP_AR_RELEASE_REVISION_VERSION_H) \
    )
    #error "MRam_Ip.c and MRam_Ip.h are for different AUTOSAR versions!"
#endif
#if ((MRAM_IP_SW_MAJOR_VERSION_C != MRAM_IP_SW_MAJOR_VERSION_H) || \
     (MRAM_IP_SW_MINOR_VERSION_C != MRAM_IP_SW_MINOR_VERSION_H) || \
     (MRAM_IP_SW_PATCH_VERSION_C != MRAM_IP_SW_PATCH_VERSION_H) \
    )
    #error "MRam_Ip.c and MRam_Ip.h have different SW versions!"
#endif

/*==================================================================================================
*                                          LOCAL MACROS
==================================================================================================*/
/* Helper macro to determine if address is in upper bank (based on 32-byte interleaving) */
#define IS_UPPER_BANK(addr) (((addr) & 0x20U) != 0U)

/* UTest password constant */
#define MRAM_IP_UTEST_PASSWORD    (0xF9F99999UL)
#define MRAM_IP_MAX_LOOP_COUNT    (10000U)    /* Safety counter for non-timeout mode */

/* Size in bytes of the MRAMC system-bus gathering write buffer, per
 * system bus port. Used by the AXI write path to decide when to drain
 * the CPU write buffer with a DSB so the gathering buffer never holds
 * more than one full batch in flight. If a future MRAMC variant changes
 * this size, this single constant captures the assumption.
 *
 * MUST be a power of 2 - the MASK derivation below uses (SIZE - 1) as a
 * bit mask, which is only correct when SIZE = 2^N (32 = 2^5 satisfies this). */
#define MRAM_IP_AXI_GATHERING_BUFFER_SIZE    (32U)

/* Address mask derived from MRAM_IP_AXI_GATHERING_BUFFER_SIZE. An address
 * AND-ed with this mask is zero exactly when it lands on a buffer-sized
 * boundary, i.e. the last write in the previous batch has just been
 * issued and a DSB is needed before the next batch begins. */
#define MRAM_IP_AXI_GATHERING_BUFFER_MASK    (MRAM_IP_AXI_GATHERING_BUFFER_SIZE - 1U)

/* Define meaningful constants to replace magic numbers */
#define MRAM_IP_UNUSEFUL_DOMAIN_ID            0xFFu
#define MRAM_IP_PLCK_VALID_DOMAINID_VALUE     2u
#define MRAM_IP_PLCK_LOCK_BLOCKED             3u

#define MRAM_IP_WORD_ALIGNMENT_MASK           0x03UL
#define MRAM_IP_HALF_WORD_ALIGNMENT_MASK      0x01UL
#define MRAM_IP_INTERLEAVE_PAGE_SIZE          32U
#define MRAM_IP_INTERLEAVE_ALIGNMENT_MASK     0x1FUL
#define MRAM_IP_WORDS_PER_INTERLEAVE_PAGE     8U
#define MRAM_IP_ALIGNED_VALUE                 0UL

/* Write-page layout: one write page is MRAM_IP_SINGLE_WRITE_PAGE_SIZE (32) bytes
 * holding MRAM_IP_WORDS_PER_WRITE_PAGE (8) WDATA words of MRAM_IP_WORD_SIZE each. */
#define MRAM_IP_WRITE_PAGE_OFFSET_MASK        (MRAM_IP_SINGLE_WRITE_PAGE_SIZE - 1u)
#define MRAM_IP_WORDS_PER_WRITE_PAGE          (MRAM_IP_SINGLE_WRITE_PAGE_SIZE / MRAM_IP_WORD_SIZE)
/* WSTAT[WID] reads all-ones (full 5-bit field) when no initiator owns the write sequence. */
#define MRAM_IP_WSTAT_WID_NO_OWNER            ((1u << MRAMC_WSTAT_WID_WIDTH) - 1u)
/* Each protect-lock register packs one 2-bit PLCK field per partition. */
#define MRAM_IP_PLCK_FIELD_WIDTH              2u
#define MRAM_IP_PLCK_FIELD_MASK               0x3u
/* Bits per byte - used when converting a byte position to a bit shift. */
#define MRAM_IP_BITS_PER_BYTE                 8u
/*==================================================================================================
*                                        GLOBAL VARIABLES
==================================================================================================*/

/*==================================================================================================
*                                         LOCAL CONSTANTS
==================================================================================================*/
/**
 * @brief Global pointer to the MRAM configuration.
 * @details This pointer is set during MRam_Ip_Init() and used by other API functions.
 *          It should not be modified directly by the user.
 * @note This module is not thread-safe. The application must ensure proper synchronization
 *       when calling MRAM functions from different contexts.
 */
static const MRam_Ip_ConfigType * MRam_Ip_Config = NULL_PTR;

/*! @brief MRAMC Base pointer array
 * Points to memory-mapped registers for the MRAM Controller(s).
 * Defined by IP_MRAMC in the hardware-specific header.
 */
static MRAMC_Type * const MRamC_Ip_BaseAddr[MRAMC_INSTANCE_COUNT] = {IP_MRAMC};

/*! @brief MRAM Memory Base pointer
 * Points to memory-mapped registers for the MRAM memory itself.
 * Defined by IP_MRAM in the hardware-specific header.
 */
static F16ASM_Type * const MRam_Ip_BaseAddr = IP_MRAM;

/*! @brief Async error mailbox - the ENABLED ERRSTAT0 errors the ISR detected,
 *         one accumulator per MRAMC instance.
 *
 * When interrupts are enabled the ISR owns ERRSTAT0 and W1C-clears it before
 * the lower-priority write/erase path could read it, so the ISR deposits the
 * enabled errors here (EnabledErrorsDetected, NOT the raw register: RE/WE
 * have no notification enable and must not leak into a write/erase Status).
 * ProcessOperation consumes and promotes them into Status.
 *
 * Why it exists:
 *   When interrupts are enabled, the ISR owns ERRSTAT0 - it reads and W1C-clears
 *   the register as soon as an enabled error fires. Because the ISR has higher
 *   priority than the thread running a write/erase, the ISR clears ERRSTAT0
 *   before the write/erase code could read it, so a direct read on the
 *   write/erase path would see nothing and the error would never reach the
 *   Status returned to the caller. To still surface it through Status, the ISR
 *   deposits here the ENABLED errors it detected (EnabledErrorsDetected) - NOT
 *   the raw ERRSTAT0 value: RE/WE have no notification enable and must not leak
 *   into a write/erase Status (see MRam_Ip_ProcessIrq). ProcessOperation
 *   consumes them at the end of the operation and promotes them into Status.
 *
 * Concurrency (MULTICORE):
 *   The ISR accumulates with |= (a read-modify-write) and the write/erase path
 *   consumes with read-then-zero - neither is a single atomic store, and the ISR
 *   may run on a DIFFERENT core than the consuming thread. So every access (ISR
 *   deposit, Phase 1b reset, Phase 6c consume) is wrapped in the
 *   MRam_Ip_ERRSTAT0_MAILBOX exclusive area (SchM placeholders at those sites);
 *   that area must also mask the local error ISR, not just spinlock cross-core.
 *   RESIDUAL (architect decision, NOT solved here): this accumulator is per
 *   INSTANCE, not per core/operation. If two cores write the same instance
 *   concurrently, one core's Phase 6c can consume an error the ISR deposited for
 *   the other core (mis-attribution). Fully separating them needs a
 *   per-(instance x core) mailbox.
 *
 * Lifetime per operation:
 *   ProcessOperation resets the entry for its instance at the start (Phase 1b)
 *   so stale bits from a previous operation are not misattributed, then reads
 *   and resets it again at the end (Phase 6c).
 *
 * Storage (MULTIPARTITION):
 *   The mailbox is generated in MRam_Ip_Cfg.c: one array per ECUC partition when the driver
 *   is mapped to partitions, a single shared array otherwise. Both cases are reached through
 *   the configured partition mapping table, so each partition owns its own mailbox and an
 *   error deposited for one partition cannot be consumed by another (freedom from interference).
 *
 * Routing the ISR deposit (MULTIPARTITION):
 *   Each ECUC partition has its own ISR, so MRam_Ip_ProcessIrq always runs in the same
 *   partition as the operation that owns the instance. MRam_Ip_GetCurrentPartition() inside
 *   the ISR therefore already identifies the correct mailbox; no separate owner-tracking
 *   variable is needed. */

/*==================================================================================================
*                                         LOCAL VARIABLES
==================================================================================================*/
/*==================================================================================================
*                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/

#define MEM_43_MRAM_START_SEC_CODE
#include "Mem_43_MRAM_MemMap.h"

/* Forward declaration: this function is defined further down but is called earlier
 * (by MRam_Ip_CheckAndUpdateRegisterSetCompletion and the write-completion path),
 * so it is declared here to avoid an implicit-declaration error under compilers that
 * treat -Wimplicit-function-declaration as an error. */
static MRam_Ip_StatusType MRam_Ip_GetControllerErrorStatusWrite(MRam_Ip_InstanceIdType InstanceId);

/**
 * @brief    Return the ECUC partition of the calling context.
 *
 * @details  Yields the current partition when multi-partition support is enabled and the single
 *           partition index otherwise, so callers do not need their own #if.
 *
 * @param[in] void
 *
 * @return    uint8   ECUC partition index of the caller.
 */
static inline uint8 MRam_Ip_GetCurrentPartition(void)
{
#if (MRAM_IP_MULTIPARTITION_ENABLED == STD_ON)
    return OsIf_GetUserId();
#else
    return 0U;
#endif
}

/**
 * @brief    Resolve the async ERRSTAT0 mailbox of a given ECUC partition.
 *
 * @details  The mailbox is generated per ECUC partition (see MRam_Ip_Cfg.c) and selected here
 *           through the configured mapping table, so each partition owns its own mailbox
 *           (freedom from interference).
 *
 * @param[in] PartitionId   ECUC partition whose mailbox is requested.
 *
 * @return    volatile uint32 *  Pointer to the mailbox array, indexed by MRAMC instance.
 */
static inline volatile uint32 * MRam_Ip_GetAsyncErrstat0SnapshotOf(uint8 PartitionId)
{
#if (MRAM_IP_MULTIPARTITION_ENABLED == STD_ON)
    volatile uint32 * pAsyncErrstat0Snapshot = NULL_PTR;

    /* The map holds NULL_PTR for partitions the driver is not mapped to, so a stale or
     * out-of-range owner must not be dereferenced (this runs in the error ISR too). */
    if (PartitionId < MRAM_IP_MAX_PARTITION)
    {
        pAsyncErrstat0Snapshot = MRam_Ip_Config->AsyncErrstat0Snapshot_PartitionMap[PartitionId];
    }

    return pAsyncErrstat0Snapshot;
#else
    (void)PartitionId;
    return MRam_Ip_Config->AsyncErrstat0Snapshot_PartitionMap[0U];
#endif
}

/**
 * @brief    Resolve the async ERRSTAT0 mailbox of the calling ECUC partition.
 *
 * @details  Used by the operation (thread) side, which resets the mailbox at the start of an
 *           operation and consumes it at the end.
 *
 * @param[in] void
 *
 * @return    volatile uint32 *  Pointer to the mailbox array, indexed by MRAMC instance.
 */
static inline volatile uint32 * MRam_Ip_GetAsyncErrstat0Snapshot(void)
{
    return MRam_Ip_GetAsyncErrstat0SnapshotOf(MRam_Ip_GetCurrentPartition());
}

/**
 * @brief Wait until a register's masked bits reach a target value, with timeout supervision.
 *
 * @details Core poll loop shared by MRam_Ip_WaitUntilRegisterBitsSet and
 *          MRam_Ip_WaitUntilRegisterBitsClear (which pass expectedMaskedValue = maskValue
 *          and 0 respectively). Kept as a single function so the timeout handling and the
 *          delay-before-read ordering cannot drift apart between the "set" and "clear" waits.
 *
 *          The delay happens BEFORE the first read on purpose: a peripheral takes a few
 *          clock cycles to advance its state after a trigger write reaches its bridge
 *          (e.g. writing WCTL[SMW]=1 starts a write, but WBUSY only goes 0 -> 1 a few
 *          cycles later). Sampling before the delay could read stale state and exit early.
 *
 * @param[in] registerPtr          Pointer to the register to monitor
 * @param[in] maskValue            Mask selecting the bits to test
 * @param[in] expectedMaskedValue  Target value of (register & maskValue) to wait for
 * @param[in] timeoutError         Error code to return on timeout
 *
 * @return MRam_Ip_StatusType
 * @retval MRAM_IP_STATUS_SUCCESS  Masked bits reached expectedMaskedValue
 * @retval timeoutError            Timeout occurred while waiting
 */
static MRam_Ip_StatusType MRam_Ip_WaitUntilRegisterBitsMatch(const volatile uint32_t *registerPtr,
                                                          uint32 maskValue,
                                                          uint32 expectedMaskedValue,
                                                          MRam_Ip_StatusType timeoutError)
{
    MRam_Ip_StatusType operationStatus = MRAM_IP_STATUS_SUCCESS;
    uint32 regValue;
#if (STD_ON == MRAM_IP_TIMEOUT_SUPERVISION_ENABLED)
    uint32 elapsedTickCount;
    uint32 timeoutTickLimit;
    uint32 currentTimestamp;

    elapsedTickCount = 0UL;
    timeoutTickLimit = OsIf_MicrosToTicks(MRAM_IP_WRITE_TIMEOUT, (OsIf_CounterType)MRAM_IP_TIMEOUT_TYPE);
    currentTimestamp = OsIf_GetCounter((OsIf_CounterType)MRAM_IP_TIMEOUT_TYPE);
#else
    (void)timeoutError;
#endif

    /* Poll until the masked bits equal the expected value (delay-then-read each pass) */
    do
    {
#if (STD_ON == MRAM_IP_TIMEOUT_SUPERVISION_ENABLED)
        elapsedTickCount += OsIf_GetElapsed(&currentTimestamp, (OsIf_CounterType)MRAM_IP_TIMEOUT_TYPE);
        if (elapsedTickCount >= timeoutTickLimit)
        {
            operationStatus = timeoutError;
            break;
        }
#endif
        /* Small delay between polling attempts (and before the first read) to reduce
         * CPU usage and avoid sampling stale register state right after a trigger write. */
        MRAM_IP_DELAY_CYCLES(10U);

        regValue = *registerPtr;
    } while ((regValue & maskValue) != expectedMaskedValue);

    return operationStatus;
}

/**
 * @brief Wait for register bits to be set (all masked bits become 1) with timeout supervision.
 *
 * @param[in] registerPtr     Pointer to the register to monitor
 * @param[in] maskValue       Mask of bits that should be set (1)
 * @param[in] timeoutError    Error code to return on timeout
 * @return MRAM_IP_STATUS_SUCCESS once set, or timeoutError on timeout.
 */
static MRam_Ip_StatusType MRam_Ip_WaitUntilRegisterBitsSet(const volatile uint32_t *registerPtr,
                                                          uint32 maskValue,
                                                          MRam_Ip_StatusType timeoutError)
{
    /* "Set" means every masked bit is 1, i.e. (register & maskValue) == maskValue. */
    return MRam_Ip_WaitUntilRegisterBitsMatch(registerPtr, maskValue, maskValue, timeoutError);
}

/**
 * @brief Wait for register bits to be cleared (all masked bits become 0) with timeout supervision.
 *
 * @param[in] registerPtr     Pointer to the register to monitor
 * @param[in] maskValue       Mask of bits that should be cleared (0)
 * @param[in] timeoutError    Error code to return on timeout
 * @return MRAM_IP_STATUS_SUCCESS once cleared, or timeoutError on timeout.
 */
static MRam_Ip_StatusType MRam_Ip_WaitUntilRegisterBitsClear(const volatile uint32_t *registerPtr,
                                                          uint32 maskValue,
                                                          MRam_Ip_StatusType timeoutError)
{
    /* "Clear" means every masked bit is 0, i.e. (register & maskValue) == 0. */
    return MRam_Ip_WaitUntilRegisterBitsMatch(registerPtr, maskValue, 0U, timeoutError);
}

/**
 * @brief   Determine MRAM memory region type for a given address
 * @details Classifies a physical address into one of the four MRAM regions
 *          (CODE, DATA, NS_OTP, UTEST), or NOT_EXISTS if the address falls
 *          in a gap between regions.
 *          Each region is checked with >= START and < END (END is exclusive).
 *
 * @param[in] Address  Physical address to classify
 *
 * @return   MRam_Ip_AddressAreaType indicating the memory region type
 * @retval   MRAM_IP_ADDRESS_AREA_TYPE_CODE        Code MRAM (large partitions)
 * @retval   MRAM_IP_ADDRESS_AREA_TYPE_NS_OTP      Non-Secure OTP
 * @retval   MRAM_IP_ADDRESS_AREA_TYPE_DATA        Data MRAM (small partition)
 * @retval   MRAM_IP_ADDRESS_AREA_TYPE_UTEST       UTest rows
 * @retval   MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS  Address not in any MRAM region
 */
static MRam_Ip_AddressAreaType MRam_Ip_GetAddressType(MRam_Ip_AddressType Address)
{
    /* Default to NOT_EXISTS, updated below if the address falls within a known region */
    MRam_Ip_AddressAreaType memType = MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS;

    /* Regions are checked from largest to smallest for fast-path on Code accesses.
     * Each comparison uses >= START and < END (half-open interval). */
    if ((Address >= MRAM_START_ADDRESS_CODE) && (Address < MRAM_END_ADDRESS_CODE))
    {
        /* Code MRAM (large partitions) */
        memType = MRAM_IP_ADDRESS_AREA_TYPE_CODE;
    }
    else if ((Address >= MRAM_START_ADDRESS_NS_OTP) && (Address < MRAM_END_ADDRESS_NS_OTP))
    {
        /* Non-Secure OTP region */
        memType = MRAM_IP_ADDRESS_AREA_TYPE_NS_OTP;
    }
    else if ((Address >= MRAM_START_ADDRESS_DATA) && (Address < MRAM_END_ADDRESS_DATA))
    {
        /* Data MRAM (small partition) */
        memType = MRAM_IP_ADDRESS_AREA_TYPE_DATA;
    }
    else if ((Address >= MRAM_START_ADDRESS_UTEST) && (Address < MRAM_END_ADDRESS_UTEST))
    {
        /* UTest rows */
        memType = MRAM_IP_ADDRESS_AREA_TYPE_UTEST;
    }
    else
    {
        /* Address is in a gap between regions; keep NOT_EXISTS. */
    }

    return memType;
}

/**
 * @brief   Validate MRAM operation parameters
 * @details Performs comprehensive validation of parameters for MRAM operations.
 *          Checks initialization state, instance ID range, buffer pointer validity,
 *          non-zero size, address region existence, and that the operation does not
 *          cross memory region boundaries or overflow uint32.
 *
 * @param[in] MemAddress     MRAM memory address for the operation
 * @param[in] pBuffer        Pointer to buffer (can be NULL if RequireBuffer is FALSE)
 * @param[in] SizeInBytes    Number of bytes for the operation
 * @param[in] InstanceId     MRAM controller instance identifier
 * @param[in] RequireBuffer  Set TRUE if operation requires valid buffer (Read/Write/Compare),
 *                           FALSE if operation doesn't need buffer (like Erase)
 *
 * @return    MRAM_IP_STATUS_SUCCESS if all validations pass
 * @retval    MRAM_IP_STATUS_ERROR_NOT_INITIALIZED             Driver not initialized
 * @retval    MRAM_IP_STATUS_ERROR_INVALID_INSTANCE_ID         InstanceId out of range
 * @retval    MRAM_IP_STATUS_ERROR_NULL_PTR_INPUT_PARAM        Buffer NULL when required
 * @retval    MRAM_IP_STATUS_ERROR_REGION_SIZE_NULL_INPUT_PARAM  Size is zero
 * @retval    MRAM_IP_STATUS_ERROR_ADDRESS_INPUT_PARAM         Address not in any MRAM region
 * @retval    MRAM_IP_STATUS_ERROR_MEMORY_REGION_SIZE_EXCEEDED Range crosses region or overflows
 */
static MRam_Ip_StatusType MRam_Ip_ValidateOperationParameters(
    MRam_Ip_AddressType MemAddress,
    const void* pBuffer,
    MRam_Ip_LengthType SizeInBytes,
    MRam_Ip_InstanceIdType InstanceId,
    boolean RequireBuffer)
{
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    MRam_Ip_AddressAreaType startAddressAreaType = MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS;
    MRam_Ip_AddressAreaType endAddressAreaType = MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS;
    MRam_Ip_AddressType endAddress = 0U;

    /* DEV_ASSERTs catch misuse during development; the runtime checks below
     * handle the same conditions in production builds. */
    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(NULL_PTR != MRam_Ip_Config);
    MRAM_IP_DEV_ASSERT(SizeInBytes != 0U);
    if (RequireBuffer)
    {
        MRAM_IP_DEV_ASSERT(pBuffer != NULL_PTR);
    }
    MRAM_IP_DEV_ASSERT(MemAddress != 0U);
    MRAM_IP_DEV_ASSERT(InstanceId < (MRam_Ip_InstanceIdType)MRAMC_INSTANCE_COUNT);
    #endif

    /* MRam_Ip_Init() must have been called before any operation */
    if(NULL_PTR == MRam_Ip_Config)
    {
        Status = MRAM_IP_STATUS_ERROR_NOT_INITIALIZED;
    }

    /* Reject invalid controller instance */
    if ((Status == MRAM_IP_STATUS_SUCCESS) &&
        (InstanceId >= (MRam_Ip_InstanceIdType)MRAMC_INSTANCE_COUNT))
    {
        Status = MRAM_IP_STATUS_ERROR_INVALID_INSTANCE_ID;
    }

    /* Erase passes NULL_PTR as buffer, so only enforce this for Write/Read/Compare */
    if ((Status == MRAM_IP_STATUS_SUCCESS) &&
        (RequireBuffer == TRUE) && (pBuffer == NULL_PTR))
    {
        Status = MRAM_IP_STATUS_ERROR_NULL_PTR_INPUT_PARAM;
    }

    /* Zero-length operations are not valid */
    if ((Status == MRAM_IP_STATUS_SUCCESS) &&
        (SizeInBytes == 0U))
    {
        Status = MRAM_IP_STATUS_ERROR_REGION_SIZE_NULL_INPUT_PARAM;
    }

    /* Map start address to its MRAM region (Code, Data, OTP, UTEST).
     * Reject anything that falls in a gap between regions. */
    if (Status == MRAM_IP_STATUS_SUCCESS)
    {
        startAddressAreaType = MRam_Ip_GetAddressType(MemAddress);
        #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
        MRAM_IP_DEV_ASSERT(startAddressAreaType != MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS);
        #endif

        if (startAddressAreaType == MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS)
        {
            Status = MRAM_IP_STATUS_ERROR_ADDRESS_INPUT_PARAM;
        }
    }

    /* Verify the entire [MemAddress .. MemAddress+SizeInBytes-1] range
     * stays inside the same MRAM region. Two things can go wrong:
     *  1) MemAddress + SizeInBytes overflows uint32 (e.g. addr near 0x0C907FFF
     *     with a huge size wraps around and may land back in UTEST, fooling
     *     the region comparison below).
     *  2) The end address is valid but belongs to a different region
     *     (e.g. a write starting at the end of CODE that spills into the gap). */
    if (Status == MRAM_IP_STATUS_SUCCESS)
    {
        /* Overflow guard: unsigned wraparound makes the sum smaller than either operand */
        if ((MemAddress + SizeInBytes) < MemAddress)
        {
            Status = MRAM_IP_STATUS_ERROR_MEMORY_REGION_SIZE_EXCEEDED;
        }
        else
        {
            endAddress = MemAddress + SizeInBytes - 1U;

            endAddressAreaType = MRam_Ip_GetAddressType(endAddress);
            #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
            MRAM_IP_DEV_ASSERT(endAddressAreaType != MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS);
            #endif

            /* Either end is outside any MRAM, or it crossed into a different region */
            if ((endAddressAreaType == MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS) ||
                (endAddressAreaType != startAddressAreaType))
            {
                Status = MRAM_IP_STATUS_ERROR_MEMORY_REGION_SIZE_EXCEEDED;
            }
        }
    }

    return Status;
}

/**
 * @brief       Get and clear MRAM memory error status from MCRS register
 * @details     Reads F16ASM MCRS, reports the highest-priority error found,
 *              and clears all detected W1C error flags in a single write.
 *              RE and RSE are also checked but not cleared (they are read-only).
 *              REWSC is not checked here because it is a diagnostic field,
 *              not an error flag. It resets when EER/TBC/DBC/SBC are cleared.
 *
 * @return      Highest priority error, or MRAM_IP_STATUS_SUCCESS if no errors
 * @retval      MRAM_IP_STATUS_SUCCESS             No errors detected
 * @retval      MRAM_IP_STATUS_ECC_UNCORRECTED     Uncorrectable ECC (highest priority)
 * @retval      Other error codes                  See errorMasks array for full priority list
 */
static MRam_Ip_StatusType MRam_Ip_GetMemoryErrorStatus(void)
{
    MRam_Ip_StatusType errorsFound = MRAM_IP_STATUS_SUCCESS;

    /* MULTICORE: MCRS is a controller-wide shared register. The read below and
     * the W1C clear at the end must form ONE atomic section against another core
     * running this same function - otherwise one core's clear drops the flags
     * the other just read, or the two clears race. The per-regset WID semaphore
     * does NOT cover MCRS. Guarded by an AUTOSAR exclusive area.
     * NOTE: this only makes read+clear atomic; MCRS has no per-regset
     * attribution, so a flag genuinely produced by two concurrent writes still
     * cannot be split between them - that is a hardware limitation. */

    /* Read MCRS once to get a consistent snapshot */
    uint32 statusReg = MRam_Ip_BaseAddr->MCRS;

    /* Error flags ordered by priority: first match determines the return value */
    const MRam_Ip_ErrorMaskMappingType errorMasks[] = {
        /* Critical ECC and data integrity errors */
        {F16ASM_MCRS_EER_MASK,   MRAM_IP_STATUS_ECC_UNCORRECTED},          /* Uncorrectable ECC error */
        {F16ASM_MCRS_TBC_MASK,   MRAM_IP_STATUS_ECC_TRIPLE_BIT_ERROR},     /* Triple bit ECC error */
        {F16ASM_MCRS_DBC_MASK,   MRAM_IP_STATUS_ECC_DOUBLE_BIT_ERROR},     /* Double bit ECC error */

        /* Write operation errors */
        {F16ASM_MCRS_WRE_MASK,   MRAM_IP_STATUS_WRITE_ERROR},              /* Write verification mismatch */
        {F16ASM_MCRS_WTE_MASK,   MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR},      /* Write transfer error */
        {F16ASM_MCRS_WCE_MASK,   MRAM_IP_STATUS_WRITE_COLLISION_ERROR},    /* Write collision (correction needed) */
        {F16ASM_MCRS_WRP_MASK,   MRAM_IP_STATUS_WRITE_PROTECTED},          /* Write to locked partition */
        {F16ASM_MCRS_WAE_MASK,   MRAM_IP_STATUS_WRITE_ADDRESS_ERROR},      /* Write address corruption */

        /* Address and integrity errors */
        {F16ASM_MCRS_AEE_MASK,   MRAM_IP_STATUS_ADDRESS_ENCODE_ERROR},     /* Address encoding mismatch */
        {F16ASM_MCRS_EEE_MASK,   MRAM_IP_STATUS_ECC_EDC_AFTER_ECC_ERROR},  /* EDC after ECC mismatch */

        /* Hardware status errors, read-only and not W1C */
        {F16ASM_MCRS_RSE_MASK,   MRAM_IP_STATUS_ERROR_REPAIR_STORAGE},     /* Repair storage corrupted (RO) */
        {F16ASM_MCRS_RE_MASK,    MRAM_IP_STATUS_ERROR_RESET},              /* Reset error (RO) */

        /* Correctable ECC, lowest priority */
        {F16ASM_MCRS_SBC_MASK,   MRAM_IP_STATUS_ECC_CORRECTED}             /* Single bit corrected */
    };

    const uint32 numErrorMasks = sizeof(errorMasks) / sizeof(MRam_Ip_ErrorMaskMappingType);

    /* MCRS bits that can be cleared by writing 1 (W1C).
     * RE (bit 24) and RSE (bit 18) are read-only and not included here. */
    const uint32 w1cMask = F16ASM_MCRS_EER_MASK  | F16ASM_MCRS_TBC_MASK |
                           F16ASM_MCRS_DBC_MASK  | F16ASM_MCRS_SBC_MASK |
                           F16ASM_MCRS_AEE_MASK  | F16ASM_MCRS_EEE_MASK |
                           F16ASM_MCRS_WRE_MASK  | F16ASM_MCRS_WCE_MASK |
                           F16ASM_MCRS_WRP_MASK  | F16ASM_MCRS_WAE_MASK |
                           F16ASM_MCRS_WTE_MASK;

    uint32 clearMask = 0u;

    /* Integration note: enter the MRam_Ip_MCRS exclusive area here (SchM service, integration-generated placeholder). */

    for (uint8 i = 0; i < numErrorMasks; i++)
    {
        if ((statusReg & errorMasks[i].registerMask) != 0u)
        {
            clearMask |= errorMasks[i].registerMask;

            /* First error found = highest priority, save it as return value */
            if (errorsFound == MRAM_IP_STATUS_SUCCESS)
            {
                errorsFound = errorMasks[i].status;
            }
        }
    }

    /* Only clear W1C flags. RE and RSE are read-only */
    clearMask &= w1cMask;

    if (clearMask != 0u)
    {
        MRam_Ip_BaseAddr->MCRS = clearMask;
    }
    /* Integration note: exit the MRam_Ip_MCRS exclusive area here (SchM service, integration-generated placeholder). */

    return errorsFound;
}

/**
 * @brief Load a 32-bit word from a byte pointer without alignment assumptions
 *
 * Avoids casting uint8* to uint32* and prevents
 * alignment faults on ARM when the source is not 4-byte aligned.
 *
 * @param[in] pSrc Pointer to 4 consecutive bytes (little-endian)
 * @return    Reconstructed 32-bit word
 */
static inline uint32 MRam_Ip_LoadWordUnaligned(const uint8 *pSrc)
{
    /* Reconstruct a 32-bit word from 4 individual bytes in little-endian order.
     * Each byte is promoted to uint32 before shifting to avoid implicit promotion issues. */
    uint32 Word;
    Word  = (uint32)pSrc[0];           /* bits  7..0  */
    Word |= (uint32)pSrc[1] << 8u;     /* bits 15..8  */
    Word |= (uint32)pSrc[2] << 16u;    /* bits 23..16 */
    Word |= (uint32)pSrc[3] << 24u;    /* bits 31..24 */
    return Word;
}

/**
 * @brief       Populates WDATA, WSTRB and triggers a single-page write or erase in MRAM
 *
 * @details     This function fills the WDATA registers for page 0 of the selected
 *              register set with the data from SourcePtr (or with the erased value
 *              pattern if SourcePtr is NULL_PTR). It then sets the byte-enable mask
 *              in WSTRB so the hardware knows which bytes to actually program, and
 *              finally triggers the write operation through WCTL.
 *
 *              The function can write anywhere from 1 to 32 bytes inside a page.
 *              If the caller requests more bytes than fit in the page, only the
 *              bytes that fit are written (the rest are handled by the next call).
 *
 *              The data filling is done in 3 steps:
 *              Step 1: if the start address is not on a 4-byte boundary,
 *                      fill the first partial WDATA register.
 *              Step 2: fill as many complete (4-byte) WDATA registers as possible.
 *              Step 3: fill the last partial WDATA register if there are leftover bytes.
 *
 *              Precondition: the caller must have already written WADDR with the
 *              target address via MRam_Ip_AcquireWriteSemaphore.
 *
 * @param[in]   Address     Target address in MRAM. Only used to calculate the byte
 *                          position inside the 32-byte page (WADDR is set by the caller).
 * @param[in]   SourcePtr   Pointer to the source data, or NULL_PTR for erase.
 * @param[in]   WriteSize   Number of bytes to write or erase. If it exceeds the page
 *                          boundary, it is automatically limited to what fits.
 * @param[in]   RegSetIndex Hardware register set index (0 or 1) for double-buffering.
 * @param[in]   InstanceId  MRAM controller instance identifier.
 */
static inline void MRam_Ip_ExecuteSinglePage(
    MRam_Ip_AddressType Address,
    const uint8 *SourcePtr,
    MRam_Ip_LengthType WriteSize,
    uint8 RegSetIndex,
    MRam_Ip_InstanceIdType InstanceId)
{
    /* A page is 32 bytes, divided into 8 WDATA registers of 4 bytes each.
     * We need to figure out where inside the page our data starts,
     * which WDATA register to write first, and which byte position inside that register. */

    /* Extract the byte position inside the 32-byte page.
     * Example: Address = 0x08000005 gives pageOffset = 5,
     * meaning data starts at byte 5 of the page. */
    uint32 pageOffset = Address & MRAM_IP_WRITE_PAGE_OFFSET_MASK;

    /* There are 8 WDATA registers per page (index 0..7), each holds 4 bytes.
     * pageOffset / 4 tells us which WDATA register our first byte goes into.
     * Example: pageOffset=5 gives wordIndex=1 (second WDATA register). */
    uint32 wordIndex = pageOffset >> 2u;

    /* Inside each WDATA register there are 4 byte positions (0, 1, 2, 3).
     * byteOffset tells at which position we start writing.
     * Example: pageOffset=5 gives byteOffset=1, so the first byte goes to position 1 in WDATA[1]. */
    uint32 byteOffset = pageOffset & MRAM_IP_WORD_ALIGNMENT_MASK;

    /* How many bytes from SourcePtr we have read so far. Increases as we copy data. */
    uint32 sourceIndex = 0u;

    /* How many bytes can fit from pageOffset to the end of this 32-byte page.
     * Example: pageOffset=5 means maxInPage=27 (bytes 5..31 are available). */
    uint32 maxInPage = 32u - pageOffset;

    /* The actual number of bytes we will write in this call.
     * If WriteSize is bigger than what fits in the page, we limit it to maxInPage. */
    uint32 remainingInPage = (WriteSize > maxInPage) ? maxInPage : WriteSize;

    /* Keeps track of the current byte position (0..31) inside the page.
     * Starts at pageOffset and goes up as we write bytes. Used at the end
     * to know which bits to set in the strobe mask. */
    uint32 currentBytePos = pageOffset;

    /* The strobe mask tells the hardware which bytes in the 32-byte page to actually write.
     * Each bit corresponds to one byte: bit 0 = byte 0, bit 31 = byte 31.
     * Only bytes that contain our data will have their bit set. */
    uint32 strobeMask = 0u;

    /* Temporary variable where we put together 4 bytes before writing them to WDATA. */
    uint32 wordData = 0u;

    /* How many bytes go into the first WDATA register when we don't start at a 4-byte boundary.
     * Example: byteOffset=1 means we can fit 3 bytes (at positions 1, 2, 3) in the first register. */
    uint32 bytesInFirstWord;

    /* Byte position offset inside the last partial WDATA register (Step 3).
     * In practice this is always 0, because Step 2 always ends on a 4-byte boundary. */
    uint32 finalByteOffset;

    /* A single byte read from the source buffer, or MRAM_IP_ERASED_VALUE_U8 if erasing. */
    uint8 byteValue;

    /* Shared loop counter for Steps 1, 3 and strobe-mask generation. */
    uint32 i;

    /* ========================================================================
     * Step 1: Handle the case where the start address is NOT on a 4-byte boundary.
     *
     * Example: if pageOffset=5, then byteOffset=1. Our data starts at byte position 1
     * inside WDATA[1], so we skip position 0 and fill positions 1, 2, 3 with our first 3 bytes.
     * ======================================================================== */
    if (byteOffset != 0u)
    {
        /* How many bytes can we put into the rest of this WDATA register?
         * There are (4 - byteOffset) positions left. If we have fewer bytes than that,
         * we only fill what we have. */
        bytesInFirstWord = (remainingInPage >= (4u - byteOffset)) ? (4u - byteOffset) : remainingInPage;
        wordData = 0u;

        /* Put each byte into the correct position inside the 32-bit value.
         * (byteOffset + i) << 3 converts the byte position to a bit shift:
         * position 0 = shift 0, position 1 = shift 8, position 2 = shift 16, position 3 = shift 24. */
        for (i = 0u; i < bytesInFirstWord; i++)
        {
            byteValue = (SourcePtr != NULL_PTR) ? SourcePtr[sourceIndex + i] : MRAM_IP_ERASED_VALUE_U8;
            wordData |= (uint32)byteValue << ((byteOffset + i) * MRAM_IP_BITS_PER_BYTE);
        }

        /* Write the result to the WDATA register */
        MRamC_Ip_BaseAddr[InstanceId]->WRL[RegSetIndex].WDATA_PAGE_WORD[0u][wordIndex] = wordData;

        /* Move the source read position forward (only when writing, not when erasing) */
        if (SourcePtr != NULL_PTR)
        {
            sourceIndex += bytesInFirstWord;
        }
        remainingInPage -= bytesInFirstWord;
        currentBytePos += bytesInFirstWord;

        /* Move to the next WDATA register */
        wordIndex = currentBytePos >> 2u;
    }

    /* ========================================================================
     * Step 2: Fill complete WDATA registers (4 bytes each).
     *
     * At this point, currentBytePos is on a 4-byte boundary, so each iteration
     * fills one entire WDATA register. We keep going until we have fewer than
     * 4 bytes left or we reach the last register (index 7).
     * ======================================================================== */
    while ((remainingInPage >= 4u) && (wordIndex < MRAM_IP_WORDS_PER_WRITE_PAGE))
    {
        if (SourcePtr != NULL_PTR)
        {
            /* Read 4 bytes from the source buffer and write them to the WDATA register.
             * LoadWordUnaligned is used because the source pointer may not be 4-byte aligned. */
            MRamC_Ip_BaseAddr[InstanceId]->WRL[RegSetIndex].WDATA_PAGE_WORD[0u][wordIndex] =
                MRam_Ip_LoadWordUnaligned(&SourcePtr[sourceIndex]);
            sourceIndex += 4u;
        }
        else
        {
            /* Erase: fill the WDATA register with the erased value (0xFFFFFFFF) */
            MRamC_Ip_BaseAddr[InstanceId]->WRL[RegSetIndex].WDATA_PAGE_WORD[0u][wordIndex] =
                MRAM_IP_ERASED_VALUE_U32;
        }
        remainingInPage -= 4u;
        currentBytePos += 4u;
        wordIndex = currentBytePos >> 2u;
    }

    /* ========================================================================
     * Step 3: Handle leftover bytes (1, 2 or 3) that do not fill a complete register.
     *
     * This works the same way as Step 1: we put the bytes into the correct positions
     * of the WDATA register. Because Step 2 always processes full 4-byte groups,
     * finalByteOffset is always 0 here (we start at position 0).
     * ======================================================================== */
    if ((remainingInPage > 0u) && (wordIndex < MRAM_IP_WORDS_PER_WRITE_PAGE))
    {
        finalByteOffset = currentBytePos & MRAM_IP_WORD_ALIGNMENT_MASK;
        wordData = 0u;

        /* Put each leftover byte into the correct position, same logic as Step 1 */
        for (i = 0u; i < remainingInPage; i++)
        {
            byteValue = (SourcePtr != NULL_PTR) ? SourcePtr[sourceIndex + i] : MRAM_IP_ERASED_VALUE_U8;
            wordData |= (uint32)byteValue << ((finalByteOffset + i) * MRAM_IP_BITS_PER_BYTE);
        }

        MRamC_Ip_BaseAddr[InstanceId]->WRL[RegSetIndex].WDATA_PAGE_WORD[0u][wordIndex] = wordData;
        currentBytePos += remainingInPage;
    }

    /* ========================================================================
     * Set the strobe mask: one bit per byte that we actually wrote.
     * Example: if we wrote bytes 5..9, bits 5,6,7,8,9 are set in the mask.
     * ======================================================================== */
    for (i = pageOffset; i < currentBytePos; i++)
    {
        strobeMask |= (1UL << i);
    }

    /* Write the strobe mask to the WSTRB register for page 0 */
    MRamC_Ip_BaseAddr[InstanceId]->WRL[RegSetIndex].WSTRB_PAGE[0u] = strobeMask;

    /* Tell the hardware to start the write operation:
     * NUM_WP = 1 means we are writing 1 page.
     * SMW = 1 triggers the actual write. It is self-clearing (returns to 0 automatically).
     * The read-modify-write preserves other fields in WCTL (like CWSL and WDCLR). */
    MRamC_Ip_BaseAddr[InstanceId]->WRL[RegSetIndex].WCTL =
        (MRamC_Ip_BaseAddr[InstanceId]->WRL[RegSetIndex].WCTL & ~MRAMC_WCTL_NUM_WP(0x0Fu)) |
        MRAMC_WCTL_NUM_WP(1u) | MRAMC_WCTL_SMW(1u);
}

/**
 * @brief       Populates WDATA, WSTRB and triggers a multi-page write or erase in MRAM
 *
 * @details     This function fills all WDATA registers for the requested number of pages,
 *              sets all WSTRB bits to 1 (all 32 bytes enabled per page), and triggers
 *              the write operation through WCTL.
 *
 *              Unlike ExecuteSinglePage, this function always writes complete pages
 *              (all 32 bytes per page). This function is only called when
 *              CalculateOptimalOperationSize has verified that the destination address
 *              is aligned to the total burst size (128B for 4 pages, 256B for 8 pages),
 *              so there is no partial-page handling needed.
 *
 *              When SourcePtr is NULL_PTR, all bytes are filled with MRAM_IP_ERASED_VALUE
 *              (erase operation).
 *
 *              Precondition: the caller must have already written WADDR with the
 *              target address via MRam_Ip_AcquireWriteSemaphore.
 *
 * @param[in]   SourcePtr   Pointer to the source data, or NULL_PTR for erase.
 * @param[in]   NumPages    Number of pages to write (4 or 8).
 * @param[in]   RegSetIndex Hardware register set index (0 or 1) for double-buffering.
 * @param[in]   InstanceId  MRAM controller instance identifier.
 */
static inline void MRam_Ip_ExecuteMultiPage(
    const uint8 *SourcePtr,
    uint8 NumPages,
    uint8 RegSetIndex,
    MRam_Ip_InstanceIdType InstanceId)
{
    /* How many bytes from SourcePtr we have read so far. Increases by 4 after each WDATA write. */
    uint32 sourceByteIndex = 0u;

    /* Each page has 8 WDATA registers (32 bytes / 4 bytes per register = 8). */
    uint8 NoOfWords = MRAM_IP_SINGLE_WRITE_PAGE_SIZE / MRAM_IP_WORD_SIZE;
    uint8 pageIdx;
    uint8 wordIdx;

    /* Go through each page (0..NumPages-1) and fill its WDATA registers */
    for (pageIdx = 0u; pageIdx < NumPages; pageIdx++)
    {
        /* For each page, fill all 8 WDATA registers (word 0 to word 7) */
        for (wordIdx = 0u; wordIdx < NoOfWords; wordIdx++)
        {
            if (SourcePtr != NULL_PTR)
            {
                /* Read 4 bytes from the source buffer and write them to the WDATA register.
                 * LoadWordUnaligned is used because the source pointer may not be 4-byte aligned. */
                MRamC_Ip_BaseAddr[InstanceId]->WRL[RegSetIndex].WDATA_PAGE_WORD[pageIdx][wordIdx] =
                    MRam_Ip_LoadWordUnaligned(&SourcePtr[sourceByteIndex]);
                sourceByteIndex += 4u;
            }
            else
            {
                /* Erase: fill the WDATA register with the erased value (0xFFFFFFFF) */
                MRamC_Ip_BaseAddr[InstanceId]->WRL[RegSetIndex].WDATA_PAGE_WORD[pageIdx][wordIdx] =
                    MRAM_IP_ERASED_VALUE_U32;
            }
        }

        /* Multi-page writes always cover complete pages, so all 32 bytes are enabled.
         * Setting WSTRB to 0xFFFFFFFF means every byte in this page will be written. */
        MRamC_Ip_BaseAddr[InstanceId]->WRL[RegSetIndex].WSTRB_PAGE[pageIdx] = 0xFFFFFFFFu;
    }

    /* Tell the hardware to start the write operation:
     * NUM_WP = NumPages (4 or 8) tells the controller how many pages to program.
     * SMW = 1 triggers the actual write. It is self-clearing (returns to 0 automatically).
     * The read-modify-write preserves other fields in WCTL (like CWSL and WDCLR). */
    MRamC_Ip_BaseAddr[InstanceId]->WRL[RegSetIndex].WCTL =
        (MRamC_Ip_BaseAddr[InstanceId]->WRL[RegSetIndex].WCTL & ~MRAMC_WCTL_NUM_WP(0x0Fu)) |
        MRAMC_WCTL_NUM_WP(NumPages) | MRAMC_WCTL_SMW(1u);
}
/**
 * @brief       Chooses the best write/erase size (1, 4, or 8 pages) based on
 *              address alignment, remaining data, and memory type
 *
 * @details     The MRAM controller can write 1 page (32B), 4 pages (128B), or
 *              8 pages (256B) in a single operation. Larger bursts are faster,
 *              but they have hardware-imposed restrictions:
 *
 *              CODE memory: supports 1-page and 8-page only
 *              DATA memory: supports 1-page, 4-page, and 8-page
 *              OTP memory:  supports 1-page only
 *              UTEST memory: supports 1-page only
 *
 *              Multi-page writes also require the destination address to be
 *              aligned to the burst size (128B for 4-page, 256B for 8-page).
 *
 *              This function picks the largest burst that meets all conditions.
 *              If none of the multi-page options apply, it falls back to 1 page.
 *
 * @param[in]   DestinationAddress  Target address in MRAM
 * @param[in]   RemainingBytes      How many bytes are left to write/erase
 * @param[in]   UnusedBytes         Byte offset within the 32-byte page (0..31).
 *                                  If non-zero, the address is not page-aligned.
 * @param[in]   MemoryType          Which MRAM region (CODE, DATA, OTP, UTEST)
 * @param[in]   IsOtpMemory         TRUE if this is an OTP region
 *
 * @return      Number of bytes for the next operation (32, 128, or 256),
 *              or less than 32 if only a partial page is needed
 */
static inline MRam_Ip_LengthType MRam_Ip_CalculateOptimalOperationSize(
    MRam_Ip_AddressType DestinationAddress,
    MRam_Ip_LengthType RemainingBytes,
    uint32 UnusedBytes,
    MRam_Ip_AddressAreaType MemoryType,
    boolean IsOtpMemory)
{
    MRam_Ip_LengthType OptimalSize;
    MRam_Ip_LengthType availableInPage;

    /* Case 1: Use a single page (or partial page) when:
     *   a) OTP memory: only 1-page writes are allowed.
     *   b) UnusedBytes != 0: the address is not page-aligned, so we must first
     *      finish the current page before we can consider multi-page bursts.
     *   c) RemainingBytes <= 32: there is not enough data for a multi-page burst. */
    if ((IsOtpMemory) || ((UnusedBytes != 0u) || (RemainingBytes <= MRAM_IP_SINGLE_WRITE_PAGE_SIZE)))
    {
        /* Calculate how many bytes fit in the rest of the current page */
        availableInPage = MRAM_IP_SINGLE_WRITE_PAGE_SIZE - UnusedBytes;

        /* Write only what we have, or what fits, whichever is smaller */
        OptimalSize = (RemainingBytes < availableInPage) ? RemainingBytes : availableInPage;
    }
    /* Case 2: Try 8-page burst (256 bytes).
     *   Allowed for CODE and DATA, requires >= 256 bytes and 256-byte alignment. */
    else if ((RemainingBytes >= MRAM_IP_EIGHT_WRITE_PAGE_SIZE) &&
            ((MemoryType == MRAM_IP_ADDRESS_AREA_TYPE_CODE) || (MemoryType == MRAM_IP_ADDRESS_AREA_TYPE_DATA)) &&
            ((DestinationAddress % MRAM_IP_EIGHT_WRITE_PAGE_SIZE) == 0u))
    {
        OptimalSize = MRAM_IP_EIGHT_WRITE_PAGE_SIZE;
    }
    /* Case 3: Try 4-page burst (128 bytes).
     *   Allowed for DATA only (CODE does not support 4-page), requires >= 128 bytes
     *   and 128-byte alignment. */
    else if ((RemainingBytes >= MRAM_IP_FOUR_WRITE_PAGE_SIZE) &&
             (MemoryType == MRAM_IP_ADDRESS_AREA_TYPE_DATA) &&
             ((DestinationAddress % MRAM_IP_FOUR_WRITE_PAGE_SIZE) == 0u)) {
        OptimalSize = MRAM_IP_FOUR_WRITE_PAGE_SIZE;
    } else
    {
        /* Case 4: None of the multi-page options apply. Use a single full page (32 bytes).
         * This also covers UTEST memory which only supports 1-page writes. */
        OptimalSize = MRAM_IP_SINGLE_WRITE_PAGE_SIZE;
    }

    return OptimalSize;
}

/**
 * @brief       Dispatches to the correct write/erase function based on operation size
 *
 * @details     This is a simple routing function. Based on the OperationSize value
 *              (previously calculated by CalculateOptimalOperationSize), it calls:
 *              - ExecuteMultiPage with 8 pages for a 256-byte operation
 *              - ExecuteMultiPage with 4 pages for a 128-byte operation
 *              - ExecuteSinglePage for anything else (1 to 32 bytes)
 *
 * @param[in]   Address       Target address in MRAM (only used by ExecuteSinglePage
 *                            to calculate the byte offset inside the page).
 * @param[in]   SourcePtr     Pointer to the source data, or NULL_PTR for erase.
 * @param[in]   OperationSize Number of bytes to process (up to 32, 128, or 256).
 * @param[in]   RegSetIndex   Hardware register set index (0 or 1) for double-buffering.
 * @param[in]   InstanceId    MRAM controller instance identifier.
 */
static inline void MRam_Ip_ExecuteOperationBySize(
    MRam_Ip_AddressType Address,
    const uint8 *SourcePtr,
    MRam_Ip_LengthType OperationSize,
    uint8 RegSetIndex,
    MRam_Ip_InstanceIdType InstanceId)
{
    if (OperationSize == MRAM_IP_EIGHT_WRITE_PAGE_SIZE) {
        /* 256 bytes: write 8 complete pages in a single burst */
        MRam_Ip_ExecuteMultiPage(SourcePtr, MRAM_IP_EIGHT_WRITE_PAGE_NUM_WPE_REG_VALUE, RegSetIndex, InstanceId);
    } else if (OperationSize == MRAM_IP_FOUR_WRITE_PAGE_SIZE) {
        /* 128 bytes: write 4 complete pages in a single burst */
        MRam_Ip_ExecuteMultiPage(SourcePtr, MRAM_IP_FOUR_WRITE_PAGE_NUM_WPE_REG_VALUE, RegSetIndex, InstanceId);
    } else {
        /* 1 to 32 bytes: write a single page (or partial page) */
        MRam_Ip_ExecuteSinglePage(Address, SourcePtr, OperationSize, RegSetIndex, InstanceId);
    }
}

/**
 * @brief       Checks a WSTAT register value for error flags (WDTE and WERR)
 *
 * @details     Shared helper used by both CheckAndUpdateRegisterSetCompletion and
 *              WaitAndCheckRegisterSetCompletion to avoid duplicating the same
 *              WSTAT error checking logic.
 *
 *              Checks in priority order:
 *              1. WDTE (watchdog timeout) - highest priority, returns timeout error
 *              2. WERR (write error) - sets werrDetected flag for the caller
 *
 * @param[in]   WstatVal      The WSTAT register value to check.
 * @param[out]  WerrDetected  Set to TRUE if WERR is set (but WDTE is not).
 *
 * @return      Error status from WSTAT, or SUCCESS if no errors.
 */
static inline MRam_Ip_StatusType MRam_Ip_CheckWstatErrors(
    uint32 WstatVal,
    boolean *WerrDetected)
{
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;

    if ((WstatVal & MRAMC_WSTAT_WDTE_MASK) != 0u)
    {
        /* The write watchdog timer expired. The hardware aborted the write. */
        Status = MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR;
    }
    else if ((WstatVal & MRAMC_WSTAT_WERR_MASK) != 0u)
    {
        /* WERR is set, meaning something went wrong during the write.
         * We flag this for the caller instead of setting a status because
         * MCRS might provide a more specific error code. */
        *WerrDetected = TRUE;
    }
    else
    {
        /* No errors in WSTAT */
    }

    return Status;
}

/**
 * @brief   Resolve the specific cause behind a WSTAT[WERR] flag.
 *
 * @details Shared by the blocking and non-blocking write completion checkers,
 *          so both map the same hardware state to the same status code and the
 *          nesting in the callers stays shallow.
 *
 *          If the other register set is idle it is safe to read the shared
 *          error registers: first MCRS for the specific F16ASM-side cause,
 *          then, only when MCRS is clean, ERRSTAT0 for a controller-level
 *          cause that has no MCRS mirror. If neither pinpoints it, a generic
 *          write error is returned. If the other register set is still active
 *          the shared registers cannot be touched (write-1-to-clear race), so
 *          a generic write error is returned and Phase 5 performs the cleanup.
 *
 * @param[in] RegSetActive  Array tracking the state of each register set.
 * @param[in] ThisRegSet    Index of the register set whose WERR is resolved.
 * @param[in] InstanceId    MRAM controller instance identifier.
 *
 * @return    Specific error status, or a generic write error when the cause
 *            cannot be isolated.
 */
static inline MRam_Ip_StatusType MRam_Ip_ResolveWriteErrorCause(
    const MRam_Ip_RegSetStateType RegSetActive[MRAMC_WRL_COUNT],
    uint8 ThisRegSet,
    MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType status = MRAM_IP_STATUS_WRITE_ERROR;
    MRam_Ip_StatusType controllerStatus;
    uint8 otherRegSet = (ThisRegSet == 0u) ? 1u : 0u;

    if (RegSetActive[otherRegSet] != REGSET_STATE_ACTIVE)
    {
        /* Other regset is idle, safe to read the shared registers. */
        status = MRam_Ip_GetMemoryErrorStatus();
        if (status == MRAM_IP_STATUS_SUCCESS)
        {
            /* MCRS had no F16ASM-side cause. Consult ERRSTAT0 for a
             * controller-level cause that has no MCRS mirror. */
            controllerStatus = MRam_Ip_GetControllerErrorStatusWrite(InstanceId);
            if (controllerStatus != MRAM_IP_STATUS_SUCCESS)
            {
                status = controllerStatus;
            }
            else
            {
                /* Neither MCRS nor ERRSTAT0 pinpointed it. */
                status = MRAM_IP_STATUS_WRITE_ERROR;
            }
        }
    }
    else
    {
        /* Other regset is active, cannot check the shared registers safely. */
        status = MRAM_IP_STATUS_WRITE_ERROR;
    }

    return status;
}

/**
 * @brief       Non-blocking check: did any active register set finish its write?
 *
 * @details     The MRAM controller has 2 register sets (0 and 1) that can work
 *              in parallel (double-buffering). While the main loop prepares data
 *              for the next write, a previous write may still be in progress.
 *
 *              This function checks each register set WITHOUT waiting. If WBUSY
 *              is 0, it means the hardware finished that write. We then check
 *              WSTAT for errors (timeout or write error) and ERRSTAT0 for
 *              controller-level errors, and mark the register set as idle.
 *
 *              MCRS handling: MCRS is shared between both register sets and its
 *              flags are W1C (write-1-to-clear). If the other register set is
 *              still active, reading and clearing MCRS could lose flags that
 *              belong to that other operation. To handle this:
 *              - If the other regset is IDLE: safe to read MCRS and get the
 *                specific error type (WCE, WRE, WTE, etc.)
 *              - If the other regset is ACTIVE: skip MCRS and return a generic
 *                WRITE_ERROR. Phase 5 will handle cleanup.
 *
 * @param[in,out] RegSetActive  Array tracking the state of each register set
 *                              (ACTIVE or IDLE). Updated to IDLE when complete.
 * @param[in,out] Status        Current operation status. Set to an error code
 *                              if a problem is detected.
 * @param[in]     InstanceId    MRAM controller instance identifier.
 */
static inline void MRam_Ip_CheckAndUpdateRegisterSetCompletion(
    MRam_Ip_RegSetStateType RegSetActive[MRAMC_WRL_COUNT],
    MRam_Ip_StatusType *Status,
    MRam_Ip_InstanceIdType InstanceId)
{
    /* Snapshot of WRL[i].WSTAT for the regset currently being checked
     * (single atomic 32-bit read, so WBUSY and WID stay consistent). */
    uint32 wstatVal;

    /* WSTAT[WID] (bits 20..16) extracted from wstatVal, compared against
     * the default 0x1F to confirm the lock has been released. */
    uint32 widVal;

    /* TRUE if MRam_Ip_CheckWstatErrors observed WSTAT[WERR] set; the
     * caller then consults MCRS for a more specific error code. */
    boolean werrDetected;

    uint8 i;

    for (i = 0u; i < MRAMC_WRL_COUNT; i++)
    {
        /* Only check register sets that are currently active and if no error has occurred yet */
        if ((RegSetActive[i] == REGSET_STATE_ACTIVE) && (*Status == MRAM_IP_STATUS_SUCCESS)) {
            /* Make sure all previous memory writes are visible before reading WSTAT */
            MCAL_DATA_SYNC_BARRIER();

            /* Read WSTAT ONCE into a local. WSTAT is volatile so each read goes
             * to the hardware bus; reading it twice could yield inconsistent
             * WBUSY/WID values (the hardware updates them independently of our
             * code). One read gives a coherent snapshot of both fields. */
            wstatVal = MRamC_Ip_BaseAddr[InstanceId]->WRL[i].WSTAT;
            widVal = (wstatVal & MRAMC_WSTAT_WID_MASK) >> MRAMC_WSTAT_WID_SHIFT;

            /* Completion check: a regset is done only when BOTH WBUSY=0 and WID=0x1F.
             * WBUSY=1 means a write is in progress. WID is latched to our domain on the
             * WADDR write and returns to 0x1F on completion or lock release (watchdog
             * timeout / CWSL=1).
             *
             * --- What the fields mean -----------------------------
             *
             * WSTAT[WBUSY] is set by hardware when the write to MRAM
             *     starts and cleared by hardware once the write finishes.
             *     1 = write in progress, 0 = not in progress.
             *
             * WSTAT[WID] is latched to the initiator's domain ID when
             *     the write sequence starts (writing the WADDR register).
             *     It returns to its default value (all 1s = 0x1F) on
             *     completion of the write operation, or on write-sequence
             *     lock release (watchdog timeout, or CWSL=1).
             *
             * In our flow:
             *     - AcquireWriteSemaphore wrote WADDR, so WID = our_domain
             *     - we do not write CWSL anywhere
             *     - watchdog stops at our WCTL[SMW]=1, so it only fires
             *       between WADDR write and SMW write
             *
             * --- Why both must hold ----------------------------------
             *
             * The relevant states for a regset whose previous write we
             * just fired:
             *
             *   WBUSY | WID         | Interpretation
             *   ------+-------------+-------------------------------------
             *     0   | our_domain  | trigger written but HW hasn't yet
             *         |             | scheduled the write (a few cycles
             *         |             | after WCTL[SMW]=1); WBUSY=0 is stale
             *     1   | our_domain  | write in progress
             *     0   | 0x1F        | write completed and lock released
             *     0   | 0x1F (WDTE) | watchdog released the lock without a
             *         |             | successful write
             *
             * Only WBUSY=0 and WID=0x1F means the regset is truly done with
             * our previous operation. The WID check rules out the stale-
             * WBUSY case, where the HW state machine simply hasn't had
             * time to raise WBUSY=1 yet.
             *
             * --- Concrete timeline for a single write ---------------
             *
             *   T0      software writes WCTL[SMW]=1
             *   T0+     peripheral accepts the write (DSB completed)
             *           HW state machine still scheduling
             *           WBUSY=0 (stale), WID=our_domain
             *   T1      HW state machine advances, raises WBUSY=1
             *           WBUSY=1, WID=our_domain
             *   T2      HW physically completes, releases lock
             *           WBUSY=0, WID=0x1F
             *
             * Reading WSTAT:
             *   anywhere in [T0, T1) -> WBUSY=0 and WID=our_domain -> KEEP ACTIVE
             *   anywhere in [T1, T2) -> WBUSY=1                 -> KEEP ACTIVE
             *   anywhere >= T2        -> WBUSY=0 and WID=0x1F       -> MARK IDLE
             *
             * --- Watchdog edge case -------------------------------
             *
             * If the write-sequence watchdog fires before WCTL[SMW]=1
             * reaches the hardware, WID returns to 0x1F and WDTE is
             * set. The condition above accepts that as "done", and the
             * WDTE check inside the block below picks up the error and
             * propagates a timeout status to the caller.
             * ============================================================ */
            if (((wstatVal & MRAMC_WSTAT_WBUSY_MASK) == 0u) && (widVal == MRAM_IP_WSTAT_WID_NO_OWNER))
            {

                /* Check WSTAT for errors (WDTE timeout, WERR write error) */
                werrDetected = FALSE;
                *Status = MRam_Ip_CheckWstatErrors(wstatVal, &werrDetected);

                /* If WERR is set, resolve the specific cause via the shared
                 * helper so the nesting here stays shallow and the blocking and
                 * non-blocking checkers report identical codes. */
                if ((werrDetected == TRUE) && (*Status == MRAM_IP_STATUS_SUCCESS))
                {
                    *Status = MRam_Ip_ResolveWriteErrorCause(RegSetActive, i, InstanceId);
                }

                /* Check ERRSTAT0 for controller-level errors (independent of MCRS).
                 * Uses the write-path variant: when interrupts are enabled the
                 * ISR owns ERRSTAT0 and this yields (returns SUCCESS), letting the
                 * async mailbox surface the error at the end of the operation. */
                if (*Status == MRAM_IP_STATUS_SUCCESS)
                {
                    *Status = MRam_Ip_GetControllerErrorStatusWrite(InstanceId);
                }

                /* Mark this register set as idle so it can be reused for the next write */
                RegSetActive[i] = REGSET_STATE_IDLE;
            }
        }
    }
}

/**
 * @brief       Waits for a single register set to finish and checks all error sources
 *
 * @details     This function waits (with timeout) for WBUSY to become 0, meaning the
 *              hardware finished the write. Then it checks all 3 error sources:
 *              WSTAT, MCRS, and ERRSTAT0.
 *
 *              Compared to CheckAndUpdateRegisterSetCompletion:
 *              - This function is BLOCKING (waits for completion).
 *              - This function checks MCRS (to get the specific error type for WERR).
 *              - This function handles OTP commit (DONE + OWC).
 *              - This function processes ONE register set (not both).
 *
 *              Called from two places:
 *              1. OTP path (inline in main loop): after each single-page OTP write.
 *                 Only one regset is ever active for OTP, so MCRS is always clean.
 *              2. Phase 5 normal path (via WaitForWriteCompletion): after the main
 *                 loop finishes, to drain remaining active register sets.
 *
 *              Note about MCRS in Phase 5: if both register sets are active,
 *              WaitForWriteCompletion calls this function for regset 0 first, which
 *              may W1C-clear MCRS flags before regset 1 is checked. If regset 1 also
 *              has WERR, it will fall back to a generic WRITE_ERROR instead of a
 *              specific error type. This is an acceptable trade-off because the error
 *              is still detected, only the specificity may be lost.
 *
 *              After the write finishes, it checks errors from 3 sources (in order):
 *              1. WSTAT (per-register-set): WDTE (timeout) and WERR (write error)
 *              2. MCRS (F16ASM shared): specific memory errors (WRE, WCE, WTE, etc.)
 *              3. ERRSTAT0 (controller-level): ECC and other hardware errors
 *
 * @param[in]   RegSetIndex  Which register set to wait on (0 or 1).
 * @param[in]   InstanceId   MRAM controller instance identifier.
 *
 * @return      MRAM_IP_STATUS_SUCCESS if no errors, or a specific error code.
 */
static inline MRam_Ip_StatusType MRam_Ip_WaitAndCheckRegisterSetCompletion(
    uint8 RegSetIndex,
    MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType CompletionStatus;

    /* Holds the return value of MRam_Ip_GetControllerErrorStatusWrite (ERRSTAT0
     * read + W1C clear). Used when WSTAT[WERR] fired but MCRS reported no
     * F16ASM-side cause, to enrich the generic WRITE_ERROR fallback with a
     * specific controller-level cause (CPE/CEE/DEE/MCE/WE/PWE) if ERRSTAT0
     * has one. Without this, the caller would lose all controller-side
     * diagnostic on the WERR path. */
    MRam_Ip_StatusType ControllerStatus = MRAM_IP_STATUS_SUCCESS;
    boolean werrDetected;
    uint32 wstatVal;

    /* ========================================================================
     * Part 1: Wait for the hardware to finish the write
     * ======================================================================== */

    /* Make sure all previous register writes are visible to the hardware */
    MCAL_DATA_SYNC_BARRIER();

    /* Wait until WSTAT[WBUSY] becomes 0. If it takes too long, return timeout error. */
    CompletionStatus = MRam_Ip_WaitUntilRegisterBitsClear(
        &(MRamC_Ip_BaseAddr[InstanceId]->WRL[RegSetIndex].WSTAT),
        MRAMC_WSTAT_WBUSY_MASK,
        MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);

    /* Ensure the completion status is visible before reading result registers */
    MCAL_DATA_SYNC_BARRIER();

    /* ========================================================================
     * Part 2: For OTP writes, also wait for the F16ASM commit to complete
     *
     * OTP writes have an extra step: the F16ASM controller must acknowledge
     * the one-time-program commit. We detect an active OTP commit by checking
     * if MCR[OWC] is still 1. The hardware clears OWC automatically when done.
     * ======================================================================== */
    if ((CompletionStatus == MRAM_IP_STATUS_SUCCESS) &&
        ((MRam_Ip_BaseAddr->MCR & F16ASM_MCR_OWC_MASK) != 0u))
    {
        /* Wait for MCRS[DONE] = 1 (F16ASM signals operation complete) */
        CompletionStatus = MRam_Ip_WaitUntilRegisterBitsSet(
            &(MRam_Ip_BaseAddr->MCRS),
            F16ASM_MCRS_DONE_MASK,
            MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);

        if (CompletionStatus == MRAM_IP_STATUS_SUCCESS)
        {
            /* Wait for MCR[OWC] = 0 (hardware auto-clears when commit is done) */
            CompletionStatus = MRam_Ip_WaitUntilRegisterBitsClear(
                &(MRam_Ip_BaseAddr->MCR),
                F16ASM_MCR_OWC_MASK,
                MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);
        }
    }

    /* ========================================================================
     * Part 3: Check all error sources (3 levels)
     *
     * We check in order:
     * 1. WSTAT: per-register-set errors (WDTE timeout, WERR general error)
     * 2. MCRS: F16ASM memory errors (gives us the specific error type)
     * 3. ERRSTAT0: controller-level errors (ECC, etc.)
     * ======================================================================== */

    /* --- Error source 1: WSTAT (per-register-set) --- */
    werrDetected = FALSE;
    if (CompletionStatus == MRAM_IP_STATUS_SUCCESS)
    {
        wstatVal = MRamC_Ip_BaseAddr[InstanceId]->WRL[RegSetIndex].WSTAT;
        CompletionStatus = MRam_Ip_CheckWstatErrors(wstatVal, &werrDetected);
    }

    /* --- Error source 2: MCRS (F16ASM, shared between register sets) ---
     *
     * Unlike MRam_Ip_CheckAndUpdateRegisterSetCompletion (the in-loop checker,
     * which guards its MCRS read with an "other regset idle" check), this
     * terminal checker reads/clears the shared MCRS unconditionally. That is
     * safe: the only caller, MRam_Ip_WaitForWriteCompletion, drains every active
     * regset in a single pass and returns the FIRST non-SUCCESS. Whichever
     * regset's check reads the shared MCRS first both RETURNS the error code and
     * W1C-clears it, so a real error is always surfaced - with its specific code
     * preserved - regardless of which regset "owned" it. A second regset whose
     * MCRS flag was just cleared still reports via its own WSTAT[WERR]. Verified
     * by the dual-regset completion harness across both timings (MCRS error
     * present at the 1st vs the 2nd read): no error is lost or downgraded, so the
     * extra guard would add complexity without changing behaviour. */
    if (CompletionStatus == MRAM_IP_STATUS_SUCCESS)
    {
        /* GetMemoryErrorStatus reads MCRS and returns a specific error code if any
         * error flags are set (WRE, WCE, WTE, etc.). It also clears the W1C flags. */
        CompletionStatus = MRam_Ip_GetMemoryErrorStatus();

        if ((CompletionStatus == MRAM_IP_STATUS_SUCCESS) && (werrDetected == TRUE))
        {
            /* WSTAT[WERR] fired but MCRS reported no F16ASM-side cause.
             * Before falling back to a generic WRITE_ERROR, consult ERRSTAT0:
             * it carries controller-level flags (CPE control parity, CEE
             * control ECC, DEE data ECC, MCE controller, WE write-path, PWE
             * posted-write) that have NO mirror in MCRS. If we skipped
             * ERRSTAT0 here, those causes would never reach the caller.
             *
             * RM: "Any error encountered for a transaction is captured in
             *      ERRSTATn, and the transaction error response is sent on
             *      the bus as well."
             *
             * We only do this promotion when MCRS was clean. If MCRS gave a
             * specific code, we keep it: MCRS[WRE]->WRITE_ERROR and
             * ERRSTAT0[ME]->MRAM_MACRO_ERROR describe the SAME failure from two
             * angles, and we would not want ERRSTAT0 to silently relabel it.
             *
             * Write-path variant: when interrupts are enabled the ISR owns
             * ERRSTAT0, so this yields (returns SUCCESS) and the async mailbox
             * surfaces the cause at end-of-operation instead. */
            ControllerStatus = MRam_Ip_GetControllerErrorStatusWrite(InstanceId);
            if (ControllerStatus != MRAM_IP_STATUS_SUCCESS)
            {
                CompletionStatus = ControllerStatus;
            }
            else
            {
                /* Both MCRS and ERRSTAT0 are clean (or ISR owns ERRSTAT0). WERR
                 * fired but no specific cause here - report generic write error. */
                CompletionStatus = MRAM_IP_STATUS_WRITE_ERROR;
            }
        }
    }

    /* --- Error source 3: ERRSTAT0 (controller-level, clean-path only) ---
     *
     * Covers the case where WSTAT and MCRS were both clean but ERRSTAT0 still
     * has a controller-level flag (CPE/CEE/DEE/MCE/UE/etc.). Write-path variant:
     * when interrupts are enabled the ISR owns ERRSTAT0 and this yields; the
     * async mailbox delivers the error into Status at the end of the operation. */
    if (CompletionStatus == MRAM_IP_STATUS_SUCCESS)
    {
        CompletionStatus = MRam_Ip_GetControllerErrorStatusWrite(InstanceId);
    }

    return CompletionStatus;
}

/**
 * @brief       Finds and returns the first available write register set (0 or 1)
 *
 * @details     The MRAM controller has 2 write register sets (WRL[0] and WRL[1]).
 *              Each can hold one write operation. This function polls both until
 *              one of them is free (WBUSY = 0).
 *
 *              Priority: WRL[0] is checked first. If both are free, WRL[0] is returned.
 *
 *              If timeout supervision is enabled, the function gives up after
 *              MRAM_IP_WRITE_TIMEOUT microseconds and returns WRITE_TIMEOUT_BUSY.
 *              If timeout supervision is disabled, the function loops forever until
 *              a register set becomes available (the caller must ensure this happens).
 *
 * @param[out]  WriteRegVariant  Pointer where the index (0 or 1) of the free
 *                               register set will be stored.
 * @param[in]   InstanceId       MRAM controller instance identifier.
 *
 * @return      MRAM_IP_STATUS_SUCCESS if a register set was acquired,
 *              MRAM_IP_STATUS_WRITE_TIMEOUT_BUSY if timeout expired.
 */
static MRam_Ip_StatusType MRam_Ip_AcquireWriteRegisterSet(uint8* WriteRegVariant, MRam_Ip_InstanceIdType InstanceId)
{
    /* Loop status; starts as WRITE_BUSY (the sentinel meaning "no regset
     * claimed yet") and is set to SUCCESS or WRITE_TIMEOUT_BUSY inside the
     * loop. The do-while exits when Status is no longer WRITE_BUSY. */
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_WRITE_BUSY;

    /* Snapshot of WRL[0].WSTAT taken once per iteration to avoid inconsistent
     * WBUSY/WID reads from separate volatile accesses. */
    uint32 wstat0;

    /* WID field (bits 20..16) extracted from wstat0 for the freeness check. */
    uint32 wid0;

    /* Snapshot of WRL[1].WSTAT (read lazily, only when reg 0 is not free). */
    uint32 wstat1;

    /* WID field extracted from wstat1. */
    uint32 wid1;

#if (STD_ON == MRAM_IP_TIMEOUT_SUPERVISION_ENABLED)
    /* Cumulative ticks elapsed inside the poll loop; compared against
     * TimeoutTicks to detect that we waited longer than allowed. */
    uint32 ElapsedTicks = 0UL;

    /* Timeout budget in counter ticks, derived from MRAM_IP_WRITE_TIMEOUT. */
    uint32 TimeoutTicks = OsIf_MicrosToTicks(MRAM_IP_WRITE_TIMEOUT, (OsIf_CounterType)MRAM_IP_TIMEOUT_TYPE);

    /* Last counter sample taken; serves as reference point for the next
     * OsIf_GetElapsed call (returns delta since this timestamp). */
    uint32 CurrentTicks = OsIf_GetCounter((OsIf_CounterType)MRAM_IP_TIMEOUT_TYPE);
#endif

    /* Poll for a regset we can claim, or until the timeout supervisor gives up.
     *
     * The MRAMC has two independent write register sets (WRL[0], WRL[1]). A
     * regset is free only when BOTH WBUSY=0 (no write executing) and WID=0x1F
     * (no owner). WID is latched to the initiator on the WADDR write and returns
     * to 0x1F on completion, watchdog timeout, or CWSL=1.
     *
     * The MRAMC has two write register sets (WRL[0] and WRL[1]) that can
     * be used independently. A regset is free to claim only when BOTH:
     *
     *     WBUSY = 0       (no write is currently executing on this regset)
     *     WID   = 0x1F    (no master currently owns the write-sequence
     *                      lock on this regset)
     *
     * RM: WSTAT[WID] is latched to the initiator's domain ID when the
     *     write sequence starts (writing WADDR), and returns to its
     *     default 0x1F only on completion of the write, on watchdog
     *     timeout, or on explicit CWSL=1.
     *
     * --- Why both must be checked together ---------------------------
     *
     *   WBUSY | WID         | Meaning                          | Decision
     *   ------+-------------+----------------------------------+----------
     *     0   | 0x1F        | truly idle, no owner             | CLAIM
     *     0   | our_domain  | we fired SMW=1 a few cycles ago, |
     *         |             | HW hasn't yet raised WBUSY=1     | NOT free
     *     0   | other       | another master holds the lock   | NOT free
     *         |             | (acquired WADDR, has not yet     |
     *         |             | issued SMW=1)                    |
     *     1   | any         | a write is in progress           | NOT free
     *     0   | 0x1F (WDTE) | the watchdog just released the   | CLAIM
     *         |             | lock; downstream code clears the |
     *         |             | stale WDTE                       |
     *
     * The WID condition is what separates a "truly idle" regset from a
     * regset whose WBUSY is still stale because the peripheral state
     * machine has not advanced yet. Only the (WBUSY=0, WID=0x1F)
     * combination guarantees no operation is pending in the regset's
     * data registers; the loop keeps polling on any other combination.
     *
     * --- Concrete two-iteration example -----------------------------
     *
     *   Iteration N (somewhere upstream):
     *     ... writes WCTL[SMW]=1 to start a write on regset 0 ...
     *
     *   T0     iter N completes WCTL[SMW]=1
     *   T0+    HW state machine still scheduling
     *          WBUSY[0]=0 (stale), WID[0]=our_domain_id
     *   T1     HW raises WBUSY[0]=1
     *   T2     HW completes the write, WBUSY[0]=0, WID[0]=0x1F
     *
     *   Iteration N+1 calls into this function:
     *     - if called in [T0, T1): WBUSY[0]=0 and WID[0]=our_id -> not free
     *                              (the WID check saves us; we try WRL[1])
     *     - if called in [T1, T2): WBUSY[0]=1 -> not free, try WRL[1]
     *     - if called >= T2:        WBUSY[0]=0 and WID[0]=0x1F -> claim WRL[0]
     *
     * --- Atomic single-read of WSTAT --------------------------------
     *
     * WSTAT is volatile; reading it twice can yield inconsistent WBUSY
     * and WID. The code below reads each regset's WSTAT into a local
     * variable once and extracts both fields from that snapshot.
     *
     * --- Lazy read of WRL[1] ----------------------------------------
     *
     * WRL[0] is the preferred regset. WRL[1].WSTAT is only read when
     * WRL[0] is not free. This avoids one MMIO read in the typical
     * fast path where regset 0 is ready.
     * ================================================================ */
    do
    {
        /* Single atomic read of WSTAT[0] avoids inconsistencies between separate
         * volatile accesses for WBUSY and WID. */
        wstat0 = MRamC_Ip_BaseAddr[InstanceId]->WRL[0u].WSTAT;
        wid0 = (wstat0 & MRAMC_WSTAT_WID_MASK) >> MRAMC_WSTAT_WID_SHIFT;

        /* Try register set 0 first (preferred) */
        if (((wstat0 & MRAMC_WSTAT_WBUSY_MASK) == 0u) && (wid0 == MRAM_IP_WSTAT_WID_NO_OWNER))
        {
            *WriteRegVariant = 0u;
            Status = MRAM_IP_STATUS_SUCCESS;
        }
        else
        {
            /* Register set 0 not free - try register set 1 (lazy read: only
             * touched when reg 0 is not available). */
            wstat1 = MRamC_Ip_BaseAddr[InstanceId]->WRL[1u].WSTAT;
            wid1 = (wstat1 & MRAMC_WSTAT_WID_MASK) >> MRAMC_WSTAT_WID_SHIFT;

            if (((wstat1 & MRAMC_WSTAT_WBUSY_MASK) == 0u) && (wid1 == MRAM_IP_WSTAT_WID_NO_OWNER))
            {
                *WriteRegVariant = 1u;
                Status = MRAM_IP_STATUS_SUCCESS;
            }
            else
            {
                /* Both register sets are not free. Check if we have waited too long. */
#if (STD_ON == MRAM_IP_TIMEOUT_SUPERVISION_ENABLED)
                ElapsedTicks += OsIf_GetElapsed(&CurrentTicks, (OsIf_CounterType)MRAM_IP_TIMEOUT_TYPE);
                if (ElapsedTicks >= TimeoutTicks)
                {
                    Status = MRAM_IP_STATUS_WRITE_TIMEOUT_BUSY;
                }
#endif
            }
        }

    } while (Status == MRAM_IP_STATUS_WRITE_BUSY);

    return Status;
}

/**
 * @brief Acquires the write sequence semaphore for a register set
 *
 * Implements spec Steps 1-2 of the Register bus write programming sequence
 *   Step 1: Write to WADDRn with the target page address. This also requests
 *           ownership of the write sequence lock for this register set.
 *   Step 2: Read WSTATn[WID] to verify that our domain ID now owns the lock.
 *           If another master owns it, re-write WADDR and retry ("go to
 *           previous step" per spec).
 *
 * Success is WID == MRAM_IP_DOMAIN_ID: after the WADDR write the hardware
 * latches WSTAT[WID] to OUR domain ID when we gain the lock. A reading of
 * WID == 0x1F ("no owner", default/reset value, all bits set on a 5-bit field)
 * therefore means our WADDR write did NOT take the lock (e.g. XRDC denied it,
 * or a transient) - we re-write WADDR and retry; the timeout catches a
 * persistent failure. (0x1F is NOT treated as success.)
 *
 * If XRDC denies access to the target address, the WADDR write is rejected
 * silently and the lock is not acquired (WID will not match). The timeout
 * mechanism catches this case.
 *
 * @param[in] MRamAddress    MRAM target address (will be masked to page boundary)
 * @param[in] WriteRegVariant Register set index (0 or 1)
 * @param[in] InstanceId     MRAMC hardware instance
 * @return MRAM_IP_STATUS_SUCCESS if semaphore acquired,
 *         MRAM_IP_STATUS_WRITE_TIMEOUT_GAIN_SEMAPHORE on timeout
 */
static MRam_Ip_StatusType MRam_Ip_AcquireWriteSemaphore(MRam_Ip_AddressType MRamAddress, uint8 WriteRegVariant, MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_WRITE_GAIN_SEMAPHORE_ERROR;

#if (STD_ON == MRAM_IP_TIMEOUT_SUPERVISION_ENABLED)
    uint32 ElapsedTicks = 0UL;
    uint32 TimeoutTicks = OsIf_MicrosToTicks(MRAM_IP_WRITE_TIMEOUT, (OsIf_CounterType)MRAM_IP_TIMEOUT_TYPE);
    uint32 CurrentTicks = OsIf_GetCounter((OsIf_CounterType)MRAM_IP_TIMEOUT_TYPE);
#endif
    uint32 currentWid;

    /* Spec Step 1: Write address to WADDRn, requesting write sequence ownership */
    MRamC_Ip_BaseAddr[InstanceId]->WRL[WriteRegVariant].WADDR = MRamAddress & MRAMC_WADDR_WADDR_MASK;

    /* Spec Step 2: Poll WSTATn[WID] until our domain ID owns the sequence */
    do
    {
        currentWid = (MRamC_Ip_BaseAddr[InstanceId]->WRL[WriteRegVariant].WSTAT & MRAMC_WSTAT_WID_MASK) >> MRAMC_WSTAT_WID_SHIFT;

        if (currentWid == MRAM_IP_DOMAIN_ID)
        {
            /* Our domain owns the write sequence */
            Status = MRAM_IP_STATUS_SUCCESS;
        }
        else
        {
            /* WID does not match our domain. Two cases:
             * - 0x1F: lock is free ("no owner"), our WADDR write was likely ignored
             *         (another master released just now, or XRDC denied us).
             *         Re-write WADDR to acquire the now-free lock.
             * - Other value: another master owns the sequence.
             *         Re-write WADDR to retry when they release.
             * In both cases: re-write WADDR and check timeout. */
#if (STD_ON == MRAM_IP_TIMEOUT_SUPERVISION_ENABLED)
            ElapsedTicks += OsIf_GetElapsed(&CurrentTicks, (OsIf_CounterType)MRAM_IP_TIMEOUT_TYPE);
            if (ElapsedTicks >= TimeoutTicks)
            {
                Status = MRAM_IP_STATUS_WRITE_TIMEOUT_GAIN_SEMAPHORE;
            }
            else
#endif
            {
                /* Spec Step 2: "If not same, go to previous step" (re-write WADDR) */
                MRamC_Ip_BaseAddr[InstanceId]->WRL[WriteRegVariant].WADDR = MRamAddress & MRAMC_WADDR_WADDR_MASK;
            }
        }
    } while (Status == MRAM_IP_STATUS_WRITE_GAIN_SEMAPHORE_ERROR);

    return Status;
}

/**
 * @brief Clears WERR and WDTE error flags from a previous write sequence
 *
 * Implements the clear portion of spec Step 3:
 * "If error is still set then write 1 to clear them."
 *
 * The spec prefixes that with "wait for some time to allow previous sequence
 * owner to clear them" before clearing. That back-off is intentionally NOT
 * implemented here:
 *   - Clean-slate policy: the driver clears stale errors up-front on every
 *     operation, so deferring to a previous owner contradicts that design.
 *   - "Some time" is an unspecified duration; polling or delaying on every
 *     write that sees a stale flag would cost real-time latency for no
 *     guaranteed benefit.
 *   - The error-stealing window it guards is narrow: a previous owner that
 *     completed normally has already read WSTAT[WERR] before releasing the
 *     lock. The case that matters here, our own watchdog firing mid-sequence
 *     (WDTE=1, WID released), is handled below by preserving WDTE so the
 *     downstream completion check still sees it.
 *
 * WSTAT error fields are W1C (Write-1-to-Clear): writing 1 clears the bit,
 * writing 0 has no effect. The write value 0x6 (WDTE | WERR) clears only
 * bits 1-2 without affecting WBUSY (bit 0) or WID (bits 16-20).
 *
 * @param[in] WriteRegVariant Register set index (0 or 1)
 * @param[in] InstanceId     MRAMC hardware instance
 */
static void MRam_Ip_ClearPreviousErrors(uint8 WriteRegVariant, MRam_Ip_InstanceIdType InstanceId)
{
    /* Pointer to the WSTAT register of the selected regset; used for both the
     * read snapshot and the final W1C clear write. */
    volatile uint32 *wstatRegPtr;

    /* 32-bit snapshot of WSTAT taken before clearing; both WDTE and WID are
     * extracted from this single read for atomic consistency. */
    uint32 currentWstat;

    /* WSTAT[WID] (bits 20..16) extracted from currentWstat. Used to decide
     * whether WDTE is "ours" or stale. */
    uint32 widVal;

    /* Mask of bits to write back to WSTAT (W1C clear). Selected by the WDTE/WID
     * combination - see the discrimination table below. */
    uint32 clearMask;

    wstatRegPtr = (volatile uint32 *)&(MRamC_Ip_BaseAddr[InstanceId]->WRL[WriteRegVariant].WSTAT);
    currentWstat = *wstatRegPtr;
    widVal = (currentWstat & MRAMC_WSTAT_WID_MASK) >> MRAMC_WSTAT_WID_SHIFT;

    /* Clear stale WERR/WDTE before starting a new write, with one twist:
     * WDTE may also mean OUR watchdog just fired.
     *
     * The write-sequence watchdog runs from the WADDR write until we write
     * WCTL[SMW]=1. The longest exposed stretch is the OTP F16ASM waits
     * (ms-scale), which can exceed the sub-ms watchdog. If it fires, WDTE=1,
     * WID goes to 0x1F (lock released) and any later SMW=1 is ignored.
     *
     * RM: There is a watchdog timer for each set of write buffer
     *     registers. The timer resets and starts counting when the write
     *     sequence lock is acquired (i.e. on WADDR write). It stops when
     *     WCTL[SMW] or WCTL[CWSL] is written 1, or it times out. On
     *     timeout the write sequence lock is released.
     *
     * RM: WSTAT[WDTE] is set by hardware when the watchdog timer expires
     *     before the software finishes the sequence. It is W1C (software
     *     clears by writing 1).
     *
     * In our code, anything between AcquireWriteSemaphore (which writes
     * WADDR) and ExecuteOperationBySize (which writes WCTL[SMW]=1) runs
     * WITH the watchdog ticking. The longest such stretch is the OTP
     * F16ASM acknowledgment waits (UTE clear, then MCRS[OMR|OMA|DONE]
     * set), which are ms-scale.
     *
     * RM: WWDOG[WDT] selects the watchdog timeout:
     *
     *     00b (default) -> 40000 register bus clocks  (~400 us @ 100 MHz)
     *     01b           -> 200 clocks                 (~2 us)
     *     10b           -> 400 clocks                 (~4 us)
     *     11b           -> 4000 clocks                (~40 us)
     *
     * Sub-millisecond watchdog vs ms-scale OTP wait -> the watchdog can
     * win the race during OTP first-page writes. When it does:
     *
     *     WDTE -> 1
     *     WID  -> 0x1F (lock released)
     *     any subsequent WCTL[SMW]=1 is silently ignored.
     *
     * RM: SMW (and other WCTL fields) can be written only by the domain
     *     ID currently shown in WSTAT[WID]. Writes from any other domain
     *     are dropped.
     *
     * --- Two distinct meanings of WDTE=1 by the time we run ----
     *
     *   WDTE=1 and WID = our_domain  -> stale flag left by a previous
     *                                owner whose lock we re-acquired.
     *                                Clear it before our sequence so it
     *                                does not affect completion checks.
     *
     *   WDTE=1 and WID = 0x1F        -> OUR watchdog has fired since
     *                                AcquireWriteSemaphore succeeded.
     *                                We no longer own the lock and our
     *                                SMW=1 will be dropped. Preserve
     *                                WDTE so the downstream completion
     *                                check picks it up and returns
     *                                MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR
     *                                to the caller.
     *
     * --- Resulting behavior table ------------------------------
     *
     *   WDTE | WID         | clearMask
     *   -----+-------------+---------------------
     *     0  | any         | WDTE | WERR (no-op on WDTE, W1C clear of WERR if set)
     *     1  | our_domain  | WDTE | WERR (clear both - stale from previous owner)
     *     1  | not our id  | WERR only      (preserve WDTE for downstream)
     *
     * WERR is cleared in every case because the watchdog only sets WDTE,
     * so any WERR seen here is a stale flag from a previous sequence and
     * should not leak into the new operation's error reporting.
     * ================================================================ */
    if (((currentWstat & MRAMC_WSTAT_WDTE_MASK) != 0u) && (widVal != MRAM_IP_DOMAIN_ID))
    {
        /* Watchdog fired in the current iteration - clear WERR only, preserve
         * WDTE so downstream sees the timeout. */
        clearMask = MRAMC_WSTAT_WERR_MASK;
    }
    else
    {
        /* Normal path: clear both error flags in a single W1C write to avoid
         * clearing concurrent flags. */
        clearMask = MRAMC_WSTAT_WDTE_MASK | MRAMC_WSTAT_WERR_MASK;
    }

    *wstatRegPtr = clearMask;
}

/**
 * @brief           Accesses MRAM to read data into the user buffer
 *
 * @param[in]  ReadAddress    Source address in MRAM to read from
 * @param[out] DesAddressPtr  Destination buffer to store read data
 * @param[in]  SizeLeft       Maximum number of bytes that can be read
 *
 * @return     Number of bytes successfully read (1, 2, or 4), or 0 if an error occurred
 */
static uint8 MRam_Ip_ReadData(uint32 ReadAddress,
                              uint8 *DesAddressPtr,
                              uint32 SizeLeft
                             )
{

    /* Variable to track how many bytes are read */
    uint8 ReadSize = 0U;  /* Default to 0 (error condition) */
    uint32 ReadWord = 0U;
    uint16 ReadHalf = 0U;

    /* Variable to check combined alignment of source and destination */
    uint32 CombinedAddress;

    /* Combine two addresses for faster alignment checking */
    CombinedAddress = ReadAddress | (uint32)DesAddressPtr;

    /* Both addresses 4-byte aligned and have enough bytes remaining */
    if ((0UL == (CombinedAddress & MRAM_IP_WORD_ALIGNMENT_MASK)) && (SizeLeft >= MRAM_IP_SIZE_4BYTE))
    {
        /* 4 bytes operation - read word from MRAM, store byte-by-byte to destination */
        ReadWord = *((const volatile uint32 *)ReadAddress);  /* Cast to a volatile pointer is required for memory-mapped HW access */
        ReadSize = MRAM_IP_SIZE_4BYTE;
        DesAddressPtr[0] = (uint8)(ReadWord);
        DesAddressPtr[1] = (uint8)(ReadWord >> 8u);
        DesAddressPtr[2] = (uint8)(ReadWord >> 16u);
        DesAddressPtr[3] = (uint8)(ReadWord >> 24u);
    }
    /* Both addresses 2-byte aligned and have enough bytes remaining */
    else if ((0UL == (CombinedAddress & MRAM_IP_HALF_WORD_ALIGNMENT_MASK)) && (SizeLeft >= MRAM_IP_SIZE_2BYTE))
    {
        /* 2 bytes operation - read halfword from MRAM, store byte-by-byte */
        ReadHalf = *((const volatile uint16 *)ReadAddress);  /* Cast to a volatile pointer is required for memory-mapped HW access */
        ReadSize = MRAM_IP_SIZE_2BYTE;
        DesAddressPtr[0] = (uint8)(ReadHalf);
        DesAddressPtr[1] = (uint8)((uint32)ReadHalf >> 8u);
    }
    else if (SizeLeft >= MRAM_IP_SIZE_1BYTE)
    {
        /* 1 byte operation - always aligned */
        ReadSize = MRAM_IP_SIZE_1BYTE;
        *DesAddressPtr = *((const volatile uint8 *)ReadAddress);  /* Cast to a volatile pointer is required for memory-mapped HW access */
    }
    else
    {
        /* ReadSize remains 0 to indicate no bytes to read */
    }

    return ReadSize;
}

static MRam_Ip_PartitionType MRam_Ip_CheckLargePartitions(MRam_Ip_AddressType Address)
{
    MRam_Ip_PartitionType result = MRAM_IP_PARTITION_NOT_EXISTS;
    MRam_Ip_AddressType offsetFromCodeStart;
    uint8 pairIndex;
    uint8 basePartition;
    uint8 partitionValue;

    /* Quick range check and arithmetic calculation */
    if ((Address >= MRAM_IP_CODE_START) && (Address < (MRAM_IP_CODE_START + (8U * MRAM_IP_LARGE_PAIR_SIZE))))
    {
        /* Calculate pair index directly using the defined constants */
        offsetFromCodeStart = Address - MRAM_IP_CODE_START;
        pairIndex = (uint8)(offsetFromCodeStart / MRAM_IP_LARGE_PAIR_SIZE);

        /* Calculate result using intermediate variable to avoid composite cast to enum */
        basePartition = IS_UPPER_BANK(Address) ?
                     (uint8)MRAM_IP_PARTITION_LARGE_0_UPPER :
                     (uint8)MRAM_IP_PARTITION_LARGE_0_LOWER;
        partitionValue = basePartition + pairIndex;
        result = (MRam_Ip_PartitionType)partitionValue;
    }

    return result;
}

static MRam_Ip_PartitionType MRam_Ip_CheckSmallPartitions(MRam_Ip_AddressType Address)
{
    MRam_Ip_PartitionType result = MRAM_IP_PARTITION_NOT_EXISTS;
    uint8 partitionIndex;
    uint8 partitionValue;

    /* Single range check and direct calculation */
    if ((Address >= MRAM_IP_DATA_START) && (Address < (MRAM_IP_DATA_START + (4U * MRAM_IP_SMALL_PARTITION_SIZE))))
    {
        /* Calculate and map partition index in one expression */
        partitionIndex = (uint8)((Address - MRAM_IP_DATA_START) / MRAM_IP_SMALL_PARTITION_SIZE);

        /* Direct mapping using arithmetic offset from base partition enum */
        partitionValue = (uint8)MRAM_IP_PARTITION_SMALL_LOWER0 + partitionIndex;
        result = (MRam_Ip_PartitionType)partitionValue;
    }

    return result;
}

static MRam_Ip_PartitionType MRam_Ip_CheckSpecialPartitions(MRam_Ip_AddressType Address)
{
    MRam_Ip_PartitionType result = MRAM_IP_PARTITION_NOT_EXISTS;

    /* Check OTP partitions */
    if (((Address >= MRAM_IP_OTP_LOWER_LARGE_START) && (Address <= MRAM_IP_OTP_LOWER_LARGE_END)) ||
        ((Address >= MRAM_IP_OTP_UPPER_LARGE_START) && (Address <= MRAM_IP_OTP_UPPER_LARGE_END)))
    {
        result = MRAM_IP_PARTITION_NS_OTP;
    }
    /* Check UTEST partition */
    else if ((Address >= MRAM_IP_UTEST_START) && (Address <= MRAM_IP_UTEST_END))
    {
        result = MRAM_IP_PARTITION_UTEST;
    }
    else
    {
        /* result already initialized to MRAM_IP_PARTITION_NOT_EXISTS */
    }

    return result;
}

/**
 * @brief   Returns the partition that a given MRAM address belongs to.
 *
 * @param[in] Address  MRAM address to classify.
 * @return    The partition type, or MRAM_IP_PARTITION_NOT_EXISTS if the address
 *            is outside every known partition.
 * @note      For large partitions the upper/lower bank is decided by the
 *            32-byte interleaving (see IS_UPPER_BANK).
 */
static MRam_Ip_PartitionType MRam_Ip_GetPartition(MRam_Ip_AddressType Address)
{
    MRam_Ip_PartitionType result = MRAM_IP_PARTITION_NOT_EXISTS;

    /* Check each partition type category */
    result = MRam_Ip_CheckLargePartitions(Address);

    if (result == MRAM_IP_PARTITION_NOT_EXISTS)
    {
        result = MRam_Ip_CheckSmallPartitions(Address);
    }

    if (result == MRAM_IP_PARTITION_NOT_EXISTS)
    {
        result = MRam_Ip_CheckSpecialPartitions(Address);
    }

    return result;
}

/**
 * @brief Determine whether OTA A/B swap is currently active.
 *
 * @details The OTA swap state is read at RUNTIME from GPR1
 *          (IP_GPR_1->GPR_RWD_0). A physical swap is active only when BOTH:
 *            - OTA_SEL == 1 ("Swap non-fixed large partitions"), AND
 *            - OTA_NUM_FIXED_LPART selects a mode that actually leaves at least
 *              one pair non-fixed (Full swap = 0x00 or Partial swap = 0x04).
 *          When OTA_NUM_FIXED_LPART == 0x10 ("All fixed - no OTA") nothing is
 *          swapped even with OTA_SEL == 1, so the logical and physical
 *          large-partition layouts coincide and the classic LOCK0 decode (plus
 *          its defensive F16ASM cross-check) stays valid.
 *
 * @return boolean - TRUE if OTA A/B swap is physically active, FALSE otherwise.
 */
static boolean MRam_Ip_IsOtaSwapActive(void)
{
    boolean swapActive = FALSE;
    uint32  gprVal;
    uint32  otaNumFixed;

    /* Single volatile read of GPR_RWD_0 - avoids two separate accesses to the
     * same volatile register (MISRA C:2012 Rule 13.2). GPR_RWD_0 is write-locked
     * by the bootloader (LOCK_EN0/LOCK_EN1 set, see S32K5xx Reference Manual, GPR1 chapter) so the value is stable
     * at runtime, but a single snapshot read is still the correct idiom. */
    gprVal = IP_GPR_1->GPR_RWD_0;

    /* Extract OTA_NUM_FIXED_LPART (bits[11:6]) to distinguish OTA modes.
     * See S32K5xx Reference Manual: "Memory organization" (39.3.1) and
     * "Over-the-air (OTA)" (39.3.6); see also MRAM_IP_OTA_NUM_FIXED_* in
     * MRam_Ip_Types.h for the full units explanation.
     *
     * UNITS: the MRAM has 16 large PARTITIONS grouped into 8 PAIRS (pair = 1 upper
     * partition + 1 lower partition = 2 partitions). A PAIR is the swap unit; this
     * register field is expressed in PARTITIONS, so partitions = pairs x 2.
     *
     *   0x00 = Full swap    -  0 partitions fixed =  0 pairs fixed;
     *                          all 8 pairs (0..7) are non-fixed (swapped).
     *   0x04 = Partial swap -  4 partitions fixed =  2 pairs fixed;
     *                          pairs 0..1 FIXED, remaining 6 pairs (2..7) non-fixed
     *                          (swapped). (4 = 2 fixed pairs x 2 partitions per pair;
     *                          RM 39.3.6: "the first two large partition pairs are fixed".)
     *   0x10 = All fixed    - 16 partitions fixed =  8 pairs fixed (all of them);
     *                          no pair is swapped, OTA_SEL is effectively ignored. */
    otaNumFixed = (gprVal & K566_GPR1_GPR_RWD_0_OTA_NUM_FIXED_LPART_MASK)
                  >> K566_GPR1_GPR_RWD_0_OTA_NUM_FIXED_LPART_SHIFT;

    if (((gprVal & K566_GPR1_GPR_RWD_0_OTA_SEL_MASK) != 0U) &&
        (otaNumFixed != MRAM_IP_OTA_NUM_FIXED_ALL))
    {
        swapActive = TRUE;
    }

    return swapActive;
}

/**
 * @brief   Decode F16ASM LOCK0 for a large partition when OTA swap is NOT active.
 * @details Extracted from MRam_Ip_CheckF16asmLockLarge to keep the caller within
 *          the HIS CCM limit. Logical pair index == physical pair index for all
 *          pairs, so LOCK0 is decoded directly. Logic unchanged.
 *
 * @param[in] Partition    Large partition to check.
 * @param[in] f16asmLock0  F16ASM LOCK0 register value.
 * @return    boolean - TRUE if F16ASM reports the partition locked, FALSE otherwise.
 */
static boolean MRam_Ip_CheckLargeLockNoSwap(MRam_Ip_PartitionType Partition, uint32 f16asmLock0)
{
    boolean isLocked = FALSE;
    uint8   pairIndex;

    /* No swap active: logical pair index == physical pair index for all pairs. */
    if ((Partition >= MRAM_IP_PARTITION_LARGE_0_LOWER) && (Partition <= MRAM_IP_PARTITION_LARGE_7_LOWER))
    {
        /* Lower bank -> LPLOCKL (bit = pair index). */
        pairIndex = (uint8)Partition - (uint8)MRAM_IP_PARTITION_LARGE_0_LOWER;
        isLocked = ((f16asmLock0 & (uint32)(1UL << (uint32)pairIndex)) != 0U);
    }
    else if ((Partition >= MRAM_IP_PARTITION_LARGE_0_UPPER) && (Partition <= MRAM_IP_PARTITION_LARGE_7_UPPER))
    {
        /* Upper bank -> LPLOCKU (bit = pair index + LPLOCKU shift). */
        pairIndex = (uint8)Partition - (uint8)MRAM_IP_PARTITION_LARGE_0_UPPER;
        isLocked = ((f16asmLock0 & (uint32)(1UL << ((uint32)pairIndex + F16ASM_LOCK0_LPLOCKU_SHIFT))) != 0U);
    }
    else
    {
        /* Not a large partition - isLocked stays FALSE */
    }

    return isLocked;
}

/**
 * @brief   Decode F16ASM LOCK0 for a large partition when OTA swap IS active.
 * @details Extracted from MRam_Ip_CheckF16asmLockLarge to keep the caller within
 *          the HIS CCM limit. Fixed pairs (0..PARTIAL_FIXED_PAIRS-1) decode LOCK0
 *          directly; non-fixed pairs defer to MRAMC LPLOCK (return FALSE). Logic
 *          unchanged.
 *
 * @param[in] Partition    Large partition to check.
 * @param[in] f16asmLock0  F16ASM LOCK0 register value.
 * @return    boolean - TRUE if F16ASM reports the partition locked, FALSE otherwise.
 */
static boolean MRam_Ip_CheckLargeLockSwap(MRam_Ip_PartitionType Partition, uint32 f16asmLock0)
{
    boolean isLocked = FALSE;
    uint8   pairIndexFixed;

    /* Swap active: fixed pairs (0..PARTIAL_FIXED_PAIRS-1) decode LOCK0
     * directly; non-fixed pairs defer to MRAMC LPLOCK (return FALSE). */
    if ((Partition >= MRAM_IP_PARTITION_LARGE_0_LOWER) && (Partition <= MRAM_IP_PARTITION_LARGE_7_LOWER))
    {
        pairIndexFixed = (uint8)Partition - (uint8)MRAM_IP_PARTITION_LARGE_0_LOWER;
        if (pairIndexFixed < MRAM_IP_OTA_PARTIAL_FIXED_PAIRS)
        {
            /* Fixed pair under partial swap: logical == physical. */
            isLocked = ((f16asmLock0 & (uint32)(1UL << (uint32)pairIndexFixed)) != 0U);
        }
        /* else: non-fixed pair - isLocked stays FALSE (defer to MRAMC LPLOCK) */
    }
    else if ((Partition >= MRAM_IP_PARTITION_LARGE_0_UPPER) && (Partition <= MRAM_IP_PARTITION_LARGE_7_UPPER))
    {
        pairIndexFixed = (uint8)Partition - (uint8)MRAM_IP_PARTITION_LARGE_0_UPPER;
        if (pairIndexFixed < MRAM_IP_OTA_PARTIAL_FIXED_PAIRS)
        {
            /* Fixed pair under partial swap: logical == physical. */
            isLocked = ((f16asmLock0 & (uint32)(1UL << ((uint32)pairIndexFixed + F16ASM_LOCK0_LPLOCKU_SHIFT))) != 0U);
        }
        /* else: non-fixed pair - isLocked stays FALSE (defer to MRAMC LPLOCK) */
    }
    else
    {
        /* Not a large partition - isLocked stays FALSE */
    }

    return isLocked;
}

/**
 * @brief Helper function to check F16ASM lock status for large partitions
 *
 * @details  Two registers describe the large-partition lock:
 *          - MRAMC LPLOCK is the value software programs. It is indexed by the
 *            LOGICAL pair and is kept swap-transparent by MRAMC:
 *            the logical partition the caller targets is always the one MRAMC locks
 *            and enforces, regardless of OTA swap. MRam_Ip_CheckMramcLock reads this
 *            and is therefore authoritative and correct under swap.
 *          - F16ASM LOCK0 is the read-only PHYSICAL mirror, split into LPLOCKL
 *            (bits 0-15, physical lower-bank partitions) and LPLOCKU (bits 16-31,
 *            physical upper-bank partitions).
 *
 *          When OTA swap is NOT active, the logical and physical layouts coincide,
 *          so LOCK0 is decoded directly by the logical pair index (the classic
 *          no-swap behaviour, preserved here as a defensive cross-check).
 *
 *          When OTA swap IS active, the physical pair that backs a given logical
 *          pair is chosen by the MRAMC OTA logic. The driver therefore does NOT guess a
 *          physical permutation. Instead it defers the large-partition lock
 *          decision to the swap-transparent MRAMC LPLOCK by reporting FALSE from
 *          this physical mirror when swap is active; the dispatcher ORs this with
 *          the authoritative isMramcLocked, so the logical lock still governs.
 *          Physical enforcement is independently guaranteed by F16ASM: any write to
 *          a physically locked partition is rejected and reported via MRAM
 *          MCRS[WRE]. This choice therefore cannot corrupt data and never falsely
 *          refuses a writable partition.
 *
 * @param[in] Partition - Large partition to check
 * @param[in] f16asmLock0 - F16ASM LOCK0 register value
 * @return boolean - TRUE if F16ASM reports the partition locked, FALSE otherwise
 */
static boolean MRam_Ip_CheckF16asmLockLarge(MRam_Ip_PartitionType Partition, uint32 f16asmLock0, boolean otaSwapActive)
{
    boolean isLocked;

    /* Swap unit is the PAIR (2 partitions; 8 pairs = 16 large partitions).
     * No swap / all-fixed: decode LOCK0 directly for every pair.
     * Partial swap (0x04): pairs 0..1 fixed -> decode directly; other pairs
     * non-fixed -> defer to MRAMC LPLOCK. Full swap (0x00): all pairs deferred.
     * The two decode paths are split into helpers to keep this function within
     * the HIS CCM limit; logic unchanged.
     * See function header and MRam_Ip_Types.h for the full RM 39.3.1/39.3.6 rationale. */
    if (otaSwapActive == FALSE)
    {
        isLocked = MRam_Ip_CheckLargeLockNoSwap(Partition, f16asmLock0);
    }
    else
    {
        isLocked = MRam_Ip_CheckLargeLockSwap(Partition, f16asmLock0);
    }

    return isLocked;
}

/**
 * @brief Helper function to check F16ASM lock status for small partitions
 *
 * @details The F16ASM LOCK1 register reports the PHYSICAL lock state
 *          of the small (DATA) partitions, split into SPLOCKL (bits 0-1, lower
 *          bank) and SPLOCKU (bits 2-3, upper bank). OTA A/B swap applies ONLY to
 *          the large (code) partition space - see S32K5xx Reference Manual, MRAMC OTA chapter NOTE: "OTA is only
 *          applicable to normal MRAM large partitions space and not applicable to
 *          any other space." Small partitions are therefore never swapped, so the
 *          logical bank maps directly to the physical half of LOCK1.
 *
 * @param[in] Partition - Small partition to check
 * @param[in] f16asmLock1 - F16ASM LOCK1 register value
 * @return boolean - TRUE if F16ASM locked, FALSE otherwise
 */
static boolean MRam_Ip_CheckF16asmLockSmall(MRam_Ip_PartitionType Partition, uint32 f16asmLock1)
{
    boolean isLocked = FALSE;

    /* Lower bank -> SPLOCKL bits 0-1. */
    if (Partition == MRAM_IP_PARTITION_SMALL_LOWER0)
    {
        isLocked = ((f16asmLock1 & (uint32)(1UL << 0U)) != 0U);
    }
    else if (Partition == MRAM_IP_PARTITION_SMALL_LOWER1)
    {
        isLocked = ((f16asmLock1 & (uint32)(1UL << 1U)) != 0U);
    }
    /* Upper bank -> SPLOCKU (bits 2-3 = SPLOCKU shift + 0/1). */
    else if (Partition == MRAM_IP_PARTITION_SMALL_UPPER0)
    {
        isLocked = ((f16asmLock1 & (uint32)(1UL << (0U + F16ASM_LOCK1_SPLOCKU_SHIFT))) != 0U);
    }
    else if (Partition == MRAM_IP_PARTITION_SMALL_UPPER1)
    {
        isLocked = ((f16asmLock1 & (uint32)(1UL << (1U + F16ASM_LOCK1_SPLOCKU_SHIFT))) != 0U);
    }
    else
    {
        /* Not a small partition - isLocked stays FALSE */
    }

    return isLocked;
}

/**
 * @brief Helper function to check F16ASM lock status for special partitions
 *
 * @param[in] Partition - Special partition to check (OTP or UTEST)
 * @param[in] f16asmLock1 - F16ASM LOCK1 register value
 * @return boolean - TRUE if F16ASM locked, FALSE otherwise
 */
static boolean MRam_Ip_CheckF16asmLockSpecial(MRam_Ip_PartitionType Partition, uint32 f16asmLock1)
{
    boolean isLocked = TRUE; /* Default to TRUE for safety */

    /* OTP partition */
    if (Partition == MRAM_IP_PARTITION_NS_OTP)
    {
        /* Check both upper and lower OTP lock bits */
        isLocked = (((f16asmLock1 & F16ASM_LOCK1_OLOCKL_MASK) != 0U) ||
                   ((f16asmLock1 & F16ASM_LOCK1_OLOCKU_MASK) != 0U));
    }
    /* UTEST partition */
    else if (Partition == MRAM_IP_PARTITION_UTEST)
    {
        /* Check both upper and lower UTEST lock bits */
        isLocked = (((f16asmLock1 & F16ASM_LOCK1_UTLOCKL_MASK) != 0U) ||
                   ((f16asmLock1 & F16ASM_LOCK1_UTLOCKU_MASK) != 0U));
    }
    else
    {
        /* isLocked remains TRUE for unknown partitions (safety) */
    }

    return isLocked;
}

/**
 * @brief Helper function to check MRAMC controller lock status
 *
 * @param[in] Partition - Partition to check
 * @param[in] InstanceId - Hardware instance ID
 * @return boolean - TRUE if MRAMC locked, FALSE otherwise
 */
static boolean MRam_Ip_CheckMramcLock(MRam_Ip_PartitionType Partition, MRam_Ip_InstanceIdType InstanceId)
{
    boolean isLocked = TRUE; /* Default to TRUE for unknown partitions (safety) */
    uint32 LckMask;
    uint8 partitionIndex;

    /* Large partitions */
    if ((Partition >= MRAM_IP_PARTITION_LARGE_0_LOWER) && (Partition <= MRAM_IP_PARTITION_LARGE_7_UPPER))
    {
        /* Calculate partition index for both upper and lower */
        if (Partition <= MRAM_IP_PARTITION_LARGE_7_LOWER)
        {
            partitionIndex = (uint8)Partition - (uint8)MRAM_IP_PARTITION_LARGE_0_LOWER;
        }
        else
        {
            partitionIndex = (uint8)Partition - (uint8)MRAM_IP_PARTITION_LARGE_0_UPPER;
        }

        LckMask = (uint32)(1UL << partitionIndex);
        isLocked = ((MRamC_Ip_BaseAddr[InstanceId]->LPLOCK & LckMask) == LckMask);
    }
    /* Small partitions */
    else if ((Partition >= MRAM_IP_PARTITION_SMALL_LOWER0) && (Partition <= MRAM_IP_PARTITION_SMALL_UPPER1))
    {
        isLocked = ((MRamC_Ip_BaseAddr[InstanceId]->SPLOCK & MRAMC_SPLOCK_LCK_MASK) == MRAMC_SPLOCK_LCK_MASK);
    }
    /* OTP partition */
    else if (Partition == MRAM_IP_PARTITION_NS_OTP)
    {
        isLocked = ((MRamC_Ip_BaseAddr[InstanceId]->LPOLOCK & MRAMC_LPOLOCK_LCK_MASK) == MRAMC_LPOLOCK_LCK_MASK);
    }
    /* UTEST partition */
    else if (Partition == MRAM_IP_PARTITION_UTEST)
    {
        isLocked = ((MRamC_Ip_BaseAddr[InstanceId]->UTLOCK & MRAMC_UTLOCK_LCK_MASK) == MRAMC_UTLOCK_LCK_MASK);
    }
    else
    {
        /* isLocked remains TRUE for unknown partitions (safety) */
    }

    return isLocked;
}


/**
 * @brief           Checks whether a partition is locked.
 *
 * @param[in]       Partition - Partition to check
 * @param[in]       InstanceId - Hardware instance ID
 * @return          TRUE if partition is locked, FALSE otherwise
 */
static boolean MRam_Ip_IsPartitionLocked(MRam_Ip_PartitionType Partition, MRam_Ip_InstanceIdType InstanceId)
{
    /* Default to LOCKED for any unknown/invalid partition value (safety:
     * deny-by-default for inputs we cannot interpret). */
    boolean IsLocked = TRUE;

    /* Lock state seen at MRAMC's writable register (LPLOCK / SPLOCK / LPOLOCK /
     * UTLOCK). This is the value software wrote. */
    boolean isMramcLocked;

    /* Lock state mirrored back at F16ASM (LOCK0 / LOCK1). Driven by MRAMC,
     * read-only. May briefly disagree with MRAMC during propagation. */
    boolean isF16asmLocked = FALSE;

    /* Snapshot of F16ASM LOCK0 - covers large-partition lock bits. */
    uint32 f16asmLock0;

    /* Snapshot of F16ASM LOCK1 - covers small-partition, OTP and UTEST bits. */
    uint32 f16asmLock1;

    /* OTA swap state, read once per call (see below). */
    boolean otaSwapActive;

    /* Only process valid partitions */
    if (Partition != MRAM_IP_PARTITION_NOT_EXISTS)
    {
        /* --- Source 1: MRAMC's writable lock register ----------------
         * Authoritative for "software intent" - this is the bit we
         * set/cleared with SetLock/ClearLock. */
        isMramcLocked = MRam_Ip_CheckMramcLock(Partition, InstanceId);

        /* --- Source 2: F16ASM's mirror of the same lock state -------
         * Authoritative for "what the underlying MRAM will actually
         * enforce" - F16ASM rejects writes based on its own LOCK0/1. */
        f16asmLock0 = MRam_Ip_BaseAddr->LOCK0;
        f16asmLock1 = MRam_Ip_BaseAddr->LOCK1;

        /* Cache the OTA swap state once per IsPartitionLocked call so that
         * MRam_Ip_IsOtaSwapActive (which reads GPR_RWD_0) is invoked only once
         * regardless of how many partitions are checked in a range operation. */
        otaSwapActive = MRam_Ip_IsOtaSwapActive();

        if (Partition <= MRAM_IP_PARTITION_LARGE_7_UPPER)
        {
            isF16asmLocked = MRam_Ip_CheckF16asmLockLarge(Partition, f16asmLock0, otaSwapActive);
        }
        else if (Partition <= MRAM_IP_PARTITION_SMALL_UPPER1)
        {
            isF16asmLocked = MRam_Ip_CheckF16asmLockSmall(Partition, f16asmLock1);
        }
        else
        {
            isF16asmLocked = MRam_Ip_CheckF16asmLockSpecial(Partition, f16asmLock1);
        }

        /* OR semantic: "locked" if EITHER source reports locked.
         *
         * Why OR rather than AND:
         *   - If software just set the lock via MRAMC, F16ASM may briefly
         *     show 0 during propagation; OR still reports LOCKED because
         *     MRAMC is already 1, so a subsequent write is correctly
         *     refused.
         *   - If F16ASM is in an unexpected lock state (e.g. asserted by
         *     a different master or by reset), OR refuses to issue a
         *     write that the hardware would reject anyway.
         *
         * Trade-off accepted: OR can also refuse writes if F16ASM glitches
         * to "locked" unexpectedly. We prefer false-refusal over false-
         * acceptance - the second one risks data loss / silent failures. */
        IsLocked = (isMramcLocked || isF16asmLocked);
    }
    /* else: Invalid partitions remain locked (IsLocked = TRUE) */

    return IsLocked;
}

/**
 * @brief           Maps a partition's 2-bit PLCK field to its lock-ownership result.
 * @details         Shared decision used by every partition kind (large/small/OTP/UTEST).
 *                  The caller extracts the PLCK field from the partition-specific
 *                  protect-lock register and passes the matching lock-owner register;
 *                  keeping the decision in one place stops the per-partition copies from
 *                  drifting apart (a missing branch in the UTEST copy was a real defect).
 *                    PLCK 10b      -> owner-restricted: report owning domain, valid.
 *                    PLCK 11b      -> blocked: no owner, NOT valid.
 *                    PLCK 00b/01b  -> any initiator: no specific owner, valid.
 *
 * @param[in]       plckValue          2-bit PLCK field already extracted from the register.
 * @param[in]       pLockOwnerReg      Lock-owner register for this partition (read only when owner-restricted).
 * @param[in]       lockOwnerMask      Mask selecting the owning-domain field in that register.
 * @param[out]      pLockDomainIDValue Receives the owning domain ID, or the unused sentinel.
 * @return          TRUE if ownership is valid, FALSE if the lock is blocked.
 */
static boolean MRam_Ip_EvaluatePlckOwnership(uint32 plckValue,
                                            const volatile uint32_t *pLockOwnerReg,
                                            uint32 lockOwnerMask,
                                            uint8 *pLockDomainIDValue)
{
    boolean result;

    if (plckValue == MRAM_IP_PLCK_VALID_DOMAINID_VALUE)
    {
        /* Owner-restricted (10b): the owning domain is named in the lock-owner register. */
        *pLockDomainIDValue = (uint8)(*pLockOwnerReg & lockOwnerMask);
        result = TRUE;
    }
    else if (plckValue == MRAM_IP_PLCK_LOCK_BLOCKED)
    {
        /* Blocked (11b): nobody may modify the lock. */
        *pLockDomainIDValue = MRAM_IP_UNUSEFUL_DOMAIN_ID;
        result = FALSE;
    }
    else
    {
        /* Any initiator (00b/01b): no specific owner, modification allowed. */
        *pLockDomainIDValue = MRAM_IP_UNUSEFUL_DOMAIN_ID;
        result = TRUE;
    }

    return result;
}

/**
 * @brief           Checks whether a large partition has valid lock ownership.
 *
 * @param[in]       Partition - Large partition type (including upper/lower designation)
 * @param[out]      pLockDomainIDValue - Pointer to store the domain ID value
 * @param[in]       InstanceId - Hardware instance ID
 * @return          TRUE if partition ownership is valid, FALSE otherwise
 */
static boolean MRam_Ip_IsLargePartitionOwnershipValid(MRam_Ip_PartitionType Partition,
                                                      uint8 * pLockDomainIDValue,
                                                      MRam_Ip_InstanceIdType InstanceId)
{
    uint8 partitionIndex = 0U;
    uint32 plckValue;
    boolean result = TRUE; /* Assume valid by default */

    *pLockDomainIDValue = MRAM_IP_UNUSEFUL_DOMAIN_ID;

    /* Calculate partition index efficiently */
    if ((Partition >= MRAM_IP_PARTITION_LARGE_0_LOWER) && (Partition <= MRAM_IP_PARTITION_LARGE_7_LOWER))
    {
        partitionIndex = (uint8)Partition - (uint8)MRAM_IP_PARTITION_LARGE_0_LOWER;
    }
    else if ((Partition >= MRAM_IP_PARTITION_LARGE_0_UPPER) && (Partition <= MRAM_IP_PARTITION_LARGE_7_UPPER))
    {
        partitionIndex = (uint8)Partition - (uint8)MRAM_IP_PARTITION_LARGE_0_UPPER;
    }
    else
    {
        /* Invalid partition type */
        result = FALSE;
    }

    /* Only process if partition is valid (result == TRUE) */
    if (result == TRUE)
    {
        /* Each PLCK field is 2 bits wide and the 8 large-partition fields are
         * packed into PLPLOCK[0], so shift by (partitionIndex * 2) to extract it. */
        plckValue = (MRamC_Ip_BaseAddr[InstanceId]->PLPLOCK[0u] >> (partitionIndex * MRAM_IP_PLCK_FIELD_WIDTH)) & MRAM_IP_PLCK_FIELD_MASK;

        result = MRam_Ip_EvaluatePlckOwnership(plckValue,
                                               &MRamC_Ip_BaseAddr[InstanceId]->LPLOCKOW[partitionIndex],
                                               MRAMC_LPLOCKOW_LOCKOWNER_MASK,
                                               pLockDomainIDValue);
    }
    return result;
}
/**
 * @brief           Checks whether a small partition has valid lock ownership.
 * @param[in]       Partition - Small partition type (including upper/lower designation)
 * @param[out]      pLockDomainIDValue - Pointer to store the domain ID value
 * @param[in]       InstanceId - Hardware instance ID
 * @return          TRUE if partition ownership is valid, FALSE otherwise
 */
static boolean MRam_Ip_IsSmallPartitionOwnershipValid(uint8 *pLockDomainIDValue,
                                                      MRam_Ip_InstanceIdType InstanceId)
{
    /* PLCK field is the low 2 bits of the dedicated PSPLOCK register; the owning
     * domain (when owner-restricted) is read from LOCKOW[0]. */
    uint32 plckValue = MRamC_Ip_BaseAddr[InstanceId]->PSPLOCK & MRAMC_PSPLOCK_PLCK_MASK;

    return MRam_Ip_EvaluatePlckOwnership(plckValue,
                                         &MRamC_Ip_BaseAddr[InstanceId]->LOCKOW[0u],
                                         MRAMC_LOCKOW_LOCKOWNER_MASK,
                                         pLockDomainIDValue);
}

/**
 * @brief           Checks whether the OTP partition has valid lock ownership.
 * @details         Verifies ownership validity in MRAMC controller registers
 *
 * @param[out]      pLockDomainIDValue - Pointer to store the domain ID value
 * @param[in]       InstanceId - Hardware instance ID
 * @return          TRUE if partition ownership is valid, FALSE otherwise
 */
static boolean MRam_Ip_IsOtpPartitionOwnershipValid(uint8 *pLockDomainIDValue, MRam_Ip_InstanceIdType InstanceId)
{
    /* PLCK field is the low 2 bits of the dedicated PLPOLOCK register; the owning
     * domain (when owner-restricted) is read from LOCKOW[1]. */
    uint32 plckValue = MRamC_Ip_BaseAddr[InstanceId]->PLPOLOCK & MRAMC_PLPOLOCK_PLCK_MASK;

    return MRam_Ip_EvaluatePlckOwnership(plckValue,
                                         &MRamC_Ip_BaseAddr[InstanceId]->LOCKOW[1u],
                                         MRAMC_LOCKOW_LOCKOWNER_MASK,
                                         pLockDomainIDValue);
}

/**
 * @brief           Checks whether the UTEST partition has valid lock ownership.
 * @details         Verifies ownership validity in MRAMC controller registers
 *
 * @param[out]      pLockDomainIDValue - Pointer to store the domain ID value
 * @param[in]       InstanceId - Hardware instance ID
 * @return          TRUE if partition ownership is valid, FALSE otherwise
 */
static boolean MRam_Ip_IsUtestPartitionOwnershipValid(uint8 *pLockDomainIDValue, MRam_Ip_InstanceIdType InstanceId)
{
    /* PLCK field is the low 2 bits of the dedicated PUTLOCK register; the owning
     * domain (when owner-restricted) is read from LOCKOW[2]. */
    uint32 plckValue = MRamC_Ip_BaseAddr[InstanceId]->PUTLOCK & MRAMC_PUTLOCK_PLCK_MASK;

    return MRam_Ip_EvaluatePlckOwnership(plckValue,
                                         &MRamC_Ip_BaseAddr[InstanceId]->LOCKOW[2u],
                                         MRAMC_LOCKOW_LOCKOWNER_MASK,
                                         pLockDomainIDValue);
}

/**
 * @brief   Reads the lock-ownership state for a partition.
 *
 * @param[in]  Partition          Partition to query.
 * @param[out] LockDomainIDValue  Receives the owning domain ID (or the unused
 *                                sentinel when there is no specific owner).
 * @param[in]  InstanceId         Hardware instance ID.
 * @return     TRUE if ownership is valid, FALSE otherwise.
 */
static boolean MRam_Ip_GetPartitionOwnership(MRam_Ip_PartitionType Partition,
                                            uint8* LockDomainIDValue,
                                            MRam_Ip_InstanceIdType InstanceId)
{
    boolean isOwnershipValid = FALSE;

    /* Handle large partitions with an algorithmic approach */
    if ((Partition >= MRAM_IP_PARTITION_LARGE_0_LOWER) && (Partition <= MRAM_IP_PARTITION_LARGE_7_UPPER))
    {
        isOwnershipValid = MRam_Ip_IsLargePartitionOwnershipValid(Partition, LockDomainIDValue, InstanceId);
    }
    /* Handle other partition types */
    else if ((Partition >= MRAM_IP_PARTITION_SMALL_LOWER0) && (Partition <= MRAM_IP_PARTITION_SMALL_UPPER1))
    {
        isOwnershipValid = MRam_Ip_IsSmallPartitionOwnershipValid(LockDomainIDValue, InstanceId);
    }
    else if (Partition == MRAM_IP_PARTITION_NS_OTP)
    {
        isOwnershipValid = MRam_Ip_IsOtpPartitionOwnershipValid(LockDomainIDValue, InstanceId);
    }
    else if (Partition == MRAM_IP_PARTITION_UTEST)
    {
        isOwnershipValid = MRam_Ip_IsUtestPartitionOwnershipValid(LockDomainIDValue, InstanceId);
    }
    else
    {
        /* Unknown partition type */
        *LockDomainIDValue = MRAM_IP_UNUSEFUL_DOMAIN_ID;
    }

    return isOwnershipValid;
}

/**
 * @brief   Maps an ownership-check result and domain IDs to an access status.
 *
 * @param[in] isOwnershipValid   TRUE if the partition's lock ownership is valid.
 * @param[in] LockDomainIDValue  Owning domain ID (or the unused sentinel).
 * @param[in] DomainIdValue      Domain ID of the caller requesting access.
 * @return    SUCCESS if access is allowed, else LOCK_OWNERSHIP_NOT_VALID or ERROR.
 */
static MRam_Ip_StatusType MRam_Ip_ValidateDomainAccess(boolean isOwnershipValid,
                                                      uint8 LockDomainIDValue,
                                                      uint8 DomainIdValue)
{
    MRam_Ip_StatusType ReturnCode = MRAM_IP_STATUS_SUCCESS;

    if (isOwnershipValid && (LockDomainIDValue != MRAM_IP_UNUSEFUL_DOMAIN_ID))
    {
        /* Check domain ID validation only if the partition ownership check succeeded and a valid domain ID is present */
        if (LockDomainIDValue != DomainIdValue)
        {
            /* Error: Attempt to modify lock bits by a master with different domain ID */
            ReturnCode = MRAM_IP_STATUS_LOCK_OWNERSHIP_NOT_VALID;
        }
    }
    else if ((isOwnershipValid != TRUE) && (LockDomainIDValue == MRAM_IP_UNUSEFUL_DOMAIN_ID))
    {
        /* Error: Partition cannot be unlocked */
        ReturnCode = MRAM_IP_STATUS_ERROR;
    }
    else
    {
        /* If isOwnershipValid && (LockDomainIDValue == MRAM_IP_UNUSEFUL_DOMAIN_ID), return SUCCESS */
    }

    return ReturnCode;
}

/**
 * @brief   Checks whether the caller's domain may modify the lock at an address.
 *
 * @param[in] Address       MRAM address whose partition lock is checked.
 * @param[in] DomainIdValue Domain ID of the caller.
 * @param[in] InstanceId    Hardware instance ID.
 * @return    SUCCESS if the domain may modify the lock, else an error status.
 */
static MRam_Ip_StatusType MRam_Ip_CheckLockDomainID(MRam_Ip_AddressType Address,
                                                   uint8 DomainIdValue,
                                                   MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType Status;
    uint8 LockDomainIDValue = MRAM_IP_UNUSEFUL_DOMAIN_ID;
    boolean isOwnershipValid = FALSE;
    MRam_Ip_PartitionType Partition;

    Partition = MRam_Ip_GetPartition(Address);

    if (Partition == MRAM_IP_PARTITION_NOT_EXISTS)
    {
        Status = MRAM_IP_STATUS_WRITE_ADDRESS_ERROR;
    }
    else
    {
        /* Get partition ownership information */
        isOwnershipValid = MRam_Ip_GetPartitionOwnership(Partition, &LockDomainIDValue, InstanceId);

        /* Validate domain access */
        Status = MRam_Ip_ValidateDomainAccess(isOwnershipValid, LockDomainIDValue, DomainIdValue);
    }

    return Status;
}

/**
 * @brief           Clears the lock bit for the specified partition.
 *
 * @param[in]       Partition - Partition type to clear lock for
 * @param[in]       InstanceId - Hardware instance ID
 */
static void MRam_Ip_ClearLockBit(MRam_Ip_PartitionType Partition,
                               MRam_Ip_InstanceIdType InstanceId)
{
    uint8 partitionNumber;
    uint32 lockMask;

    /* MULTICORE (MC5): LPLOCK/SPLOCK/LPOLOCK/UTLOCK are shared lock registers,
     * and LPLOCK packs 8 partitions' lock bits into ONE word - so two cores
     * clearing DIFFERENT partitions still RMW the same register and can lose
     * each other's update (a partition left locked -> WRP on its write, or left
     * unlocked -> integrity hole). The STD_OFF auto-lock path does not acquire
     * protect-lock (PLCK) ownership, so nothing arbitrates this cross-core.
     * Guard the RMW with a SHORT exclusive area - a real spinlock is fine here
     * (no blocking waits inside). The symmetric MRam_Ip_SetPartitionLock uses the
     * same area. Placeholder (integration-generated), shown as a comment. */
    /* Integration note: enter the MRam_Ip_LOCKREG exclusive area here (SchM service, integration-generated placeholder). */

    /* Handle large partitions - lower bank */
    if ((Partition >= MRAM_IP_PARTITION_LARGE_0_LOWER) && (Partition <= MRAM_IP_PARTITION_LARGE_7_LOWER))
    {
        /* Extract partition number (0-7) from the partition type */
        partitionNumber = (uint8)Partition - (uint8)MRAM_IP_PARTITION_LARGE_0_LOWER;

        /* Calculate lock mask: (1 << partitionNumber) */
        lockMask = ((uint32)1U << partitionNumber);

        /* Clear the lock bit for this partition */
        MRamC_Ip_BaseAddr[InstanceId]->LPLOCK &= ~lockMask;
    }
    /* Handle large partitions - upper bank */
    else if ((Partition >= MRAM_IP_PARTITION_LARGE_0_UPPER) && (Partition <= MRAM_IP_PARTITION_LARGE_7_UPPER))
    {
        /* Extract partition number (0-7) from the partition type */
        partitionNumber = (uint8)Partition - (uint8)MRAM_IP_PARTITION_LARGE_0_UPPER;

        /* Calculate lock mask: (1 << partitionNumber) */
        lockMask = ((uint32)1U << partitionNumber);

        /* Clear the lock bit for this partition */
        MRamC_Ip_BaseAddr[InstanceId]->LPLOCK &= ~lockMask;
    }
    /* Handle other partition types */
    else
    {
        switch (Partition)
        {
            case MRAM_IP_PARTITION_NS_OTP:
                MRamC_Ip_BaseAddr[InstanceId]->LPOLOCK &= ~MRAMC_LPOLOCK_LCK_MASK;
                break;

            /* Small partitions */
            case MRAM_IP_PARTITION_SMALL_LOWER0:
            case MRAM_IP_PARTITION_SMALL_LOWER1:
            case MRAM_IP_PARTITION_SMALL_UPPER0:
            case MRAM_IP_PARTITION_SMALL_UPPER1:
                MRamC_Ip_BaseAddr[InstanceId]->SPLOCK &= ~MRAMC_SPLOCK_LCK_MASK;
                break;

            case MRAM_IP_PARTITION_UTEST:
                MRamC_Ip_BaseAddr[InstanceId]->UTLOCK &= ~MRAMC_UTLOCK_LCK_MASK;
                break;

            default:
                /* Unsupported partition type */
                break;
        }
    }
    /* Integration note: exit the MRam_Ip_LOCKREG exclusive area here (SchM service, integration-generated placeholder). */
}

/**
 * @brief           Sets the lock on a specific partition (internal).
 *
 * Symmetric counterpart of MRam_Ip_ClearLockBit: both write LPLOCK /
 * SPLOCK / LPOLOCK / UTLOCK directly without domain checks. Compiled
 * unconditionally because the STD_OFF auto-management path in
 * ProcessOperation needs to re-lock partitions even though the public
 * MRam_Ip_SetLock API is not exposed in STD_OFF mode.
 *
 * @param[in]       Partition - Partition to lock
 * @param[in]       InstanceId - Hardware instance ID
 * @param[out]      pSuccess - Pointer to success flag (TRUE if lock set successfully)
 */
static void MRam_Ip_SetPartitionLock(MRam_Ip_PartitionType Partition,
                                   MRam_Ip_InstanceIdType InstanceId,
                                   boolean *pSuccess)
{
    uint8 partitionNumber;
    uint32 lockMask;

    *pSuccess = TRUE;

    /* MULTICORE (MC5): same shared lock-register RMW hazard as ClearLockBit -
     * LPLOCK packs 8 partitions per word, so concurrent SetPartitionLock on
     * different partitions from two cores can lose an update. Guard with the
     * same short exclusive area. Placeholder (integration-generated). */
    /* Integration note: enter the MRam_Ip_LOCKREG exclusive area here (SchM service, integration-generated placeholder). */

    /* Handle large partitions - lower bank */
    if ((Partition >= MRAM_IP_PARTITION_LARGE_0_LOWER) && (Partition <= MRAM_IP_PARTITION_LARGE_7_LOWER))
    {
        /* Extract partition number (0-7) from the partition type */
        partitionNumber = (uint8)Partition - (uint8)MRAM_IP_PARTITION_LARGE_0_LOWER;

        /* Calculate lock mask: (1 << partitionNumber) */
        lockMask = ((uint32)1U << partitionNumber);

        /* Set the lock bit for this partition */
        MRamC_Ip_BaseAddr[InstanceId]->LPLOCK |= lockMask;
    }
    /* Handle large partitions - upper bank */
    else if ((Partition >= MRAM_IP_PARTITION_LARGE_0_UPPER) && (Partition <= MRAM_IP_PARTITION_LARGE_7_UPPER))
    {
        /* Extract partition number (0-7) from the partition type */
        partitionNumber = (uint8)Partition - (uint8)MRAM_IP_PARTITION_LARGE_0_UPPER;

        /* Calculate lock mask: (1 << partitionNumber) */
        lockMask = ((uint32)1U << partitionNumber);

        /* Set the lock bit for this partition */
        MRamC_Ip_BaseAddr[InstanceId]->LPLOCK |= lockMask;
    }
    /* Handle other partition types */
    else
    {
        switch (Partition)
        {
            case MRAM_IP_PARTITION_NS_OTP:
                MRamC_Ip_BaseAddr[InstanceId]->LPOLOCK = MRAMC_LPOLOCK_LCK_MASK;
                break;

            /* Small partitions */
            case MRAM_IP_PARTITION_SMALL_LOWER0:
            case MRAM_IP_PARTITION_SMALL_LOWER1:
            case MRAM_IP_PARTITION_SMALL_UPPER0:
            case MRAM_IP_PARTITION_SMALL_UPPER1:
                MRamC_Ip_BaseAddr[InstanceId]->SPLOCK = MRAMC_SPLOCK_LCK_MASK;
                break;

            case MRAM_IP_PARTITION_UTEST:
                MRamC_Ip_BaseAddr[InstanceId]->UTLOCK = MRAMC_UTLOCK_LCK_MASK;
                break;

            default:
                /* Unsupported partition type */
                *pSuccess = FALSE;
                break;
        }
    }

    /* Verify the lock write actually took effect.
     * Lock writes (LPLOCK/SPLOCK/LPOLOCK/UTLOCK) can be silently dropped by the
     * hardware if the corresponding Protect-Lock register (PLPLOCK/PSPLOCK/
     * PLPOLOCK/PUTLOCK) is configured to deny modification. Without this
     * read-back the STD_OFF re-lock path (ConfigureLocksInRange -> Phase 6)
     * would report SUCCESS while leaving the partition UNLOCKED, so the caller
     * never raises MRAM_IP_STATUS_PARTITION_LOCK_RESTORE_FAILED. Mirror the
     * verification already done by the public MRam_Ip_SetLock API: re-read the
     * bit we just wrote and confirm it now reads back as set. Only performed
     * for a recognized partition type (pSuccess still TRUE). */
    if (*pSuccess == TRUE)
    {
        if (MRam_Ip_CheckMramcLock(Partition, InstanceId) != TRUE)
        {
            *pSuccess = FALSE;
        }
    }
    /* Integration note: exit the MRam_Ip_LOCKREG exclusive area here (SchM service, integration-generated placeholder). */
}

/**
 * @brief       Decode a raw ERRSTAT0 register value into a driver status code.
 * @details     Pure function: it only inspects the supplied value, it does NOT
 *              read or write any hardware register. Returns the highest-priority
 *              error encoded in the value, or MRAM_IP_STATUS_SUCCESS if none.
 *
 *              This decode is shared by two consumers that must agree on the
 *              mapping:
 *                1. MRam_Ip_DecodeAndClearErrstat0 - reads ERRSTAT0 live and
 *                   clears it.
 *                2. The async-error mailbox consumer in ProcessOperation - the
 *                   ISR captured the ERRSTAT0 snapshot (and already cleared the
 *                   real register), so the driver decodes that snapshot here
 *                   without touching hardware.
 *              Keeping the priority table in one place guarantees both paths
 *              report the same code for the same bits.
 *
 * @param[in]   statusReg  Raw ERRSTAT0 value (live read or ISR snapshot).
 * @return      Highest priority error, or MRAM_IP_STATUS_SUCCESS if no error bit set.
 */
static MRam_Ip_StatusType MRam_Ip_DecodeErrstat0(uint32 statusReg)
{
    /* Result: highest-priority error found, SUCCESS if none. */
    MRam_Ip_StatusType errorsFound = MRAM_IP_STATUS_SUCCESS;

    uint32 i;

    /* Error flags ordered by priority: first match determines the return value */
    const MRam_Ip_ErrorMaskMappingType errorMasks[] = {
        {MRAMC_ERRSTAT0_RE_MASK,    MRAM_IP_STATUS_ERROR_READ_PATH},         /* Error on read path */
        {MRAMC_ERRSTAT0_WE_MASK,    MRAM_IP_STATUS_ERROR_WRITE_PATH},        /* Error on write path */
        {MRAMC_ERRSTAT0_PWE_MASK,   MRAM_IP_STATUS_POSTED_WRITE_ERROR},      /* Posted write error */
        {MRAMC_ERRSTAT0_CPE_MASK,   MRAM_IP_STATUS_ERROR_CONTROL_PARITY},    /* Control parity error */
        {MRAMC_ERRSTAT0_CEE_MASK,   MRAM_IP_STATUS_ECC_CONTROL_ERROR},       /* Control ECC error */
        {MRAMC_ERRSTAT0_DEE_MASK,   MRAM_IP_STATUS_ECC_READ_DATA},           /* Data ECC error */
        {MRAMC_ERRSTAT0_MCE_MASK,   MRAM_IP_STATUS_ERROR_MRAM_CONTROLLER},   /* MRAM controller error */
        {MRAMC_ERRSTAT0_ME_MASK,    MRAM_IP_STATUS_MRAM_MACRO_ERROR},        /* MRAM macro reported an error - aggregate of WRE/EER/AEE; caller should inspect MCRS for specific cause */
        {MRAMC_ERRSTAT0_MEEE_MASK,  MRAM_IP_STATUS_ECC_EDC_AFTER_ECC_ERROR}, /* EDC after ECC error */
        {MRAMC_ERRSTAT0_UE_MASK,    MRAM_IP_STATUS_ERROR_USER_CONFIG}        /* User configuration error */
    };

    const uint32 numErrorMasks = sizeof(errorMasks) / sizeof(MRam_Ip_ErrorMaskMappingType);

    for (i = 0u; i < numErrorMasks; i++)
    {
        if ((statusReg & errorMasks[i].registerMask) != 0u)
        {
            /* Table is in priority order, so the first hit is the code to report. */
            errorsFound = errorMasks[i].status;
            break;
        }
    }

    return errorsFound;
}

/* ============================================================================
 * ERRSTAT0 path-decode masks
 * ----------------------------------------------------------------------------
 * ERRSTAT0 is one shared register that mixes errors from different paths. A
 * write/erase Status must be decoded only from write-relevant bits, and a read
 * Status only from read-relevant bits - otherwise the returned code can
 * describe the wrong path entirely. MRam_Ip_DecodeErrstat0 ranks the RE/WE
 * summary bits above every specific cause, so a stray RE left in the register
 * by another master's read would otherwise mask the real write error.
 *
 * Classification, taken from the ERRSTAT0 field descriptions:
 *   RE   - RM: "Read Error ... error on read path."             -> read only
 *   DEE  - RM: "Data ECC Error ... ECC error on read data."     -> read only
 *   MEEE - RM: "MRAM EDC After ECC Error ... from MRAM."         -> read only
 *   WE   - RM: "Write Error ... error on write path."            -> write only
 *   PWE  - RM: "Posted Write Error ... posted (bufferable) write"-> write only
 *   CPE/CEE/MCE - control/address request-path errors            -> both
 *   ME   - RM: "MRAM Error ... write verify (WRE) for write, OR
 *          uncorrectable read ECC (EER) for read, OR address
 *          encode (AEE) for read."                               -> both
 *   UE   - RM: "User error ... user configuration error."        -> both
 *
 * Why ME stays on BOTH paths: on a write it means WRE (write-verify failure) -
 * the single most important write error - and on a read it means EER/AEE. The
 * caller inspects MCRS for the exact cause. Dropping ME from the write path
 * would hide write-verify failures, so it must NOT be treated as a read bit.
 * ========================================================================== */

/* Full set of ERRSTAT0 error bits this driver handles - the W1C clear set
 * (no reserved bits touched). Equals the union of the read and write masks.
 * Object-like macro (rvalue-only constant), not a file-scope object. */
#define MRam_Ip_Errstat0AllKnownErrors ((uint32)( \
    MRAMC_ERRSTAT0_RE_MASK  | MRAMC_ERRSTAT0_WE_MASK   | MRAMC_ERRSTAT0_PWE_MASK | \
    MRAMC_ERRSTAT0_CPE_MASK | MRAMC_ERRSTAT0_CEE_MASK  | MRAMC_ERRSTAT0_DEE_MASK | \
    MRAMC_ERRSTAT0_MCE_MASK | MRAMC_ERRSTAT0_ME_MASK   | MRAMC_ERRSTAT0_MEEE_MASK | \
    MRAMC_ERRSTAT0_UE_MASK))

/* Bits a WRITE/ERASE may report as its Status: the write-side + shared error
 * bits, EXCLUDING the read-side-only bits RE, DEE, MEEE (those are raised only
 * by read operations; despite the name they are W1C, not register-read-only). */
#define MRam_Ip_Errstat0WriteDecodeMask ((uint32)( \
    MRAMC_ERRSTAT0_WE_MASK  | MRAMC_ERRSTAT0_PWE_MASK | MRAMC_ERRSTAT0_CPE_MASK | \
    MRAMC_ERRSTAT0_CEE_MASK | MRAMC_ERRSTAT0_MCE_MASK | MRAMC_ERRSTAT0_ME_MASK  | \
    MRAMC_ERRSTAT0_UE_MASK))

/* Bits a READ may report as its Status: the read-side + shared error bits,
 * EXCLUDING the write-side-only bits WE, PWE. */
#define MRam_Ip_Errstat0ReadDecodeMask ((uint32)( \
    MRAMC_ERRSTAT0_RE_MASK  | MRAMC_ERRSTAT0_DEE_MASK | MRAMC_ERRSTAT0_MEEE_MASK | \
    MRAMC_ERRSTAT0_CPE_MASK | MRAMC_ERRSTAT0_CEE_MASK | MRAMC_ERRSTAT0_MCE_MASK  | \
    MRAMC_ERRSTAT0_ME_MASK  | MRAMC_ERRSTAT0_UE_MASK))

/**
 * @brief       Read ERRSTAT0, decode the path-relevant error, clear all flags.
 * @details     Shared core for the read- and write-path controller-error
 *              helpers. It always W1C-clears EVERY known error bit currently
 *              set (so no flag is left behind for the next caller), but DECODES a
 *              status code only from the bits selected by DecodeMask.
 *
 *              Why decode is masked but the clear is not: ERRSTAT0 mixes read-,
 *              write- and shared-path bits. Each caller passes the mask for ITS
 *              path, so a write never returns a read-path code and a read never
 *              returns a write-path code. Clearing stays global because leaving
 *              a foreign bit set would only let a later operation mis-attribute
 *              it to itself.
 *
 * @param[in]   InstanceId  MRAM controller instance identifier
 * @param[in]   DecodeMask  Subset of ERRSTAT0 error bits to decode for this path
 * @return      Highest-priority error within DecodeMask, or SUCCESS if none.
 */
static MRam_Ip_StatusType MRam_Ip_DecodeAndClearErrstat0(MRam_Ip_InstanceIdType InstanceId, uint32 DecodeMask)
{
    /* MULTICORE: the ERRSTAT0 read here and the W1C clear below must be atomic
     * against the error ISR (MRam_Ip_ProcessIrq) and Phase 6c possibly running
     * on another core - guarded by the SAME exclusive area as those.
     * The ME->MCRS resolution further down runs OUTSIDE this area (it enters the
     * separate MCRS area inside GetMemoryErrorStatus), so the two areas are
     * acquired sequentially, never nested -> no lock-ordering deadlock. */

    /* Live snapshot of ERRSTAT0, read once for a consistent view. */
    uint32 statusReg = MRamC_Ip_BaseAddr[InstanceId]->ERRSTAT0;

    /* Highest-priority error among ONLY this path's bits. */
    MRam_Ip_StatusType errorsFound = MRam_Ip_DecodeErrstat0(statusReg & DecodeMask);

    /* Specific MCRS cause used to resolve the generic ME aggregate (see below).
     * Defaults SUCCESS so a clean MCRS leaves errorsFound untouched. */
    MRam_Ip_StatusType macroCause = MRAM_IP_STATUS_SUCCESS;

    /* Every known error bit present, cleared W1C in one write regardless of
     * DecodeMask. All listed bits are W1C (unlike MCRS RE/RSE), so no
     * read-only filtering is needed. */
    uint32 clearMask = statusReg & MRam_Ip_Errstat0AllKnownErrors;

    /* Integration note: enter the MRam_Ip_ERRSTAT0_MAILBOX exclusive area here (SchM service, integration-generated placeholder). */

    if (clearMask != 0u)
    {
        MRamC_Ip_BaseAddr[InstanceId]->ERRSTAT0 = clearMask;
    }
    /* Integration note: exit the MRam_Ip_ERRSTAT0_MAILBOX exclusive area here (SchM service, integration-generated placeholder). */

    /* ERRSTAT0[ME] is only a summary bit. RM: "MRAM Error ... write verify
     * (WRE) for write, OR uncorrectable read ECC (EER) for read, OR address
     * encode (AEE) for read" - the real cause always lives in MCRS. Reporting
     * the generic MRAM_MACRO_ERROR would hide which of those it was (and the
     * ECC severity SBC/DBC/TBC), so when the decode lands on the ME aggregate
     * we consult MCRS and return its specific code instead. MRAM_MACRO_ERROR
     * survives only as a last-resort fallback for the race/edge where ME is set
     * but the MCRS macro flags are already gone.
     *
     * Path behaviour:
     *   - Read path: MCRS still holds the cause (e.g. EER) here, so this
     *     upgrades MACRO to the precise ECC_UNCORRECTED / ADDRESS_ENCODE_ERROR.
     *   - Write path: the completion checker already read+cleared MCRS before
     *     ERRSTAT0 is consulted, so MCRS reads clean and we keep MACRO - but the
     *     specific code was already returned by that MCRS-first read, so nothing
     *     is lost (no regression). */
    if (errorsFound == MRAM_IP_STATUS_MRAM_MACRO_ERROR)
    {
        macroCause = MRam_Ip_GetMemoryErrorStatus();
        if (macroCause != MRAM_IP_STATUS_SUCCESS)
        {
            errorsFound = macroCause;
        }
    }

    return errorsFound;
}

/**
 * @brief   Write/erase-path controller-error retrieval that yields ERRSTAT0
 *          ownership to the error ISR when interrupts are enabled.
 * @details Why a separate variant from MRam_Ip_DecodeAndClearErrstat0:
 *
 *          When MRAMC error interrupts are enabled, the ISR
 *          (MRam_Ip_ProcessIrq) runs at a higher priority than the thread
 *          performing a write/erase. The ISR reads and W1C-clears ERRSTAT0 the
 *          moment an enabled error fires. If the write/erase path also read and
 *          cleared ERRSTAT0 mid-operation, two things would go wrong:
 *            1. It would race the ISR for the same W1C register.
 *            2. Whichever ran first would consume the flag, so the error would
 *               reach the caller through only ONE channel instead of being
 *               handled cleanly by the ISR.
 *          So when interrupts are enabled we do NOT touch ERRSTAT0 here: we
 *          return SUCCESS and let the ISR capture the error into the async
 *          mailbox, which ProcessOperation promotes into Status at the end of
 *          the operation (Phase 6c). The ISR always wins the race, by design.
 *
 *          When interrupts are disabled, no ISR runs, so this behaves exactly
 *          like MRam_Ip_DecodeAndClearErrstat0 (read + W1C clear) - that is
 *          the only way the error can be observed at all.
 *
 *          IMPORTANT: only the write/erase path may use this. The Read path
 *          must keep calling MRam_Ip_DecodeAndClearErrstat0 directly, because
 *          the read-path errors RE and WE have NO notification-enable bit in
 *          ERRNTCTL0 and therefore never raise an interrupt - the mailbox would
 *          never receive them, so the Read path must always read ERRSTAT0 itself.
 *
 *          Precondition: MRam_Ip_Config is non-NULL. The write/erase entry
 *          points validate this (ERROR_NOT_INITIALIZED) before any path that
 *          reaches this helper.
 *
 * @param[in]   InstanceId  MRAM controller instance identifier
 * @return      MRAM_IP_STATUS_SUCCESS when interrupts are enabled (ISR owns the
 *              error), otherwise the decoded ERRSTAT0 status.
 */
static MRam_Ip_StatusType MRam_Ip_GetControllerErrorStatusWrite(MRam_Ip_InstanceIdType InstanceId)
{
    /* Result: SUCCESS when the ISR owns ERRSTAT0, else the live decode. */
    MRam_Ip_StatusType status = MRAM_IP_STATUS_SUCCESS;

    if (MRam_Ip_Config->MRamControllerConfig.MRamCInterruptsEnabled != TRUE)
    {
        /* No ISR will run: the write/erase path is the only observer, so we read
         * and clear ERRSTAT0 ourselves. Decode only write-relevant bits so a
         * read-path error (RE/DEE/MEEE) set by a concurrent reader on another
         * port is NOT reported as this write/erase's Status. The register is
         * still fully cleared — only the decoded code is path-restricted. */
        MRam_Ip_StatusType decodedStatus = MRam_Ip_DecodeAndClearErrstat0(InstanceId, MRam_Ip_Errstat0WriteDecodeMask);

        /* The decoded controller error status is tested here. A
         * genuine error is propagated to the caller through the return value;
         * SUCCESS is kept otherwise. */
        if (decodedStatus != MRAM_IP_STATUS_SUCCESS)
        {
            status = decodedStatus;
        }
    }
    /* else: interrupts enabled -> leave ERRSTAT0 to the ISR; the mailbox +
     * Phase 6c will surface any error into Status. */

    return status;
}

/**
 * @brief   Enables MRAM controller error-notification interrupts.
 * @details Clears any pending ERRSTAT0 flags first, then enables the per-error
 *          notification bits in ERRNTCTL0.
 *
 * @param[in] InstanceId         Hardware instance ID.
 * @param[in] InterruptsEnabled  TRUE enables the interrupts; FALSE does nothing.
 */
static void MRam_Ip_EnableInterrupts(const MRam_Ip_InstanceIdType InstanceId, const boolean InterruptsEnabled)
{
    if (InterruptsEnabled == TRUE)
    {
    /* First clear any pending errors in ERRSTAT0 */
    MRamC_Ip_BaseAddr[InstanceId]->ERRSTAT0  = MRAMC_ERRSTAT0_RE_MASK |
                                               MRAMC_ERRSTAT0_WE_MASK  |
                                               MRAMC_ERRSTAT0_PWE_MASK |
                                               MRAMC_ERRSTAT0_CPE_MASK |
                                               MRAMC_ERRSTAT0_CEE_MASK |
                                               MRAMC_ERRSTAT0_DEE_MASK |
                                               MRAMC_ERRSTAT0_MCE_MASK |
                                               MRAMC_ERRSTAT0_ME_MASK  |
                                               MRAMC_ERRSTAT0_MEEE_MASK |
                                               MRAMC_ERRSTAT0_UE_MASK;

    /* Enable the per-error notification bits in ERRNTCTL0 */
    MRamC_Ip_BaseAddr[InstanceId]->ERRNTCTL0 = MRAMC_ERRNTCTL0_PWENE_MASK |
                                                 MRAMC_ERRNTCTL0_CPENE_MASK |
                                               MRAMC_ERRNTCTL0_CEENE_MASK |
                                               MRAMC_ERRNTCTL0_DEENE_MASK |
                                               MRAMC_ERRNTCTL0_MCENE_MASK |
                                               MRAMC_ERRNTCTL0_MENE_MASK  |
                                               MRAMC_ERRNTCTL0_MEEENE_MASK |
                                               MRAMC_ERRNTCTL0_UENE_MASK;
    }
}

/**
 * @brief   Disables MRAM controller error-notification interrupts.
 * @details Clears the ERRNTCTL0 notification-enable bits, then clears any
 *          pending ERRSTAT0 flags.
 *
 * @param[in] InstanceId  Hardware instance ID.
 */
static void MRam_Ip_DisableInterrupts(const MRam_Ip_InstanceIdType InstanceId)
{
    MRamC_Ip_BaseAddr[InstanceId]->ERRNTCTL0 = ~(MRAMC_ERRNTCTL0_PWENE_MASK |
                                                MRAMC_ERRNTCTL0_CPENE_MASK |
                                                MRAMC_ERRNTCTL0_CEENE_MASK |
                                                MRAMC_ERRNTCTL0_DEENE_MASK |
                                                MRAMC_ERRNTCTL0_MCENE_MASK |
                                                MRAMC_ERRNTCTL0_MENE_MASK  |
                                                MRAMC_ERRNTCTL0_MEEENE_MASK |
                                                MRAMC_ERRNTCTL0_UENE_MASK);

    /* clear any pending errors in ERRSTAT0 */
    MRamC_Ip_BaseAddr[InstanceId]->ERRSTAT0 = MRAMC_ERRSTAT0_RE_MASK |
                                              MRAMC_ERRSTAT0_WE_MASK  |
                                              MRAMC_ERRSTAT0_PWE_MASK |
                                              MRAMC_ERRSTAT0_CPE_MASK |
                                              MRAMC_ERRSTAT0_CEE_MASK |
                                              MRAMC_ERRSTAT0_DEE_MASK |
                                              MRAMC_ERRSTAT0_MCE_MASK |
                                              MRAMC_ERRSTAT0_ME_MASK  |
                                              MRAMC_ERRSTAT0_MEEE_MASK |
                                              MRAMC_ERRSTAT0_UE_MASK;
}


/**
 * @brief Helper function to get next boundary for large partitions
 *
 * Handles the logic for determining the next partition boundary for large partitions
 * (LARGE_0 through LARGE_7). Large partitions are interleaved every 32 bytes.
 *
 * @param[in] CurrentPartition The current large partition type
 * @param[in] Address         Current address within the partition
 * @return MRam_Ip_AddressType Next partition boundary address
 */
static MRam_Ip_AddressType MRam_Ip_GetNextLargePartitionBoundary(MRam_Ip_PartitionType CurrentPartition, MRam_Ip_AddressType Address)
{
    MRam_Ip_AddressType NextAddress = 0U;

    /*
     * Large partition enum values are structured:
     * LOWER: 1..8   (MRAM_IP_PARTITION_LARGE_0_LOWER to MRAM_IP_PARTITION_LARGE_7_LOWER)
     * UPPER: 9..16  (MRAM_IP_PARTITION_LARGE_0_UPPER to MRAM_IP_PARTITION_LARGE_7_UPPER)
     *
     * Pair index = (partition_value - 1) % 8  (works for both LOWER and UPPER)
     */
    uint32 partitionVal = (uint32)CurrentPartition;
    uint32 pairIndex;
    MRam_Ip_AddressType pairEnd;
    MRam_Ip_AddressType nextPairStart;

    /* Validate this is a large partition (LOWER: 1-8, UPPER: 9-16) */
    if ((partitionVal >= (uint32)MRAM_IP_PARTITION_LARGE_0_LOWER) &&
        (partitionVal <= (uint32)MRAM_IP_PARTITION_LARGE_7_UPPER))
    {
        /* Compute pair index (0-7) from partition enum value */
        pairIndex = (partitionVal - 1U) % 8U;

        /* Compute pair end address: base + (pairIndex + 1) * pair_size - 1 */
        pairEnd = MRAM_IP_CODE_START + ((pairIndex + 1U) * MRAM_IP_LARGE_PAIR_SIZE) - 1U;

        /* Compute next pair start: for pairs 0-6 it's pairEnd + 1, for pair 7 it's small partition start */
        if (pairIndex < 7U)
        {
            nextPairStart = pairEnd + 1U;
        }
        else
        {
            /* Last large pair (7) transitions to small partitions */
            nextPairStart = MRAM_IP_SMALL_LOWER0_START;
        }

        /* Calculate next boundary address */
        if (Address < pairEnd)
        {
            /* Find next 32-byte boundary which changes the partition */
            NextAddress = (Address & ~MRAM_IP_INTERLEAVE_ALIGNMENT_MASK) + MRAM_IP_INTERLEAVE_PAGE_SIZE;

            /* If we've reached the end of this pair, jump to next pair */
            if (NextAddress > pairEnd)
            {
                NextAddress = nextPairStart;
            }
        }
        else
        {
            /* Address is beyond pair end, jump to next pair */
            NextAddress = nextPairStart;
        }
    }
    /* else: Unknown large partition type - keep NextAddress as 0 (end of memory) */

    return NextAddress;
}


/**
 * @brief Helper function to get next boundary for small partitions
 *
 * Handles the logic for determining the next partition boundary for small partitions
 * (SMALL_LOWER0, SMALL_LOWER1, SMALL_UPPER0, SMALL_UPPER1). Small partitions are not interleaved.
 *
 * @param[in] CurrentPartition The current small partition type
 * @return MRam_Ip_AddressType Next partition boundary address
 */
static MRam_Ip_AddressType MRam_Ip_GetNextSmallPartitionBoundary(MRam_Ip_PartitionType CurrentPartition)
{
    MRam_Ip_AddressType NextAddress;

    if (CurrentPartition == MRAM_IP_PARTITION_SMALL_LOWER0)
    {
        /* Next boundary is start of SMALL_LOWER1 partition */
        NextAddress = MRAM_IP_SMALL_LOWER1_START;
    }
    else if (CurrentPartition == MRAM_IP_PARTITION_SMALL_LOWER1)
    {
        /* Next boundary is start of SMALL_UPPER0 partition */
        NextAddress = MRAM_IP_SMALL_UPPER0_START;
    }
    else if (CurrentPartition == MRAM_IP_PARTITION_SMALL_UPPER0)
    {
        /* Next boundary is start of SMALL_UPPER1 partition */
        NextAddress = MRAM_IP_SMALL_UPPER1_START;
    }
    else if (CurrentPartition == MRAM_IP_PARTITION_SMALL_UPPER1)
    {
        /* Next boundary is start of OTP partition */
        NextAddress = MRAM_IP_OTP_LOWER_LARGE_START;
    }
    /* Unknown small partition type */
    else
    {
        NextAddress = 0U;
    }

    return NextAddress;
}

/**
 * @brief Helper function to get next boundary for special partitions
 *
 * Handles the logic for determining the next partition boundary for special partitions
 * (OTP and UTEST partitions).
 *
 * @param[in] CurrentPartition The current special partition type
 * @param[in] Address         Current address within the partition
 * @return MRam_Ip_AddressType Next partition boundary address
 */
static MRam_Ip_AddressType MRam_Ip_GetNextSpecialPartitionBoundary(MRam_Ip_PartitionType CurrentPartition, MRam_Ip_AddressType Address)
{
    MRam_Ip_AddressType NextAddress;

    if (CurrentPartition == MRAM_IP_PARTITION_NS_OTP)
    {
        if (Address < MRAM_IP_OTP_LOWER_LARGE_END)
        {
            /* Next boundary is start of upper OTP range */
            NextAddress = MRAM_IP_OTP_UPPER_LARGE_START;
        }
        else if (Address < MRAM_IP_OTP_UPPER_LARGE_END)
        {
            /* Next boundary is start of UTEST partition */
            NextAddress = MRAM_IP_UTEST_START;
        }
        else
        {
            /* Next boundary is start of UTEST partition */
            NextAddress = MRAM_IP_UTEST_START;
        }
    }
    else if (CurrentPartition == MRAM_IP_PARTITION_UTEST)
    {
        /* UTEST is the last partition, so end of memory */
        NextAddress = 0U; /* End of memory */
    }
    /* Unknown special partition type */
    else
    {
        NextAddress = 0U; /* End of memory */
    }

    return NextAddress;
}

/**
 * @brief Gets the address of the next partition boundary after the given address
 *
 * This function efficiently determines the next partition boundary by using knowledge
 * of the memory map and partition sizes rather than small incremental steps.
 *
 * @param[in] Address          Current address
 * @return MRam_Ip_AddressType Address of the next partition boundary, or 0 if end of addressable memory
 */
static MRam_Ip_AddressType MRam_Ip_GetNextPartitionBoundary(MRam_Ip_AddressType Address)
{
    MRam_Ip_PartitionType CurrentPartition = MRam_Ip_GetPartition(Address);

    /* Initialize result to 0 (end of addressable memory) */
    MRam_Ip_AddressType NextAddress = 0U; /* Default to end of addressable memory */

    /* Check if current address is in any valid partition */
    if (CurrentPartition != MRAM_IP_PARTITION_NOT_EXISTS)
    {
        /* Check if it's a large partition (LARGE_0 through LARGE_7, both upper and lower) */
        if (CurrentPartition <= MRAM_IP_PARTITION_LARGE_7_UPPER)
        {
            /* Handle large partition boundary calculation */
            NextAddress = MRam_Ip_GetNextLargePartitionBoundary(CurrentPartition, Address);
        }
        /* Check if it's a small partition (SMALL_LOWER0 through SMALL_UPPER1) */
        else if (CurrentPartition <= MRAM_IP_PARTITION_SMALL_UPPER1)
        {
            /* Handle small partition boundary calculation */
            NextAddress = MRam_Ip_GetNextSmallPartitionBoundary(CurrentPartition);
        }
        /* Handle special partitions (OTP, UTEST) */
        else
        {
            /* Handle special partition boundary calculation */
            NextAddress = MRam_Ip_GetNextSpecialPartitionBoundary(CurrentPartition, Address);
        }
    }
    /* else: CurrentPartition == MRAM_IP_PARTITION_NOT_EXISTS, NextAddress remains 0 */

    return NextAddress;
}

/**
 * @brief Sets or clears locks for all partitions in a given address range
 *
 * This function identifies all partitions in the specified address range and
 * attempts to set or clear the locks for each of them based on the SetLock parameter.
 * This ensures proper access control for operations that span multiple partitions.
 *
 * @param[in] StartAddress     Starting address of the range
 * @param[in] SizeInBytes      Size of the range in bytes
 * @param[in] DomainId         Domain ID for permission checking
 * @param[in] SetLock          TRUE to set locks, FALSE to clear locks
 * @param[in] InstanceId       Hardware instance ID
 *
 * @return MRam_Ip_StatusType  MRAM_IP_STATUS_SUCCESS if all locks were configured successfully,
 *                             appropriate error code otherwise
 */
static MRam_Ip_StatusType MRam_Ip_ConfigureLocksInRange(
    MRam_Ip_AddressType StartAddress,
    MRam_Ip_LengthType SizeInBytes,
    uint8 DomainId,
    boolean SetLock,
    MRam_Ip_InstanceIdType InstanceId)
{
    /* Final return status of the lock-configuration walk over the address range. */
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;

    /* Last address in the requested range (StartAddress + SizeInBytes - 1). */
    MRam_Ip_AddressType EndAddress;

    /* Address currently being mapped to a partition during the walk. */
    MRam_Ip_AddressType CurrentAddress;

    /* Partition that CurrentAddress maps to for the current loop iteration. */
    MRam_Ip_PartitionType CurrentPartition;

    /* Single-bit mask (1 << CurrentPartition) used to test and update processedPartitions. */
    uint32 partitionBit;

    /* processedPartitions: bitmap so each distinct partition is locked/unlocked
     * at most once per call. Bit N (partition enum value) is set after the
     * SetLock/ClearLock for that partition.
     *
     * De-dup is needed because LARGE partitions interleave LOWER/UPPER banks
     * every 32 bytes (IS_UPPER_BANK tests address bit 5) and the boundary walk
     * steps by 32 bytes, so a range revisits the same two partitions repeatedly.
     *
     * GetPartition maps every address to a partition. For LARGE partitions
     * the hardware interleaves LOWER and UPPER banks every 32 bytes -
     * IS_UPPER_BANK at the top of this file tests address bit 5:
     *
     *     addr 0x08000000  bit5=0  ->  LARGE_0_LOWER
     *     addr 0x08000020  bit5=1  ->  LARGE_0_UPPER
     *     addr 0x08000040  bit5=0  ->  LARGE_0_LOWER
     *     addr 0x08000060  bit5=1  ->  LARGE_0_UPPER
     *     ...
     *
     * GetNextPartitionBoundary advances by 32 bytes inside a LARGE pair,
     * so a range that spans a LARGE pair visits the same two partitions
     * over and over. The bitmap lets us recognize "already processed" no
     * matter how the addresses interleave.
     *
     * --- Bitmap width ------------------------------------------
     *
     * MRam_Ip_PartitionType values (see MRam_Ip_Types.c):
     *     NOT_EXISTS=0, LARGE_x_LOWER=1..8, LARGE_x_UPPER=9..16,
     *     SMALL_*=17..20, NS_OTP=21, UTEST=22
     *
     * Maximum is 22, comfortably within the 32 bits of a uint32. NOT_EXISTS
     * is handled separately so bit 0 is unused.
     *
     * --- Trace for a 256-byte operation at 0x08000000 ---------
     *
     *   Iter | Address     | Partition       | Bit       | Bitmap before | Action  | Bitmap after
     *   -----+-------------+-----------------+-----------+---------------+---------+--------------
     *      1 | 0x08000000  | LARGE_0_LOWER=1 | 0x0000002 | 0x0000000     | Lock op | 0x0000002
     *      2 | 0x08000020  | LARGE_0_UPPER=9 | 0x0000200 | 0x0000002     | Lock op | 0x0000202
     *      3 | 0x08000040  | LARGE_0_LOWER   | 0x0000002 | 0x0000202     | Skip    | 0x0000202
     *      4 | 0x08000060  | LARGE_0_UPPER   | 0x0000200 | 0x0000202     | Skip    | 0x0000202
     *      5 | 0x08000080  | LARGE_0_LOWER   | 0x0000002 | 0x0000202     | Skip    | 0x0000202
     *     ...                                                              (all Skip)
     *
     *   -> 2 SetLock/ClearLock calls across 8 iterations.
     *
     * --- Note for future maintainers ---------------------------
     *
     * If MRam_Ip_PartitionType ever grows past 31 entries, `1uL << N`
     * becomes undefined behavior. Widen the bitmap (e.g. uint64) or add
     * an explicit bound check before the shift.
     * ================================================================ */
    uint32 processedPartitions = 0u;

#if (STD_ON != MRAM_IP_PARTITION_SET_LOCK_API)
    /* TRUE when the internal MRam_Ip_SetPartitionLock helper successfully
     * set the lock bit for the current partition.
     *
     * Only declared (and only used) in STD_OFF mode, because that is the
     * only mode where ConfigureLocksInRange calls SetPartitionLock
     * directly. In STD_ON mode this function is called with SetLock=FALSE
     * only (driver does not auto-lock; user manages via MRam_Ip_SetLock). */
    boolean LockSetOk = FALSE;
#endif

    /* Calculate end address (being careful about potential overflow) */
    EndAddress = (StartAddress + SizeInBytes - 1U);

    /* Validate end address is not less than start address (would indicate overflow) */
    if (EndAddress >= StartAddress)
    {
        /* Start with the first address */
        CurrentAddress = StartAddress;

        /* Process each partition in the range */
        while ((CurrentAddress <= EndAddress) && (Status == MRAM_IP_STATUS_SUCCESS) && (CurrentAddress != 0U))
        {
            /* Get the partition for the current address */
            CurrentPartition = MRam_Ip_GetPartition(CurrentAddress);

            /* Compute bit position for this partition in the bitmap.
             * Safe because all known enum values are < 32 (max 22 = UTEST). */
            partitionBit = (1uL << (uint32)CurrentPartition);

            /* Skip if this is an invalid partition or we've already processed it */
            if ((CurrentPartition == MRAM_IP_PARTITION_NOT_EXISTS) ||
                ((processedPartitions & partitionBit) != 0u))
            {
                /* Move to the next partition boundary */
                CurrentAddress = MRam_Ip_GetNextPartitionBoundary(CurrentAddress);
                continue;
            }
            /* Dispatch on SetLock direction. Both branches are compiled
             * unconditionally; the STD_ON gating only applies to the
             * "explicitly locked" early-out (which depends on the public
             * Set-Lock API contract) and to the choice of which set-path
             * to call.
             *
             * SetLock semantics by mode:
             *   STD_ON  - Driver does NOT auto-manage locks. The user
             *             calls MRam_Ip_ClearLock manually before
             *             write/erase and MRam_Ip_SetLock manually
             *             after. ProcessOperation's Phase 2 and Phase 6
             *             are both #if STD_OFF, so they do not invoke
             *             this function at all in STD_ON mode. The code
             *             below is therefore dead in STD_ON - kept
             *             compiled for symmetry and to keep this
             *             function self-contained if a future caller
             *             needs the dispatcher in STD_ON.
             *   STD_OFF - Driver auto-manages: Phase 2 calls with FALSE
             *             (unlock), Phase 6 calls with TRUE (re-lock).
             *             MRam_Ip_SetLock is not in the binary, so the
             *             internal MRam_Ip_SetPartitionLock helper is
             *             used directly. */
            if (SetLock)
            {
#if (STD_ON == MRAM_IP_PARTITION_SET_LOCK_API)
                /* Public Lock API enabled: route through the full
                 * MRam_Ip_SetLock validation pipeline. */
                Status = MRam_Ip_SetLock(CurrentAddress, DomainId, InstanceId);
#else
                /* Public Lock API disabled - MRam_Ip_SetLock is not in
                 * the binary. Use the internal SetPartitionLock helper
                 * directly. Skipping full validation is safe because
                 * the driver itself unlocked this partition in Phase 2
                 * of the same ProcessOperation call. */
                LockSetOk = FALSE;
                (void)DomainId; /* not needed on this branch */
                MRam_Ip_SetPartitionLock(CurrentPartition, InstanceId, &LockSetOk);
                Status = (LockSetOk == TRUE) ? MRAM_IP_STATUS_SUCCESS
                                             : MRAM_IP_STATUS_ERROR;
#endif
            }
#if (STD_ON == MRAM_IP_PARTITION_SET_LOCK_API)
            else if (MRam_Ip_IsPartitionLocked(CurrentPartition, InstanceId))
            {
                /* Partition is explicitly locked - refuse to unlock for write/erase.
                 * Only meaningful in STD_ON: the caller is expected to call
                 * ClearLock manually before write/erase, so finding an explicit
                 * lock here means caller forgot. With STD_OFF the driver owns
                 * the lock state and always unlocks. */
                Status = MRAM_IP_STATUS_PARTITION_LOCKED;
            }
#endif
            else
            {
                /* Try to clear the lock for this partition */
                Status = MRam_Ip_ClearLock(CurrentAddress, DomainId, InstanceId);
            }

            /* Mark this partition as processed so subsequent encounters skip it */
            processedPartitions |= partitionBit;

            /* Move to the next partition boundary */
            CurrentAddress = MRam_Ip_GetNextPartitionBoundary(CurrentAddress);
        }
    }
    else
    {
        Status = MRAM_IP_STATUS_WRITE_ADDRESS_ERROR;
    }

    return Status;
}

/**
 * @brief  Flush the MRAMC gathering write buffer on every configured system
 *         bus port, then wait for hardware to confirm the operation.
 *
 * @details
 * Per spec, each MRAMC system-bus port carries a 32-byte single-entry
 * gathering write buffer. CPU writes accumulate there before reaching MRAM
 * cells; the writes "complete" from the CPU's perspective as soon as they
 * hit the buffer, well before they commit to memory.
 *
 * RM: writing 1 to PC[port][IB] invalidates all read-buffer entries AND
 *     flushes all write-buffer entries for that port. Hardware clears the
 *     bit when the operation completes.
 *
 * We iterate over every configured port because a given AXI access could
 * be served by any of them; flushing all is the simplest correct strategy.
 *
 * @param[in] InstanceId  MRAMC instance to operate on.
 *
 * @return    MRAM_IP_STATUS_SUCCESS on completion of the flush,
 *            MRAM_IP_STATUS_ERROR_TIMEOUT if any port did not clear IB in
 *            time.
 */
static MRam_Ip_StatusType MRam_Ip_FlushAxiPortBuffers(MRam_Ip_InstanceIdType InstanceId)
{
    /* Result of the flush. SUCCESS by default; updated to the first
     * port's timeout if any port fails to clear its IB bit. */
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;

    /* Per-port wait result; used to capture only the FIRST timeout while
     * still waiting on every port (so the HW state is uniform on exit). */
    MRam_Ip_StatusType PortStatus;

    /* Number of system-bus ports declared in MRam_Ip_Config; cached so we
     * walk the same count in both phases below even if MRam_Ip_Config were
     * to be mutated concurrently (which the @warning on the entry points
     * explicitly forbids - this is defense in depth). */
    uint8 PortCount;

    /* Loop counter shared by both phases. */
    uint8 portIndex;

    /* Initialization is verified up-front by MRam_Ip_ValidateOperationParameters
     * in the entry path (ProcessOperation_AXI) - if MRam_Ip_Config were NULL
     * the function would have returned ERROR_NOT_INITIALIZED before any
     * code path that reaches this helper. */
    PortCount = MRam_Ip_Config->MRamControllerConfig.MRamCPortConfigCount;

    /* Phase 1: TRIGGER. Set PC[IB] on every configured port up-front, so
     * the hardware starts flushing them all in parallel and we do not
     * leave any port untouched if a later port times out. */
    for (portIndex = 0u; portIndex < PortCount; portIndex++)
    {
        MRamC_Ip_BaseAddr[InstanceId]->PC[MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[portIndex].id] |= MRAMC_PC_IB(TRUE);
    }

    /* Phase 2: WAIT. Poll every port's IB bit independently. Keep going
     * even if one port times out, so the function exits with all ports
     * observed; only the FIRST timeout is reported through Status. */
    for (portIndex = 0u; portIndex < PortCount; portIndex++)
    {
        PortStatus = MRam_Ip_WaitUntilRegisterBitsClear(
            &(MRamC_Ip_BaseAddr[InstanceId]->PC[MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[portIndex].id]),
            MRAMC_PC_IB_MASK,
            MRAM_IP_STATUS_ERROR_TIMEOUT);

        if ((Status == MRAM_IP_STATUS_SUCCESS) && (PortStatus != MRAM_IP_STATUS_SUCCESS))
        {
            Status = PortStatus;
        }
    }

    return Status;
}

/**
 * @brief  Read-modify-write a contiguous run of 1..4 bytes inside a single
 *         32-bit MRAM word.
 *
 * Used by ProcessOperation_AXI for the HEAD and TAIL phases of an
 * unaligned-range operation. The BODY phase writes full aligned words
 * directly and does not call this helper.
 *
 * Caller contract: this function does NOT flush the MRAMC gathering write
 * buffer. The caller must call MRam_Ip_FlushAxiPortBuffers before invoking
 * the helper so the RMW read returns the latest committed word value.
 *
 * Constraint: (Address & 0x03) + NumBytes must be <= 4 - the modified run
 * has to fit entirely inside ONE 32-bit word. NumBytes must be > 0. Both
 * conditions are runtime-checked below; on violation the helper exits as
 * a silent no-op (callers always satisfy this; the check is defense in
 * depth, not error reporting).
 *
 * Erase semantics: when SrcPtr is NULL_PTR the helper substitutes
 * MRAM_IP_ERASED_VALUE_U8 for every byte. This keeps a single helper for
 * both write and erase paths.
 *
 * @param[in] Address       First MRAM byte address to modify.
 * @param[in] NumBytes      How many consecutive bytes to write (1..4).
 * @param[in] SrcPtr        Source byte array, or NULL_PTR for erase mode.
 * @param[in] SrcStartIdx   Index into SrcPtr of the first byte to copy.
 */
static void MRam_Ip_RmwPartialWord_AXI(MRam_Ip_AddressType Address,
                                       uint32 NumBytes,
                                       uint8 const * SrcPtr,
                                       MRam_Ip_LengthType SrcStartIdx)
{
    /* Word-aligned base address used for the RMW read and the final write. */
    MRam_Ip_AddressType WordAddress = Address & ~MRAM_IP_WORD_ALIGNMENT_MASK;

    /* Position (0..3) of the first byte to modify inside the 32-bit word. */
    uint32 ByteOffset = Address & MRAM_IP_WORD_ALIGNMENT_MASK;

    /* Word value snapshot read from MRAM for the modify step. */
    uint32 CurrentWord;

    /* Word value after applying the requested byte modifications. */
    uint32 NewWord;

    /* Bit mask covering exactly the byte positions being modified - used
     * to wipe them from CurrentWord and to gate the new values. */
    uint32 ByteMask = 0u;

    /* New byte values, each placed at its target byte position inside
     * the 32-bit word so the final OR can merge them in one step. */
    uint32 NewBytes = 0u;

    /* Loop counter over the bytes to be written. */
    uint32 i;

    /* Source byte value used in each iteration (data byte or erased value). */
    uint8 SrcByte;

    /* Bit shift amount = byte-position x 8. */
    uint32 Shift;

    /* Defensive check: only proceed when the byte run fits inside the 32-bit
     * word, so the shift below stays below 32 (no undefined behavior). */
    if ((NumBytes != 0U) && ((ByteOffset + NumBytes) <= 4U))
    {
        for (i = 0u; i < NumBytes; i++)
        {
            /* Mask the byte index to 0..3 so the shift stays below 32; the
             * bounds check above already guarantees this, so behavior is
             * unchanged. */
            Shift = ((ByteOffset + i) & 3u) * MRAM_IP_BITS_PER_BYTE;
            ByteMask |= (uint32)0xFFU << Shift;

            if (SrcPtr != NULL_PTR)
            {
                SrcByte = SrcPtr[SrcStartIdx + i];
            }
            else
            {
                SrcByte = MRAM_IP_ERASED_VALUE_U8;
            }
            NewBytes |= (uint32)SrcByte << Shift;
        }

        CurrentWord = *((volatile uint32*)WordAddress);
        NewWord = (CurrentWord & ~ByteMask) | (NewBytes & ByteMask);
        *((volatile uint32*)WordAddress) = NewWord;

        /* Barrier so the write is visible to the peripheral before the caller
         * sequences anything else, regardless of memory attributes. */
        MCAL_DATA_SYNC_BARRIER();
    }
}


/**
 * @brief Initialize ActiveErrors structure to all FALSE values
 * @details Sets all error notification flags to FALSE - extracted to reduce CCM */
static void MRam_Ip_InitializeActiveErrors(MRam_Ip_InterruptConfigType* ActiveErrors)
{
    ActiveErrors->enablePostedWriteErrorNotification = (boolean)FALSE;
    ActiveErrors->enableControlParityErrorNotification = (boolean)FALSE;
    ActiveErrors->enableControlEccErrorNotification = (boolean)FALSE;
    ActiveErrors->enableDataEccErrorNotification = (boolean)FALSE;
    ActiveErrors->enableControllerErrorNotification = (boolean)FALSE;
    ActiveErrors->enableMemoryErrorNotification = (boolean)FALSE;
    ActiveErrors->enableMemoryEdcAfterEccErrorNotification = (boolean)FALSE;
    ActiveErrors->enableUserErrorNotification = (boolean)FALSE;
}

/**
 * @brief Process all MRAM error conditions
 * @details Checks each error type against notification settings and status flags,
 *          updates ActiveErrors structure and accumulates flags to clear. */
static void MRam_Ip_ProcessErrorConditions(uint32 ErrorNotificationEnabled,
                                          uint32 ErrorStatus,
                                          MRam_Ip_InterruptConfigType* ActiveErrors,
                                          uint32* ErrorsToBeCleared)
{
    /* Check for Posted Write Error (PWE) - a posted (bufferable) write failed */
    if (((ErrorNotificationEnabled & MRAMC_ERRNTCTL0_PWENE_MASK) != 0U) &&
        ((ErrorStatus & MRAMC_ERRSTAT0_PWE_MASK) != 0U))
    {
        /* Store the error in the ActiveErrors structure for the callback */
        ActiveErrors->enablePostedWriteErrorNotification = (boolean)TRUE;
        /* Mark this error flag to be cleared after processing */
        *ErrorsToBeCleared |= MRAMC_ERRSTAT0_PWE_MASK;
    }

    /* Check for Control Parity Error (CPE) - parity error on the control/address path */
    if (((ErrorNotificationEnabled & MRAMC_ERRNTCTL0_CPENE_MASK) != 0U) &&
        ((ErrorStatus & MRAMC_ERRSTAT0_CPE_MASK) != 0U))
    {
        ActiveErrors->enableControlParityErrorNotification = (boolean)TRUE;
        *ErrorsToBeCleared |= MRAMC_ERRSTAT0_CPE_MASK;
    }

    /* Check for Control ECC Error (CEE) - ECC error on the control/address path */
    if (((ErrorNotificationEnabled & MRAMC_ERRNTCTL0_CEENE_MASK) != 0U) &&
        ((ErrorStatus & MRAMC_ERRSTAT0_CEE_MASK) != 0U))
    {
        ActiveErrors->enableControlEccErrorNotification = (boolean)TRUE;
        *ErrorsToBeCleared |= MRAMC_ERRSTAT0_CEE_MASK;
    }

    /* Check for Data ECC Error (DEE) - ECC error on read data */
    if (((ErrorNotificationEnabled & MRAMC_ERRNTCTL0_DEENE_MASK) != 0U) &&
        ((ErrorStatus & MRAMC_ERRSTAT0_DEE_MASK) != 0U))
    {
        ActiveErrors->enableDataEccErrorNotification = (boolean)TRUE;
        *ErrorsToBeCleared |= MRAMC_ERRSTAT0_DEE_MASK;
    }

    /* Check for MRAM Controller Error (MCE) */
    if (((ErrorNotificationEnabled & MRAMC_ERRNTCTL0_MCENE_MASK) != 0U) &&
        ((ErrorStatus & MRAMC_ERRSTAT0_MCE_MASK) != 0U))
    {
        ActiveErrors->enableControllerErrorNotification = (boolean)TRUE;
        *ErrorsToBeCleared |= MRAMC_ERRSTAT0_MCE_MASK;
    }

    /* Check for Memory Error (MRAM macro error [MENE]: aggregate of write-verify
     * WRE / uncorrectable read ECC EER / address-encode AEE - exact cause is in
     * MCRS). Routed to the DEDICATED enableMemoryErrorNotification field so the
     * callback can tell it apart from the MRAMC controller error MCE ([MCENE]);
     * previously both collapsed onto enableControllerErrorNotification, leaving
     * enableMemoryErrorNotification permanently FALSE. */
    if (((ErrorNotificationEnabled & MRAMC_ERRNTCTL0_MENE_MASK) != 0U) &&
        ((ErrorStatus & MRAMC_ERRSTAT0_ME_MASK) != 0U))
    {
        ActiveErrors->enableMemoryErrorNotification = (boolean)TRUE;
        *ErrorsToBeCleared |= MRAMC_ERRSTAT0_ME_MASK;
    }

    /* Check for MRAM EDC-After-ECC Error (MEEE) - a serious data-integrity
     * problem detected in the MRAM array */
    if (((ErrorNotificationEnabled & MRAMC_ERRNTCTL0_MEEENE_MASK) != 0U) &&
        ((ErrorStatus & MRAMC_ERRSTAT0_MEEE_MASK) != 0U))
    {
        ActiveErrors->enableMemoryEdcAfterEccErrorNotification = (boolean)TRUE;
        *ErrorsToBeCleared |= MRAMC_ERRSTAT0_MEEE_MASK;
    }

    /* Check for User Error (UE) - user configuration error */
    if (((ErrorNotificationEnabled & MRAMC_ERRNTCTL0_UENE_MASK) != 0U) &&
        ((ErrorStatus & MRAMC_ERRSTAT0_UE_MASK) != 0U))
    {
        ActiveErrors->enableUserErrorNotification = (boolean)TRUE;
        *ErrorsToBeCleared |= MRAMC_ERRSTAT0_UE_MASK;
    }
}

/**
 * @brief Check if a word contains a mismatched byte compared to a reference byte value
 * @details Scans each byte in a word to find if any byte differs from the expected value.
 *          Extracted to reduce nesting level in CompareBlankCheck and CompareNormalData.
 *
 * @param[in] WordPtr     Pointer to the word bytes to check
 * @param[in] ExpectedVal Expected byte value to compare against
 *
 * @return MRAM_IP_STATUS_COMPARE_MISMATCH if any byte differs, MRAM_IP_STATUS_SUCCESS otherwise
 */
static inline MRam_Ip_StatusType MRam_Ip_CheckWordBytes(const uint8* WordPtr, uint8 ExpectedVal)
{
    MRam_Ip_StatusType Result = MRAM_IP_STATUS_SUCCESS;
    uint32 byteIdx;

    for (byteIdx = 0U; byteIdx < 4U; byteIdx++)
    {
        if (WordPtr[byteIdx] != ExpectedVal)
        {
            Result = MRAM_IP_STATUS_COMPARE_MISMATCH;
            break;
        }
    }

    return Result;
}

/**
 * @brief Check if two words have a mismatched byte at corresponding positions
 * @details Compares two words byte-by-byte to find position of first mismatch.
 *          Extracted to reduce nesting level in CompareNormalData.
 *
 * @param[in] WordPtr1 Pointer to first word bytes
 * @param[in] WordPtr2 Pointer to second word bytes
 *
 * @return MRAM_IP_STATUS_COMPARE_MISMATCH if any byte differs, MRAM_IP_STATUS_SUCCESS otherwise
 */
static inline MRam_Ip_StatusType MRam_Ip_CheckWordBytePair(const uint8* WordPtr1, const uint8* WordPtr2)
{
    MRam_Ip_StatusType Result = MRAM_IP_STATUS_SUCCESS;
    uint32 byteIdx;

    for (byteIdx = 0U; byteIdx < 4U; byteIdx++)
    {
        if (WordPtr1[byteIdx] != WordPtr2[byteIdx])
        {
            Result = MRAM_IP_STATUS_COMPARE_MISMATCH;
            break;
        }
    }

    return Result;
}

/**
 * @brief Perform blank check comparison - extracted to reduce CCM
 * @details Compare MRAM data against predefined blank values with optimized word-aligned access
 *          when possible, falling back to byte-by-byte comparison otherwise. */
static MRam_Ip_StatusType MRam_Ip_CompareBlankCheck(const uint8* TempReadBuffer,
                                                    uint32 ChunkSize,
                                                    MRam_Ip_AddressType CurrentMRamAddress)
{
    /* Size of a 32-bit word in bytes - used for word-aligned comparisons */
    const uint32 WORD_SIZE = 4U;

    /*
     * Mask to check 4-byte alignment (binary: 00000011)
     * When an address is 4-byte aligned, its two lowest bits are 0
     * Example: 0x08001000 & 0x3 = 0x0 (aligned)
     *          0x08001001 & 0x3 = 0x1 (not aligned)
     */
    const uint32 WORD_ALIGNMENT_MASK = 0x3U;

    /*
     * Minimum size required for word-based comparison
     * We need at least 4 bytes to perform a complete word comparison
     * For small chunks (1-3 bytes), we fall back to byte comparison
     */
    const uint32 MIN_SIZE_FOR_WORD_COMPARE = 4U;

    /* Status to track comparison result */
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;

    /*
     * Counter for iterating through bytes/words during comparison
     * Used for tracking position within the current chunk
     * Example: When comparing bytes 0-31 of the buffer
     */
    uint32 compareIndex;



    /*
     * Number of complete 32-bit words in the current chunk for optimized comparison
     * Example: If ChunkSize = 20 bytes:
     * - wordChunks = 20 / 4 = 5 complete words
     * - Bytes 0-19 are processed as 5 words (0-3, 4-7, 8-11, 12-15, 16-19)
     */
    uint32 wordChunks;

    /* Reconstructed word from read buffer for comparison */
    uint32 readWord;

    /*
     * Flag indicating whether a mismatch was found in word comparison
     * Used to break out of nested loops efficiently when a mismatch is found
     */
    boolean mismatchFound;

    /*
     * Pointer to MRAM data for byte-by-byte comparison within mismatched word
     * Example: If a word mismatch is found, we need to find which specific byte differs
     */
    const uint8* bytePtr1;

    /*
     * Check if address is 4-byte aligned and chunk is at least 4 bytes
     * Word-based comparison can be 4-8 times faster than byte-by-byte
     */
    if (((CurrentMRamAddress & WORD_ALIGNMENT_MASK) == 0U) &&
        (ChunkSize >= MIN_SIZE_FOR_WORD_COMPARE))
    {
        /*
         * Word-aligned blank check for better performance
         * Compare WORD_SIZE (4) bytes at a time against blank value
         */
        wordChunks = ChunkSize / WORD_SIZE;
        mismatchFound = FALSE;

        /*
         * Compare WORD_SIZE bytes at a time against blank value
         * This is much faster than byte-by-byte comparison
         */
        for (compareIndex = 0U; (compareIndex < wordChunks) && (mismatchFound != TRUE); compareIndex++)
        {
            readWord = MRam_Ip_LoadWordUnaligned(&TempReadBuffer[compareIndex * WORD_SIZE]);
            if (readWord != MRAM_IP_ERASED_VALUE_U32)
            {
                /*
                 * Word mismatch found - find the exact byte that differs
                 * This is needed for precise error reporting
                 */
                bytePtr1 = &TempReadBuffer[compareIndex * WORD_SIZE];
                Status = MRam_Ip_CheckWordBytes(bytePtr1, MRAM_IP_ERASED_VALUE_U8);
                if (Status != MRAM_IP_STATUS_SUCCESS)
                {
                    mismatchFound = TRUE;
                }
            }
        }

        /*
         * Compare any remaining bytes that didn't fit into complete words
         *
         * Example: If ChunkSize = 22:
         * - 5 complete words (20 bytes) were compared above
         * - 2 remaining bytes (at offsets 20 and 21) are compared here
         */
        if ((Status == MRAM_IP_STATUS_SUCCESS) && ((ChunkSize % WORD_SIZE) != 0U))
        {
            for (compareIndex = (wordChunks * WORD_SIZE); compareIndex < ChunkSize; compareIndex++)
            {
                if (TempReadBuffer[compareIndex] != MRAM_IP_ERASED_VALUE_U8)
                {
                    Status = MRAM_IP_STATUS_COMPARE_MISMATCH;
                    break;
                }
            }
        }
    }
    else
    {
        /*
         * Fall back to standard byte-by-byte blank check when:
         * - Addresses are not 4-byte aligned, or
         * - Chunk size is smaller than a complete word
         *
         * While slower, this method works for any alignment and size
         */
        for (compareIndex = 0U; compareIndex < ChunkSize; compareIndex++)
        {
            if (TempReadBuffer[compareIndex] != MRAM_IP_ERASED_VALUE_U8)
            {
                /* Record the exact address where mismatch occurred */
                Status = MRAM_IP_STATUS_COMPARE_MISMATCH;
                break;
            }
        }
    }

    return Status;
}

/**
 * @brief Perform normal data comparison - extracted to reduce CCM
 * @details Use word comparison for aligned addresses, byte comparison otherwise.
 *          Optimized comparison with word-by-word (4 bytes) comparison when addresses are aligned,
 *          falling back to byte-by-byte comparison otherwise. */
static MRam_Ip_StatusType MRam_Ip_CompareNormalData(const uint8* TempReadBuffer,
                                                    const uint8* pu8SrcAddress,
                                                    uint32 ChunkSize,
                                                    MRam_Ip_AddressType CurrentMRamAddress)
{
    /* Size of a 32-bit word in bytes - used for word-aligned comparisons */
    const uint32 WORD_SIZE = 4U;

    /*
     * Mask to check 4-byte alignment (binary: 00000011)
     * When an address is 4-byte aligned, its two lowest bits are 0
     * Example: 0x08001000 & 0x3 = 0x0 (aligned)
     *          0x08001001 & 0x3 = 0x1 (not aligned)
     */
    const uint32 WORD_ALIGNMENT_MASK = 0x3U;

    /*
     * Minimum size required for word-based comparison
     * We need at least 4 bytes to perform a complete word comparison
     * For small chunks (1-3 bytes), we fall back to byte comparison
     */
    const uint32 MIN_SIZE_FOR_WORD_COMPARE = 4U;

    /* Status to track comparison result */
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;

    /*
     * Counter for iterating through bytes/words during comparison
     * Used for tracking position within the current chunk
     * Example: When comparing bytes 0-31 of the buffer
     */
    uint32 compareIndex;



    /*
     * Number of complete 32-bit words in the current chunk for optimized comparison
     * Example: If ChunkSize = 20 bytes:
     * - wordChunks = 20 / 4 = 5 complete words
     * - Bytes 0-19 are processed as 5 words (0-3, 4-7, 8-11, 12-15, 16-19)
     */
    uint32 wordChunks;

    /* Reconstructed words from buffers for comparison */
    uint32 readWord;
    uint32 srcWord;

    /*
     * Flag indicating whether a mismatch was found in word comparison
     * Used to break out of nested loops efficiently when a mismatch is found
     */
    boolean mismatchFound;

    /*
     * Pointer to MRAM data for byte-by-byte comparison within mismatched word
     * Example: If a word mismatch is found, we need to find which specific byte differs
     */
    const uint8* bytePtr1;

    /*
     * Pointer to source data for byte-by-byte comparison within mismatched word
     * Used together with bytePtr1 to find exact byte mismatch position
     */
    const uint8* bytePtr2;

    /* -------------------------------------------------------------------------
     * OPTIMIZED COMPARISON
     * Use word comparison for aligned addresses, byte comparison otherwise
     * ------------------------------------------------------------------------- */

    /*
     * Check if both addresses are 4-byte aligned and chunk is at least 4 bytes
     * Word-based comparison can be 4-8 times faster than byte-by-byte
     *
     * Three alignment conditions must be met:
     * 1. MRAM address is 4-byte aligned:
     *    Example: 0x08001100 & 0x3 = 0 (aligned), 0x08001101 & 0x3 = 1 (unaligned)
     *
     * 2. Source buffer is 4-byte aligned:
     *    Example: Buffer at 0x20000100 & 0x3 = 0 (aligned)
     *             Buffer at 0x20000101 & 0x3 = 1 (unaligned)
     *
     * 3. Have at least 4 bytes to compare:
     *    Example: ChunkSize = 16 (>= 4, suitable for word comparison)
     *             ChunkSize = 3 (< 4, must use byte comparison)
     */
    if (((CurrentMRamAddress & WORD_ALIGNMENT_MASK) == 0U) &&
        (((uint32)pu8SrcAddress & WORD_ALIGNMENT_MASK) == 0U) &&
        (ChunkSize >= MIN_SIZE_FOR_WORD_COMPARE))
    {
        /*
         * Word-aligned comparison for better performance
         * Compare WORD_SIZE (4) bytes at a time instead of one by one
         *
         * Example: For a 32-byte chunk:
         * - Instead of 32 byte comparisons, perform 8 word comparisons
         * - This is a 4x reduction in comparison operations
         */
        wordChunks = ChunkSize / WORD_SIZE;  /* Number of complete words */
        mismatchFound = FALSE;

        /*
         * Compare WORD_SIZE bytes at a time until:
         * - All complete words are compared, or
         * - A mismatch is found (tracked by mismatchFound flag)
         *
         * Example with 20-byte chunk (5 words):
         * - Compare words at offsets 0, 4, 8, 12, 16
         * - If mismatch at offset 8, stop and identify exact byte
         */
        for (compareIndex = 0U; (compareIndex < wordChunks) && (mismatchFound != TRUE); compareIndex++)
        {
            readWord = MRam_Ip_LoadWordUnaligned(&TempReadBuffer[compareIndex * WORD_SIZE]);
            srcWord = MRam_Ip_LoadWordUnaligned(&pu8SrcAddress[compareIndex * WORD_SIZE]);
            if (readWord != srcWord)
            {
                /*
                 * Word mismatch found - find the exact byte that differs
                 * Get byte-level pointers and compare byte-by-byte
                 */
                bytePtr1 = &TempReadBuffer[compareIndex * WORD_SIZE];
                bytePtr2 = &pu8SrcAddress[compareIndex * WORD_SIZE];
                Status = MRam_Ip_CheckWordBytePair(bytePtr1, bytePtr2);
                if (Status != MRAM_IP_STATUS_SUCCESS)
                {
                    mismatchFound = TRUE;
                }
            }
        }

        /*
         * Compare any remaining bytes that didn't fit into complete words
         *
         * Example: If ChunkSize = 22:
         * - 5 complete words (20 bytes) were compared above
         * - 2 remaining bytes (at offsets 20 and 21) are compared here
         *
         * This ensures partial words at the end of a chunk are also compared.
         */
        if ((Status == MRAM_IP_STATUS_SUCCESS) && ((ChunkSize % WORD_SIZE) != 0U))
        {
            for (compareIndex = (wordChunks * WORD_SIZE); compareIndex < ChunkSize; compareIndex++)
            {
                if (TempReadBuffer[compareIndex] != pu8SrcAddress[compareIndex])
                {
                    /*
                     * Calculate exact mismatch address
                     *
                     * Example: If mismatch at the 21st byte:
                     * - compareIndex = 20 (21st byte, zero-indexed)
                     */
                    Status = MRAM_IP_STATUS_COMPARE_MISMATCH;
                    break;
                }
            }
        }
    }
    else
    {
        /*
         * Fall back to standard byte-by-byte comparison when:
         * - Addresses are not 4-byte aligned, or
         * - Chunk size is smaller than a complete word
         *
         * Examples when this path is used:
         * 1. Address 0x08001001 (not word-aligned)
         * 2. Source buffer at address 0x20000101 (not word-aligned)
         * 3. ChunkSize = 3 (too small for word comparison)
         *
         * While slower, this method works for any alignment and size
         */
        for (compareIndex = 0U; compareIndex < ChunkSize; compareIndex++)
        {
            if (TempReadBuffer[compareIndex] != pu8SrcAddress[compareIndex])
            {
                /*
                 * Record the exact address where mismatch occurred
                 *
                 * Example: If starting at 0x08001001 and mismatch at byte 5:
                 * - compareIndex = 5 (6th byte, zero-indexed)
                 */
                Status = MRAM_IP_STATUS_COMPARE_MISMATCH;
                break;
            }
        }
    }

    return Status;
}

#define MEM_43_MRAM_STOP_SEC_CODE
#include "Mem_43_MRAM_MemMap.h"

/*==================================================================================================
*                                        GLOBAL FUNCTIONS
==================================================================================================*/

#define MEM_43_MRAM_START_SEC_CODE
#include "Mem_43_MRAM_MemMap.h"

/**
 * @brief           Returns the lock status of the partition at an address.
 *
 * @param[in]  Address HW Memory Address
 * @param[in]  InstanceId HW InstanceID
 * @return     MRAM_IP_STATUS_PARTITION_LOCKED if the partition is locked
 *             MRAM_IP_STATUS_PARTITION_UNLOCKED if the partition is unlocked
 *             MRAM_IP_STATUS_ERROR_INVALID_INSTANCE_ID if instance ID is invalid
 *             MRAM_IP_STATUS_ERROR_ADDRESS_INPUT_PARAM if address is invalid
 *
 * @implements      MRam_Ip_GetLock_Activity
 */
MRam_Ip_StatusType MRam_Ip_GetLock(MRam_Ip_AddressType Address, MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType ReturnCode;
    MRam_Ip_PartitionType Partition;
    MRam_Ip_AddressAreaType MemoryType;

    /* Input parameter validation */
    /* Check instance ID validity */
    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(InstanceId < (MRam_Ip_InstanceIdType)MRAMC_INSTANCE_COUNT);
    #endif

    /* Check address validity */
    MemoryType = MRam_Ip_GetAddressType(Address);
    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(MemoryType != MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS);
    #endif

    /* Initialize ReturnCode to avoid uninitialized variable issues */
    ReturnCode = MRAM_IP_STATUS_PARTITION_LOCKED;

    if (InstanceId >= (MRam_Ip_InstanceIdType)MRAMC_INSTANCE_COUNT)
    {
        /* Initialize with default return code for error condition */
        ReturnCode = MRAM_IP_STATUS_ERROR_INVALID_INSTANCE_ID;
    }
    else if (MemoryType == MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS)
    {
        ReturnCode = MRAM_IP_STATUS_ERROR_ADDRESS_INPUT_PARAM;
    }
    /* Only proceed if the address is in a valid memory area and instance is valid */
    else
    {
        Partition = MRam_Ip_GetPartition(Address);

        /* Check partition validity and lock status */
        if (MRAM_IP_PARTITION_NOT_EXISTS == Partition)
        {
            /* Address not in any known partition - return locked for safety */
            ReturnCode = MRAM_IP_STATUS_WRITE_ADDRESS_ERROR;
        }
        else if (MRam_Ip_IsPartitionLocked(Partition, InstanceId))
        {
            /* Partition is locked */
            ReturnCode = MRAM_IP_STATUS_PARTITION_LOCKED;
        }
        else
        {
            /* Partition is unlocked */
            ReturnCode = MRAM_IP_STATUS_PARTITION_UNLOCKED;
        }
    }

    return ReturnCode;
}

/**
 * @brief   Perform the actual unlock once the partition is known to be locked.
 * @details Extracted from MRam_Ip_ClearLock to keep the caller's nesting depth
 *          within the HIS LEVEL limit (<= 4). Checks the lock domain ID, clears
 *          the partition lock bit and performs the symmetric post-write
 *          verification. Logic unchanged.
 *
 * @param[in]  Address       HW Memory Address
 * @param[in]  DomainIdValue Domain ID of the requesting core
 * @param[in]  InstanceId    Hardware Instance ID
 * @return     MRAM_IP_STATUS_SUCCESS on success, or the specific error.
 */
static MRam_Ip_StatusType MRam_Ip_ClearLockOnLockedPartition(MRam_Ip_AddressType Address,
                                                             uint8 DomainIdValue,
                                                             MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType ReturnCode;
    MRam_Ip_PartitionType Partition;

    /* Check the lock Domain Id */
    ReturnCode = MRam_Ip_CheckLockDomainID(Address, DomainIdValue, InstanceId);

    if (ReturnCode == MRAM_IP_STATUS_SUCCESS)
    {
        Partition = MRam_Ip_GetPartition(Address);

        if (Partition == MRAM_IP_PARTITION_NOT_EXISTS)
        {
            /* Invalid partition - address not in any known partition */
            ReturnCode = MRAM_IP_STATUS_WRITE_ADDRESS_ERROR;
        }
        else
        {
            /* Clear the lock bit for the specified partition */
            MRam_Ip_ClearLockBit(Partition, InstanceId);

            /* Post-write verification.
             *
             * Lock writes (e.g. LPLOCK &= ~mask) can be silently
             * dropped by the hardware if the corresponding Protect
             * Lock register (PLPLOCK / PSPLOCK / PLPOLOCK / PUTLOCK)
             * is configured to deny modification. Re-read the bit
             * we just wrote and confirm it now reads back as cleared.
             *
             * We use MRam_Ip_CheckMramcLock (not GetLock) because
             * we are verifying our own write to MRAMC's lock
             * register, not the downstream F16ASM-reflected state.
             * Symmetric with the post-write check in SetLock. */
            if (MRam_Ip_CheckMramcLock(Partition, InstanceId) != FALSE)
            {
                ReturnCode = MRAM_IP_STATUS_ERROR;
            }
            /* else: ReturnCode remains MRAM_IP_STATUS_SUCCESS */
        }
    }
    /* else: ReturnCode already contains error from MRam_Ip_CheckLockDomainID */

    return ReturnCode;
}

/**
 * @brief           Unlocks the partition at an address for the requesting core, if allowed.
 *
 * @param[in]  Address       HW Memory Address
 * @param[in]  DomainIdValue Domain ID of the requesting core
 * @param[in]  InstanceId    HW Instance ID
 * @return     MRAM_IP_STATUS_SUCCESS if lock was cleared successfully or already unlocked
 *             MRAM_IP_STATUS_ERROR if unable to clear lock
 *             MRAM_IP_STATUS_ERROR_ADDRESS_INPUT_PARAM if address is invalid
 *             MRAM_IP_STATUS_ERROR_INVALID_INSTANCE_ID if instance ID is invalid
 *             MRAM_IP_STATUS_LOCK_OWNERSHIP_NOT_VALID if lock ownership validation fails
 *
 * @implements      MRam_Ip_ClearLock_Activity
 */
MRam_Ip_StatusType MRam_Ip_ClearLock(MRam_Ip_AddressType Address,
                                   uint8 DomainIdValue,
                                   MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType ReturnCode = MRAM_IP_STATUS_SUCCESS;
    MRam_Ip_AddressAreaType MemoryType;

    /* Input parameter validation */
    /* Check instance ID validity */
    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(InstanceId < (MRam_Ip_InstanceIdType)MRAMC_INSTANCE_COUNT);
    #endif

    /* Check address validity */
    MemoryType = MRam_Ip_GetAddressType(Address);
    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(MemoryType != MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS);
    #endif

    if (InstanceId >= (MRam_Ip_InstanceIdType)MRAMC_INSTANCE_COUNT)
    {
        ReturnCode = MRAM_IP_STATUS_ERROR_INVALID_INSTANCE_ID;
    }

    /* Handle invalid address */
    if ((ReturnCode == MRAM_IP_STATUS_SUCCESS) &&
        (MemoryType == MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS))
    {
        ReturnCode = MRAM_IP_STATUS_ERROR_ADDRESS_INPUT_PARAM;
    }

    /* Address and instance ID are valid, proceed with unlock operations */
    if (ReturnCode == MRAM_IP_STATUS_SUCCESS)
    {
        /* Check if partition is already unlocked */
        ReturnCode = MRam_Ip_GetLock(Address, InstanceId);

        if (ReturnCode == MRAM_IP_STATUS_PARTITION_UNLOCKED)
        {
            /* This partition has been already unlocked */
            ReturnCode = MRAM_IP_STATUS_SUCCESS;
        }
        else if (ReturnCode == MRAM_IP_STATUS_PARTITION_LOCKED)
        {
            /* Partition is locked, attempt to unlock it. The domain-ID check,
             * lock-bit clear and post-write verification are done in a helper
             * to keep this function within the HIS LEVEL limit. */
            ReturnCode = MRam_Ip_ClearLockOnLockedPartition(Address, DomainIdValue, InstanceId);
        }
        else
        {
            /* ReturnCode already contains error from MRam_Ip_GetLock */
        }
    }

    return ReturnCode;
}

#if (STD_ON == MRAM_IP_PARTITION_SET_LOCK_API)
/**
 * @brief   Perform the actual lock once the partition is known to be unlocked.
 * @details Extracted from MRam_Ip_SetLock to keep the caller's nesting depth
 *          within the HIS LEVEL limit (<= 4). Checks the lock domain ID, sets
 *          the partition lock and performs the symmetric post-write
 *          verification. Logic unchanged.
 *
 * @param[in]  Address       HW Memory Address
 * @param[in]  DomainIdValue Domain ID of the requesting core
 * @param[in]  InstanceId    HW Instance ID
 * @return     MRAM_IP_STATUS_SUCCESS on success, or the specific error.
 */
static MRam_Ip_StatusType MRam_Ip_SetLockOnUnlockedPartition(MRam_Ip_AddressType Address,
                                                             uint8 DomainIdValue,
                                                             MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType ReturnCode;
    MRam_Ip_PartitionType Partition;
    boolean LockSuccess = FALSE;

    /* First check lock domain ID to ensure this core has permission */
    ReturnCode = MRam_Ip_CheckLockDomainID(Address, DomainIdValue, InstanceId);

    if (ReturnCode == MRAM_IP_STATUS_SUCCESS)
    {
        /* Domain ID check passed, get partition and set lock */
        Partition = MRam_Ip_GetPartition(Address);

        if (Partition == MRAM_IP_PARTITION_NOT_EXISTS)
        {
            /* Address not in any known partition */
            ReturnCode = MRAM_IP_STATUS_WRITE_ADDRESS_ERROR;
        }
        else
        {
            /* Set partition lock */
            MRam_Ip_SetPartitionLock(Partition, InstanceId, &LockSuccess);

            if (LockSuccess != TRUE)
            {
                /* SetPartitionLock did not act: the partition type
                 * was not recognized. */
                ReturnCode = MRAM_IP_STATUS_ERROR;
            }
            /* Post-write verification.
             *
             * Lock writes (e.g. LPLOCK |= mask) can be silently
             * dropped by the hardware if the corresponding Protect
             * Lock register (PLPLOCK / PSPLOCK / PLPOLOCK / PUTLOCK)
             * is configured to deny modification. Re-read the bit
             * we just wrote and confirm it now reads back as set.
             *
             * We use MRam_Ip_CheckMramcLock (not GetLock) because
             * we are verifying our own write to MRAMC's lock
             * register, not the downstream F16ASM-reflected state.
             * F16ASM LOCK0/1 may have a 1-cycle propagation delay
             * after a MRAMC update, and the AND semantic in GetLock
             * would mistake the propagation window for a denied
             * write. */
            else if (MRam_Ip_CheckMramcLock(Partition, InstanceId) != TRUE)
            {
                ReturnCode = MRAM_IP_STATUS_ERROR;
            }
            else
            {
                /* ReturnCode remains MRAM_IP_STATUS_SUCCESS */
            }
        }
    }
    /* else: ReturnCode already contains error from MRam_Ip_CheckLockDomainID */

    return ReturnCode;
}

/**
 * @brief           Locks the partition at an address for the requesting core, if allowed.
 *
 * @param[in]  Address       HW Memory Address
 * @param[in]  DomainIdValue Domain ID of the requesting core
 * @param[in]  InstanceId    HW Instance ID
 * @return     MRAM_IP_STATUS_SUCCESS if lock was set successfully or already locked
 *             MRAM_IP_STATUS_ERROR if unable to set lock
 *             MRAM_IP_STATUS_ERROR_ADDRESS_INPUT_PARAM if address is invalid
 *             MRAM_IP_STATUS_ERROR_INVALID_INSTANCE_ID if instance ID is invalid
 *             MRAM_IP_STATUS_LOCK_OWNERSHIP_NOT_VALID if lock ownership validation fails
 *
 * @implements MRam_Ip_SetLock_Activity
 */
MRam_Ip_StatusType MRam_Ip_SetLock(MRam_Ip_AddressType Address,
                                 uint8 DomainIdValue,
                                 MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType ReturnCode;
    MRam_Ip_AddressAreaType MemoryType;

    /* Input parameter validation */
    /* Check instance ID validity */
    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(InstanceId < (MRam_Ip_InstanceIdType)MRAMC_INSTANCE_COUNT);
    #endif

    /* Check address validity */
    MemoryType = MRam_Ip_GetAddressType(Address);
    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(MemoryType != MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS);
    #endif

    if (InstanceId >= (MRam_Ip_InstanceIdType)MRAMC_INSTANCE_COUNT)
    {
        ReturnCode = MRAM_IP_STATUS_ERROR_INVALID_INSTANCE_ID;
    }
    /* Handle invalid address */
    else if (MemoryType == MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS)
    {
        ReturnCode = MRAM_IP_STATUS_ERROR_ADDRESS_INPUT_PARAM;
    }
    /* Address and instance ID are valid, proceed with lock operations */
    else
    {
        /* Check if partition is already locked */
        ReturnCode = MRam_Ip_GetLock(Address, InstanceId);

        if (ReturnCode == MRAM_IP_STATUS_PARTITION_LOCKED)
        {
            /* Partition is already locked, consider this a success */
            ReturnCode = MRAM_IP_STATUS_SUCCESS;
        }
        else if (ReturnCode == MRAM_IP_STATUS_PARTITION_UNLOCKED)
        {
            /* Partition is not locked, attempt to lock it. The domain-ID check,
             * partition lock and post-write verification are done in a helper
             * to keep this function within the HIS LEVEL limit. */
            ReturnCode = MRam_Ip_SetLockOnUnlockedPartition(Address, DomainIdValue, InstanceId);
        }
        else
        {
            /* ReturnCode already contains error from MRam_Ip_GetLock */
        }
    }

    return ReturnCode;
}

#endif /* STD_ON == MRAM_IP_PARTITION_SET_LOCK_API */

/**
 * @brief   Enable UTest mode for MRAM testing and diagnostics
 * @details This function enables the User Test (UTest) mode in the MRAM controller,
 *          which allows access to special test functions including array integrity
 *          checks, ECC logic verification, and other diagnostic operations.
 *
 *          The function follows the hardware-specified sequence:
 *          1. Ensures no low-power request is in progress (waits for MCRS[LPR] = 0)
 *          2. Ensures no OTP commit operation is active (waits for MCRS[OMR] and MCRS[OMA] = 0)
 *          3. Clears any existing error flags to ensure clean test environment
 *          4. Writes the UTest password (0xF9F99999) to UT0 register
 *          5. Waits for UTest mode to be enabled (UT0[UTE] = 1)
 *
 *          Once UTest mode is active, specialized test operations can be performed
 *          such as array integrity checks, ECC logic tests, and reference recovery.
 *
 * @note    UTest mode should only be used for testing and diagnostic purposes.
 *          Normal memory operations (read/write) should not be performed while
 *          UTest mode is active.
 *
 * @note    The function includes timeout protection to prevent infinite waiting
 *          if hardware doesn't respond as expected.
 *
 * @return  MRam_Ip_StatusType
 * @retval  MRAM_IP_STATUS_SUCCESS              UTest mode successfully enabled
 * @retval  MRAM_IP_STATUS_WRITE_TIMEOUT_BUSY   Timeout waiting for preconditions or UTest enable
 *
 */
static MRam_Ip_StatusType MRam_Ip_EnableUTest(void)
{
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;

    /* Validate base address pointer */
    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(NULL_PTR != MRam_Ip_BaseAddr);
    #endif

    /*1. Ensure that a low-power request is not in process. Wait until MCRS[LPR] = 0.*/
    Status = MRam_Ip_WaitUntilRegisterBitsClear(&(MRam_Ip_BaseAddr->MCRS),
                                                F16ASM_MCRS_LPR_MASK,
                                                MRAM_IP_STATUS_WRITE_TIMEOUT_BUSY);

    /*2. Ensure that an OTP commit is not in progress. Wait until the OMR and OMA fields in MCRS are both 0.*/
    if(Status == MRAM_IP_STATUS_SUCCESS)
    {
        /* Fixed condition: Wait until both OMR and OMA are 0 */
        Status = MRam_Ip_WaitUntilRegisterBitsClear(&(MRam_Ip_BaseAddr->MCRS),
                                                    (F16ASM_MCRS_OMA_MASK | F16ASM_MCRS_OMR_MASK),
                                                    MRAM_IP_STATUS_WRITE_TIMEOUT_BUSY);
    }

    if(Status == MRAM_IP_STATUS_SUCCESS)
    {
        /*3. Eliminate any errors to ensure robust software and procedure execution.
            Examine all flags in MCRS and RADR and clear any set flag. */
            MRam_Ip_StatusType ClearStatus = MRam_Ip_GetMemoryErrorStatus();
            if (ClearStatus != MRAM_IP_STATUS_SUCCESS)
            {
                /* Error status intentionally not propagated - clearing HW error register before UTest */
            }

        /** 4. Provide the password that F16ASM needs to enter UTest mode.
         *  Use a 32-bit write to write F9F9_9999h to UTest 0 (UT0).
         */
        MRam_Ip_BaseAddr->UT0 = MRAM_IP_UTEST_PASSWORD;

        /*5. Allow time for F16ASM to accept the password and enter UTest mode.
                Wait until UT0[UTE] = 1.*/
        /* Wait until UT0[UTE] becomes 1 */
        Status = MRam_Ip_WaitUntilRegisterBitsSet(&(MRam_Ip_BaseAddr->UT0),
                                                    F16ASM_UT0_UTE_MASK,
                                                    MRAM_IP_STATUS_WRITE_TIMEOUT_BUSY);
    }

    return Status;
}

/**
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * @brief      Exits MRAM UTest (self-test) mode.
 *
 * @details    Clears the UTE bit in UT0 to exit UTest mode. If any test operation is still
 *             in progress, it is stopped first. The function waits until UTE = 0 before
 *             returning.
 *
 * @return     MRam_Ip_StatusType
 * @retval     MRAM_IP_STATUS_SUCCESS             UTest mode exited successfully
 * @retval     MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR Timeout waiting for UTest mode to exit
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
static MRam_Ip_StatusType MRam_Ip_DisableUTest(void)
{
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;

    /* Exit UTest mode by writing UT0[UTE] = 0, then wait until the bit is cleared. */
    MRam_Ip_BaseAddr->UT0 &= ~F16ASM_UT0_UTE_MASK;

    Status = MRam_Ip_WaitUntilRegisterBitsClear(&(MRam_Ip_BaseAddr->UT0),
                                                F16ASM_UT0_UTE_MASK,
                                                MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);

    return Status;
}

/**
 * @brief   Processes breakpoints during UTest array integrity check
 * @details Implements the breakpoint processing loop.
 *          Loops while UT0[NAIBP] is set:
 *          1. Examine MCRS for EER, TBC, DBC, SBC flags
 *          2. Read RADR for breakpoint address
 *          3. Clear MCRS flags (W1C: direct write)
 *          4. Clear UT0[NAIBP] (RW: read-modify-write)
 *          5. Wait for UT0[AID] = 1
 *          6. Check NAIBP again
 *
 * @param[in,out] Results  Pointer to structure to accumulate error flags and address
 *
 * @return MRam_Ip_StatusType
 * @retval MRAM_IP_STATUS_SUCCESS            All breakpoints processed
 * @retval MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR Timeout waiting for AID
 */
static MRam_Ip_StatusType MRam_Ip_UTestBreakpointProcessing(
    MRam_Ip_ArrayIntegrityCheckType *Results)
{
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    uint32 mcrsRegValue;
    uint32 ut0Val;

    while ((MRam_Ip_BaseAddr->UT0 & F16ASM_UT0_NAIBP_MASK) == F16ASM_UT0_NAIBP_MASK)
    {
        mcrsRegValue = MRam_Ip_BaseAddr->MCRS;

        /* Examine EER, TBC, DBC, SBC flags in MCRS */
        if ((mcrsRegValue & F16ASM_MCRS_EER_MASK) != 0U)
        {
            Results->FLAG_ERR = (boolean)TRUE;
        }
        if ((mcrsRegValue & F16ASM_MCRS_TBC_MASK) != 0U)
        {
            Results->FLAG_TBC = (boolean)TRUE;
        }
        if ((mcrsRegValue & F16ASM_MCRS_DBC_MASK) != 0U)
        {
            Results->FLAG_DBC = (boolean)TRUE;
        }
        if ((mcrsRegValue & F16ASM_MCRS_SBC_MASK) != 0U)
        {
            Results->FLAG_SBC = (boolean)TRUE;
        }

        /* Examine RADR for breakpoint address (last breakpoint address is kept) */
        Results->RADDR = (MRam_Ip_BaseAddr->RADR & F16ASM_RADR_RADDR_MASK)
                         >> F16ASM_RADR_RADDR_SHIFT;

        /* Clear EER, TBC, DBC, SBC flags in MCRS (W1C: write only the set flags) */
        MRam_Ip_BaseAddr->MCRS = mcrsRegValue & (F16ASM_MCRS_EER_MASK |
            F16ASM_MCRS_TBC_MASK | F16ASM_MCRS_DBC_MASK | F16ASM_MCRS_SBC_MASK);

        /* Write 0 to UT0[NAIBP] per RM Figure 70 (RW bit, not W1C) */
        ut0Val = MRam_Ip_BaseAddr->UT0;
        ut0Val &= ~F16ASM_UT0_NAIBP_MASK;
        MRam_Ip_BaseAddr->UT0 = ut0Val;

        /* Wait until UT0[AID] becomes 1 again */
        Status = MRam_Ip_WaitUntilRegisterBitsSet(&(MRam_Ip_BaseAddr->UT0),
                                                   F16ASM_UT0_AID_MASK,
                                                   MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);
        if (Status != MRAM_IP_STATUS_SUCCESS)
        {
            break;
        }
    }

    return Status;
}

/**
 * @brief      Performs an array integrity self-check on MRAM memory
 *
 * This function implements the 10-step array integrity self-check procedure as specified
 * in the hardware reference manual. It reads data from a selected memory partition
 * and calculates a Multiple Input Signature Register (MISR) value, which can be used
 * to verify memory integrity and detect incorrect reads or ECC events.
 *
 * The procedure follows these steps:
 * 1. Enter UTest mode
 * 2. Select the partition to check (by writing to RADR)
 * 3. Optionally enable sequential addressing (by setting AIS bit)
 * 4. Optionally seed MISR with initial values
 * 5. Optionally enable breakpoints for error detection
 * 6. Start the array-integrity check (by setting AIE bit)
 * 7. Wait for completion (until AID bit becomes 1)
 * 8. Process breakpoints if enabled and detected
 * 9. Read the resulting MISR values for verification
 * 10. End the array-integrity check (by clearing AIE bit)
 *
 * @param[in]  Address               First address of the partition to check
 * @param[in]  SequentialAddressing  TRUE to enable sequential addressing mode, FALSE for default addressing
 * @param[in]  ArrayValuesMISR       Pointer to array of initial MISR seed values (can be NULL)
 * @param[in]  ArrayLengthMISR       Length of the ArrayValuesMISR array (should be <= 10)
 * @param[in]  EnableBreakpoints     TRUE to enable breakpoints on ECC errors, FALSE to disable
 * @param[in]  InstanceId            Instance identifier for the MRAM module
 *
 * @return     MRam_Ip_ArrayIntegrityCheckType  Structure containing:
 *             - Error flags (FLAG_ERR, FLAG_TBC, FLAG_DBC, FLAG_SBC) if breakpoints were detected
 *             - Address (RADDR) where error occurred if applicable
 *             - MISR values for signature verification
 *
 * @note       This function requires proper system frequency configuration
 *             by setting appropriate RWSC and RWSL fields in the MCR register.
 *
 * @note       For UMISR9, only bit 0 is available in hardware.
 */
MRam_Ip_ArrayIntegrityCheckType MRam_Ip_UTestArrayIntegrityCheck(MRam_Ip_AddressType Address, boolean SequentialAddressing, const uint32 * ArrayValuesMISR, uint8 ArrayLengthMISR, boolean EnableBreakpoints, MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_ArrayIntegrityCheckType Results;
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    MRam_Ip_StatusType clearStatus;
    uint8 initIdx;
    uint8 i;
    uint8 misrIdx;

    Results.FLAG_ERR = (boolean)FALSE;
    Results.FLAG_TBC = (boolean)FALSE;
    Results.FLAG_DBC = (boolean)FALSE;
    Results.FLAG_SBC = (boolean)FALSE;
    Results.RADDR = 0U;
    for (initIdx = 0U; initIdx < 10U; initIdx++)
    {
        Results.MISR[initIdx] = 0U;
    }
    (void)InstanceId;

    /* Validate parameters */
    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(MRam_Ip_GetAddressType(Address) != MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS);
    MRAM_IP_DEV_ASSERT((Address & MRAM_IP_WRITE_PAGE_OFFSET_MASK) == 0U);     /* Address must be 32-byte page aligned */
    MRAM_IP_DEV_ASSERT(ArrayLengthMISR <= 10U);      /* Max 10 MISR registers (UMISR0-8 + UMISR9) */
    if (ArrayValuesMISR != NULL_PTR)
    {
        MRAM_IP_DEV_ASSERT(ArrayLengthMISR > 0U);    /* If seed array provided, length must be > 0 */
    }
    #endif


    /*1. Enter UTest mode.*/
    Status = MRam_Ip_EnableUTest();

    if (Status == MRAM_IP_STATUS_SUCCESS)
    {
        /*2. Select the partition to receive the array-integrity check. Write the first address of the desired partition to Read Address Logging (RADR).*/
        MRam_Ip_BaseAddr->RADR = Address;

        /*3. Optionally enable sequential addressing. Write 1 to UT0[AIS]. */
        if (SequentialAddressing != FALSE)
        {
            MRam_Ip_BaseAddr->UT0 |= F16ASM_UT0_AIS_MASK;
        }

        /*4. Optionally seed the MISR with desired values. Write the values to UTest Multiple Input Signature n (UMISR0 - UMISR8) and UTest Multiple Input Signature 9 (UMISR9).*/
        if (ArrayValuesMISR != NULL_PTR)
        {
            for (i = 0; i < (ArrayLengthMISR - 1u); i++)
            {
                MRam_Ip_BaseAddr->UMISR[i] = ArrayValuesMISR[i];
            }

            if (ArrayLengthMISR == 10U)
            {
                MRam_Ip_BaseAddr->UMISR9 = ArrayValuesMISR[ArrayLengthMISR - 1u];
            }
        }

        /*5. Optionally enable breakpoints. */
        if (EnableBreakpoints != FALSE)
        {
            /*Write 1 to UT0[AIBPE].*/
            MRam_Ip_BaseAddr->UT0 |= F16ASM_UT0_AIBPE_MASK;

            /* IMPORTANT: Rather than clearing error flags directly, use the function */
            /* This ensures all errors are properly detected and cleared */
            clearStatus = MRam_Ip_GetMemoryErrorStatus();
            if (clearStatus != MRAM_IP_STATUS_SUCCESS)
            {
                /* Previous error flags were present and have been cleared */
            }

            /* Clear RADR register*/
            MRam_Ip_BaseAddr->RADR = 0U;

            /*If you want a breakpoint to occur after a correction, write 1 to MCR[CVE].*/
            MRam_Ip_BaseAddr->MCR |= F16ASM_MCR_CVE_MASK;
        }

        /*6. Start the array-integrity check. Write 1 to UT0[AIE].*/
        MRam_Ip_BaseAddr->UT0 |= F16ASM_UT0_AIE_MASK;

        /*7. Allow time for F16ASM to complete the array-integrity check. Wait until UT0[AID] becomes 1.*/
        Status = MRam_Ip_WaitUntilRegisterBitsSet(&(MRam_Ip_BaseAddr->UT0),
                                                F16ASM_UT0_AID_MASK,
                                                MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);

        /*8. Process breakpoints per RM Figure 70 (loop until no more breakpoints) */
        if ((EnableBreakpoints != FALSE) && (Status == MRAM_IP_STATUS_SUCCESS))
        {
            Status = MRam_Ip_UTestBreakpointProcessing(&Results);
        }

        /* 9. Read MISR values for signature verification  */
        if (Status == MRAM_IP_STATUS_SUCCESS)
        {
            for (misrIdx = 0U; misrIdx < (uint8)F16ASM_UMISR08_COUNT; misrIdx++)
            {
                Results.MISR[misrIdx] = MRam_Ip_BaseAddr->UMISR[misrIdx];
            }
            Results.MISR[9] = MRam_Ip_BaseAddr->UMISR9;
        }

        /*10. End the array-integrity check. Write 0 to UT0[AIE]*/
        MRam_Ip_BaseAddr->UT0 &= ~(F16ASM_UT0_AIE_MASK);
    }

    return Results;
}

/**
 * @brief Performs ECC logic check on MRAM.
 *
 * This function follows the steps defined in the reference manual section 36.4.3.3.4:
 * 1. Enter UTest mode
 * 2. Enable the inversion of ECC data
 * 3. Provide data and check-bit values to read
 * 4. Specify the page address to receive data
 * 5. Read the array
 * 6. Determine status of read operation
 * 7. Disable the inversion of ECC data
 *
 * ECC logic check allows you to simulate ECC errors by providing test data.
 * Based on the data provided, different types of errors can be generated:
 * - Single-bit correction
 * - Double-bit correction
 * - Triple-bit correction
 * - Four-bit detection
 *
 * @param[in]   Address       Memory address to test
 * @param[in]   DataValues    Array of data values to use for ECC test (UD0-UD8)
 * @param[in]   DataLength    Length of the data array (max 9)
 * @param[out]  Results       Pointer to structure to store results of the operation
 * @param[in]   InstanceId    Instance ID
 * @return      Operation status (MRAM_IP_STATUS_SUCCESS or error code)
 */
MRam_Ip_StatusType MRam_Ip_UTestECCLogicCheck(MRam_Ip_AddressType Address,
                                              const uint32 * DataValues,
                                              uint8 DataLength,
                                              MRam_Ip_ArrayIntegrityCheckType *Results,
                                              MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    uint32 mcrsValue;
    uint32 errorMask;
    uint8 initIdx;
    uint8 writeLength;
    volatile uint32 *pUdRegs;
    uint8 i;
    (void)InstanceId;

    /* Validate parameters */
    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(Results != NULL_PTR);
    MRAM_IP_DEV_ASSERT(MRam_Ip_GetAddressType(Address) != MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS);
    MRAM_IP_DEV_ASSERT((Address & MRAM_IP_WRITE_PAGE_OFFSET_MASK) == 0U);     /* Address must be 32-byte page aligned */
    MRAM_IP_DEV_ASSERT(DataValues != NULL_PTR);
    MRAM_IP_DEV_ASSERT(DataLength <= 9U);             /* Max 9 data registers (UD0-UD8) */
    MRAM_IP_DEV_ASSERT(DataLength > 0U);
    #endif

    if (Results != NULL_PTR)
    {
        Results->FLAG_ERR = FALSE;
        Results->FLAG_TBC = FALSE;
        Results->FLAG_DBC = FALSE;
        Results->FLAG_SBC = FALSE;
        Results->RADDR = 0U;
        for (initIdx = 0U; initIdx < 10U; initIdx++)
        {
            Results->MISR[initIdx] = 0U;
        }
    }

    /* 1. Enter UTest mode */
    Status = MRam_Ip_EnableUTest();

    if (Status == MRAM_IP_STATUS_SUCCESS)
    {
        /* 2. Enable the inversion of ECC data */
        MRam_Ip_BaseAddr->UT0 |= F16ASM_UT0_EIE_MASK;

        /* 3. Optimized data writing with bounds checking */
        if ((DataValues != NULL_PTR) && (DataLength > 0U))
        {
            /* Determine actual length to prevent array overflow */
            writeLength = (DataLength <= 8U) ? DataLength : 8U;

            /* Optimized loop with pointer arithmetic */
            pUdRegs = (volatile uint32 *)&MRam_Ip_BaseAddr->UD_0_TO_7[0];
            for (i = 0U; i < writeLength; i++)
            {
                pUdRegs[i] = DataValues[i];
            }

            /* Handle UD8 register separately if needed */
            if (DataLength == 9U)
            {
                MRam_Ip_BaseAddr->UD8 = DataValues[8];
            }
        }

        /* 4. Specify the page address to receive data. RADR RADDR mask is
         * already in-position (bits [24:5]); do NOT left-shift it. */
        MRam_Ip_BaseAddr->RADR = (Address & F16ASM_RADR_RADDR_MASK);

        /* 5. Trigger the read via the UT read path (RADR[UTRR]=1) instead of
         * an AHB load. An AHB load while UT0[EIE]=1 would return an
         * uncorrectable ECC bus error and escalate to HardFault. */
        MRam_Ip_BaseAddr->RADR |= F16ASM_RADR_UTRR_MASK;

        /* 5b. Wait for controller to signal read completion. */
        (void)MRam_Ip_WaitUntilRegisterBitsSet(&(MRam_Ip_BaseAddr->MCRS),
                                               F16ASM_MCRS_DONE_MASK,
                                               MRAM_IP_STATUS_WRITE_TIMEOUT_BUSY);

        /* 6. Determine the status of the read operation */
        if (Results != NULL_PTR)
        {
            /* Cache MCRS register value to avoid multiple reads */
            mcrsValue = MRam_Ip_BaseAddr->MCRS;
            /* Check EER, TBC, DBC, and SBC flags in MCRS */
            Results->FLAG_ERR = ((mcrsValue & F16ASM_MCRS_EER_MASK) == F16ASM_MCRS_EER_MASK);
            Results->FLAG_TBC = ((mcrsValue & F16ASM_MCRS_TBC_MASK) == F16ASM_MCRS_TBC_MASK);
            Results->FLAG_DBC = ((mcrsValue & F16ASM_MCRS_DBC_MASK) == F16ASM_MCRS_DBC_MASK);
            Results->FLAG_SBC = ((mcrsValue & F16ASM_MCRS_SBC_MASK) == F16ASM_MCRS_SBC_MASK);

            /* Check if any error occurred using combined mask */
            errorMask = F16ASM_MCRS_EER_MASK | F16ASM_MCRS_TBC_MASK |
                        F16ASM_MCRS_DBC_MASK | F16ASM_MCRS_SBC_MASK;

            if ((mcrsValue & errorMask) != 0U)
            {
                /* Get error address only if needed */
                Results->RADDR = (MRam_Ip_BaseAddr->RADR & F16ASM_RADR_RADDR_MASK) >> F16ASM_RADR_RADDR_SHIFT;
            }
        }
        else
        {
            /* If Results is NULL, just cache MCRS for clearing */
            mcrsValue = MRam_Ip_BaseAddr->MCRS;
        }

        /* 7. Optimized flag clearing - clear all error flags in one operation */
        errorMask = (mcrsValue & (F16ASM_MCRS_EER_MASK | F16ASM_MCRS_TBC_MASK |
                                  F16ASM_MCRS_DBC_MASK | F16ASM_MCRS_SBC_MASK));

        if (errorMask != 0U)
        {
            /* Clear all set error flags in one write */
            MRam_Ip_BaseAddr->MCRS = errorMask;
        }

        /* 8. Disable the inversion of ECC data */
        MRam_Ip_BaseAddr->UT0 &= ~F16ASM_UT0_EIE_MASK;
    }

    /* Exit UTest mode regardless of BIST result. */
    (void)MRam_Ip_DisableUTest();

    return Status;
}

/**
 * @brief Performs EDC-after-ECC logic check on MRAM.
 *
 * This function follows the steps defined in the reference manual section 36.4.3.3.5:
 * 1. Enter UTest mode
 * 2. Enable the EDC-after-ECC data input
 * 3. Provide data and check-bit values to read
 * 4. Specify the page address to receive data
 * 5. Read the array
 * 6. Determine status of read operation
 * 7. Disable the EDC-after-ECC data input
 *
 * EDC-after-ECC logic check allows you to verify the EDC logic that protects
 * corrected data coming from the ECC logic. This test ensures that the
 * error detection system for the ECC correction logic itself is functioning.
 *
 * @param[in]   Address       Memory address to test
 * @param[in]   DataValues    Array of data values to use for EDC test (UD9-UD17)
 * @param[in]   DataLength    Length of the data array (max 9)
 * @param[out]  ResultEEE     Pointer to store the EEE flag result
 * @param[in]   InstanceId    Instance ID
 * @return      Operation status (MRAM_IP_STATUS_SUCCESS or error code)
 */
MRam_Ip_StatusType MRam_Ip_UTestEDCAfterECCLogicCheck(MRam_Ip_AddressType Address,
                                                     const uint32 * DataValues,
                                                     uint8 DataLength,
                                                     boolean *ResultEEE,
                                                     MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    uint8 i;
    (void) InstanceId;

    /* Validate parameters */
    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(ResultEEE != NULL_PTR);
    MRAM_IP_DEV_ASSERT(MRam_Ip_GetAddressType(Address) != MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS);
    MRAM_IP_DEV_ASSERT((Address & MRAM_IP_WRITE_PAGE_OFFSET_MASK) == 0U);     /* Address must be 32-byte page aligned */
    MRAM_IP_DEV_ASSERT(DataValues != NULL_PTR);
    MRAM_IP_DEV_ASSERT(DataLength <= 9U);             /* Max 9 data registers (UD9-UD17) */
    MRAM_IP_DEV_ASSERT(DataLength > 0U);
    #endif

    if (ResultEEE != NULL_PTR)
    {
        *ResultEEE = (boolean)FALSE;
    }

    /* 1. Enter UTest mode */
    Status = MRam_Ip_EnableUTest();

    if (Status == MRAM_IP_STATUS_SUCCESS)
    {
        /* 2. Enable the EDC-after-ECC data input */
        MRam_Ip_BaseAddr->UT0 |= F16ASM_UT0_EDIE_MASK;

        /* 3. Provide data and check-bit values to read */
        if ((DataValues != NULL_PTR) && (DataLength > 0U))
        {
            /* Write data to UD9-UD16 registers */
            for (i = 0U; i < ((DataLength <= 8U) ? DataLength : 8U); i++)
            {
                MRam_Ip_BaseAddr->UD_9_TO_16[i] = DataValues[i];
            }

            /* Write data to UD17 if necessary */
            if ((DataLength > 8U) && (DataLength <= 9U))
            {
                MRam_Ip_BaseAddr->UD17 = DataValues[8];
            }
        }

        /* 4. Specify the page address. RADR RADDR mask is already in-position
         * (bits [24:5]); do NOT left-shift it. */
        MRam_Ip_BaseAddr->RADR = (Address & F16ASM_RADR_RADDR_MASK);

        /* 5. Trigger the read via the UT read path (RADR[UTRR]=1). Do NOT
         * issue an AHB load while UT0[EDIE]=1 - it returns uncorrectable
         * ECC and escalates to HardFault. */
        MRam_Ip_BaseAddr->RADR |= F16ASM_RADR_UTRR_MASK;

        /* 5b. Wait for controller to signal read completion. */
        (void)MRam_Ip_WaitUntilRegisterBitsSet(&(MRam_Ip_BaseAddr->MCRS),
                                               F16ASM_MCRS_DONE_MASK,
                                               MRAM_IP_STATUS_WRITE_TIMEOUT_BUSY);

        /* 6. Determine the status of the read operation */
        /* Examine the MCRS[EEE] flag */
        if (ResultEEE != NULL_PTR)
        {
            *ResultEEE = ((MRam_Ip_BaseAddr->MCRS & F16ASM_MCRS_EEE_MASK) == F16ASM_MCRS_EEE_MASK);
        }

        /* Clear the EEE flag if set */
        if ((MRam_Ip_BaseAddr->MCRS & F16ASM_MCRS_EEE_MASK) == F16ASM_MCRS_EEE_MASK)
        {
            MRam_Ip_BaseAddr->MCRS = F16ASM_MCRS_EEE_MASK;
        }

        /* 7. Disable the EDC-after-ECC data input */
        MRam_Ip_BaseAddr->UT0 &= ~(F16ASM_UT0_EDIE_MASK);
    }

    /* Exit UTest mode regardless of BIST result. */
    (void)MRam_Ip_DisableUTest();

    return Status;
}

/**
 * @brief Performs Address-encode logic check on MRAM.
 *
 * This function follows the address-encode logic check sequence:
 * 1. Enter UTest mode
 * 2. Enable the inversion of the address-encode value
 * 3. Provide the address bit or bits to invert
 * 4. Provide the address bit or bits to invert to the MRAMC
 * 5. Specify the page address to receive the inverted address
 * 6. Read the array
 * 7. Determine the status of the read operation
 * 8. Disable the inversion of the address-encode value
 *
 * @param[in]   Address      Memory address to test
 * @param[in]   AeisValue    Value for UA0[AEIS] - Address-encode invert selector
 * @param[in]   AeiValue     Value for UA0[AEI] - Address-encode invert
 * @param[in]   AeicValue    Value for UA1[AEIC] - Address-encode invert complement
 * @param[in]   AeioValue    Value for UA1[AEIO] - Address-encode invert output
 * @param[out]  ResultAEE    Pointer to store the AEE flag result
 * @param[in]   InstanceId   Instance ID
 * @return      Operation status (MRAM_IP_STATUS_SUCCESS or error code)
 */
MRam_Ip_StatusType MRam_Ip_UTestAddressEncodeLogicCheck(
    MRam_Ip_AddressType Address,
    uint32 AeisValue,
    uint32 AeiValue,
    uint32 AeicValue,
    uint32 AeioValue,
    boolean *ResultAEE,
    MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    uint32 ReadData;
    (void) InstanceId;
    /* Validate parameter values against register field widths */
    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(ResultAEE != NULL_PTR);
    MRAM_IP_DEV_ASSERT(MRam_Ip_GetAddressType(Address) != MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS);
    MRAM_IP_DEV_ASSERT((Address & MRAM_IP_WRITE_PAGE_OFFSET_MASK) == 0U);     /* Address must be 32-byte page aligned */
    MRAM_IP_DEV_ASSERT(AeisValue <= 0x0FU);          /* AEIS: 4 bits, max 0xF       */
    MRAM_IP_DEV_ASSERT(AeiValue  <= 0x00FFFFFFU);    /* AEI:  24 bits, max 0xFFFFFF */
    MRAM_IP_DEV_ASSERT(AeicValue <= 0xFFU);           /* AEIC: 8 bits, max 0xFF     */
    MRAM_IP_DEV_ASSERT(AeioValue <= 0x7FFFFFU);       /* AEIO: 23 bits, max 0x7FFFFF */
    #endif

    if (ResultAEE != NULL_PTR)
    {
        *ResultAEE = (boolean)FALSE;
    }

    /* 1. Enter UTest mode */
    Status = MRam_Ip_EnableUTest();

    if (Status == MRAM_IP_STATUS_SUCCESS)
    {
        /* 2. Enable the inversion of the address-encode value */
        MRam_Ip_BaseAddr->UT0 |= F16ASM_UT0_AEIE_MASK;

        /* 3. Provide the address bit or bits to invert */
        /* Configure UA0 register with AEIS and AEI fields */
        MRam_Ip_BaseAddr->UA0 = (F16ASM_UA0_AEIS(AeisValue) | F16ASM_UA0_AEI(AeiValue));

        /* Configure UA1 register with AEIC and AEIO fields */
        MRam_Ip_BaseAddr->UA1 = (F16ASM_UA1_AEIC(AeicValue) | F16ASM_UA1_AEIO(AeioValue));

        /* 5. Specify the page address to receive the inverted address */
        MRam_Ip_BaseAddr->RADR = (Address & F16ASM_RADR_RADDR_MASK);

        /* 6. Read the array - Submit a read request to the MRAMC */
        ReadData = *((volatile uint32*)Address);
        (void)ReadData;  /* Prevent unused variable warning */

        /* 7. Determine the status of the read operation */
        /* Examine the MCRS[AEE] flag */
        if (ResultAEE != NULL_PTR)
        {
            *ResultAEE = ((MRam_Ip_BaseAddr->MCRS & F16ASM_MCRS_AEE_MASK) == F16ASM_MCRS_AEE_MASK);
        }

        /* Clear the AEE flag if set */
        if ((MRam_Ip_BaseAddr->MCRS & F16ASM_MCRS_AEE_MASK) == F16ASM_MCRS_AEE_MASK)
        {
            MRam_Ip_BaseAddr->MCRS = F16ASM_MCRS_AEE_MASK;
        }

        /* 8. Disable the inversion of the address-encode value */
        MRam_Ip_BaseAddr->UT0 &= ~(F16ASM_UT0_AEIE_MASK);
    }

    /* Exit UTest mode regardless of BIST result. */
    (void)MRam_Ip_DisableUTest();

    return Status;
}

/**
 * @brief Performs Reference recovery and refresh operation on MRAM.
 *
 * This function follows the reference recovery and refresh sequence:
 * 1. Enter UTest mode
 * 2. Enable the operation
 * 3. Start the operation
 * 4. Allow time for F16ASM to complete the operation
 * 5. Disable the operation
 *
 * Reference recovery and refresh can recover MRAM references if a known
 * magnetic overexposure or an array detection corruption event occurs.
 * Reads and writes of the MRAM are not allowed during this operation.
 * This operation cannot be aborted or suspended.
 *
 * @param[in]   InstanceId   Instance ID
 * @return      Operation status (MRAM_IP_STATUS_SUCCESS or error code)
 */
MRam_Ip_StatusType MRam_Ip_UTestReferenceRecoveryRefresh(MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    (void) InstanceId;


    /* 1. Enter UTest mode */
    Status = MRam_Ip_EnableUTest();

    if (Status == MRAM_IP_STATUS_SUCCESS)
    {
        /* 2. Enable the operation */
        MRam_Ip_BaseAddr->UT0 |= F16ASM_UT0_RRE_MASK;

        /* 3. Start the operation */
        MRam_Ip_BaseAddr->UT0 |= F16ASM_UT0_AIE_MASK;

        /* 4. Allow time for F16ASM to complete the operation */
        /* Wait until UT0[AID] becomes 1 */
        Status = MRam_Ip_WaitUntilRegisterBitsSet(&(MRam_Ip_BaseAddr->UT0),
                                                F16ASM_UT0_AID_MASK,
                                                MRAM_IP_STATUS_WRITE_TIMEOUT_BUSY);

        /* 5. Disable the operation */
        /* Write 0 to the RRE and AIE fields in UTest 0 (UT0) */
        MRam_Ip_BaseAddr->UT0 &= ~(F16ASM_UT0_RRE_MASK | F16ASM_UT0_AIE_MASK);
    }

    /* Exit UTest mode regardless of BIST result. */
    (void)MRam_Ip_DisableUTest();

    return Status;
}

/**
 * @brief Configure Port Read ID Assignment registers for a specific port
 *
 * @param[in] PortConfig    Pointer to the port configuration
 * @param[in] InstanceId    HW instance ID
 */
static void MRam_Ip_ConfigurePortRIA(const MRam_Ip_PortConfigType *PortConfig,
                                     MRam_Ip_InstanceIdType InstanceId)
{
    switch (PortConfig->id)
    {
        /*M7 Core*/
        case MRAM_IP_PORT_ID_1:
        {
            MRamC_Ip_BaseAddr[InstanceId]->P1_RIA_W0 = MRAMC_P1_RIA_W0_MASK_ID(PortConfig->PortReadIDAssignmentWord0.MaskDomainID) |
                                                    MRAMC_P1_RIA_W0_NUM_ENTRIES(PortConfig->PortReadIDAssignmentWord0.BufferEntries) |
                                                    MRAMC_P1_RIA_W0_ENABLE(PortConfig->PortReadIDAssignmentWord0.Enable ? TRUE : FALSE) |
                                                    MRAMC_P1_RIA_W0_LOCK(TRUE);

            MRamC_Ip_BaseAddr[InstanceId]->P1_RIA_W1 = MRAMC_P1_RIA_W1_MASK_ID(PortConfig->PortReadIDAssignmentWord1.MaskDomainID) |
                                                    MRAMC_P1_RIA_W1_NUM_ENTRIES(PortConfig->PortReadIDAssignmentWord1.BufferEntries) |
                                                    MRAMC_P1_RIA_W1_ENABLE(PortConfig->PortReadIDAssignmentWord1.Enable ? TRUE : FALSE) |
                                                    MRAMC_P1_RIA_W1_LOCK(TRUE);
            break;
        }
        /*M7 Core*/
        case MRAM_IP_PORT_ID_2:
        {
            MRamC_Ip_BaseAddr[InstanceId]->P2_RIA_W0 = MRAMC_P2_RIA_W0_MASK_ID(PortConfig->PortReadIDAssignmentWord0.MaskDomainID) |
                                                    MRAMC_P2_RIA_W0_NUM_ENTRIES(PortConfig->PortReadIDAssignmentWord0.BufferEntries) |
                                                    MRAMC_P2_RIA_W0_ENABLE(PortConfig->PortReadIDAssignmentWord0.Enable ? TRUE : FALSE) |
                                                    MRAMC_P2_RIA_W0_LOCK(TRUE);

            MRamC_Ip_BaseAddr[InstanceId]->P2_RIA_W1 = MRAMC_P2_RIA_W1_MASK_ID(PortConfig->PortReadIDAssignmentWord1.MaskDomainID) |
                                                    MRAMC_P2_RIA_W1_NUM_ENTRIES(PortConfig->PortReadIDAssignmentWord1.BufferEntries) |
                                                    MRAMC_P2_RIA_W1_ENABLE(PortConfig->PortReadIDAssignmentWord1.Enable ? TRUE : FALSE) |
                                                    MRAMC_P2_RIA_W1_LOCK(TRUE);
            break;
        }
        /*R52 Core*/
        case MRAM_IP_PORT_ID_3:
        {
            MRamC_Ip_BaseAddr[InstanceId]->P3_RIA_W0 = MRAMC_P3_RIA_W0_MASK_ID(PortConfig->PortReadIDAssignmentWord0.MaskDomainID) |
                                                    MRAMC_P3_RIA_W0_NUM_ENTRIES(PortConfig->PortReadIDAssignmentWord0.BufferEntries) |
                                                    MRAMC_P3_RIA_W0_ENABLE(PortConfig->PortReadIDAssignmentWord0.Enable ? TRUE : FALSE) |
                                                    MRAMC_P3_RIA_W0_LOCK(TRUE);
            break;
        }
        default:
            /* No action required - port ID is validated at configuration time */
            (void)PortConfig;
            break;
    }
}

/**
 * @brief Configure partition lock registers
 *
 * @param[in] pConfig       Pointer to MRAM configuration
 * @param[in] InstanceId    HW instance ID
 */
static void MRam_Ip_ConfigurePartitionLocks(MRam_Ip_ConfigType const * pConfig,
                                            MRam_Ip_InstanceIdType InstanceId)
{
    MRamC_Ip_BaseAddr[InstanceId]->LPLOCK = MRAMC_LPLOCK_LCK0(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.LCK0 ? TRUE : FALSE) |
                                        MRAMC_LPLOCK_LCK1(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.LCK1 ? TRUE : FALSE) |
                                        MRAMC_LPLOCK_LCK2(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.LCK2 ? TRUE : FALSE) |
                                        MRAMC_LPLOCK_LCK3(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.LCK3 ? TRUE : FALSE) |
                                        MRAMC_LPLOCK_LCK4(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.LCK4 ? TRUE : FALSE) |
                                        MRAMC_LPLOCK_LCK5(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.LCK5 ? TRUE : FALSE) |
                                        MRAMC_LPLOCK_LCK6(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.LCK6 ? TRUE : FALSE) |
                                        MRAMC_LPLOCK_LCK7(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.LCK7 ? TRUE : FALSE);

    MRamC_Ip_BaseAddr[InstanceId]->PLPLOCK[0u] = MRAMC_PLPLOCK_PLCK0(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.PLCK0) |
                                            MRAMC_PLPLOCK_PLCK1(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.PLCK1) |
                                            MRAMC_PLPLOCK_PLCK2(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.PLCK2) |
                                            MRAMC_PLPLOCK_PLCK3(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.PLCK3) |
                                            MRAMC_PLPLOCK_PLCK4(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.PLCK4) |
                                            MRAMC_PLPLOCK_PLCK5(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.PLCK5) |
                                            MRAMC_PLPLOCK_PLCK6(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.PLCK6) |
                                            MRAMC_PLPLOCK_PLCK7(pConfig->MRamControllerConfig.MRamCLargePartitionLockConfig.PLCK7);

    MRamC_Ip_BaseAddr[InstanceId]->SPLOCK = MRAMC_SPLOCK_LCK(pConfig->MRamControllerConfig.MRamCSmallPartitionLockConfig.LCK ? TRUE : FALSE);

    MRamC_Ip_BaseAddr[InstanceId]->PSPLOCK = MRAMC_PSPLOCK_PLCK(pConfig->MRamControllerConfig.MRamCSmallPartitionLockConfig.PLCK);

    MRamC_Ip_BaseAddr[InstanceId]->LPOLOCK = MRAMC_LPOLOCK_LCK(pConfig->MRamControllerConfig.MRamCLargePartitionOTPLockConfig.LCK ? TRUE : FALSE);

    MRamC_Ip_BaseAddr[InstanceId]->PLPOLOCK = MRAMC_PLPOLOCK_PLCK(pConfig->MRamControllerConfig.MRamCLargePartitionOTPLockConfig.PLCK);
}

/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * @brief   Initialize the MRAMC and MRAM.
 * @details Configures the MRAM controller and memory with specified settings, clears any pending
 *          errors, and verifies proper initialization.
 *
 * @param[in]  pConfig Pointer to configuration structure
 * @param[in]  InstanceId HW instance ID
 *
 * @implements MRam_Ip_Init_Activity
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
void MRam_Ip_Init(MRam_Ip_ConfigType const * pConfig, MRam_Ip_InstanceIdType InstanceId)
{
    /* Validate input parameters */
    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(NULL_PTR != pConfig);
    /* Validate base pointers are properly initialized */
    MRAM_IP_DEV_ASSERT(NULL_PTR != MRamC_Ip_BaseAddr[InstanceId]);
    MRAM_IP_DEV_ASSERT(NULL_PTR != MRam_Ip_BaseAddr);
    MRAM_IP_DEV_ASSERT(InstanceId < (MRam_Ip_InstanceIdType)MRAMC_INSTANCE_COUNT);
    #endif

    uint8 PC_Index = 0U;

    MRam_Ip_Config = pConfig;

    /*************Start config MRAMC*************/
#if defined MRAMC_CFG_DERR_SUP_MASK
    /* Map the boolean configuration flag to an unsigned bitfield value before
     * it is placed into the register (a set flag maps to 1, a clear flag to 0).
     * The written value is unchanged; the ternary yields an unsigned result so
     * no boolean value is used directly as an unsigned operand. */
    MRamC_Ip_BaseAddr[InstanceId]->CFG = MRAMC_CFG_DERR_SUP((MRam_Ip_Config->MRamControllerConfig.MRamDataErrorSuppress != FALSE) ? 1UL : 0UL);
#endif

    for (PC_Index = 0; PC_Index < MRam_Ip_Config->MRamControllerConfig.MRamCPortConfigCount; PC_Index++)
    {
        MRamC_Ip_BaseAddr[InstanceId]->PC[MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[PC_Index].id] = MRAMC_PC_IB(MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[PC_Index].IB ? TRUE : FALSE) |
                                                                                                            MRAMC_PC_RCBFEN(MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[PC_Index].RCBFEN ? TRUE : FALSE) |
                                                                                                            MRAMC_PC_RDBFEN(MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[PC_Index].RDBFEN ? TRUE : FALSE) |
                                                                                                            MRAMC_PC_RCPFEN(MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[PC_Index].RCPFEN ? TRUE : FALSE) |
                                                                                                            MRAMC_PC_RDPFEN(MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[PC_Index].RDPFEN ? TRUE : FALSE) |
                                                                                                            MRAMC_PC_WRBFEN(MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[PC_Index].WRBFEN ? TRUE : FALSE);

        /* Configure Port Read ID Assignment registers */
        MRam_Ip_ConfigurePortRIA(&MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[PC_Index], InstanceId);
    }

    /* Configure partition locks and protection levels */
    MRam_Ip_ConfigurePartitionLocks(MRam_Ip_Config, InstanceId);

    /* Configure watchdog timer if enabled */
    if (MRam_Ip_Config->MRamControllerConfig.MRamCWatchdogConfig.watchdogTimerEnabled == TRUE)
    {
        MRamC_Ip_BaseAddr[InstanceId]->WWDOG = MRAMC_WWDOG_WDL(FALSE) |
                                            MRAMC_WWDOG_WDT(MRam_Ip_Config->MRamControllerConfig.MRamCWatchdogConfig.watchdogTimer) |
                                            MRAMC_WWDOG_WDD(FALSE); /* FALSE = Timer enabled */
    }
    else
    {
        /* Disable watchdog timer */
        MRamC_Ip_BaseAddr[InstanceId]->WWDOG = MRAMC_WWDOG_WDL(FALSE) |
                                            MRAMC_WWDOG_WDT(MRAM_IP_WATCHDOG_40000_CLOCKS) |
                                            MRAMC_WWDOG_WDD(TRUE); /* TRUE = Timer disabled */
    }

    /* Enable interrupts based on configuration */
    MRam_Ip_EnableInterrupts(InstanceId, MRam_Ip_Config->MRamControllerConfig.MRamCInterruptsEnabled);

    /*************Stop config MRAMC*************/

    /*************Start config MRAM*************/
    /* Configure MRAM memory settings */
    /* Check if MRAM is idle before setting WPL */
    if (MRam_Ip_Config->MRamMemoryConfig.WPL == TRUE)
    {
        (void)MRam_Ip_WaitUntilRegisterBitsClear(&(MRamC_Ip_BaseAddr[InstanceId]->WRL[0u].WSTAT),
                                                                MRAMC_WSTAT_WBUSY_MASK,
                                                                MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);

        (void)MRam_Ip_WaitUntilRegisterBitsClear(&(MRamC_Ip_BaseAddr[InstanceId]->WRL[1u].WSTAT),
                                                                MRAMC_WSTAT_WBUSY_MASK,
                                                                MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);
    }

    MRam_Ip_BaseAddr->MCR = F16ASM_MCR_CVE(MRam_Ip_Config->MRamMemoryConfig.CVE ? TRUE : FALSE) |
                        F16ASM_MCR_WPL(MRam_Ip_Config->MRamMemoryConfig.WPL ? TRUE : FALSE) |
                        F16ASM_MCR_RWSL(TRUE) |
                        F16ASM_MCR_RWSC(MRam_Ip_Config->MRamMemoryConfig.RWSC);
    /*Clear MCRS register to reset to default state for errors status */
    if (MRam_Ip_Config->MRamMemoryConfig.CVE == TRUE)
    {
        MRam_Ip_BaseAddr->MCRS = F16ASM_MCRS_EER_MASK |
                                   F16ASM_MCRS_TBC_MASK |
                                   F16ASM_MCRS_DBC_MASK |
                                   F16ASM_MCRS_SBC_MASK |
                                   F16ASM_MCRS_AEE_MASK |
                                   F16ASM_MCRS_EEE_MASK |
                                   F16ASM_MCRS_WRE_MASK |
                                   F16ASM_MCRS_WCE_MASK |
                                   F16ASM_MCRS_WRP_MASK |
                                   F16ASM_MCRS_WAE_MASK |
                                   F16ASM_MCRS_WTE_MASK;
    }
    /*************Stop config MRAM*************/
}

/** * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * @brief   DeInitialize the MRAMC and MRAM.
 * @details Restores MRAM controller and memory to default configuration:
 *          - Enables all buffer functionalities in port configuration
 *          - Clears all partition lock settings to unlock state
 *          - Disables and resets watchdog timer configuration
 *          - Sets MRAM memory to default operational parameters
 *
 * @param[in]  InstanceId HW InstanceID
 *
 * @implements MRam_Ip_DeInit_Activity
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
void MRam_Ip_DeInit(MRam_Ip_InstanceIdType InstanceId)
{
    boolean continueExecution = TRUE;

    /* Loop index over configured ports, and per-step status for the teardown waits */
    uint8 PC_Index = 0u;
    MRam_Ip_StatusType status;
    uint32 ut0Value;
    MRam_Ip_StatusType clearStatus;

    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(NULL_PTR != MRam_Ip_Config);
    MRAM_IP_DEV_ASSERT(InstanceId < (MRam_Ip_InstanceIdType)MRAMC_INSTANCE_COUNT);
    #endif

    MRam_Ip_DisableInterrupts(InstanceId);
    if((MRam_Ip_BaseAddr->UT0 & F16ASM_UT0_UTE_MASK) == F16ASM_UT0_UTE_MASK)
    {
        /* Check if we can safely exit UTest mode */
        ut0Value = MRam_Ip_BaseAddr->UT0;

        /* Verify AID = 1 and other test modes are disabled */
        if (((ut0Value & F16ASM_UT0_AID_MASK) == F16ASM_UT0_AID_MASK) &&
            ((ut0Value & (F16ASM_UT0_RRE_MASK | F16ASM_UT0_AIE_MASK |
                        F16ASM_UT0_EIE_MASK | F16ASM_UT0_EDIE_MASK |
                        F16ASM_UT0_AEIE_MASK)) == 0U))
        {
            /* Safe to exit UTest mode */
            MRam_Ip_BaseAddr->UT0 &= ~F16ASM_UT0_UTE_MASK;

            /* Wait for UTest mode to exit */
            status = MRam_Ip_WaitUntilRegisterBitsClear(&(MRam_Ip_BaseAddr->UT0),
                                                        F16ASM_UT0_UTE_MASK,
                                                        MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);
            if (status != MRAM_IP_STATUS_SUCCESS)
            {
                continueExecution = FALSE;
            }
        }
        else
        {
            /* Cannot safely exit UTest mode - force stop ongoing operations */
            if ((ut0Value & F16ASM_UT0_AIE_MASK) != 0U) {
                MRam_Ip_BaseAddr->UT0 &= ~F16ASM_UT0_AIE_MASK;  /* Stop array integrity */
            }
            if ((ut0Value & F16ASM_UT0_RRE_MASK) != 0U) {
                MRam_Ip_BaseAddr->UT0 &= ~F16ASM_UT0_RRE_MASK;  /* Stop reference recovery */
            }
            /* Clear other test enables */
            MRam_Ip_BaseAddr->UT0 &= ~(F16ASM_UT0_EIE_MASK | F16ASM_UT0_EDIE_MASK | F16ASM_UT0_AEIE_MASK);

            /* Wait for AID = 1, then exit UTest */
            status = MRam_Ip_WaitUntilRegisterBitsSet(&(MRam_Ip_BaseAddr->UT0),
                                                        F16ASM_UT0_AID_MASK,
                                                        MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);

            if (status != MRAM_IP_STATUS_SUCCESS)
            {
                continueExecution = FALSE;
            }

            /* Now safe to exit */
            MRam_Ip_BaseAddr->UT0 &= ~F16ASM_UT0_UTE_MASK;
        }
    }

    /* Wait for any pending write operations to complete with timeout protection */
    if (continueExecution)
    {
        status = MRam_Ip_WaitUntilRegisterBitsClear(&(MRamC_Ip_BaseAddr[InstanceId]->WRL[0u].WSTAT),
                                                                MRAMC_WSTAT_WBUSY_MASK,
                                                                MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);
        if (status != MRAM_IP_STATUS_SUCCESS)
        {
            continueExecution = FALSE;
        }


        status = MRam_Ip_WaitUntilRegisterBitsClear(&(MRamC_Ip_BaseAddr[InstanceId]->WRL[1u].WSTAT),
                                                                MRAMC_WSTAT_WBUSY_MASK,
                                                                MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);
        if (status != MRAM_IP_STATUS_SUCCESS)
        {
            continueExecution = FALSE;
        }
    }

    /* Check and exit low power mode if active */
    if (continueExecution && ((MRam_Ip_BaseAddr->MCRS & F16ASM_MCRS_LPA_MASK) == F16ASM_MCRS_LPA_MASK))
    {
        /* Clear LPR bit to exit low power mode (W1C behavior) */
        MRam_Ip_BaseAddr->MCRS = F16ASM_MCRS_LPR_MASK;  /* Write 1 to clear */

        /* Wait for low power mode to exit */
        status = MRam_Ip_WaitUntilRegisterBitsClear(&(MRam_Ip_BaseAddr->MCRS),
                                                                F16ASM_MCRS_LPA_MASK,
                                                                MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);
        if (status != MRAM_IP_STATUS_SUCCESS)
        {
            continueExecution = FALSE;
        }
    }

    /* Process with configuration reset if no critical errors occurred */
    if (continueExecution)
    {
        /* Clear all error status flags before reset */
        clearStatus = MRam_Ip_GetMemoryErrorStatus();
        if (clearStatus != MRAM_IP_STATUS_SUCCESS)
        {
            /* Previous error flags were present and have been cleared */
        }

        /*************Start config MRAMC*************/
#if defined MRAMC_CFG_DERR_SUP_MASK
        MRamC_Ip_BaseAddr[InstanceId]->CFG = MRAMC_CFG_DERR_SUP(FALSE);
#endif

        /* Reset port configuration registers - enable all buffer functionalities */
        for (PC_Index = 0; PC_Index < MRam_Ip_Config->MRamControllerConfig.MRamCPortConfigCount; PC_Index++)
        {
            /* Enable write buffer, disable invalidate buffer, disable code/data prefetching, enable read buffers */
            MRamC_Ip_BaseAddr[InstanceId]->PC[MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[PC_Index].id] = MRAMC_PC_WRBFEN(TRUE)      | /* Enable write buffer */
                                                                                                                    MRAMC_PC_IB(FALSE)        | /* Disable invalidate buffer */
                                                                                                                    MRAMC_PC_RCPFEN(FALSE)    | /* Disable code prefetching */
                                                                                                                    MRAMC_PC_RDPFEN(FALSE)    | /* Disable data prefetching */
                                                                                                                    MRAMC_PC_RDBFEN(TRUE)     | /* Enable read data buffer */
                                                                                                                    MRAMC_PC_RCBFEN(TRUE);      /* Enable read code buffer */
        }

        /* Clear all large partition lock settings */
        MRamC_Ip_BaseAddr[InstanceId]->LPLOCK = MRAMC_LPLOCK_LCK0(FALSE) | /* Unlock large partition 0 */
                                MRAMC_LPLOCK_LCK1(FALSE) | /* Unlock large partition 1 */
                                MRAMC_LPLOCK_LCK2(FALSE) | /* Unlock large partition 2 */
                                MRAMC_LPLOCK_LCK3(FALSE) | /* Unlock large partition 3 */
                                MRAMC_LPLOCK_LCK4(FALSE) | /* Unlock large partition 4 */
                                MRAMC_LPLOCK_LCK5(FALSE) | /* Unlock large partition 5 */
                                MRAMC_LPLOCK_LCK6(FALSE) | /* Unlock large partition 6 */
                                MRAMC_LPLOCK_LCK7(FALSE);  /* Unlock large partition 7 */

        /* Clear small partition lock setting */
        MRamC_Ip_BaseAddr[InstanceId]->SPLOCK = MRAMC_SPLOCK_LCK(FALSE);  /* Unlock small partition */

        /* Clear OTP partition lock setting */
        MRamC_Ip_BaseAddr[InstanceId]->LPOLOCK = MRAMC_LPOLOCK_LCK(FALSE);  /* Unlock OTP partition */

        /* Clear permanent large partition lock settings */
        MRamC_Ip_BaseAddr[InstanceId]->PLPLOCK[0u] = MRAMC_PLPLOCK_PLCK0(FALSE) | /* Disable permanent lock for large partition 0 */
                                        MRAMC_PLPLOCK_PLCK1(FALSE) | /* Disable permanent lock for large partition 1 */
                                        MRAMC_PLPLOCK_PLCK2(FALSE) | /* Disable permanent lock for large partition 2 */
                                        MRAMC_PLPLOCK_PLCK3(FALSE) | /* Disable permanent lock for large partition 3 */
                                        MRAMC_PLPLOCK_PLCK4(FALSE) | /* Disable permanent lock for large partition 4 */
                                        MRAMC_PLPLOCK_PLCK5(FALSE) | /* Disable permanent lock for large partition 5 */
                                        MRAMC_PLPLOCK_PLCK6(FALSE) | /* Disable permanent lock for large partition 6 */
                                        MRAMC_PLPLOCK_PLCK7(FALSE);  /* Disable permanent lock for large partition 7 */

        /* Clear permanent small partition lock setting */
        MRamC_Ip_BaseAddr[InstanceId]->PSPLOCK = MRAMC_PSPLOCK_PLCK(FALSE);  /* Disable permanent lock for small partition */

        /* Clear permanent OTP partition lock setting */
        MRamC_Ip_BaseAddr[InstanceId]->PLPOLOCK = MRAMC_PLPOLOCK_PLCK(FALSE);  /* Disable permanent lock for OTP partition */

        /* Reset watchdog configuration - enable watchdog with default timer value */
        MRamC_Ip_BaseAddr[InstanceId]->WWDOG = MRAMC_WWDOG_WDL(FALSE) | /* Set watchdog lock to 0 (unlock configuration) */
                                               MRAMC_WWDOG_WDT(FALSE) | /* Set watchdog timer to 0 (40000 clocks) */
                                               MRAMC_WWDOG_WDD(FALSE);  /* Set watchdog disable bit to 0 (enabled) */
        /*************Stop config MRAMC*************/

        /*************Start config MRAM*************/
        /* Reset MRAM memory configuration */
        MRam_Ip_BaseAddr->MCR = F16ASM_MCR_CVE(TRUE)     | /* Enable correction verification to ensure data integrity */
                                F16ASM_MCR_WPL(FALSE)    | /* Set write pulse length to 0 (minimum value) for default timing */
                                F16ASM_MCR_RWSC(FALSE)   | /* Set read wait state count to 0 (minimum value) */
                                F16ASM_MCR_RWSL(TRUE);  /* Enable read wait states for low frequencies to ensure stability */
        /*************Stop config MRAM*************/
    }

    MRam_Ip_Config = NULL_PTR;
}

/**
 * @brief   Unified AXI write/erase implementation using direct memory-mapped access
 *
 * Handles both write (copy from source buffer) and erase (write erased values)
 * using byte/halfword/word AXI accesses based on alignment. Manages partition
 * locks around the operation.
 *
 * @param[in] DestAddress      Target MRAM address
 * @param[in] pu8SrcAddress    Source data (NULL_PTR for erase)
 * @param[in] SizeInBytes      Bytes to process
 * @param[in] InstanceId       MRAM controller instance
 * @param[in] IsWriteOperation TRUE for write, FALSE for erase
 * @return    MRam_Ip_StatusType
 */
/* MRam_Ip_AxiCursor is defined in MRam_Ip_Types.h */

/**
 * @brief   Flush the port buffers, then program one sub-word (1..3 byte) run and advance
 *          the cursor. Shared by the HEAD and TAIL phases of MRam_Ip_AxiOp_WriteRange,
 *          which are identical except for how PartialBytes is derived.
 * @details The flush makes the read inside MRam_Ip_RmwPartialWord_AXI see the latest
 *          committed word. On a flush failure pAxiCursor->Status holds the error and the
 *          cursor is left unchanged so the caller stops.
 *
 * @param[in,out] pAxiCursor       Status + address + remaining + source-index cursor.
 * @param[in]     PartialBytes     Number of bytes (1..3) to program in this run.
 * @param[in]     RmwSrcPtr        Source for the RMW, or NULL_PTR for erase.
 * @param[in]     IsWriteOperation TRUE for write (advances the source index), FALSE for erase.
 * @param[in]     InstanceId       MRAM controller instance identifier.
 */
static void MRam_Ip_AxiWritePartialWord(MRam_Ip_AxiCursor *pAxiCursor,
                                        uint32 PartialBytes,
                                        uint8 const * RmwSrcPtr,
                                        boolean IsWriteOperation,
                                        MRam_Ip_InstanceIdType InstanceId)
{
    pAxiCursor->Status = MRam_Ip_FlushAxiPortBuffers(InstanceId);
    if (pAxiCursor->Status == MRAM_IP_STATUS_SUCCESS)
    {
        MRam_Ip_RmwPartialWord_AXI(pAxiCursor->MRamAddress, PartialBytes, RmwSrcPtr, pAxiCursor->currentIndex);

        pAxiCursor->MRamAddress += PartialBytes;
        if (IsWriteOperation)
        {
            pAxiCursor->currentIndex += PartialBytes;
        }
        pAxiCursor->RemainingBytes -= PartialBytes;
    }
}

/**
 * @brief   Writes/erases the range with the HEAD / BODY / TAIL AXI pattern.
 * @details Extracted verbatim from MRam_Ip_ProcessOperation_AXI to keep HIS_CCM
 *          in range; logic is unchanged. Advances the cursor and sets pAxiCursor->Status
 *          on a port-buffer flush failure.
 *
 * @param[in,out] pAxiCursor               Status + address + remaining + source-index cursor.
 * @param[in]     RmwSrcPtr         Source for the partial-word RMW, or NULL_PTR for erase.
 * @param[in]     pu8SrcAddress     Source buffer for the aligned BODY word writes.
 * @param[in]     IsWriteOperation  TRUE for write, FALSE for erase.
 * @param[in]     InstanceId        MRAM controller instance identifier.
 */
static void MRam_Ip_AxiOp_WriteRange(MRam_Ip_AxiCursor *pAxiCursor,
                                     uint8 const * RmwSrcPtr,
                                     uint8 const * pu8SrcAddress,
                                     boolean IsWriteOperation,
                                     MRam_Ip_InstanceIdType InstanceId)
{
    /* Number of bytes processed by the HEAD or TAIL partial-word phase.
     * Computed from the address alignment and the bytes still to write. */
    uint32 PartialBytes;

    /* ================================================================
     * Explicit HEAD / BODY / TAIL pattern for the actual write/erase.
     *
     * HEAD: 0..3 unaligned starting bytes - one RMW brings the address
     *       up to the next 4-byte boundary, after which the bulk path can
     *       run on aligned addresses only.
     * BODY: bulk aligned 4-byte word writes (or erases). Single MMIO
     *       store per word, no per-iteration helper call, no per-iteration
     *       flush. This is the hot path; the MRAMC gathering buffer is
     *       allowed to merge adjacent stores, and the trailing flush at
     *       the end of the function drains everything before we sample
     *       ERRSTAT0 / MCRS.
     * TAIL: 0..3 trailing bytes after the aligned bulk - one RMW.
     *
     * Each RMW phase flushes the port buffers first so the read inside
     * RmwPartialWord_AXI returns the latest committed word value.
     * ================================================================ */

    /* PHASE 1: HEAD ------------------------------------------------- */
    if ((pAxiCursor->Status == MRAM_IP_STATUS_SUCCESS) &&
        ((pAxiCursor->MRamAddress & MRAM_IP_WORD_ALIGNMENT_MASK) != 0U) &&
        (pAxiCursor->RemainingBytes > 0U))
    {
        /* Bytes between the current address and the next 4-byte boundary,
         * capped at RemainingBytes for very small operations that begin
         * unaligned and end before reaching the next boundary. */
        PartialBytes = 4U - (pAxiCursor->MRamAddress & MRAM_IP_WORD_ALIGNMENT_MASK);
        if (PartialBytes > (uint32)pAxiCursor->RemainingBytes)
        {
            PartialBytes = (uint32)pAxiCursor->RemainingBytes;
        }

        MRam_Ip_AxiWritePartialWord(pAxiCursor, PartialBytes, RmwSrcPtr, IsWriteOperation, InstanceId);
    }

    /* PHASE 2: BODY ------------------------------------------------- */
    while ((pAxiCursor->Status == MRAM_IP_STATUS_SUCCESS) && (pAxiCursor->RemainingBytes >= 4U))
    {
        if (IsWriteOperation)
        {
            *((volatile uint32*)pAxiCursor->MRamAddress) = MRam_Ip_LoadWordUnaligned(&pu8SrcAddress[pAxiCursor->currentIndex]);
        }
        else
        {
            *((volatile uint32*)pAxiCursor->MRamAddress) = MRAM_IP_ERASED_VALUE_U32;
        }

        pAxiCursor->MRamAddress += 4U;
        if (IsWriteOperation)
        {
            pAxiCursor->currentIndex += 4U;
        }
        pAxiCursor->RemainingBytes -= 4U;

        /* Each MRAMC system-bus port carries a single-entry gathering
         * write buffer of MRAM_IP_AXI_GATHERING_BUFFER_SIZE bytes. The
         * spec does not document what happens when the buffer is full
         * and a new write arrives - implementations may either
         * back-pressure the bus (safe, but stalls the CPU) or evict the
         * current entry to make room (undefined merge semantics).
         *
         * To avoid relying on that unspecified behavior, drain the CPU
         * write buffer at every buffer-sized boundary so at most one
         * buffer worth of writes is ever in flight. The cost is a single
         * DSB per buffer-size / 4 word writes; negligible compared to
         * MRAM commit latency. */
        if ((pAxiCursor->MRamAddress & MRAM_IP_AXI_GATHERING_BUFFER_MASK) == 0U)
        {
            MCAL_DATA_SYNC_BARRIER();
        }
    }

    /* PHASE 3: TAIL ------------------------------------------------- */
    if ((pAxiCursor->Status == MRAM_IP_STATUS_SUCCESS) && (pAxiCursor->RemainingBytes > 0U))
    {
        /* The BODY loop consumes every full 4-byte chunk, so on entry
         * here RemainingBytes is in [1..3]. The cast to uint32 therefore
         * loses no bits even if MRam_Ip_LengthType is later widened past
         * 32 bits, and the value fits the NumBytes parameter range
         * documented on MRam_Ip_RmwPartialWord_AXI. */
        PartialBytes = (uint32)pAxiCursor->RemainingBytes;

        MRam_Ip_AxiWritePartialWord(pAxiCursor, PartialBytes, RmwSrcPtr, IsWriteOperation, InstanceId);
    }
}

/**
 * @brief   Post-write AXI finalize: flush the gathering buffer, read controller
 *          and memory error status, promote any async-mailbox error into Status.
 * @details Extracted verbatim from MRam_Ip_ProcessOperation_AXI to keep HIS_CCM
 *          in range; logic unchanged. The flush and the ERRSTAT0/MCRS reads run
 *          UNCONDITIONALLY (even on the error path) so pending writes commit and
 *          no flag leaks to the next call; each result is applied to Status only
 *          if Status was still SUCCESS.
 *
 * @param[in] Status            Status accumulated by the write phases.
 * @param[in] InstanceId        MRAM controller instance identifier.
 * @param[in] interruptsEnabled TRUE when the error ISR owns ERRSTAT0 (mailbox path).
 * @return    The updated status.
 */
static MRam_Ip_StatusType MRam_Ip_AxiOp_PostWriteCheck(MRam_Ip_StatusType Status,
                                                       MRam_Ip_InstanceIdType InstanceId,
                                                       boolean interruptsEnabled)
{
    /* Status returned by the trailing best-effort port-buffer flush.
     * Applied to Status only if the latter is still SUCCESS. */
    MRam_Ip_StatusType FinalFlushStatus;

    /* Status returned by the trailing ERRSTAT0 read+clear. Same preservation
     * rule. The read is unconditional so PWE / WE / UE flags do not leak. */
    MRam_Ip_StatusType ControllerStatus;

    /* Status returned by the trailing MCRS read+clear. Same preservation rule. */
    MRam_Ip_StatusType MemoryStatus;

    /* ERRSTAT0 bits consumed from the async mailbox (non-zero only when
     * interrupts are enabled and the ISR captured an error). */
    uint32 asyncErrSnapshot = 0u;

    /* Local working copy of the Status parameter. All accumulation
     * below operates on this local and it is returned; the Status parameter is
     * only read once (to seed the local) and never modified. */
    MRam_Ip_StatusType result = Status;

    /* ======================================================
     * Post-write flush of the MRAMC gathering write buffer.
     *
     * The MCAL_DATA_SYNC_BARRIER calls inside the write loop only drain the
     * CPU's own write buffer up to the peripheral; they do NOT force the
     * MRAMC gathering write buffer to commit to MRAM cells. Without an
     * explicit flush here:
     *   - a subsequent read of the destination could return stale data
     *   - errors raised by the actual commit (PWE / WE / ECC etc.) would
     *     not yet be visible to the ERRSTAT0 / MCRS check below
     *
     * The flush is attempted UNCONDITIONALLY, even on the error path:
     * earlier phases may have left writes pending in the gathering buffer
     * (HEAD wrote some bytes, then TAIL's flush timed out). If we skipped
     * the flush here, those buffered writes would commit later - by which
     * time the locks have been restored - and could raise spurious PWE
     * errors that the next caller would attribute to its own operation.
     *
     * The flush's own status is preserved only if Status was already
     * SUCCESS; otherwise we keep the original (more meaningful) error. */
    FinalFlushStatus = MRam_Ip_FlushAxiPortBuffers(InstanceId);
    /* The flush status is tested explicitly. It is promoted into
     * result only when it reports an error and no earlier error was recorded. */
    if ((result == MRAM_IP_STATUS_SUCCESS) && (FinalFlushStatus != MRAM_IP_STATUS_SUCCESS))
    {
        result = FinalFlushStatus;
    }

    /* Post-operation error check.
     *
     * AXI volatile-pointer writes have no per-transaction completion handshake
     * (unlike the register path's WSTAT[WBUSY]). Errors surface in two places:
     *   - ERRSTAT0 (controller): we decode only the write-relevant bits (PWE,
     *     WE, UE, MCE, CPE, CEE, ME); read-only bits RE/DEE/MEEE may be set by a
     *     concurrent reader and must not be reported here (still cleared).
     *   - MCRS (F16ASM memory): write and ECC errors (WRE/WCE/WTE, EER/TBC/DBC/
     *     SBC, WRP, WAE).
     *
     * MCRS is read unconditionally (W1C clear) so flags from the trailing flush
     * do not leak into the next call. The ERRSTAT0 read yields to the ISR when
     * interrupts are enabled (the mailbox consume surfaces the cause) or
     * reads+clears directly when disabled. Each result promotes to Status only
     * if Status is still SUCCESS, so an earlier error is never overwritten.
     */
    ControllerStatus = MRam_Ip_GetControllerErrorStatusWrite(InstanceId);
    /* The controller status is tested explicitly and promoted
     * into result only when it reports an error and result is still SUCCESS. */
    if ((result == MRAM_IP_STATUS_SUCCESS) && (ControllerStatus != MRAM_IP_STATUS_SUCCESS))
    {
        result = ControllerStatus;
    }
    MemoryStatus = MRam_Ip_GetMemoryErrorStatus();
    /* Test the returned status in its own statement so it is always evaluated,
     * then promote it only if no earlier error was recorded (first error wins). */
    if (MemoryStatus != MRAM_IP_STATUS_SUCCESS)
    {
        if (result == MRAM_IP_STATUS_SUCCESS)
        {
            result = MemoryStatus;
        }
    }

    /* Async error promotion (interrupts enabled): the ISR captured any enabled
     * ERRSTAT0 error into the mailbox (the ERRSTAT0 read above yielded to it).
     * Consume the snapshot and, if the operation otherwise succeeded, promote
     * the write-relevant cause into Status - so the error reaches the caller via
     * Status as well as the ISR callback. Decode masks to write-relevant bits so
     * a concurrent reader's read-side bit cannot become this write's Status.
     * Mirror of the register-bus Phase 6c. */
    if (interruptsEnabled == TRUE)
    {
        /* Integration note: enter the MRam_Ip_ERRSTAT0_MAILBOX exclusive area here (SchM service, integration-generated placeholder). */
        volatile uint32 * pAsyncErrstat0Snapshot = MRam_Ip_GetAsyncErrstat0Snapshot();

        if (NULL_PTR != pAsyncErrstat0Snapshot)
        {
            asyncErrSnapshot = pAsyncErrstat0Snapshot[InstanceId];
            pAsyncErrstat0Snapshot[InstanceId] = 0u;
        }
        /* Integration note: exit the MRam_Ip_ERRSTAT0_MAILBOX exclusive area here (SchM service, integration-generated placeholder). */

        if ((result == MRAM_IP_STATUS_SUCCESS) && (asyncErrSnapshot != 0u))
        {
            result = MRam_Ip_DecodeErrstat0(asyncErrSnapshot & MRam_Ip_Errstat0WriteDecodeMask);
        }
    }

    return result;
}

static MRam_Ip_StatusType MRam_Ip_ProcessOperation_AXI(
    MRam_Ip_AddressType DestAddress,
    uint8 const * pu8SrcAddress,
    MRam_Ip_LengthType SizeInBytes,
    MRam_Ip_InstanceIdType InstanceId,
    boolean IsWriteOperation)
{
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    MRam_Ip_AddressType MRamAddress = DestAddress;
    MRam_Ip_LengthType RemainingBytes = SizeInBytes;
    MRam_Ip_LengthType currentIndex = 0u;

#if (MRAM_IP_CACHE_INVALIDATION == STD_ON)
    /* Bytes actually written = SizeInBytes minus what is still pending. Used to
     * invalidate ONLY the committed range, correct on full success and on a
     * partial failure alike (RemainingBytes counts down from SizeInBytes as we
     * write). Guarded by the same macro as its use. */
    MRam_Ip_LengthType bytesWritten = 0u;
#endif

    /* MRAM region classification of the destination address. Used by the
     * region-eligibility check below to reject regions that the AXI write
     * path does not support (OTP, UTEST). */
    MRam_Ip_AddressAreaType MemoryType;

    /* Convenience local that points the partial-word RMW helper at the
     * source buffer for writes, or at NULL_PTR for erases. */
    uint8 const * RmwSrcPtr;

    /* Cached "interrupts enabled" config flag (read only AFTER validation
     * confirms MRam_Ip_Config is non-NULL). When TRUE the error ISR owns
     * ERRSTAT0 and the async mailbox carries the error - see the mailbox reset
     * before the write phases and the consume+promote after the post-op check
     * (mirror of the register-bus Phase 1b / Phase 6c). */
    boolean interruptsEnabled = FALSE;

    /* TRUE once parameter validation passed. Gates the config-dereferencing
     * steps (interrupts-enabled cache and the unconditional post-write finalize)
     * so none of them run on the validation-failure path, where MRam_Ip_Config
     * may be NULL and nothing was written or locked. This keeps the
     * function at a single exit instead of an early return after validation. */
    boolean ParametersValid = FALSE;

#if (STD_OFF == MRAM_IP_PARTITION_SET_LOCK_API)
    boolean LocksCleared = FALSE;

    /* Status returned by the post-operation lock restore. Consulted in Phase 6:
     * if the data operation succeeded but the re-lock failed, Status is promoted
     * to PARTITION_LOCK_RESTORE_FAILED so the caller learns the range is left
     * unprotected. An existing operation error is preserved (it outranks a
     * follow-on restore failure). */
    MRam_Ip_StatusType LockStatus;
#endif

    /* Validate operation parameters. This is the only check that may see
     * a NULL MRam_Ip_Config / an invalid InstanceId / an out-of-range
     * address - every later step (including the unconditional trailing
     * flush and error-status reads) dereferences MRam_Ip_Config and
     * touches HW registers indexed by InstanceId, so a failure here MUST
     * abort the operation before any of that runs. */
    Status = MRam_Ip_ValidateOperationParameters(DestAddress, pu8SrcAddress, SizeInBytes, InstanceId, IsWriteOperation);

    if (Status == MRAM_IP_STATUS_SUCCESS)
    {
        /* Validation passed -> MRam_Ip_Config is non-NULL: safe to cache the
         * flag and to run the config-dereferencing finalize later. */
        ParametersValid = TRUE;
        interruptsEnabled = (MRam_Ip_Config->MRamControllerConfig.MRamCInterruptsEnabled == TRUE);
    }

    /* Reject OTP and UTEST targets in the AXI path.
     *
     * OTP (One-Time Programmable):
     *   - Spec mandates the OWC (OTP Write Commit) handshake via F16ASM
     *     MCR/MCRS for every committed page. The AXI volatile-pointer
     *     path does not run that sequence.
     *   - OTP cells follow one-way bit-transition physics; an unprotected
     *     read-modify-write (which the byte/halfword helpers in this path
     *     perform) would either fail to commit or burn extra cells.
     *   - Conclusion: OTP via AXI is unsupported by spec and unsafe.
     *
     * UTEST:
     *   - Spec allows single-page writes to UTEST via the register bus.
     *   - Spec does NOT explicitly forbid AXI writes to UTEST, but it
     *     also does not document them. There is no positive confirmation
     *     that the system bus interface guarantees correct behavior here.
     *   - UTEST is used for safety-mechanism verification (e.g. reference
     *     and sense amplifier trim checks). Sub-word RMW writes through
     *     this path could disturb the carefully-laid-out test patterns
     *     that the trim-check sequences expect to read back.
     *   - Conclusion: defensively rejected pending explicit spec support
     *     or a documented use case.
     *
     * Address is valid (in a known region), but invalid for THIS code path,
     * hence WRITE_ADDRESS_ERROR. Caller should use the register-bus
     * MRam_Ip_Write API for OTP and UTEST writes.
     *
     * Guarded by Status == SUCCESS so a validation failure above is not
     * overwritten and MRam_Ip_GetAddressType is only consulted for an
     * operation that is still viable. */
    if (Status == MRAM_IP_STATUS_SUCCESS)
    {
        MemoryType = MRam_Ip_GetAddressType(DestAddress);
        if ((MemoryType == MRAM_IP_ADDRESS_AREA_TYPE_NS_OTP) ||
            (MemoryType == MRAM_IP_ADDRESS_AREA_TYPE_UTEST))
        {
            Status = MRAM_IP_STATUS_WRITE_ADDRESS_ERROR;
        }
    }

    /* Clear locks before operation */
    if (Status == MRAM_IP_STATUS_SUCCESS)
    {
        Status = MRam_Ip_ConfigureLocksInRange(DestAddress, SizeInBytes, MRAM_IP_DOMAIN_ID, FALSE, InstanceId);

#if (STD_OFF == MRAM_IP_PARTITION_SET_LOCK_API)
        if (Status == MRAM_IP_STATUS_SUCCESS)
        {
            LocksCleared = TRUE;
        }
        else
        {
            /* Restore any partitions that were partially unlocked before the failure */
            (void)MRam_Ip_ConfigureLocksInRange(DestAddress, SizeInBytes, MRAM_IP_DOMAIN_ID, TRUE, InstanceId);
        }
#endif
    }

    /* Select the partial-word RMW source pointer once: the source buffer
     * for writes, or NULL_PTR for erases (RmwPartialWord_AXI substitutes
     * MRAM_IP_ERASED_VALUE_U8 when SrcPtr is NULL_PTR). */
    RmwSrcPtr = (IsWriteOperation) ? pu8SrcAddress : NULL_PTR;

    /* ISR/MULTICORE: when interrupts are enabled the error ISR owns ERRSTAT0 and
     * deposits enabled errors into the async mailbox. Reset this instance's
     * mailbox before writing so a stale snapshot from a previous operation is
     * not misattributed to this one (mirror of the register-bus Phase 1b). The
     * matching consume+promote runs after the post-op error check. Guarded by
     * the same exclusive area as the ISR deposit (placeholder). */
    if ((Status == MRAM_IP_STATUS_SUCCESS) && (interruptsEnabled == TRUE))
    {
        /* Integration note: enter the MRam_Ip_ERRSTAT0_MAILBOX exclusive area here (SchM service, integration-generated placeholder). */
        /* Drop any stale snapshot of a previous operation. */
        volatile uint32 * pAsyncErrstat0Snapshot;

        pAsyncErrstat0Snapshot = MRam_Ip_GetAsyncErrstat0Snapshot();

        if (NULL_PTR != pAsyncErrstat0Snapshot)
        {
            pAsyncErrstat0Snapshot[InstanceId] = 0u;
        }
        /* Integration note: exit the MRam_Ip_ERRSTAT0_MAILBOX exclusive area here (SchM service, integration-generated placeholder). */
    }

    /* HEAD / BODY / TAIL write/erase - extracted to MRam_Ip_AxiOp_WriteRange to
     * keep HIS_CCM in range (logic unchanged). Pack the cursor, run the phases,
     * unpack the advanced state. */
    {
        MRam_Ip_AxiCursor axiCursor;
        axiCursor.Status         = Status;
        axiCursor.MRamAddress    = MRamAddress;
        axiCursor.RemainingBytes = RemainingBytes;
        axiCursor.currentIndex   = currentIndex;

        MRam_Ip_AxiOp_WriteRange(&axiCursor, RmwSrcPtr, pu8SrcAddress, IsWriteOperation, InstanceId);

        /* Copy back only the state consumed after this block. Status is always
         * read; RemainingBytes is read only by the cache-invalidation range
         * calc below. MRamAddress and currentIndex are not read again, so their
         * write-backs were removed as dead stores. */
        Status         = axiCursor.Status;
#if (MRAM_IP_CACHE_INVALIDATION == STD_ON)
        RemainingBytes = axiCursor.RemainingBytes;
#endif
    }

    /* Post-write finalize (flush gathering buffer + controller/memory error
     * status + async-mailbox promotion) — extracted to
     * MRam_Ip_AxiOp_PostWriteCheck for HIS_CCM; logic unchanged. Runs on the
     * operational error path too (so pending gathering-buffer writes still
     * commit and no ERRSTAT0/MCRS flag leaks to the next call), but is gated by
     * ParametersValid so it is skipped on the validation-failure path where
     * MRam_Ip_Config may be NULL and nothing was written. */
    if (ParametersValid)
    {
        Status = MRam_Ip_AxiOp_PostWriteCheck(Status, InstanceId, interruptsEnabled);
    }

#if (STD_OFF == MRAM_IP_PARTITION_SET_LOCK_API)
    /* Restore locks after operation - only when Lock API is disabled.
     *
     * Why: if the data operation itself succeeded, a failed re-lock is the
     * only thing the caller does not yet know about, so surface it (the range
     * is now left unprotected). If the operation already failed, keep that
     * primary cause: it is more actionable than a follow-on restore failure.
     * This mirrors the register-bus path (MRam_Ip_ProcessOperation, Phase 6a)
     * so both public write APIs report this condition identically.
     *
     * Safety: returning SUCCESS while a partition stayed unlocked would hide a
     * loss of write protection on safety-critical memory. */
    if (LocksCleared)
    {
        LockStatus = MRam_Ip_ConfigureLocksInRange(DestAddress, SizeInBytes, MRAM_IP_DOMAIN_ID, TRUE, InstanceId);

        if ((Status == MRAM_IP_STATUS_SUCCESS) && (LockStatus != MRAM_IP_STATUS_SUCCESS))
        {
            Status = MRAM_IP_STATUS_PARTITION_LOCK_RESTORE_FAILED;
        }
    }
#endif

#if (MRAM_IP_CACHE_INVALIDATION == STD_ON)
    /* Invalidate the CPU cache for the range we ACTUALLY wrote, so subsequent
     * reads via the same address see the new MRAM contents, not the stale
     * cached value. Mirrors the register-bus path (MRam_Ip_Write).
     *
     * Invalidate [DestAddress, +bytesWritten) regardless of Status: on a partial
     * failure (HEAD/BODY wrote, a later phase failed) the written prefix's cache
     * is stale and MUST be invalidated too - gating on success would leave it
     * stale. bytesWritten is 0 only if nothing was written, in which case we
     * skip. (Validation failure returns earlier, so DestAddress is valid here.) */
    bytesWritten = SizeInBytes - RemainingBytes;
    if (bytesWritten > 0u)
    {
        (void)Cache_Ip_InvalidateByAddr(CACHE_IP_CORE, CACHE_IP_DATA, DestAddress, bytesWritten);
    }
#endif

    return Status;
}

/**
 * @brief   Writes data to MRAM using direct AXI memory-mapped access
 *
 * @param[in] DestAddress    Target MRAM address
 * @param[in] pu8SrcAddress  Source data buffer. MUST NOT alias another MRAM
 *                           region: when the source itself lives in MRAM,
 *                           the per-port read buffers serving the source
 *                           and the gathering write buffer serving the
 *                           destination contend for the same controller and
 *                           the per-port PC[IB] flushes performed by this
 *                           path also invalidate the source's read buffer,
 *                           degrading throughput by 1-2 orders of magnitude.
 *                           Also, (uintptr_t)pu8SrcAddress + SizeInBytes
 *                           must not overflow - the validator checks the
 *                           destination range but does NOT bounds-check the
 *                           source buffer.
 * @param[in] SizeInBytes    Bytes to write
 * @param[in] InstanceId     MRAM controller instance
 * @return    MRam_Ip_StatusType
 *
 * @warning  MULTICORE / REENTRANCY. This function touches shared MRAMC state
 *           (LPLOCK / SPLOCK / LPOLOCK / UTLOCK, ERRSTAT0 + the async error
 *           mailbox, MCRS, PC[port][IB]). Each shared-register critical section
 *           is wrapped in an AUTOSAR exclusive area (SchM_Enter/Exit_MRam_Ip_
 *           {LOCKREG, ERRSTAT0_MAILBOX, MCRS}) - currently PLACEHOLDER comments
 *           that the INTEGRATOR MUST wire to real cross-core exclusive areas
 *           (the ERRSTAT0_MAILBOX area must ALSO mask the local error ISR, not
 *           just spinlock cross-core). Until wired, concurrent calls race on
 *           these registers. Residual caller responsibilities even when wired:
 *           (a) do not write the SAME address from two cores without your own
 *           coherency handling; (b) the async error mailbox is per-INSTANCE, so
 *           two cores writing the same instance concurrently can mis-attribute
 *           an ERRSTAT0 error between them; (c) PC[port][IB] flush from two cores
 *           on the same port may lengthen each other's invalidation wait (no
 *           data loss).
 *
 * @warning  Performance for byte-aligned and half-word-aligned writes is
 *           significantly lower than for 4-byte-aligned writes, because
 *           sub-word writes require a port-buffer flush whenever the
 *           target 32-bit word changes. Prefer 4-byte-aligned addresses
 *           and multiple-of-4 sizes for throughput-sensitive paths.
 *
 * @implements MRam_Ip_Write_AXI_Activity
 */
MRam_Ip_StatusType MRam_Ip_Write_AXI(MRam_Ip_AddressType DestAddress,
                       uint8 const * pu8SrcAddress,
                       MRam_Ip_LengthType SizeInBytes,
                       MRam_Ip_InstanceIdType InstanceId)
{
    return MRam_Ip_ProcessOperation_AXI(DestAddress, pu8SrcAddress, SizeInBytes, InstanceId, TRUE);
}

/**
 * @brief Wait for any remaining active write register sets to complete
 *
 * @param[in,out] RegSetActive   Array of register set states
 * @param[in]     InstanceId     Hardware instance ID
 *
 * @return Status of the completion check
 */
static MRam_Ip_StatusType MRam_Ip_WaitForWriteCompletion(
    MRam_Ip_RegSetStateType RegSetActive[],
    MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    MRam_Ip_StatusType CompletionStatus;
    uint8 i;

    for (i = 0u; i < MRAMC_WRL_COUNT; i++)
    {
        if (RegSetActive[i] == REGSET_STATE_ACTIVE)
        {
            CompletionStatus = MRam_Ip_WaitAndCheckRegisterSetCompletion(i, InstanceId);
            RegSetActive[i] = REGSET_STATE_IDLE;
            if ((CompletionStatus != MRAM_IP_STATUS_SUCCESS) && (Status == MRAM_IP_STATUS_SUCCESS))
            {
                Status = CompletionStatus;
            }
        }
    }

    return Status;
}


/**
 * @brief   Unified write/erase implementation through MRAMC register sets
 *
 * Handles both write and erase using the dual register set architecture.
 * For writes, data is loaded into WDATA registers from the source buffer.
 * For erase, WDATA is filled with erased values. OTP erase is rejected.
 * Manages partition locks, cache invalidation, and OTP-specific sequencing.
 *
 * @param[in] DestAddress      Target MRAM address
 * @param[in] SourceAddressPtr Source data (NULL_PTR for erase)
 * @param[in] SizeInBytes      Bytes to process
 * @param[in] InstanceId       MRAM controller instance
 * @param[in] IsWriteOperation TRUE for write, FALSE for erase
 * @return    MRam_Ip_StatusType
 */
/* MRam_Ip_WriteOpCtx is defined in MRam_Ip_Types.h */

/**
 * @brief   Program and track one write/erase page: OTP page pre-conditions,
 *          the data or erase trigger and the progress counters. Extracted
 *          from MRam_Ip_WriteOp_ExecutePage so the caller nesting stays
 *          shallow. Logic unchanged; runs only while Status is SUCCESS.
 */
static void MRam_Ip_ExecutePage_ProgramAndTrack(MRam_Ip_WriteOpCtx *pWriteOpCtx, uint8 WriteRegVariant, boolean *pOperationStarted)
{
    uint32 UnusedBytes;                 /* page bytes consumed by alignment */
    MRam_Ip_LengthType OperationSize;   /* bytes the controller programs this pass */

                /* Setup operation */
                MRam_Ip_ClearPreviousErrors(WriteRegVariant, pWriteOpCtx->InstanceId);
                MRamC_Ip_BaseAddr[pWriteOpCtx->InstanceId]->WRL[WriteRegVariant].WCTL |= MRAMC_WCTL_WDCLR_MASK;

                /* Calculate operation parameters */
                UnusedBytes = pWriteOpCtx->CurrentAddress - (pWriteOpCtx->CurrentAddress & MRAMC_WADDR_WADDR_MASK);
                OperationSize = MRam_Ip_CalculateOptimalOperationSize(pWriteOpCtx->CurrentAddress, pWriteOpCtx->RemainingBytes, UnusedBytes, pWriteOpCtx->MemoryType, pWriteOpCtx->IsOtpMemory);

                /* OperationSize from MRam_Ip_CalculateOptimalOperationSize already represents
                 * the net bytes to process: for unaligned addresses, it returns
                 * min(RemainingBytes, MRAM_IP_SINGLE_WRITE_PAGE_SIZE - UnusedBytes). */

                if (pWriteOpCtx->IsWriteOperation)
                {
                    /* ---- Prepare F16ASM for the next OTP page (OTP only) ---- */
                    if (pWriteOpCtx->IsOtpMemory)
                    {
                        /* Verify OTP commit pre-conditions before each OWC write.
                         * After each page completes, WBUSY->0 releases the write sequence
                         * lock; the next AcquireWriteSemaphore re-writes WADDR and may send a
                         * new commit request, so wait for F16ASM to acknowledge before OWC=1.
                         *
                         * RM: "Wait until: UT0[UTE] is 0. The OMR and OMA fields in MCRS are
                         *     both 1." Only then write 1 to MCR[OWC].
                         *
                         * Why UTE first: an active UTest session (UTE=1) blocks an OTP commit,
                         * and the spec lists UTE==0 ahead of OMR/OMA in the acknowledge step.
                         * DONE=1 is also required (previous page completed) and is kept in the
                         * MCRS wait below. */
                        pWriteOpCtx->Status = MRam_Ip_WaitUntilRegisterBitsClear(
                            &(MRam_Ip_BaseAddr->UT0),
                            F16ASM_UT0_UTE_MASK,
                            MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);
                        if (pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS)
                        {
                            pWriteOpCtx->Status = MRam_Ip_WaitUntilRegisterBitsSet(
                                &(MRam_Ip_BaseAddr->MCRS),
                                (F16ASM_MCRS_OMR_MASK | F16ASM_MCRS_OMA_MASK | F16ASM_MCRS_DONE_MASK),
                                MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);
                        }
                        if (pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS)
                        {
                            MRam_Ip_BaseAddr->MCR |= F16ASM_MCR_OWC_MASK;
                        }
                    }

                    if (pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS)
                    {
                        /* ---- Write the data and trigger the operation ---- */
                        MRam_Ip_ExecuteOperationBySize(pWriteOpCtx->CurrentAddress, &pWriteOpCtx->SourceAddressPtr[pWriteOpCtx->sourceOffset], OperationSize, WriteRegVariant, pWriteOpCtx->InstanceId);

                        /* Update source offset (write only) */
                        pWriteOpCtx->sourceOffset += OperationSize;
                    }
                }
                else
                {
                    /* Execute erase operation (NULL_PTR triggers erase-value fill) */
                    if (pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS)
                    {
                        MRam_Ip_ExecuteOperationBySize(pWriteOpCtx->CurrentAddress, NULL_PTR, OperationSize, WriteRegVariant, pWriteOpCtx->InstanceId);
                    }
                }

                if (pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS)
                {
                    /* Update tracking variables */
                    pWriteOpCtx->CurrentAddress += OperationSize;
                    pWriteOpCtx->RemainingBytes -= OperationSize;
#if (MRAM_IP_CACHE_INVALIDATION == STD_ON)
                    /* Count this page as written: its cached copy is now stale
                     * regardless of whether completion later reports an error,
                     * so it must be part of the invalidated range. */
                    pWriteOpCtx->bytesWritten += OperationSize;
#endif
                    pWriteOpCtx->RegSetActive[WriteRegVariant] = REGSET_STATE_ACTIVE;
                    (*pOperationStarted) = TRUE;

                    /* For OTP, wait immediately for completion (write only, erase rejects OTP earlier) */
                    if (pWriteOpCtx->IsOtpMemory)
                    {
                        pWriteOpCtx->Status = MRam_Ip_WaitAndCheckRegisterSetCompletion(WriteRegVariant, pWriteOpCtx->InstanceId);
                        pWriteOpCtx->RegSetActive[WriteRegVariant] = REGSET_STATE_IDLE;
                    }
                }
}

/**
 * @brief   One write/erase page: semaphore, OTP commit handshake, data write and
 *          progress tracking. Extracted from MRam_Ip_WriteOp_PageLoop for HIS_CCM;
 *          runs only while Status is SUCCESS. Logic unchanged.
 */
static void MRam_Ip_WriteOp_ExecutePage(MRam_Ip_WriteOpCtx *pWriteOpCtx, uint8 WriteRegVariant, boolean *pOperationStarted)
{
        if (pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS)
        {
            /* Acquire semaphore */
            pWriteOpCtx->Status = MRam_Ip_AcquireWriteSemaphore(pWriteOpCtx->CurrentAddress, WriteRegVariant, pWriteOpCtx->InstanceId);

            if (pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS)
            {
                /* ---- OTP commit acknowledgment (OTP only, first page) ----
                 *
                 * After AcquireWriteSemaphore wrote WADDR with an OTP address,
                 * MRAMC sends an OTP-commit request to F16ASM. We now wait
                 * for F16ASM to acknowledge it.
                 *
                 * RM: "Wait until F16ASM accepts and acknowledges the OTP-
                 *      commit request. Wait until UT0[UTE] is 0 and MCRS[OMR]
                 *      and MCRS[OMA] are both 1."
                 *
                 * Why this wait is HERE (inside the loop) and not in Phase 3:
                 *   OMR only goes to 1 AFTER WADDR has been written with an
                 *   OTP address. Before WADDR, there is nothing to wait for —
                 *   no commit has been requested yet. So this is the only
                 *   wait that genuinely has to live inside the watchdog
                 *   window. Everything else (UTE, DONE) was pre-checked in
                 *   Phase 3.
                 *
                 * Why this is safe despite the watchdog ticking:
                 *   Phase 3 already disabled WWDOG (when not locked). The
                 *   wait below can take as long as F16ASM needs without
                 *   losing the write-sequence lock. The software timeout
                 *   inside WaitUntilRegisterBitsSet is the actual upper bound.
                 *
                 * This handshake only needs to happen once per ProcessOperation
                 * call; subsequent OTP pages reuse the acknowledged state. The
                 * MCRS[DONE]=1 check is kept as a redundant defensive check
                 * even though it was verified in Phase 3 — re-checking
                 * is cheap and catches any unexpected transition. */
                if (pWriteOpCtx->IsOtpMemory && (pWriteOpCtx->OtpCommitAcked != TRUE))
                {
                    pWriteOpCtx->Status = MRam_Ip_WaitUntilRegisterBitsSet(
                        &(MRam_Ip_BaseAddr->MCRS),
                        (F16ASM_MCRS_OMR_MASK | F16ASM_MCRS_OMA_MASK | F16ASM_MCRS_DONE_MASK),
                        MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);

                    if (pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS)
                    {
                        pWriteOpCtx->OtpCommitAcked = TRUE;
                    }
                }

                if (pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS)
                {
                    MRam_Ip_ExecutePage_ProgramAndTrack(pWriteOpCtx, WriteRegVariant, pOperationStarted);
                }
            }
        }
}

/**
 * @brief   Phase 4 main write/erase page loop, extracted from
 *          MRam_Ip_ProcessOperation to satisfy HIS_CCM. Logic is unchanged;
 *          the loop's shared state lives in *pWriteOpCtx.
 */
static void MRam_Ip_WriteOp_PageLoop(MRam_Ip_WriteOpCtx *pWriteOpCtx)
{
    uint8 WriteRegVariant = 0u;            /* register set handed out this iteration */
    boolean OperationStarted;              /* TRUE once an op was actually triggered */

    /* ========== PHASE 4: MAIN OPERATION LOOP ========== */
    while ((pWriteOpCtx->RemainingBytes > 0u) && (pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS))
    {

        OperationStarted = FALSE;

        /* Step 1: Try to acquire available register set with timeout protection */
        pWriteOpCtx->Status = MRam_Ip_AcquireWriteRegisterSet(&WriteRegVariant, pWriteOpCtx->InstanceId);

        if (pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS)
        {
            /* If this register set is still marked ACTIVE, it means the previous
             * write completed (WBUSY=0, that is why AcquireWriteRegisterSet returned
             * it) but CheckAndUpdate never processed it. Check for errors now,
             * BEFORE acquiring the semaphore and clearing error flags. */
            if (pWriteOpCtx->RegSetActive[WriteRegVariant] == REGSET_STATE_ACTIVE)
            {
                boolean werrDetected = FALSE;
                uint32 wstatVal = MRamC_Ip_BaseAddr[pWriteOpCtx->InstanceId]->WRL[WriteRegVariant].WSTAT;
                pWriteOpCtx->Status = MRam_Ip_CheckWstatErrors(wstatVal, &werrDetected);
                if ((werrDetected == TRUE) && (pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS))
                {
                    pWriteOpCtx->Status = MRam_Ip_ResolveWriteErrorCause(pWriteOpCtx->RegSetActive, WriteRegVariant, pWriteOpCtx->InstanceId);
                }
                if ((pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS) && (werrDetected == FALSE))
                {
                    /* Write-path variant: yields to the ISR when interrupts are
                     * enabled (mailbox + Phase 6c deliver any error to Status). */
                    pWriteOpCtx->Status = MRam_Ip_GetControllerErrorStatusWrite(pWriteOpCtx->InstanceId);
                }
                pWriteOpCtx->RegSetActive[WriteRegVariant] = REGSET_STATE_IDLE;
            }
        }

        MRam_Ip_WriteOp_ExecutePage(pWriteOpCtx, WriteRegVariant, &OperationStarted);

        /* Step 3: Check completion of active register sets (non-OTP only) */
        if ((pWriteOpCtx->IsOtpMemory != TRUE) && (pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS))
        {
            MRam_Ip_CheckAndUpdateRegisterSetCompletion(pWriteOpCtx->RegSetActive, &pWriteOpCtx->Status, pWriteOpCtx->InstanceId);
        }

        /* Step 4: Brief delay if no register set was available */
        if ((OperationStarted != TRUE) && (pWriteOpCtx->Status == MRAM_IP_STATUS_SUCCESS))
        {
            MRAM_IP_DELAY_CYCLES(10U);
        }
    }
}

/* MRam_Ip_OtpSetupCtx is defined in MRam_Ip_Types.h */

/**
 * @brief   Phase 3 OTP-write initialization, extracted from
 *          MRam_Ip_ProcessOperation to satisfy HIS_CCM. Logic unchanged.
 */
static void MRam_Ip_WriteOp_OtpSetup(MRam_Ip_OtpSetupCtx *pOtpSetupCtx)
{
    uint32 wwdogVal = 0U;            /* WWDOG snapshot read at step 4 */
    boolean wdogLocked = FALSE;      /* TRUE if WWDOG.WDL set (register locked) */
    boolean wdogAlreadyDisabled = FALSE; /* TRUE if WWDOG.WDD already set */

    /* ========== PHASE 3: OTP INITIALIZATION (Write only) ==========
     *
     * For OTP writes, we do four preparation steps BEFORE entering the main
     * loop. Three of them are pre-conditions the RM requires (no commit in
     * flight, UTest mode off, controller idle), and the fourth disables the
     * write watchdog so the OMR/OMA acknowledge wait inside the loop is not
     * timing-bounded.
     *
     * Why do everything we can BEFORE the main loop:
     *   The write watchdog starts ticking when AcquireWriteSemaphore writes
     *   WADDR (inside the loop) and only stops when SMW=1 is written. Any
     *   blocking wait we do between those two writes eats into the watchdog
     *   budget. So we move every check we can outside that window. UTE and
     *   DONE are independent of WADDR (writing WADDR does not change them),
     *   so they can be safely verified here, once, before the loop.
     */
    if ((pOtpSetupCtx->Status == MRAM_IP_STATUS_SUCCESS) && pOtpSetupCtx->IsOtpMemory && pOtpSetupCtx->IsWriteOperation)
    {
        /* MULTICORE defense-in-depth (MC3/MC4): serialize the WHOLE OTP write
         * against other cores. During this operation the write watchdog is
         * disabled (WWDOG is common to both write buffers) and the shared
         * MCR[OWC] is RMW-written. F16ASM excludes concurrent MRAM writes only
         * while an OTP commit is actually requested/executing - NOT across the
         * gaps in this window (before the first WADDR, between pages, and until
         * Phase 6b restores WWDOG).
         *
         * Entered UNCONDITIONALLY here - NOT gated on whether we end up disabling
         * WWDOG. Reason: a second core must block at this Enter until THIS OTP
         * fully completes. If it instead reached Phase 3 and read WWDOG while we
         * have it transiently disabled, it would see wdogAlreadyDisabled, skip
         * its own disable, and run its OTP with NO watchdog - re-exposing the
         * OTP-ack vs watchdog race. Blocking at the Enter prevents that.
         *
         * Coarse area: held across the multi-page OTP loop with BLOCKING waits,
         * so the integrator must implement it as a sleeping lock / BSW
         * serialization, NOT a raw spinlock. OTP is rare and already exclusive,
         * so normal CODE/DATA write throughput is unaffected. Balanced by the
         * OtpWriteAreaEntered-gated SchM_Exit after Phase 6b. Placeholder
         * (integration-generated), shown as a comment so the file compiles. */
        pOtpSetupCtx->OtpWriteAreaEntered = TRUE;
        /* Integration note: enter the MRam_Ip_OTP_WRITE exclusive area here (SchM service, integration-generated placeholder). */

        /* Step 1: make sure no previous OTP commit is still in flight.
         * If OMR or OMA is still 1, the chip is mid-commit from a prior
         * operation and we must not start a new one. */
        pOtpSetupCtx->Status = MRam_Ip_WaitUntilRegisterBitsClear(&(MRam_Ip_BaseAddr->MCRS),
                                                (F16ASM_MCRS_OMR_MASK | F16ASM_MCRS_OMA_MASK),
                                                MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);

        /* Step 2: make sure F16ASM UTest mode is off.
         *
         * RM: "F16ASM does not allow you to perform OTP reads, MRAM reads or
         *      MRAM writes when you request or execute an OTP-write operation."
         *
         * UTE is a software-controlled bit (it never flips on its own). If
         * UTE were 1, the OTP commit acknowledge would never come. We check
         * here, BEFORE WADDR is written, so the wait does NOT run inside the
         * watchdog window. Doing this in the loop (as before) was the main
         * reason the watchdog could win the race on the first OTP page.
         *
         * Safety: under the @warning NOT REENTRANT contract, no other thread
         * can flip UTE between this check and the OTP commit below. */
        if (pOtpSetupCtx->Status == MRAM_IP_STATUS_SUCCESS)
        {
            pOtpSetupCtx->Status = MRam_Ip_WaitUntilRegisterBitsClear(&(MRam_Ip_BaseAddr->UT0),
                                                        F16ASM_UT0_UTE_MASK,
                                                        MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);
        }

        /* Step 3: make sure the controller is idle (DONE=1).
         *
         * RM: "MCRS[DONE] = 1 means MRAM is accessible. Useful to observe
         *      after a reset, the termination of a low-power operation, or
         *      the termination of an OTP-commit process."
         *
         * MCR[OWC]=1 also requires DONE=1 as a pre-condition, so we verify
         * it now, outside the watchdog window. DONE only transitions due to
         * reset, low-power, or an active OTP commit - none of which happens
         * mid-call under the reentrancy contract. */
        if (pOtpSetupCtx->Status == MRAM_IP_STATUS_SUCCESS)
        {
            pOtpSetupCtx->Status = MRam_Ip_WaitUntilRegisterBitsSet(&(MRam_Ip_BaseAddr->MCRS),
                                                     F16ASM_MCRS_DONE_MASK,
                                                     MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);
        }

        /* Step 4: disable the write watchdog for this OTP path.
         *
         * The main loop writes WADDR (which starts the watchdog) then waits for
         * F16ASM to set MCRS[OMR]=MCRS[OMA]=1. That ack has no documented upper
         * bound, but the watchdog does (max 40000 register-bus clocks at WDT=00b);
         * if the ack outlasts it we lose the lock and the page is never written.
         * Disabling WWDOG removes the race.
         *
         * Two pre-conditions decide whether we touch WWDOG at all:
         *
         *   1. WDL must be 0 (register not locked).
         *      RM: "1b - Lock enabled. All fields in this register, including
         *           this field, can not be written until next reset."
         *      If WDL=1, the write below would be ignored by HW; there is no
         *      point trying. We accept the residual timing risk - the UTE and
         *      DONE checks above already shrank the watchdog window down to
         *      just the OMR/OMA wait.
         *
         *   2. WDD must be 0 (watchdog currently ENABLED).
         *      RM: "0b - Watchdog timer enabled. 1b - Watchdog timer disabled."
         *      If WDD is already 1, the boot code or another driver has
         *      already disabled the watchdog. There is no race to mitigate,
         *      so we skip the save/restore dance and leave WWDOG alone.
         *      Touching it would only risk introducing a write-back that
         *      isn't ours to make.
         *
         * Only when BOTH conditions hold do we snapshot the current value,
         * set WDD=1, and arrange for Phase 6 to restore.
         *
         * Safety trade-offs while WWDOG is disabled:
         *   The watchdog exists to protect against a thread that holds the
         *   write-sequence lock and never finishes. With WWDOG disabled,
         *   we lose that protection - but only for ourselves, and only
         *   while WwdogWasModified is TRUE. We still have the software
         *   timeout inside WaitUntilRegisterBits{Set,Clear} as a backstop
         *   against an unresponsive F16ASM. Under @warning NOT REENTRANT,
         *   no other thread is using the write engine at the same time.
         *
         * Restoration is done in Phase 6 below. */
        if (pOtpSetupCtx->Status == MRAM_IP_STATUS_SUCCESS)
        {
            wwdogVal = MRamC_Ip_BaseAddr[pOtpSetupCtx->InstanceId]->WWDOG;
            wdogLocked = ((wwdogVal & MRAMC_WWDOG_WDL(1u)) != 0u);
            wdogAlreadyDisabled = ((wwdogVal & MRAMC_WWDOG_WDD(1u)) != 0u);

            if ((wdogLocked == FALSE) && (wdogAlreadyDisabled == FALSE))
            {
                pOtpSetupCtx->SavedWwdog = wwdogVal;
                pOtpSetupCtx->WwdogWasModified = TRUE;
                /* Set WDD=1 (disabled) while keeping every other field intact.
                 * This WWDOG read+disable runs INSIDE the coarse OTP-write
                 * exclusive area entered at the top of Phase 3, so the snapshot
                 * saved for the Phase 6b restore is consistent cross-core (no
                 * other core can have WWDOG in a transient state here). */
                MRamC_Ip_BaseAddr[pOtpSetupCtx->InstanceId]->WWDOG = wwdogVal | MRAMC_WWDOG_WDD(1u);
            }
        }

        /* (Previous "Step 5: clear stale MCRS flags" was removed -
         * unified MCRS + ERRSTAT0 cleanup now happens once for every
         * operation in Phase 1b above, regardless of OTP vs CODE/DATA.) */
    }
}

/* MRam_Ip_TeardownCtx is defined in MRam_Ip_Types.h */

/**
 * @brief   Phase 5/6 completion, lock/WWDOG restore, async-error promotion and
 *          cache invalidation
 */
static void MRam_Ip_WriteOp_Teardown(MRam_Ip_TeardownCtx *pTeardownCtx)
{
    uint32 asyncErrSnapshot = 0u;   /* ERRSTAT0 snapshot consumed in Phase 6c */
    uint8 i;

    /* ========== PHASE 5: COMPLETION ========== */
    if (pTeardownCtx->IsOtpMemory != TRUE)
    {
        if (pTeardownCtx->Status == MRAM_IP_STATUS_SUCCESS)
        {
            /* Normal path: wait and check errors for remaining active operations */
            pTeardownCtx->Status = MRam_Ip_WaitForWriteCompletion(pTeardownCtx->RegSetActive, pTeardownCtx->InstanceId);
        }
        else
        {
            /* Error path: wait for HW to finish (WBUSY=0) so any still-running
             * write completes, then clear WSTAT flags on each abandoned regset
             * to keep the per-regset semaphore state consistent for the next
             * call. Do NOT overwrite Status - preserve the original error.
             *
             * Why we DO NOT touch MCRS / ERRSTAT0 here:
             *   Cleanup of those shared registers is done at the START of every
             *   operation (Phase 1b), not at the end. Doing it here as well
             *   would discard diagnostic that the caller's safety subsystem
             *   may still want to inspect after this function returns. */
            for (i = 0u; i < MRAMC_WRL_COUNT; i++)
            {
                if (pTeardownCtx->RegSetActive[i] == REGSET_STATE_ACTIVE)
                {
                    (void)MRam_Ip_WaitUntilRegisterBitsClear(
                        &(MRamC_Ip_BaseAddr[pTeardownCtx->InstanceId]->WRL[i].WSTAT),
                        MRAMC_WSTAT_WBUSY_MASK,
                        MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);
                    /* Clear stale WSTAT error flags from this regset */
                    MRam_Ip_ClearPreviousErrors(i, pTeardownCtx->InstanceId);
                    pTeardownCtx->RegSetActive[i] = REGSET_STATE_IDLE;
                }
            }
        }
    }

#if (STD_OFF == MRAM_IP_PARTITION_SET_LOCK_API)
    /* ========== PHASE 6a: LOCK RESTORE (STD_OFF only) ==========
     *
     * Re-lock every partition that Phase 2 unlocked, restoring the
     * pre-call lock state. Symmetric with Phase 2.
     *
     * This call only does something now because ConfigureLocksInRange
     * has been updated to dispatch on SetLock=TRUE in STD_OFF mode
     * (calls MRam_Ip_SetPartitionLock helper directly, since the public
     * MRam_Ip_SetLock is not in the binary in STD_OFF). Before that
     * fix, SetLock=TRUE in STD_OFF silently fell through to ClearLock
     * - partitions stayed unlocked across calls and accumulated.
     *
     * Failure handling:
     *   - If LockRestoreStatus reports a problem AND Status is still
     *     SUCCESS (the data op succeeded), promote to
     *     MRAM_IP_STATUS_PARTITION_LOCK_RESTORE_FAILED so the caller
     *     knows the range is now unprotected.
     *   - If Status already carries an error from the data op itself,
     *     keep it: that primary cause is more actionable than a
     *     follow-on restore failure. */
    if (pTeardownCtx->LocksCleared)
    {
        MRam_Ip_StatusType LockRestoreStatus =
            MRam_Ip_ConfigureLocksInRange(pTeardownCtx->DestAddress, pTeardownCtx->SizeInBytes, MRAM_IP_DOMAIN_ID, TRUE, pTeardownCtx->InstanceId);

        if ((pTeardownCtx->Status == MRAM_IP_STATUS_SUCCESS) &&
            (LockRestoreStatus != MRAM_IP_STATUS_SUCCESS))
        {
            pTeardownCtx->Status = MRAM_IP_STATUS_PARTITION_LOCK_RESTORE_FAILED;
        }
    }
#endif

    /* ========== PHASE 6b: WWDOG RESTORE ==========
     *
     * If Phase 3 disabled the write watchdog for the OTP path, put it back
     * exactly as we found it. This must run regardless of Status: even on
     * the error path we have to leave the controller in the state the
     * caller expects.
     *
     * Why a full register restore and not just "clear WDD":
     *   Phase 3 saved the FULL WWDOG value before modifying it. We do not
     *   know which other fields (WDT tune) the boot code may have set, so
     *   the safest restoration is the original 32-bit value verbatim.
     *
     * Note: WDL=1 (locked) prevents writes to WWDOG. If WDL got set between
     * Phase 3 and here, this write would be ignored - but that cannot
     * happen because WDL is set-only and only by software, and no other
     * thread is allowed to touch the driver during one call (see
     * @warning NOT REENTRANT). */
    if (pTeardownCtx->WwdogWasModified)
    {
        MRamC_Ip_BaseAddr[pTeardownCtx->InstanceId]->WWDOG = pTeardownCtx->SavedWwdog;
    }

    /* Exit the coarse OTP-write exclusive area entered at the top of Phase 3.
     * Gated by OtpWriteAreaEntered (NOT WwdogWasModified) so Enter/Exit stay
     * balanced even when we did not modify WWDOG (already disabled/locked) and on
     * the error path. Placed AFTER the WWDOG restore so the restore happens
     * inside the area. Placeholder (integration-generated). */
    if (pTeardownCtx->OtpWriteAreaEntered)
    {
        /* Integration note: exit the MRam_Ip_OTP_WRITE exclusive area here (SchM service, integration-generated placeholder). */
    }

    /* ========== PHASE 6c: ASYNC ERROR PROMOTION ==========
     *
     * When interrupts are enabled, ERRSTAT0 errors that fired during this
     * operation were captured by the ISR into the async mailbox (the
     * write/erase path deliberately did NOT read ERRSTAT0 mid-operation - see
     * MRam_Ip_GetControllerErrorStatusWrite). Here we consume that snapshot and,
     * if the operation otherwise succeeded, promote it into Status so the caller
     * learns about the error through the return value as well as via the ISR
     * callback.
     *
     * Consume unconditionally (read then zero) so a snapshot never leaks into
     * the next operation. Promote only when Status is still SUCCESS: if the
     * operation already failed for an operational reason (WSTAT/MCRS), that
     * primary cause is more actionable and must not be overwritten by a
     * follow-on async code.
     *
     * When interrupts are disabled the mailbox is always 0 (the ISR never
     * runs), so this block is a no-op and the in-operation reads already
     * surfaced any ERRSTAT0 error. */
    if (pTeardownCtx->interruptsEnabled == TRUE)
    {
        /* The read-and-clear of the mailbox below must be ATOMIC with respect to
         * MRam_Ip_ProcessIrq, which does a read-modify-write (|=) on the same
         * entry. The ISR can preempt this thread (the driver does not mask
         * interrupts for the duration of the operation), so if it fired between
         * the read and the zeroing, the error it just deposited would be wiped
         * from the mailbox - reaching the caller only via the callback and never
         * via the returned Status, breaking the "both channels" guarantee.
         *
         * Guarded with an AUTOSAR exclusive area. The SchM_Enter/Exit calls are
         * PLACEHOLDERS shown as comments: the SchM_* services are generated by
         * the integration (RTE/BSW) and are not present in this build, so calling
         * them here would not compile. The integrator must replace these comments
         * with the real exclusive-area macros for this module.
         * Only this thread side needs the guard; entering the exclusive area
         * blocks the ISR, so MRam_Ip_ProcessIrq itself does not enter it. */
        /* Integration note: enter the MRam_Ip_ERRSTAT0_MAILBOX exclusive area here (SchM service, integration-generated placeholder). */
        volatile uint32 * pAsyncErrstat0Snapshot = MRam_Ip_GetAsyncErrstat0Snapshot();

        if (NULL_PTR != pAsyncErrstat0Snapshot)
        {
            asyncErrSnapshot = pAsyncErrstat0Snapshot[pTeardownCtx->InstanceId];
            pAsyncErrstat0Snapshot[pTeardownCtx->InstanceId] = 0u;
        }
        /* Integration note: exit the MRam_Ip_ERRSTAT0_MAILBOX exclusive area here (SchM service, integration-generated placeholder). */

        if ((pTeardownCtx->Status == MRAM_IP_STATUS_SUCCESS) && (asyncErrSnapshot != 0u))
        {
            /* Decode only write-relevant bits. The mailbox already holds just
             * the enabled errors, but the enabled set still includes read-side
             * ECC bits (DEE/MEEE) that a concurrent reader on another port could
             * have triggered during this operation. Masking here keeps a
             * read-side error from ever surfacing as this write/erase's Status. */
            pTeardownCtx->Status = MRam_Ip_DecodeErrstat0(asyncErrSnapshot & MRam_Ip_Errstat0WriteDecodeMask);
        }
    }

#if (MRAM_IP_CACHE_INVALIDATION == STD_ON)
    /* Invalidate ONLY the range we actually wrote, starting at DestAddress.
     *
     * Why guarded by bytesWritten > 0 (and not run unconditionally):
     *   On an early/validation failure nothing was written and DestAddress /
     *   SizeInBytes are the caller-supplied values that were just rejected as
     *   invalid. Invalidating an arbitrary range there is at best wasted work
     *   and at worst dangerous: on a write-back D-cache, invalidate-without-
     *   clean over a cacheable region with dirty lines would DISCARD them,
     *   losing unrelated writes. So we only invalidate when at least one page
     *   was actually triggered, and only across [DestAddress, +bytesWritten) -
     *   which is also exactly right on a partial failure. */
    if (pTeardownCtx->bytesWritten > 0u)
    {
        (void)Cache_Ip_InvalidateByAddr(CACHE_IP_CORE, CACHE_IP_DATA, pTeardownCtx->DestAddress, pTeardownCtx->bytesWritten);
    }
#endif

}

/**
 * @brief   Phase 1b hardware clean-slate (clear stale MCRS/ERRSTAT0 + wait for
 *          controller ready), extracted from MRam_Ip_ProcessOperation for HIS_CCM.
 *          Logic unchanged.
 */
static void MRam_Ip_WriteOp_CleanSlate(MRam_Ip_StatusType *pStatus,
                                       boolean interruptsEnabled,
                                       MRam_Ip_InstanceIdType InstanceId)
{
    /* ========== PHASE 1b: HW STATE CLEANUP (at start) ==========
     *
     * Clear any sticky MCRS / ERRSTAT0 flags left over from a previous
     * operation, so this ProcessOperation call starts from a known-clean
     * state. The diagnostic info those flags held (if any) belongs to
     * the previous caller - they have already returned and either
     * inspected it or chose not to. Carrying it forward would cause
     * THIS operation's CheckAndUpdate / inline drain steps to surface
     * stale errors as if they were this operation's own.
     *
     * Return values are intentionally discarded:
     *   - At the start of an operation, we do not care what the pre-state
     *     was; we only care that the slate is clean for what comes next.
     *   - If the cleanup itself fails to reach the hardware, downstream
     *     reads in Phase 4 / Phase 5 will surface the lingering flags
     *     naturally - the operation does not silently succeed on a
     *     corrupt controller.
     *
     * ERRSTAT0 ownership depends on interrupt configuration:
     *   - Interrupts enabled: the ISR owns ERRSTAT0 and clears it. We must
     *     NOT clear it here (that would steal a flag the ISR has not yet
     *     serviced). Instead we reset the async mailbox so any snapshot left
     *     over from the previous operation is discarded and not misattributed
     *     to this one.
     *   - Interrupts disabled: no ISR runs, so we clear ERRSTAT0 ourselves,
     *     exactly as the original design did.
     * MCRS is always cleared here regardless: it is F16ASM state that the
     * error ISR (which only handles ERRSTAT0) never touches. */
    if ((*pStatus) == MRAM_IP_STATUS_SUCCESS)
    {
        /* Controller-ready gate (all operations).
         *
         * RM: "During reset recovery ... You cannot write to registers until
         *      MCRS[DONE] is 1, indicating that reset recovery is complete."
         *      "MCRS[DONE] = 0 ... while in Low-Power Sleep / mid OTP-commit."
         *
         * Everything that follows in this function writes MRAMC/F16ASM
         * registers (the cleanup below, then WADDR/WDATA/WSTRB/WCTL in the
         * main loop). If the controller is still in reset recovery (DONE=0),
         * those register writes would be lost. We therefore wait for DONE=1
         * before touching anything. In normal operation DONE is already 1, so
         * this returns immediately; it only blocks on the genuine
         * not-yet-ready edge (e.g. a write issued right after reset / on
         * return from low-power). The OTP path additionally re-checks DONE as
         * an OWC pre-condition in Phase 3/Phase 4, which is unaffected. */
        (*pStatus) = MRam_Ip_WaitUntilRegisterBitsSet(&(MRam_Ip_BaseAddr->MCRS),
                                                  F16ASM_MCRS_DONE_MASK,
                                                  MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR);
    }

    if ((*pStatus) == MRAM_IP_STATUS_SUCCESS)
    {
        /* The read-and-clear result is tested. Stale MCRS flags
         * from a previous operation are cleared by this read and intentionally
         * NOT promoted into *pStatus (they belong to the previous caller). */
        if (MRam_Ip_GetMemoryErrorStatus() != MRAM_IP_STATUS_SUCCESS)
        {
            /* No action: stale pre-operation status is discarded by design. */
        }

        if (interruptsEnabled == TRUE)
        {
            /* ISR owns ERRSTAT0 - just drop any stale mailbox snapshot.
             * MULTICORE: ordered against the ISR's |= deposit (which runs in the
             * same exclusive area) so this reset cannot be interleaved by an ISR
             * on another core. Placeholder (integration-generated). */
            /* Integration note: enter the MRam_Ip_ERRSTAT0_MAILBOX exclusive area here (SchM service, integration-generated placeholder). */
            /* Claim the instance for this partition so the ISR deposits into our mailbox, then
             * drop any stale snapshot of a previous operation. */
            volatile uint32 * pAsyncErrstat0Snapshot;

            pAsyncErrstat0Snapshot = MRam_Ip_GetAsyncErrstat0Snapshot();

            if (NULL_PTR != pAsyncErrstat0Snapshot)
            {
                pAsyncErrstat0Snapshot[InstanceId] = 0u;
            }
            /* Integration note: exit the MRam_Ip_ERRSTAT0_MAILBOX exclusive area here (SchM service, integration-generated placeholder). */
        }
        else
        {
            /* No ISR — clear ERRSTAT0 ourselves for a clean slate. */
            /* The read-and-clear result is tested; a stale
             * ERRSTAT0 flag is cleared here and intentionally not promoted. */
            if (MRam_Ip_DecodeAndClearErrstat0(InstanceId, MRam_Ip_Errstat0AllKnownErrors) != MRAM_IP_STATUS_SUCCESS)
            {
                /* No action: stale pre-operation status is discarded by design. */
            }
        }
    }
}

static MRam_Ip_StatusType MRam_Ip_ProcessOperation(
    MRam_Ip_AddressType DestAddress,
    const uint8 *SourceAddressPtr,
    MRam_Ip_LengthType SizeInBytes,
    MRam_Ip_InstanceIdType InstanceId,
    boolean IsWriteOperation)
{
    /* ========== VARIABLE DECLARATIONS ========== */
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    MRam_Ip_LengthType RemainingBytes = 0U;
    MRam_Ip_AddressType CurrentAddress = 0U;
    MRam_Ip_LengthType sourceOffset = 0U;  /* Index into source buffer (write only) */
    MRam_Ip_AddressAreaType MemoryType = MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS;
    boolean IsOtpMemory = FALSE;

#if (STD_OFF == MRAM_IP_PARTITION_SET_LOCK_API)
    /* TRUE if Phase 2 successfully cleared partition locks in the target
     * range. Gates the Phase 6 restore so we only re-lock what we cleared
     * (no-op if Phase 2 was skipped or failed before any partition was
     * touched).
     *
     * Only relevant in STD_OFF mode where the driver auto-manages locks.
     * In STD_ON mode the user is responsible for unlocking before calling
     * and re-locking after, so neither Phase 2 unlock nor Phase 6 restore
     * runs and this flag does not exist. */
    boolean LocksCleared = FALSE;
#endif

    /* Register set management */
    MRam_Ip_RegSetStateType RegSetActive[MRAMC_WRL_COUNT] = {REGSET_STATE_IDLE, REGSET_STATE_IDLE};
    boolean OtpCommitAcked = FALSE;  /* Tracks whether the OTP commit request has been acknowledged by F16ASM */

#if (MRAM_IP_CACHE_INVALIDATION == STD_ON)
    /* Running total of bytes for which a write/erase was actually triggered to
     * MRAM. Used at the very end to invalidate ONLY the range we touched.
     *
     * Why a dedicated counter and not (SizeInBytes - RemainingBytes):
     *   RemainingBytes starts at 0 and is set to SizeInBytes only AFTER Phase 1
     *   validation passes, then counts down to 0 on full success. So both an
     *   early validation failure (never written, RemainingBytes == 0) and a
     *   full success (RemainingBytes == 0) look identical via RemainingBytes -
     *   the subtraction would wrongly report SizeInBytes as "written" on a
     *   validation failure. This counter stays 0 unless the loop actually
     *   triggered a page, so it is unambiguous for success, partial failure,
     *   and early exit alike.
     *
     * Guarded by the same macro as its only use, so builds with cache
     * invalidation off carry neither the variable nor the per-page increment. */
    MRam_Ip_LengthType bytesWritten = 0U;
#endif

    /* Saved WWDOG value, used to restore the write watchdog at the end of an
     * OTP-write path that temporarily disabled it.
     *
     * Why we need to disable the write watchdog for OTP writes:
     *   Between writing WADDR (which acquires the write-sequence lock and
     *   starts the watchdog) and writing WCTL[SMW]=1 (which stops it), the
     *   OTP path has to wait for F16ASM to acknowledge the OTP-commit
     *   request (MCRS[OMR]=MCRS[OMA]=1). The duration of that ack is not
     *   specified in the RM. The watchdog has a finite maximum (40000
     *   register-bus clocks); if the ack takes longer, the watchdog releases
     *   our lock and SMW=1 is silently dropped - the OTP page would never
     *   be written, and the caller would get a timeout error for a perfectly
     *   healthy chip.
     *
     *   RM: "Watchdog timer resets and starts counting once write sequence
     *        lock is acquired. It stops when WCTLn[SMW] or WCTLn[CWSL] is
     *        written 1, or it times out. Write sequence lock is released if
     *        watchdog timeout occurs."
     *
     *   By disabling WWDOG just for the OTP path, the OMR/OMA wait can take
     *   as long as F16ASM needs without losing the lock. The software
     *   timeout inside WaitUntilRegisterBits{Set,Clear} still protects us
     *   against a hard HW hang. */
    uint32 SavedWwdog = 0U;
    boolean WwdogWasModified = FALSE;

    /* TRUE once the coarse cross-core OTP-write exclusive area has been entered
     * (top of Phase 3, OTP write path). Gates the matching exit after Phase 6b
     * so the area is balanced even on the error path and even when WWDOG was not
     * modified by us - see the MULTICORE note at the Phase 3 entry. */
    boolean OtpWriteAreaEntered = FALSE;

    /* Cached copy of the controller's "interrupts enabled" config flag.
     *
     * Defaults FALSE and is only set TRUE AFTER Phase 1 validation has
     * confirmed MRam_Ip_Config is non-NULL. Phase 1b and Phase 6c read this
     * local instead of dereferencing MRam_Ip_Config again, so that on the
     * not-initialized early-exit path (validation failed because Config was
     * NULL) Phase 6c - which runs regardless of Status - does NOT dereference
     * a NULL pointer. It also avoids re-reading the same config field twice. */
    boolean interruptsEnabled = FALSE;

    /* ========== PHASE 1: VALIDATION ========== */
    Status = MRam_Ip_ValidateOperationParameters(DestAddress, SourceAddressPtr, SizeInBytes, InstanceId, IsWriteOperation);

    if (Status == MRAM_IP_STATUS_SUCCESS)
    {
        RemainingBytes = SizeInBytes;
        CurrentAddress = DestAddress;
        MemoryType = MRam_Ip_GetAddressType(DestAddress);
        IsOtpMemory = (MRAM_IP_ADDRESS_AREA_TYPE_NS_OTP == MemoryType);

        /* Validation passed, so MRam_Ip_Config is non-NULL: safe to cache the
         * interrupts-enabled flag now. Used by Phase 1b and Phase 6c. */
        interruptsEnabled = (MRam_Ip_Config->MRamControllerConfig.MRamCInterruptsEnabled == TRUE);

        /* Erase-specific: reject OTP memory */
        if ((!IsWriteOperation) && IsOtpMemory)
        {
            Status = MRAM_IP_STATUS_ERASE_OTP_NOT_ALLOWED;
        }

        /* OTP-write-specific: require a full-page (256-bit) aligned write.
         *
         * RM: "the OTP-write operation is 256 bits (1 page) in size." Unlike a
         *      normal MRAM write - where the RM explicitly allows byte/word/
         *      double-word sizes via the internal read-modify-write feature -
         *      the OTP-write section grants no sub-page form, and the OTP
         *      commit step recommends 256-bit data to match the ECC segment.
         *
         * Why we reject (instead of pad): OTP is one-time-programmable. A
         * partial-page OTP write commits only the strobed bytes; the rest of
         * that 256-bit page stay erased. The page can never be completed
         * later - a second write to the same OTP page is an overwrite of an
         * already-committed location and sets the write-verify error (WRE).
         * Padding would silently commit bytes the caller never supplied, which
         * for one-time memory is worse than rejecting. So we require the caller
         * to present whole 32-byte pages.
         *
         * A full-page OTP write needs both:
         *   - DestAddress aligned to the 32-byte page boundary, and
         *   - SizeInBytes a whole multiple of 32 bytes. */
        if ((Status == MRAM_IP_STATUS_SUCCESS) && IsWriteOperation && IsOtpMemory)
        {
            if (((DestAddress % MRAM_IP_SINGLE_WRITE_PAGE_SIZE) != 0u) ||
                ((SizeInBytes % MRAM_IP_SINGLE_WRITE_PAGE_SIZE) != 0u))
            {
                Status = MRAM_IP_STATUS_OTP_ALIGNMENT_ERROR;
            }
        }
    }

    /* ========== PHASE 1b: HW STATE CLEANUP (extracted to
     * MRam_Ip_WriteOp_CleanSlate for HIS_CCM; logic unchanged) ========== */
    MRam_Ip_WriteOp_CleanSlate(&Status, interruptsEnabled, InstanceId);

    /* ========== PHASE 2: ACCESS CONTROL ==========
     *
     * Pre-check partition locks for the range this operation will touch,
     * and in STD_OFF mode also auto-manage them.
     *
     * The ConfigureLocksInRange(..., FALSE, ...) pre-check below runs in
     * BOTH modes so the register-bus path reports a locked partition the
     * same way the AXI path (MRam_Ip_ProcessOperation_AXI) does:
     *
     *   STD_ON  - The public Set-Lock API (MRam_Ip_SetLock / MRam_Ip_GetLock)
     *             is exposed and the user manages locks explicitly: ClearLock
     *             before write/erase, SetLock after. The driver does NOT
     *             auto-manage. The pre-check only inspects lock state: if a
     *             target partition is still locked it returns
     *             MRAM_IP_STATUS_PARTITION_LOCKED and the operation aborts;
     *             otherwise it is a harmless no-op. Phase 6 does not re-lock.
     *   STD_OFF - The public Set-Lock API is hidden; the driver auto-manages.
     *             The pre-check unlocks every partition in range (recorded in
     *             LocksCleared) and Phase 6 re-locks them afterwards, leaving
     *             the caller's lock state unchanged. */
    if (Status == MRAM_IP_STATUS_SUCCESS)
    {
        Status = MRam_Ip_ConfigureLocksInRange(DestAddress, SizeInBytes, MRAM_IP_DOMAIN_ID, FALSE, InstanceId);

#if (STD_OFF == MRAM_IP_PARTITION_SET_LOCK_API)
        if (Status == MRAM_IP_STATUS_SUCCESS)
        {
            /* All partitions in range unlocked. Mark so Phase 6 knows
             * to re-lock them at the end of the operation. */
            LocksCleared = TRUE;
        }
        else
        {
            /* Phase 2 unlock failed partway through the range. Try to
             * roll back by re-locking everything we touched, so the
             * caller's lock state is not left half-modified.
             *
             * The rollback's own return is intentionally discarded
             * (via the unused RollbackStatus): we preserve the
             * original Status (the unlock failure that brought us
             * here) because the caller cares more about why the
             * operation failed than about how the rollback went.
             *
             * Known limitation: if both the unlock AND the rollback
             * fail, the range may be left partially unlocked. The
             * caller sees only the unlock-failure cause and has no
             * direct signal about the rollback's outcome. */
            MRam_Ip_StatusType RollbackStatus =
                MRam_Ip_ConfigureLocksInRange(DestAddress, SizeInBytes, MRAM_IP_DOMAIN_ID, TRUE, InstanceId);
            (void)RollbackStatus;
        }
#endif
    }

    /* ========== PHASE 3: OTP INITIALIZATION (extracted to
     * MRam_Ip_WriteOp_OtpSetup for HIS_CCM; logic unchanged) ========== */
    {
        MRam_Ip_OtpSetupCtx otpSetupCtx;
        otpSetupCtx.InstanceId          = InstanceId;
        otpSetupCtx.IsOtpMemory         = IsOtpMemory;
        otpSetupCtx.IsWriteOperation    = IsWriteOperation;
        otpSetupCtx.Status              = Status;
        otpSetupCtx.OtpWriteAreaEntered = OtpWriteAreaEntered;
        otpSetupCtx.SavedWwdog          = SavedWwdog;
        otpSetupCtx.WwdogWasModified    = WwdogWasModified;

        MRam_Ip_WriteOp_OtpSetup(&otpSetupCtx);

        Status              = otpSetupCtx.Status;
        OtpWriteAreaEntered = otpSetupCtx.OtpWriteAreaEntered;
        SavedWwdog          = otpSetupCtx.SavedWwdog;
        WwdogWasModified    = otpSetupCtx.WwdogWasModified;
    }

    /* ========== PHASE 4: MAIN OPERATION LOOP (extracted to
     * MRam_Ip_WriteOp_PageLoop for HIS_CCM; logic unchanged) ========== */
    {
        MRam_Ip_WriteOpCtx writeOpCtx;
        writeOpCtx.SourceAddressPtr = SourceAddressPtr;
        writeOpCtx.InstanceId       = InstanceId;
        writeOpCtx.MemoryType       = MemoryType;
        writeOpCtx.IsOtpMemory      = IsOtpMemory;
        writeOpCtx.IsWriteOperation = IsWriteOperation;
        writeOpCtx.Status           = Status;
        writeOpCtx.CurrentAddress   = CurrentAddress;
        writeOpCtx.RemainingBytes   = RemainingBytes;
        writeOpCtx.sourceOffset     = sourceOffset;
        writeOpCtx.RegSetActive[0]  = RegSetActive[0];
        writeOpCtx.RegSetActive[1]  = RegSetActive[1];
        writeOpCtx.OtpCommitAcked   = OtpCommitAcked;
#if (MRAM_IP_CACHE_INVALIDATION == STD_ON)
        writeOpCtx.bytesWritten     = bytesWritten;
#else
        /* Initialize unconditionally so the field is never read
         * uninitialized inside MRam_Ip_WriteOp_PageLoop, even in builds where
         * cache invalidation is disabled and the running count is unused. */
        writeOpCtx.bytesWritten     = 0u;
#endif

        MRam_Ip_WriteOp_PageLoop(&writeOpCtx);

        /* Copy back only the state consumed after this block by the Teardown phase
         * (Status, RegSetActive, bytesWritten). CurrentAddress/RemainingBytes/
         * sourceOffset/OtpCommitAcked are not read again, so their write-backs were
         * removed as dead stores. */
        Status          = writeOpCtx.Status;
        RegSetActive[0] = writeOpCtx.RegSetActive[0];
        RegSetActive[1] = writeOpCtx.RegSetActive[1];
#if (MRAM_IP_CACHE_INVALIDATION == STD_ON)
        bytesWritten    = writeOpCtx.bytesWritten;
#endif
    }

    /* ========== PHASE 5/6: COMPLETION + TEARDOWN (extracted to
     * MRam_Ip_WriteOp_Teardown for HIS_CCM; logic unchanged) ========== */
    {
        MRam_Ip_TeardownCtx teardownCtx;
        teardownCtx.InstanceId          = InstanceId;
        teardownCtx.DestAddress         = DestAddress;
        teardownCtx.SizeInBytes         = SizeInBytes;
        teardownCtx.IsOtpMemory         = IsOtpMemory;
        teardownCtx.interruptsEnabled   = interruptsEnabled;
#if (STD_OFF == MRAM_IP_PARTITION_SET_LOCK_API)
        teardownCtx.LocksCleared        = LocksCleared;
#endif
        teardownCtx.WwdogWasModified    = WwdogWasModified;
        teardownCtx.SavedWwdog          = SavedWwdog;
        teardownCtx.OtpWriteAreaEntered = OtpWriteAreaEntered;
#if (MRAM_IP_CACHE_INVALIDATION == STD_ON)
        teardownCtx.bytesWritten        = bytesWritten;
#endif
        teardownCtx.Status              = Status;
        teardownCtx.RegSetActive[0]     = RegSetActive[0];
        teardownCtx.RegSetActive[1]     = RegSetActive[1];

        MRam_Ip_WriteOp_Teardown(&teardownCtx);

        Status = teardownCtx.Status;
    }
    return Status;
}

/**
 * @brief        Writes data to MRAM memory
 * @details      This function writes the specified data to MRAM memory. It supports writing to different
 *               memory types (CODE, DATA, OTP) and handles the MRAM controller's dual register set
 *               architecture for optimized performance. For OTP memory, it performs single-page writes
 *               with special handling and verification. For standard memory, it can use both register
 *               sets concurrently for improved throughput.
 *
 * @param[in]    DestAddress      Target address in MRAM to write to
 * @param[in]    SourceAddressPtr Pointer to source data buffer
 * @param[in]    SizeInBytes      Number of bytes to write
 * @param[in]    InstanceId       MRAM controller instance ID
 *
 * @return       MRam_Ip_StatusType
 * @retval       MRAM_IP_STATUS_SUCCESS             Write operation completed successfully
 * @retval       MRAM_IP_STATUS_WRITE_ERROR         General write error occurred
 * @retval       MRAM_IP_STATUS_WRITE_PROTECTED     Write to protected area attempted
 * @retval       MRAM_IP_STATUS_WRITE_ADDRESS_ERROR Invalid address error
 * @retval       MRAM_IP_STATUS_WRITE_COLLISION_ERROR Write collision detected
 * @retval       MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR Timeout occurred during write
 * @retval       MRAM_IP_STATUS_WRITE_TIMEOUT_BUSY  Timeout while waiting for controller to be free
 * @retval       MRAM_IP_STATUS_WRITE_BUSY          Controller is busy with another operation
 * @retval       MRAM_IP_STATUS_WRITE_GAIN_SEMAPHORE_ERROR Failed to acquire write semaphore
 *
 * @implements   MRam_Ip_Write_Activity
 */
MRam_Ip_StatusType MRam_Ip_Write(MRam_Ip_AddressType DestAddress,
                                 const uint8 *SourceAddressPtr,
                                 MRam_Ip_LengthType SizeInBytes,
                                 MRam_Ip_InstanceIdType InstanceId)
{
    return MRam_Ip_ProcessOperation(DestAddress, SourceAddressPtr, SizeInBytes, InstanceId, TRUE);
}

/**
 * @brief Erases data in the MRAM memory
 *
 * This function erases (sets to all 1s) a specified region of MRAM memory. It supports
 * different memory regions (Code, Data) with optimized handling for each type.
 * For regular memory regions, the function uses dual hardware register sets for parallel
 * operations when possible to maximize throughput.
 *
 * OTP (One-Time Programmable) memory cannot be erased, and attempts to erase OTP memory
 * will result in a MRAM_IP_STATUS_ERASE_OTP_NOT_ALLOWED error being returned.
 *
 * @param[in] DestAddress      Base address in MRAM to start erasing from
 * @param[in] SizeInBytes      Number of bytes to erase
 * @param[in] InstanceId       Hardware instance ID for multi-controller systems
 *
 * @return MRam_Ip_StatusType  Status of the operation
 */
MRam_Ip_StatusType MRam_Ip_Erase(MRam_Ip_AddressType DestAddress,
                                 MRam_Ip_LengthType SizeInBytes,
                                 MRam_Ip_InstanceIdType InstanceId)
{
    return MRam_Ip_ProcessOperation(DestAddress, NULL_PTR, SizeInBytes, InstanceId, FALSE);
}

/**
 * @brief Reads data from MRAM memory into a buffer
 *
 * This function reads a specified number of bytes from MRAM memory (including OTP memory)
 * into the provided buffer. It handles buffer invalidation to ensure memory coherency,
 * supports different memory areas (CODE, DATA, OTP), and includes comprehensive error
 * detection and notification.
 *
 * For OTP memory, it includes special handling to wait for any in-progress OTP operations.
 * For regular memory (CODE, DATA), it checks buffer enable flags and performs optimizations
 * like prefetching where appropriate.
 *
 * @param[in]  SrcAddress       Source address in MRAM to read from
 * @param[out] DestAddressPtr   Pointer to destination buffer to store data
 * @param[in]  SizeInBytes      Number of bytes to read
 * @param[in]  InstanceId       MRAM instance identifier
 *
 * @return MRam_Ip_StatusType
 * @retval MRAM_IP_STATUS_SUCCESS            Read operation completed successfully
 * @retval MRAM_IP_STATUS_ERROR              Generic error occurred
 * @retval MRAM_IP_STATUS_READ_NOT_ALLOWED   Read operation not allowed for the memory area
 * @retval MRAM_IP_STATUS_ERROR_TIMEOUT       Timeout occurred during read operation
 * @retval MRAM_IP_STATUS_MEMORY_ERROR       Memory error detected
 * @retval MRAM_IP_STATUS_ECC_UNCORRECTED    Uncorrected ECC error detected
 * @retval MRAM_IP_STATUS_ECC_DOUBLE_BIT_ERROR Double-bit ECC error detected
 * @retval MRAM_IP_STATUS_ECC_TRIPLE_BIT_ERROR Triple-bit ECC error detected
 */
/**
 * @brief Read: per-port read-buffer-enable check (non-OTP). Extracted from
 *        MRam_Ip_Read for HIS_CCM; logic unchanged.
 */
static MRam_Ip_StatusType MRam_Ip_Read_CheckPortBuffersEnabled(MRam_Ip_AddressAreaType memoryType, MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType operationStatus = MRAM_IP_STATUS_SUCCESS;
    uint8 portIndex;
            for (portIndex =0u; portIndex < MRam_Ip_Config->MRamControllerConfig.MRamCPortConfigCount; portIndex++) /* M7 Core Support only P1 and P2 ports */
            {
                switch (memoryType)
                {
                case MRAM_IP_ADDRESS_AREA_TYPE_CODE:
                    /* Check if code buffers are enabled for this port */
                    if((MRamC_Ip_BaseAddr[InstanceId]->PC[MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[portIndex].id] & MRAMC_PC_RCBFEN_MASK) != 0u)
                    {
                        operationStatus = MRAM_IP_STATUS_SUCCESS;
                    }
                    break;

                case MRAM_IP_ADDRESS_AREA_TYPE_DATA:
                    /* Check if data buffers are enabled for this port */
                    if((MRamC_Ip_BaseAddr[InstanceId]->PC[MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[portIndex].id] & MRAMC_PC_RDBFEN_MASK) != 0u)
                    {
                        operationStatus = MRAM_IP_STATUS_SUCCESS;
                    }
                    break;

                default:
                    /* Unknown memory type - reading not allowed */
                    operationStatus = MRAM_IP_STATUS_READ_NOT_ALLOWED;
                    break;
                }
            }
    return operationStatus;
}

/**
 * @brief Read: per-port prefetch configuration. Called ONCE before the read loop.
 *        memoryType and port config are invariant across iterations, so there is
 *        no need to repeat this inside the loop.
 */
static void MRam_Ip_Read_ConfigurePrefetch(MRam_Ip_AddressAreaType memoryType, boolean isOtpMemoryRegion, MRam_Ip_InstanceIdType InstanceId)
{
    uint8 portIndex;

    /* Prefetch is only applicable for non-OTP memory regions */
    if (isOtpMemoryRegion != TRUE)
    {
        for (portIndex = 0u; portIndex < MRam_Ip_Config->MRamControllerConfig.MRamCPortConfigCount; portIndex++) /* M7 Core Support only P1 and P2 ports */
        {
            /* Enable appropriate prefetch mode based on memory type */
            switch (memoryType)
            {
            case MRAM_IP_ADDRESS_AREA_TYPE_CODE:
                /* Enable code prefetching for improved performance */
                MRamC_Ip_BaseAddr[InstanceId]->PC[MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[portIndex].id] |= MRAMC_PC_RCPFEN(MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[portIndex].RCPFEN ? TRUE : FALSE);
                break;

            case MRAM_IP_ADDRESS_AREA_TYPE_DATA:
                /* Enable data prefetching for improved performance */
                MRamC_Ip_BaseAddr[InstanceId]->PC[MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[portIndex].id] |= MRAMC_PC_RDPFEN(MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[portIndex].RDPFEN ? TRUE : FALSE);
                break;

            default:
                /* No prefetching for other memory types */
                break;
            }
        }
    }
}

/**
 * @brief Read: per-port buffer invalidation for one data chunk. Called on every
 *        loop iteration to ensure cache coherency before each read.
 *        Prefetch configuration has been moved out of this function into
 *        MRam_Ip_Read_ConfigurePrefetch, which is called once before the loop.
 */
static MRam_Ip_StatusType MRam_Ip_Read_InvalidatePorts(MRam_Ip_InstanceIdType InstanceId)
{
    MRam_Ip_StatusType operationStatus = MRAM_IP_STATUS_SUCCESS;
    uint8 portIndex;

    for (portIndex = 0u; portIndex < MRam_Ip_Config->MRamControllerConfig.MRamCPortConfigCount; portIndex++) /* M7 Core Support only P1 and P2 ports */
    {
        /* Set invalidate buffer bit and wait for hardware to clear it */
        MRamC_Ip_BaseAddr[InstanceId]->PC[MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[portIndex].id] |= MRAMC_PC_IB(TRUE);

        /* Wait for hardware to complete invalidation */
        operationStatus = MRam_Ip_WaitUntilRegisterBitsClear(
            &(MRamC_Ip_BaseAddr[InstanceId]->PC[MRam_Ip_Config->MRamControllerConfig.MRamCPortConfig[portIndex].id]),
            MRAMC_PC_IB_MASK,
            MRAM_IP_STATUS_ERROR_TIMEOUT);

        /* If invalidation timed out, exit the loop */
        if (operationStatus != MRAM_IP_STATUS_SUCCESS)
        {
            break;
        }
    }

    return operationStatus;
}

MRam_Ip_StatusType MRam_Ip_Read(MRam_Ip_AddressType SrcAddress,
                                uint8 *DestAddressPtr,
                                MRam_Ip_LengthType SizeInBytes,
                                MRam_Ip_InstanceIdType InstanceId
                                )
{
    uint32 currentReadAddress;          /* Current address being read from MRAM */
    uint32 remainingBytesToRead;        /* Remaining number of bytes to read */
    uint8 bytesReadInOperation;         /* Number of bytes read in current read operation */
    MRam_Ip_AddressAreaType memoryType; /* Type of memory area being accessed (CODE, DATA, OTP) */
    MRam_Ip_StatusType operationStatus; /* Status of the read operation */
    boolean isOtpMemoryRegion;          /* Flag indicating if reading from OTP memory */
    MRam_Ip_LengthType destOffset = 0U; /* Index into destination buffer (replaces pointer arithmetic) */
    currentReadAddress = SrcAddress;
    remainingBytesToRead = SizeInBytes;

    operationStatus = MRam_Ip_ValidateOperationParameters(SrcAddress,
                                                            DestAddressPtr,
                                                            SizeInBytes,
                                                            InstanceId,
                                                            TRUE);

#if (MRAM_IP_CACHE_INVALIDATION == STD_ON)
    /* Invalidate the cache for the source range ONLY after validation passed.
     * Handing a caller-supplied address/size to the cache driver BEFORE the
     * NULL / range / overflow checks could, on a wild range, discard unrelated
     * dirty cache lines (data loss on a write-back D-cache). */
    if (operationStatus == MRAM_IP_STATUS_SUCCESS)
    {
        (void)Cache_Ip_InvalidateByAddr(CACHE_IP_CORE, CACHE_IP_DATA, SrcAddress, SizeInBytes);
    }
#endif

    memoryType = MRam_Ip_GetAddressType(currentReadAddress);

    /* Identify if this is OTP memory (requires special handling) */
    isOtpMemoryRegion = (MRAM_IP_ADDRESS_AREA_TYPE_NS_OTP == memoryType);

    if(operationStatus == MRAM_IP_STATUS_SUCCESS)
    {
        /* Different initialization paths for OTP vs regular memory */
        if (isOtpMemoryRegion)
        {
            /* Wait for any OTP operations to complete before reading */
            operationStatus = MRam_Ip_WaitUntilRegisterBitsClear(&(MRam_Ip_BaseAddr->MCRS),
                                                              (F16ASM_MCRS_OMR_MASK | F16ASM_MCRS_OMA_MASK),
                                                              MRAM_IP_STATUS_ERROR_TIMEOUT);
        }
        else
        {
            /* CODE/DATA memory initialization - check buffer enable flags */
            operationStatus = MRam_Ip_Read_CheckPortBuffersEnabled(memoryType, InstanceId);
        }

        /* Clear any existing errors in MCRS register before reading */
        MRam_Ip_StatusType ClearStatus = MRam_Ip_GetMemoryErrorStatus();
        if (ClearStatus != MRAM_IP_STATUS_SUCCESS)
        {
            /* Error status intentionally not propagated - clearing HW error register before read */
        }


        /* Clear any errors in ERRSTAT0 register for this instance */
        ClearStatus = MRam_Ip_DecodeAndClearErrstat0(InstanceId, MRam_Ip_Errstat0AllKnownErrors);
        if (ClearStatus != MRAM_IP_STATUS_SUCCESS)
        {
            /* Error status intentionally not propagated - clearing controller error register before read */
        }
    }

    /* Configure prefetch once before the loop - memoryType and port config are
     * invariant across iterations, so there is no need to repeat this inside
     * the loop. This is the key performance improvement for ARTDCMEM-1656. */
    if (operationStatus == MRAM_IP_STATUS_SUCCESS)
    {
        MRam_Ip_Read_ConfigurePrefetch(memoryType, isOtpMemoryRegion, InstanceId);
    }

    /* Main read operation loop - only proceed if initialization was successful */
    while ((operationStatus == MRAM_IP_STATUS_SUCCESS) && (remainingBytesToRead > 0UL))
    {
        /* Buffer invalidation for coherency (critical for multi-port operation).
         * Prefetch configuration has been moved before the loop (see above).
         * A failed invalidation can leave stale buffered data that a subsequent
         * read would return without setting any ERRSTAT0 error flag, so the
         * timeout is propagated and this read is aborted instead of ignored. */
        operationStatus = MRam_Ip_Read_InvalidatePorts(InstanceId);

        if (operationStatus == MRAM_IP_STATUS_SUCCESS)
        {
            /* Perform actual read operation to user buffer */
            bytesReadInOperation = MRam_Ip_ReadData(currentReadAddress, &DestAddressPtr[destOffset], remainingBytesToRead);

            /* Read path: decode only read-relevant bits so a write-path error
             * (WE/PWE) set by a concurrent writer is not reported as this read's
             * Status. The register is still fully cleared. */
            operationStatus = MRam_Ip_DecodeAndClearErrstat0(InstanceId, MRam_Ip_Errstat0ReadDecodeMask);

            if (operationStatus == MRAM_IP_STATUS_SUCCESS)
            {
                /* Advance pointers and counters for next data chunk */
                currentReadAddress += bytesReadInOperation;
                destOffset += bytesReadInOperation;
                remainingBytesToRead -= bytesReadInOperation;
            }
        }
    }

    return operationStatus;
}




/**
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * @brief   Erase a specified number of bytes starting from a target memory address
 * @details This function erases memory by writing predefined "erased" values to each memory
 *          location. It optimizes performance by using the largest possible write operations
 *          based on address alignment.
 *
 * @param[in]  DestAddress The target memory address where erasing should begin
 *                         Example: 0x08000100 (an address in MRAM Code region)
 * @param[in]  SizeInBytes Number of bytes to be erased
 *                         Example: 1024 (erase 1KB of memory)
 * @param[in]  InstanceId  Hardware instance ID of the MRAM controller (typically 0)
 *
 * @return     MRAM_IP_STATUS_SUCCESS if the erase operation succeeded
 *             MRAM_IP_STATUS_ERROR_NOT_INITIALIZED if the driver is not initialized
 *             Other error codes from MRam_Ip_ValidateOperationParameters if validation fails
 *
 * @warning  MULTICORE / REENTRANCY. This function touches shared MRAMC state
 *           (LPLOCK / SPLOCK / LPOLOCK / UTLOCK, ERRSTAT0 + the async error
 *           mailbox, MCRS, PC[port][IB]). Each shared-register critical section
 *           is wrapped in an AUTOSAR exclusive area (SchM_Enter/Exit_MRam_Ip_
 *           {LOCKREG, ERRSTAT0_MAILBOX, MCRS}) - currently PLACEHOLDER comments
 *           that the INTEGRATOR MUST wire to real cross-core exclusive areas
 *           (the ERRSTAT0_MAILBOX area must ALSO mask the local error ISR, not
 *           just spinlock cross-core). Until wired, concurrent calls race on
 *           these registers. Residual caller responsibilities even when wired:
 *           (a) do not write the SAME address from two cores without your own
 *           coherency handling; (b) the async error mailbox is per-INSTANCE, so
 *           two cores writing the same instance concurrently can mis-attribute
 *           an ERRSTAT0 error between them; (c) PC[port][IB] flush from two cores
 *           on the same port may lengthen each other's invalidation wait (no
 *           data loss).
 *
 * @warning  Performance for byte-aligned and half-word-aligned erase ranges
 *           is significantly lower than for 4-byte-aligned ones, because
 *           sub-word writes require a port-buffer flush whenever the
 *           target 32-bit word changes. Prefer 4-byte-aligned addresses
 *           and multiple-of-4 sizes for throughput-sensitive paths.
 *
 * @implements MRam_Ip_Erase_AXI_Activity
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
MRam_Ip_StatusType MRam_Ip_Erase_AXI(MRam_Ip_AddressType DestAddress,
                                     MRam_Ip_LengthType SizeInBytes,
                                     MRam_Ip_InstanceIdType InstanceId)
{
    return MRam_Ip_ProcessOperation_AXI(DestAddress, NULL_PTR, SizeInBytes, InstanceId, FALSE);
}

/**
 * @brief   Process MRAM controller interrupts.
 * @details Processes MRAM controller interrupt by identifying active error conditions,
 *          notifying registered callbacks, and clearing interrupt flags. This function
 *          should be called from the interrupt service routine when an MRAM error
 *          interrupt is triggered.
 *
 *          If the driver is not initialized (ISR called before Init), all pending
 *          error flags in ERRSTAT0 are cleared and the function returns immediately,
 *          avoiding blocking execution due to unserviced interrupts.
 *
 *          All pending ERRSTAT0 flags are cleared regardless of whether their corresponding
 *          notification is enabled in ERRNTCTL0, including RE and WE flags which have no
 *          notification enable bits.
 *
 * @param[in]  InstanceId  Hardware instance ID of the MRAM controller generating the interrupt
 *
 * @implements MRam_Ip_ProcessIrq_Activity
 */
void MRam_Ip_ProcessIrq(MRam_Ip_InstanceIdType InstanceId)
{
    /* All variables declared at the beginning of the function */
    uint32 ErrorStatus = 0U;
    uint32 ErrorNotificationEnabled = 0U;
    uint32 EnabledErrorsDetected = 0U;
    uint32 ErrorAddress = 0U;
    boolean isDriverInitialized = (NULL_PTR != MRam_Ip_Config);
    MRam_Ip_InterruptConfigType ActiveErrors;

    /* Validate instance ID is within valid range */
    #if (MRAM_IP_DEV_ERROR_DETECT == STD_ON)
    MRAM_IP_DEV_ASSERT(InstanceId < (MRam_Ip_InstanceIdType)MRAMC_INSTANCE_COUNT);
    #endif

    MRam_Ip_InitializeActiveErrors(&ActiveErrors);

    /* Validate instance ID before proceeding with interrupt processing */
    if (isDriverInitialized && (InstanceId < (MRam_Ip_InstanceIdType)MRAMC_INSTANCE_COUNT))
    {
        /* ---- MULTICORE critical section: shared ERRSTAT0 + async mailbox ----
         * ERRSTAT0 (controller-wide) and MRam_Ip_AsyncErrstat0Snapshot are both
         * shared across cores. The ERRSTAT0 read, the mailbox deposit, and the
         * W1C clear below must form ONE atomic section against (a) another core's
         * write/erase reading+clearing ERRSTAT0 (MRam_Ip_DecodeAndClearErrstat0)
         * and (b) Phase 6c consuming the mailbox. The per-regset WID semaphore
         * does NOT cover these. Guarded by the SAME AUTOSAR exclusive area as
         * those sites; the SchM call is a PLACEHOLDER (integration-generated,
         * not in this build) shown as a comment so the file compiles. The
         * integrator MUST enter this area from the ISR too - a thread-only guard
         * would not block this ISR running on another core. The area must ALSO
         * mask this interrupt on the LOCAL core (a full AUTOSAR exclusive area
         * does both): implemented as a bare cross-core spinlock WITHOUT local
         * interrupt masking, this ISR could preempt a same-core thread that
         * already holds the area and spin forever - a self-deadlock.
         *
         * The user callback is invoked AFTER this section (outside the lock): it
         * may run long and a cross-core spinlock must be held only for the few
         * register/mailbox accesses. It uses the snapshot captured here, so
         * clearing ERRSTAT0 first does not affect it. */
        /* Integration note: enter the MRam_Ip_ERRSTAT0_MAILBOX exclusive area here (SchM service, integration-generated placeholder). */

        /* Read the error notification control register to determine which notifications are enabled */
        ErrorNotificationEnabled = MRamC_Ip_BaseAddr[InstanceId]->ERRNTCTL0;

        /* Read the error status register to determine which errors are active */
        ErrorStatus = MRamC_Ip_BaseAddr[InstanceId]->ERRSTAT0;

        /* Address of transaction that encountered error */
        ErrorAddress = MRamC_Ip_BaseAddr[InstanceId]->ERRSTAT1;

        /* Process all error conditions and accumulate flags to clear */
        MRam_Ip_ProcessErrorConditions(ErrorNotificationEnabled, ErrorStatus, &ActiveErrors, &EnabledErrorsDetected);

        /* Deposit detected errors into the async-error mailbox BEFORE clearing
         * ERRSTAT0 below: once cleared, a lower-priority write/erase can no longer
         * observe it, so this snapshot is how the error reaches the returned Status.
         * Accumulate with |= so back-to-back interrupts are not lost.
         *
         * Why we deposit EnabledErrorsDetected and NOT the raw ErrorStatus:
         *   The mailbox feeds the write/erase Status (Phase 6c) and must carry
         *   only the errors this ISR actually owns and reports through the
         *   callback. The raw ERRSTAT0 snapshot can ALSO contain RE (read path)
         *   and WE (write path) bits. Those have NO notification-enable in
         *   ERRNTCTL0 and therefore never trigger this ISR - when the ISR runs
         *   it is always because some OTHER, enabled error fired, and RE/WE may
         *   just happen to be set at that instant (e.g. a stale RE from an
         *   earlier read, or a read on another port). RE in particular belongs
         *   to the read path, not to a write/erase.
         *
         *   If a raw RE/WE bit leaked into the mailbox, MRam_Ip_DecodeErrstat0
         *   - which ranks RE above WE above every enabled error - would make a
         *   successful write/erase return a read-path error code (ERROR_READ_
         *   PATH), masking the real, enabled cause that this ISR already
         *   reported via the callback. Depositing only EnabledErrorsDetected
         *   keeps Status and the callback in agreement and never attributes a
         *   foreign bit to the operation.
         *
         * RE/WE are still W1C-cleared below (we clear the full ErrorStatus), so
         * leaving them out of the mailbox does not leave them set in the register.
         * See the declaration of MRam_Ip_AsyncErrstat0Snapshot for the full
         * rationale. */
        if (EnabledErrorsDetected != 0U)
        {
            /* Each ECUC partition has its own ISR, so MRam_Ip_GetCurrentPartition() here
             * already identifies the correct partition's mailbox. Deposit directly. */
            volatile uint32 * pOwnerMailbox = MRam_Ip_GetAsyncErrstat0Snapshot();

            if (NULL_PTR != pOwnerMailbox)
            {
                pOwnerMailbox[InstanceId] |= EnabledErrorsDetected;
            }
        }

        /* Clear ALL pending error flags, including non-enabled
         * ones and RE/WE which have no corresponding notification enable bits in ERRNTCTL0 */
        if (ErrorStatus != 0U)
        {
            MRamC_Ip_BaseAddr[InstanceId]->ERRSTAT0 = ErrorStatus;
        }
        /* Integration note: exit the MRam_Ip_ERRSTAT0_MAILBOX exclusive area here (SchM service, integration-generated placeholder). */

        /* Invoke the registered callback OUTSIDE the critical section above, so
         * a cross-core exclusive area is never held across user code. It uses
         * the ActiveErrors/ErrorAddress snapshot captured under the lock. */
        if ((NULL_PTR != MRam_Ip_ErrorCallbacks) && (EnabledErrorsDetected != 0U))
        {
            MRam_Ip_ErrorCallbacks(InstanceId, ActiveErrors, ErrorAddress);
        }
    }
    else if (InstanceId < (MRam_Ip_InstanceIdType)MRAMC_INSTANCE_COUNT)
    {
        /* Driver not initialized: clear only enabled interrupt status flags.
         * Per CPR_RTD_00012: "ISR shall clear the interrupt status flag
         * only for the enabled interrupts and return immediately." */
        uint32 enabledFlags = MRamC_Ip_BaseAddr[InstanceId]->ERRNTCTL0;
        uint32 statusFlags  = MRamC_Ip_BaseAddr[InstanceId]->ERRSTAT0;
        uint32 flagsToClear = statusFlags & enabledFlags;

        if (flagsToClear != 0U)
        {
            MRamC_Ip_BaseAddr[InstanceId]->ERRSTAT0 = flagsToClear;
        }
    }
    else
    {
        /* Invalid instance ID - no action required */
    }
}

/**
 * @brief   Compare data between source buffer and MRAM memory or perform blank check
 * @details This function has two modes of operation:
 *          1. Normal compare: Compare contents of a source buffer with data in MRAM memory
 *          2. Blank check: When pu8SrcAddress is NULL_PTR, verify if MRAM memory contains erased values
 *
 *          The comparison is done efficiently by:
 *          1. Reading MRAM data in chunks (up to 32 bytes at a time)
 *          2. Using word-by-word (4 bytes) comparison when addresses are aligned
 *          3. Falling back to byte-by-byte comparison otherwise
 *          4. Stopping at the first mismatch and reporting its exact location
 *
 *          Example:
 *          When comparing 100 bytes starting at MRAM address 0x08001000 with a RAM buffer:
 *          - The function will read 32 bytes at a time from MRAM
 *          - If both addresses are word-aligned, it compares 4 bytes at once (8x faster)
 *          - If a mismatch is found at offset 50, it returns with address 0x08001032
 *            (0x08001000 + 50 = 0x08001032)
 *
 * @param[in]  MRamSrcAddress    Address in MRAM memory to compare from
 * @param[in]  pu8SrcAddress     Pointer to source buffer to compare with, or NULL for blank check
 * @param[in]  SizeInBytes       Number of bytes to compare
 * @param[in]  InstanceId        MRAM controller instance identifier
 *
 * @return     MRam_Ip_StatusType
 * @retval     MRAM_IP_STATUS_SUCCESS         Comparison successful, data matches or memory is blank
 * @retval     MRAM_IP_STATUS_COMPARE_MISMATCH Data does not match or memory is not blank
 * @retval     MRAM_IP_STATUS_ERROR_ADDRESS_INPUT_PARAM Invalid input parameters
 * @retval     Other error codes from MRam_Ip_Read
 *
 * @implements MRam_Ip_Compare_Activity
 */
MRam_Ip_StatusType MRam_Ip_Compare(MRam_Ip_AddressType MRamSrcAddress,
                                   uint8 const * pu8SrcAddress,
                                   MRam_Ip_LengthType SizeInBytes,
                                   MRam_Ip_InstanceIdType InstanceId)
{
    /* -------------------------------------------------------------------------
     * LOCAL CONSTANTS DECLARATION
     * ------------------------------------------------------------------------- */

    /*
     * Size of temporary buffer in bytes - matches typical MRAM page size
     * Reading in 32-byte chunks provides good balance between:
     * - Memory usage (small enough for stack allocation)
     * - Performance (large enough to minimize read operations)
     * - Hardware efficiency (matches typical MRAM controller buffers)
     */
    const uint32 BUFFER_SIZE = 32U;

    /* -------------------------------------------------------------------------
     * LOCAL VARIABLES DECLARATION
     * ------------------------------------------------------------------------- */
    /* Status to track read operation and final result */
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;

    /*
     * Current address in MRAM memory being processed
     * This variable is updated after each chunk is processed
     * Example: If starting at 0x08001000 and reading 32-byte chunks:
     * - First iteration: CurrentMRamAddress = 0x08001000
     * - Second iteration: CurrentMRamAddress = 0x08001020
     */
    MRam_Ip_AddressType CurrentMRamAddress = MRamSrcAddress;

    /*
     * Remaining bytes to be processed
     * Example: If SizeInBytes = 100 and we process in 32-byte chunks:
     * - Initial RemainingBytes = 100
     * - After first chunk: RemainingBytes = 68
     * - After second chunk: RemainingBytes = 36
     * - After third chunk: RemainingBytes = 4
     * - After fourth chunk: RemainingBytes = 0 (done)
     */
    MRam_Ip_LengthType RemainingBytes = SizeInBytes;

    /*
     * Buffer to store data read from MRAM - BUFFER_SIZE bytes
     * This temporary buffer holds a copy of MRAM data for comparison
     * Using a fixed-size buffer avoids dynamic memory allocation
     */
    uint8 TempReadBuffer[32U];

    /*
     * Size of the current chunk to read (limited by buffer size)
     * Example: If RemainingBytes = 100, ChunkSize = 32 (BUFFER_SIZE)
     *          If RemainingBytes = 16, ChunkSize = 16 (remaining bytes)
     */
    uint32 ChunkSize;

    /* Index into source buffer (avoids modifying the parameter pointer) */
    uint32 sourceOffset = 0U;

    /*
     * Flag indicating whether we're doing a blank check operation
     * When pu8SrcAddress is NULL_PTR, we perform a blank check against erased values
     */
    boolean isBlankCheck = (NULL_PTR == pu8SrcAddress);

    /* -------------------------------------------------------------------------
     * INPUT PARAMETER VALIDATION
     * Checks that inputs are valid before proceeding with comparison
     * ------------------------------------------------------------------------- */
    if (isBlankCheck)
    {
        /* For blank check, only validate MRAM address and size */
        Status = MRam_Ip_ValidateOperationParameters(MRamSrcAddress, NULL_PTR, SizeInBytes, InstanceId, FALSE);
    }
    else
    {
        /* For normal compare, validate all parameters */
        Status = MRam_Ip_ValidateOperationParameters(MRamSrcAddress, pu8SrcAddress, SizeInBytes, InstanceId, TRUE);
    }

#if (MRAM_IP_CACHE_INVALIDATION == STD_ON)
    /* Invalidate the cache for the source range ONLY after validation passed -
     * never hand a caller-supplied (possibly invalid) address/size to the cache
     * driver before NULL / range / overflow checks (a wild range could discard
     * unrelated dirty cache lines). */
    if (Status == MRAM_IP_STATUS_SUCCESS)
    {
        (void)Cache_Ip_InvalidateByAddr(CACHE_IP_CORE, CACHE_IP_DATA, MRamSrcAddress, SizeInBytes);
    }
#endif

    /* If validation failed, skip comparison - the while loop condition handles this */

    /* -------------------------------------------------------------------------
     * MAIN COMPARISON LOGIC
     * Process data in chunks until all bytes are compared or a mismatch is found
     * ------------------------------------------------------------------------- */
    /*
     * Process data in chunks until all bytes are compared or a mismatch/error occurs
     * This approach has several advantages:
     * - Reduces stack memory usage (fixed buffer size)
     * - Works efficiently with MRAM's page-based architecture
     * - Avoids timeout issues with large transfers
     *
     * Example of chunking with 100 bytes starting at 0x08001000:
     * - Iteration 1: Read & compare 32 bytes from 0x08001000-0x0800101F
     * - Iteration 2: Read & compare 32 bytes from 0x08001020-0x0800103F
     * - Iteration 3: Read & compare 32 bytes from 0x08001040-0x0800105F
     * - Iteration 4: Read & compare 4 bytes from 0x08001060-0x08001063
     * - Done: All 100 bytes compared
     */
    while ((RemainingBytes > 0U) && (Status == MRAM_IP_STATUS_SUCCESS))
    {
        /*
         * Determine optimal chunk size for this iteration
         * This ensures we don't read beyond the requested data
         *
         * Examples:
         * - If RemainingBytes = 100, ChunkSize = 32 (BUFFER_SIZE)
         * - If RemainingBytes = 16, ChunkSize = 16 (just what's needed)
         */
        ChunkSize = (RemainingBytes >= BUFFER_SIZE) ? BUFFER_SIZE : RemainingBytes;

        /*
         * Read data from MRAM using the public API
         * This handles all low-level MRAM access details including:
         * - Cache invalidation if needed
         * - ECC error detection and handling
         * - Access permissions and security
         *
         * Example: Reading 32 bytes from MRAM address 0x08001020 into TempReadBuffer
         */
        Status = MRam_Ip_Read(CurrentMRamAddress,
                              TempReadBuffer,
                              ChunkSize,
                              InstanceId);

        /*
         * Only proceed with comparison if read was successful
         * Possible read errors include:
         * - ECC errors (correctable or uncorrectable)
         * - Access permission violations
         * - Hardware timeout or bus errors
         */
        if (Status == MRAM_IP_STATUS_SUCCESS)
        {
            if (isBlankCheck)
            {
                /* -------------------------------------------------------------------------
                 * BLANK CHECK MODE
                 * Compare MRAM data against predefined blank values
                 * ------------------------------------------------------------------------- */
                Status = MRam_Ip_CompareBlankCheck(TempReadBuffer, ChunkSize, CurrentMRamAddress);
            }
            else
            {
                /* -------------------------------------------------------------------------
                 * NORMAL COMPARISON MODE
                 * Compare MRAM data with source buffer data
                 * ------------------------------------------------------------------------- */
                Status = MRam_Ip_CompareNormalData(TempReadBuffer, &pu8SrcAddress[sourceOffset], ChunkSize, CurrentMRamAddress);
            }

            /*
             * Update pointers and counters for next iteration if comparison successful
             * This prepares for the next chunk of data or completes the operation
             */
            if (Status == MRAM_IP_STATUS_SUCCESS)
            {
                /*
                 * Move to next chunk of data to compare
                 *
                 * Example with 100 bytes starting at 0x08001000, first iteration with ChunkSize=32:
                 * - CurrentMRamAddress updated from 0x08001000 to 0x08001020
                 * - pu8SrcAddress advances by 32 bytes to point to next source data (only in normal compare mode)
                 * - RemainingBytes decreases from 100 to 68
                 *
                 * This continues until RemainingBytes becomes 0 or a mismatch is found
                 */
                CurrentMRamAddress += ChunkSize;  /* Move to next MRAM address */
                if (isBlankCheck != TRUE)
                {
                    sourceOffset += ChunkSize;  /* Advance source index (only if not blank check) */
                }
                RemainingBytes -= ChunkSize;     /* Decrease bytes left to compare */
            }
            /* else: Status is non-SUCCESS (mismatch), loop will exit via while condition */
        }
        /* else: Read error, loop will exit via while condition */
    }

    return Status;
}

#define MEM_43_MRAM_STOP_SEC_CODE
#include "Mem_43_MRAM_MemMap.h"

#ifdef _cplusplus
}
#endif

/** @} */


