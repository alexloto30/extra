[!NOCODE!][!//
[!//////////////////////////////////////////////////////////////////////////////////////////////////
[!////////////////////////   VARIABLE DEFINE FOR EB TRESOS       ///////////////////////////////////

[!VAR "CpuTypeSupport" = "'uint32'"!]
[!VAR "Multicoresupport" = "'STD_OFF'"!]

[!IF "node:exists(as:modconf("MemAcc")[1]/MemAccGeneral/MemAcc64BitSupport)"!]
[!IF "as:modconf("MemAcc")[1]/MemAccGeneral/MemAcc64BitSupport"!]
    [!VAR "CpuTypeSupport" = "'uint64'"!]
[!ENDIF!]
[!ENDIF!]

[!IF "node:exists(as:modconf("MemAcc")[1]/AutosarExt/MemAccMulticoreType3Support)"!]
[!IF "as:modconf("MemAcc")[1]/AutosarExt/MemAccMulticoreType3Support"!]
    [!VAR "Multicoresupport" = "'STD_ON'"!]
[!ENDIF!]
[!ENDIF!]

[!/* A referenced ECUC partition only yields per-partition storage if it is also assigned to an
     OS application, because that is what resolves it to a partition index. The generated
     partition map is sized from the SAME set (see Mem_43_MRAM_Cfg.c), so the switch
     below must be derived from it as well: deriving it from the plain reference count could
     enable the multipartition code against a single entry map and index it out of bounds. */!]
[!VAR "MultiPartitionSupport" = "'STD_OFF'"!][!//

[!IF "num:i(count(MemGeneral/MemEcucPartitionRef/*)) = num:i(0)"!]
    [!IF "node:exists(as:modconf("MemAcc")[1]/AutosarExt/MemAccMulticoreType3Support)"!]
        [!IF "as:modconf("MemAcc")[1]/AutosarExt/MemAccMulticoreType3Support"!]
            [!ERROR!]MemAccMulticoreType3Support is enabled on MemAcc but MemEcucPartitionRef is not configured in Mem_43_MRAM_MRam. All partitions are in MemAccEcucPartitionRef need to be added in MemEcucPartitionRef[!ENDERROR!]
        [!ENDIF!]
    [!ENDIF!]
[!ELSE!]
    [!VAR "MultiPartitionSupport" = "'STD_ON'"!]
[!ENDIF!][!//

[!VAR "UseXRDCConfig" = "'STD_OFF'"!]
[!IF "node:exists(as:modconf("Rm")[1]/RmGeneral/RmEnableXRDCSupport)"!]
[!IF "as:modconf("Rm")[1]/RmGeneral/RmEnableXRDCSupport"!]
    [!VAR "UseXRDCConfig" = "'STD_ON'"!]
[!ENDIF!]
[!ENDIF!]

[!VAR "MemAcc_Used" = "'STD_OFF'"!]
[!IF "node:exists(as:modconf("MemAcc")[1])"!]
    [!VAR "MemAcc_Used" = "'STD_ON'"!]
[!ENDIF!]


[!//////////////////////////////////////////////////////////////////////////////////////////////////
[!///////////////////////    FUNCTION (MACRO) FOR EB TRESOS      ///////////////////////////////////


[!//////////////////////////////////////////////////////////////////////////////////////////////////
[!ENDNOCODE!][!//
[!AUTOSPACING!][!//
/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : MRAM
*   Dependencies         : None
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
*   Copyright 2024 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef MEM_43_MRAM_CFG_DEFINES_H
#define MEM_43_MRAM_CFG_DEFINES_H

/**
 * @file        Mem_43_MRAM_CfgDefines.h
 *
 * @addtogroup  MEM_43_MRAM Driver
 * implement    Mem_43_MRAM_CfgDefines.h_Artifact
 *
 * @{
 */

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Mcal.h"

/*==================================================================================================
                               SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define MEM_43_MRAM_VENDOR_ID_CFG_DEFINES                           43
#define MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_CFG_DEFINES            4
#define MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_CFG_DEFINES            9
#define MEM_43_MRAM_AR_RELEASE_REVISION_VERSION_CFG_DEFINES         0
#define MEM_43_MRAM_SW_MAJOR_VERSION_CFG_DEFINES                    1
#define MEM_43_MRAM_SW_MINOR_VERSION_CFG_DEFINES                    0
#define MEM_43_MRAM_SW_PATCH_VERSION_CFG_DEFINES                    0

/*==================================================================================================
                                      FILE VERSION CHECKS
==================================================================================================*/
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and StandardTypes header file are of the same Autosar version */
    #if ((MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_CFG_DEFINES != STD_AR_RELEASE_MAJOR_VERSION) || \
         (MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_CFG_DEFINES != STD_AR_RELEASE_MINOR_VERSION) \
        )
        #error "AutoSar Version Numbers of Mem_43_MRam_CfgDefines.h and Std_Types.h are different"
    #endif
#endif

#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and Mcal header file are of the same version */
    #if ((MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_CFG_DEFINES != MCAL_AR_RELEASE_MAJOR_VERSION) || \
         (MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_CFG_DEFINES != MCAL_AR_RELEASE_MINOR_VERSION) \
        )
        #error "AutoSar Version Numbers of Mem_43_MRam_CfgDefines.h and Mcal.h are different"
    #endif
#endif

/*==================================================================================================
                                       DEFINES AND MACROS
==================================================================================================*/


/* Number of configured Mem instances */
#define MEM_43_MRAM_INSTANCE_COUNT                           ([!"num:i(count(MemInstance/*))"!]U)

/* Number of configured Mem Internal Units */
#define MEM_43_MRAM_INTERNAL_UNIT_COUNT                      (1U)

/* Pre-processor switch to enable and disable development error detection */
#define MEM_43_MRAM_DEV_ERROR_DETECT                         ([!IF "MemGeneral/MemDevErrorDetect"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])

/* Mem Hardware Compare Service Api */
#define MEM_43_MRAM_HW_COMPARE_SERVICE                       ([!IF "MemAutosarExt/MemHwCompareService"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])

/* Mem Hardware UTest Service Api */
#define MEM_43_MRAM_HW_UTEST_SERVICE                         ([!IF "MemAutosarExt/MemHwUTestService"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])

/* Enable calculates CRC for items */
#define MEM_43_MRAM_CHECK_CFG_CRC                            ([!IF "MemAutosarExt/MemEnableCheckCfgCrc"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])

/* Support for User mode.
* If this parameter has been configured to TRUE the Mem driver can be executed from both supervisor and user mode.
*/
#define MEM_43_MRAM_ENABLE_USER_MODE_SUPPORT                 ([!IF "MemAutosarExt/MemEnableUserModeSupport"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])

/** Check the driver user mode is enabled only when the MCAL_ENABLE_USER_MODE_SUPPORT is enabled */
#if (MEM_43_MRAM_ENABLE_USER_MODE_SUPPORT == STD_ON)
#ifndef MCAL_ENABLE_USER_MODE_SUPPORT
    #error MCAL_ENABLE_USER_MODE_SUPPORT is not enabled. For running Mem_MRam in user mode the MCAL_ENABLE_USER_MODE_SUPPORT needs to be defined.
#endif /* ifndef MCAL_ENABLE_USER_MODE_SUPPORT */
#endif /* (MEM_43_MRAM_ENABLE_USER_MODE_SUPPORT == STD_ON) */

/* Enable Multicore support when using MemAcc*/
#define MEM_43_MRAM_MULTICORE_ENABLED                        ([!"$Multicoresupport"!])

/* Enable Multipartition support to ensure freedom from interference (driver mapped to ECUC partition(s)) */
#define MEM_43_MRAM_MULTIPARTITION_ENABLED                   ([!"$MultiPartitionSupport"!])

/* Use the XRDC in RM module to config */
#define MEM_43_MRAM_USE_XRDC_CONFIG                          ([!"$UseXRDCConfig"!])

/* MemAcc driver used as support? */
#define MEM_43_MRAM_MEMACC_USED                              ([!"$MemAcc_Used"!])

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* MEM_43_MRAM_CFG_DEFINES_H */

