/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : MRAM
*   Dependencies         : None
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
*   Copyright 2024 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef MEM_43_MRAM_IPW_H
#define MEM_43_MRAM_IPW_H

/**
 * @file       Mem_43_MRAM_Ipw.h
 *
 * @addtogroup MEM_43_MRAM Driver
 * implement   Mem_43_MRAM_Ipw.h_Artifact
 *
 * @{
 */

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
                                         INCLUDE FILES
 1) system and project includes
 2) needed interfaces from external units
 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Mem_43_MRAM_Types.h"
#include "OsIf.h"

#if (STD_ON == MEM_43_MRAM_USE_XRDC_CONFIG)
#include "CDD_Rm.h"
#endif

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define MEM_43_MRAM_IPW_VENDOR_ID_H                       43
#define MEM_43_MRAM_IPW_AR_RELEASE_MAJOR_VERSION_H        4
#define MEM_43_MRAM_IPW_AR_RELEASE_MINOR_VERSION_H        9
#define MEM_43_MRAM_IPW_AR_RELEASE_REVISION_VERSION_H     0
#define MEM_43_MRAM_IPW_SW_MAJOR_VERSION_H               1
#define MEM_43_MRAM_IPW_SW_MINOR_VERSION_H                0
#define MEM_43_MRAM_IPW_SW_PATCH_VERSION_H                0

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if current file and Mem_43_MRAM_Types.h header file are of the same vendor */
#if (MEM_43_MRAM_IPW_VENDOR_ID_H != MEM_43_MRAM_TYPES_VENDOR_ID)
    #error "Mem_43_MRAM_Ipw.h and Mem_43_MRAM_Types.h have different vendor ids"
#endif
/* Check if current file and Mem_43_MRAM_Types.h header file are of the same Autosar version */
#if ((MEM_43_MRAM_IPW_AR_RELEASE_MAJOR_VERSION_H    != MEM_43_MRAM_TYPES_AR_RELEASE_MAJOR_VERSION) || \
     (MEM_43_MRAM_IPW_AR_RELEASE_MINOR_VERSION_H    != MEM_43_MRAM_TYPES_AR_RELEASE_MINOR_VERSION) || \
     (MEM_43_MRAM_IPW_AR_RELEASE_REVISION_VERSION_H != MEM_43_MRAM_TYPES_AR_RELEASE_REVISION_VERSION) \
    )
    #error "AutoSar Version Numbers of Mem_43_MRAM_Ipw.h and Mem_43_MRAM_Types.h are different"
#endif
/* Check if current file and Mem_43_MRAM_Types.h header file are of the same Software version */
#if ((MEM_43_MRAM_IPW_SW_MAJOR_VERSION_H != MEM_43_MRAM_TYPES_SW_MAJOR_VERSION) || \
     (MEM_43_MRAM_IPW_SW_MINOR_VERSION_H != MEM_43_MRAM_TYPES_SW_MINOR_VERSION) || \
     (MEM_43_MRAM_IPW_SW_PATCH_VERSION_H != MEM_43_MRAM_TYPES_SW_PATCH_VERSION) \
    )
    #error "Software Version Numbers of Mem_43_MRAM_Ipw.h and Mem_43_MRAM_Types.h are different"
#endif

#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and OsIf.h header file are of the same Autosar version */
    #if ((MEM_43_MRAM_IPW_AR_RELEASE_MAJOR_VERSION_H != OSIF_AR_RELEASE_MAJOR_VERSION) || \
         (MEM_43_MRAM_IPW_AR_RELEASE_MINOR_VERSION_H != OSIF_AR_RELEASE_MINOR_VERSION) \
        )
        #error "AutoSar Version Numbers of Mem_43_MRAM_Ipw.h and OsIf.h are different"
    #endif
#endif
/*==================================================================================================
*                                    DEFINES AND MACROS
==================================================================================================*/

/*==================================================================================================
*                                    VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                    FUNCTION PROTOTYPES
==================================================================================================*/

#define MEM_43_MRAM_START_SEC_CODE
#include "Mem_43_MRAM_MemMap.h"


/**
 * @brief       Initialize the hardware resources.
 * @details
 *
 * @return      Std_ReturnType
 */
Std_ReturnType Mem_43_MRAM_IPW_Init(const Mem_43_MRAM_ConfigType *ConfigPtr, uint32 InstanceIndex);

/**
 * @brief       DeInitialize the hardware resources.
 * @details
 *
 * @return      Std_ReturnType
 */
void Mem_43_MRAM_IPW_DeInit(const Mem_43_MRAM_ConfigType *ConfigPtr, uint32 InstanceIndex);

/**
 * @brief       IP wrapper erase function.
 * @details
 *
 * @param[in]   InstanceIndex       ID of the related memory driver instance.
 * @param[in]   JobInfo             Job runtime information
 *
 * @return      Mem_43_MRAM_JobResultType
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_Erase(uint32 InstanceIndex,
                                                  Mem_43_MRAM_JobRuntimeInfoType *JobInfo
                                                 );


/**
 * @brief       IP wrapper write function.
 * @details
 *
 * @param[in]   InstanceIndex       ID of the related memory driver instance.
 * @param[in]   JobInfo             Job runtime information
 *
 * @return      Mem_43_MRAM_JobResultType
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_Write(uint32 InstanceIndex,
                                                  Mem_43_MRAM_JobRuntimeInfoType *JobInfo
                                                 );


/**
 * @brief       IP wrapper read function.
 * @details
 *
 * @param[in]   InstanceIndex       ID of the related memory driver instance.
 * @param[in]   JobInfo             Job runtime information
 *
 * @return      Mem_43_MRAM_JobResultType
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_Read(uint32 InstanceIndex,
                                                 Mem_43_MRAM_JobRuntimeInfoType *JobInfo
                                                );


#if (MEM_43_MRAM_HW_COMPARE_SERVICE == STD_ON)
/**
 * @brief       IP wrapper Compare function.
 * @details
 *
 * @param[in]   InstanceIndex       ID of the related memory driver instance.
 * @param[in]   JobInfo             Job runtime information
 *
 * @return      Mem_43_MRAM_JobResultType
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_Compare(uint32 InstanceIndex,
                                                    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
                                                   );
#endif /* MEM_43_MRAM_HW_COMPARE_SERVICE == STD_ON */

#if (MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON)
/**
 * @brief       IP wrapper UTest Reference Recovery/Refresh function.
 * @details     Synchronous one-shot BIST service; ignores address/length.
 *
 * @param[in]   InstanceIndex       ID of the related memory driver instance.
 * @param[in]   JobInfo             Job runtime information
 *
 * @return      Mem_43_MRAM_JobResultType
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_UTestReferenceRecoveryRefresh(uint32 InstanceIndex,
                                                    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
                                                   );

/**
 * @brief       IP wrapper UTest EDC-after-ECC Logic Check function.
 * @details     Synchronous one-shot BIST; params + ResultEEE slot are carried via JobInfo->DataPtr.
 *
 * @param[in]   InstanceIndex       ID of the related memory driver instance.
 * @param[in]   JobInfo             Job runtime information
 *
 * @return      Mem_43_MRAM_JobResultType
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_EDCAfterECCLogicCheck(uint32 InstanceIndex,
                                                    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
                                                   );

/**
 * @brief       IP wrapper UTest Address-Encode Logic Check function.
 * @details     Synchronous one-shot BIST; params + ResultAEE slot are carried via JobInfo->DataPtr.
 *
 * @param[in]   InstanceIndex       ID of the related memory driver instance.
 * @param[in]   JobInfo             Job runtime information
 *
 * @return      Mem_43_MRAM_JobResultType
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_AddressEncodeLogicCheck(uint32 InstanceIndex,
                                                    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
                                                   );

/**
 * @brief       IP wrapper UTest ECC Logic Check function.
 * @details     Synchronous one-shot BIST; params + embedded Result slot are carried via JobInfo->DataPtr.
 *
 * @param[in]   InstanceIndex       ID of the related memory driver instance.
 * @param[in]   JobInfo             Job runtime information
 *
 * @return      Mem_43_MRAM_JobResultType
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_ECCLogicCheck(uint32 InstanceIndex,
                                                    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
                                                   );

/**
 * @brief       IP wrapper UTest Array Integrity Check function.
 * @details     Synchronous one-shot BIST; params + embedded Result slot are carried via JobInfo->DataPtr.
 *              The IP function returns the result by value and has no status enum, so the JobResult is
 *              derived from the result flags.
 *
 * @param[in]   InstanceIndex       ID of the related memory driver instance.
 * @param[in]   JobInfo             Job runtime information
 *
 * @return      Mem_43_MRAM_JobResultType
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_ArrayIntegrityCheck(uint32 InstanceIndex,
                                                    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
                                                   );
#endif /* MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON */

/**
 * @brief       IP wrapper blank check function.
 * @details
 *
 * @param[in]   InstanceIndex       ID of the related memory driver instance.
 * @param[in]   JobInfo             Job runtime information
 *
 * @return      Mem_43_MRAM_JobResultType
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_BlankCheck(uint32 InstanceIndex,
                                                       Mem_43_MRAM_JobRuntimeInfoType *JobInfo
                                                      );

#define MEM_43_MRAM_STOP_SEC_CODE
#include "Mem_43_MRAM_MemMap.h"


#ifdef __cplusplus
}
#endif

/** @} */

#endif /* MEM_43_MRAM_IPW_H */
