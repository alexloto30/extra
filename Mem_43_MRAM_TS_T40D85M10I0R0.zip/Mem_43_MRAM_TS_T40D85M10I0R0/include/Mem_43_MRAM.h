/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : MRAM
*   Dependencies         : None
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
*   Copyright 2024 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef MEM_43_MRAM_H
#define MEM_43_MRAM_H

/**
 * @file       Mem_43_MRAM.h
 *
 * @defgroup   MEM_43_MRAM MEM_43_MRAM Driver
 * @implements Mem_43_MRAM.h_Artifact
 *
 * @{
 */

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
                                         INCLUDE FILES
 1) system and project includes
 2) needed interfaces from external units
 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Mem_43_MRAM_Cfg.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define MEM_43_MRAM_VENDOR_ID                      43
#define MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION       4
#define MEM_43_MRAM_AR_RELEASE_MINOR_VERSION       9
#define MEM_43_MRAM_AR_RELEASE_REVISION_VERSION    0
#define MEM_43_MRAM_SW_MAJOR_VERSION               1
#define MEM_43_MRAM_SW_MINOR_VERSION               0
#define MEM_43_MRAM_SW_PATCH_VERSION               0

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/

/* Check if current file and Mem_43_MRAM_Cfg.h header file are of the same vendor */
#if (MEM_43_MRAM_VENDOR_ID != MEM_43_MRAM_VENDOR_ID_CFG)
    #error "Mem_43_MRAM.h and Mem_43_MRAM_Cfg.h have different vendor ids"
#endif
/* Check if current file and Mem_43_MRAM_Cfg.h header file are of the same Autosar version */
#if ((MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION    != MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_CFG) || \
     (MEM_43_MRAM_AR_RELEASE_MINOR_VERSION    != MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_CFG) || \
     (MEM_43_MRAM_AR_RELEASE_REVISION_VERSION != MEM_43_MRAM_AR_RELEASE_REVISION_VERSION_CFG) \
    )
    #error "AutoSar Version Numbers of Mem_43_MRAM.h and Mem_43_MRAM_Cfg.h are different"
#endif
/* Check if current file and Mem_43_MRAM_Cfg.h header file are of the same Software version */
#if ((MEM_43_MRAM_SW_MAJOR_VERSION != MEM_43_MRAM_SW_MAJOR_VERSION_CFG) || \
     (MEM_43_MRAM_SW_MINOR_VERSION != MEM_43_MRAM_SW_MINOR_VERSION_CFG) || \
     (MEM_43_MRAM_SW_PATCH_VERSION != MEM_43_MRAM_SW_PATCH_VERSION_CFG) \
    )
    #error "Software Version Numbers of Mem_43_MRAM.h and Mem_43_MRAM_Cfg.h are different"
#endif

/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/


/*==================================================================================================
                                          CONSTANTS
==================================================================================================*/


/*==================================================================================================
                                       GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
                                       GLOBAL FUNCTIONS (Synchronous Functions)
==================================================================================================*/

/**
 * @brief        The function initializes Mem_43_MRAM module.
 */
void Mem_43_MRAM_Init(const Mem_43_MRAM_ConfigType* ConfigPtr);


/**
 * @brief        The function de-initializes the Mem_43_MRAM module.
 */
void Mem_43_MRAM_DeInit(void);


/**
 * @brief        Return the version information of the Mem module.
 */
void Mem_43_MRAM_GetVersionInfo(Std_VersionInfoType * VersionInfoPtr);


/**
 * @brief        Returns the result of the most recent job.
 */
/* If AUTOSAR R21-11 is used the return type will be taken from Mem driver */
Mem_43_MRAM_JobResultType Mem_43_MRAM_GetJobResult(Mem_43_MRAM_InstanceIdType InstanceId);

/**
 * @brief        Suspends active memory operation using hardware mechanism.
 */
Std_ReturnType Mem_43_MRAM_Suspend(Mem_43_MRAM_InstanceIdType InstanceId);

/**
 * @brief        Resumes suspended memory operation using hardware mechanism.
 */
Std_ReturnType Mem_43_MRAM_Resume(Mem_43_MRAM_InstanceIdType InstanceId);

/**
 * @brief        Propagates an ECC error to the memory upper layers
 */
void Mem_43_MRAM_PropagateError(Mem_43_MRAM_InstanceIdType InstanceId);


/*==================================================================================================
                                       GLOBAL FUNCTIONS (Asynchronous Functions)
==================================================================================================*/

/**
 * @brief            Reads from flash memory.
 */
Std_ReturnType Mem_43_MRAM_Read(Mem_43_MRAM_InstanceIdType    InstanceId,
                                 Mem_43_MRAM_AddressType       SourceAddress,
                                 Mem_43_MRAM_DataType         *DestinationDataPtr,
                                 Mem_43_MRAM_LengthType        Length
                                );

/**
 * @brief            Writes to flash memory.
 */
Std_ReturnType Mem_43_MRAM_Write(Mem_43_MRAM_InstanceIdType     InstanceId,
                                  Mem_43_MRAM_AddressType        TargetAddress,
                                  const Mem_43_MRAM_DataType    *SourceDataPtr,
                                  Mem_43_MRAM_LengthType         Length
                                 );


/**
 * @brief            Erase one or more complete flash sectors.
 */
Std_ReturnType Mem_43_MRAM_Erase(Mem_43_MRAM_InstanceIdType    InstanceId,
                                  Mem_43_MRAM_AddressType       TargetAddress,
                                  Mem_43_MRAM_LengthType        Length
                                 );


/**
 * @brief            Verify whether a given memory area has been erased but not (yet) programmed.
 */
Std_ReturnType Mem_43_MRAM_BlankCheck(Mem_43_MRAM_InstanceIdType    InstanceId,
                                       Mem_43_MRAM_AddressType       TargetAddress,
                                       Mem_43_MRAM_LengthType        Length
                                      );


/**
 * @brief            Trigger a hardware specific service.
 */
Std_ReturnType Mem_43_MRAM_HwSpecificService(Mem_43_MRAM_InstanceIdType     instanceId,
                                              Mem_43_MRAM_HwServiceIdType    hwServiceId,
                                              Mem_43_MRAM_DataType         * dataPtr,
                                              Mem_43_MRAM_LengthType       * lengthPtr
                                             );
/*==================================================================================================
                                       GLOBAL FUNCTIONS (Scheduled Functions)
==================================================================================================*/

/**
 * @brief            Service to handle the requested jobs and the internal management operations.
 */
void Mem_43_MRAM_MainFunction(void);


#ifdef __cplusplus
}
#endif

/** @} */

#endif /* MEM_43_MRAM_H */
