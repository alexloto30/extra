/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : MRAM
*   Dependencies         : None
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
*   Copyright 2024 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef MRAM_IP_TYPES_H
#define MRAM_IP_TYPES_H

/**
 * @file       MRAM_Ip_Types.h
 *
 * @addtogroup MRAM_IP
 * implement   MRAM_Ip_Types.h_Artifact
 *
 * @{
 */

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Std_Types.h"

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define MRAM_IP_TYPES_VENDOR_ID                    43
#define MRAM_IP_TYPES_AR_RELEASE_MAJOR_VERSION     4
#define MRAM_IP_TYPES_AR_RELEASE_MINOR_VERSION     9
#define MRAM_IP_TYPES_AR_RELEASE_REVISION_VERSION  0
#define MRAM_IP_TYPES_SW_MAJOR_VERSION             1
#define MRAM_IP_TYPES_SW_MINOR_VERSION             0
#define MRAM_IP_TYPES_SW_PATCH_VERSION             0

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if MRAM_Ip_Types header file and Std_Types.h header file are of the same Autosar version */
    #if ((MRAM_IP_TYPES_AR_RELEASE_MAJOR_VERSION != STD_AR_RELEASE_MAJOR_VERSION) || \
         (MRAM_IP_TYPES_AR_RELEASE_MINOR_VERSION != STD_AR_RELEASE_MINOR_VERSION) \
        )
        #error "Autosar Version Numbers of MRAM_Ip_Types.h and Std_Types.h are different"
    #endif
#endif

/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/

#define MRAM_IP_REGSET_COUNT        (2U) /*!< @brief Number of hardware write register sets */

/*!
 * @brief          MRAM byte size definitions for data access
 * @details        Defines the number of bytes used for different data access operations:
 *                 - 1 byte access (8-bit)
 *                 - 2 byte access (16-bit)
 *                 - 4 byte access (32-bit)
 */
/*! @brief the number of bytes uses to compare (1 byte) */
#define MRAM_IP_SIZE_1BYTE            (1U)
/*! @brief the number of bytes uses to compare (2 byte) */
#define MRAM_IP_SIZE_2BYTE            (2U)
/*! @brief the number of bytes uses to compare (2 byte) */
#define MRAM_IP_SIZE_3BYTE            (3U)
/*! @brief the number of bytes uses to compare (4 byte) */
#define MRAM_IP_SIZE_4BYTE            (4U)


/*!
 * @brief          Memory map of MRAM regions as defined in hardware reference manual
 * @details        Defines the memory map layout and sizes for different MRAM regions:
 *                 - Code MRAM region (32MB starting at 0x08000000)
 *                 - Non-Secure One-Time Programmable MRAM region (48KB starting at 0x0C404000)
 *                 - Data MRAM region (256KB starting at 0x0C800000)
 *                 Each region has defined start address, implemented size in KB, and calculated end address
 */
/*! @brief Start address of Code MRAM region - memory mapped at 0x08000000 per SoC specification */
#define MRAM_START_ADDRESS_CODE       (0x08000000UL)
/*! @brief Implemented size (Kb) Code MRAM */
#define MRAM_IMPLEMENTED_SIZE_CODE    (32768UL)
/*! @brief End address Code MRAM */
#define MRAM_END_ADDRESS_CODE         (MRAM_START_ADDRESS_CODE + (MRAM_IMPLEMENTED_SIZE_CODE * 1024UL))

/*! @brief Start address of Non-Secure One-Time Programmable MRAM region */
#define MRAM_START_ADDRESS_NS_OTP     (0x0C404000UL)
/*! @brief Implemented size (Kb) NON Secure OTP MRAM */
#define MRAM_IMPLEMENTED_SIZE_NS_OTP  (48UL)
/*! @brief End address NON Secure OTP */
#define MRAM_END_ADDRESS_NS_OTP       (MRAM_START_ADDRESS_NS_OTP + (MRAM_IMPLEMENTED_SIZE_NS_OTP * 1024UL))

/*! @brief Start address of Data MRAM region */
#define MRAM_START_ADDRESS_DATA       (0x0C800000UL)
/*! @brief Implemented size (Kb) Data MRAM */
#define MRAM_IMPLEMENTED_SIZE_DATA    (256UL)
/*! @brief End address Data MRAM */
#define MRAM_END_ADDRESS_DATA         (MRAM_START_ADDRESS_DATA + (MRAM_IMPLEMENTED_SIZE_DATA * 1024UL))

/*! @brief Start address of UTEST region */
#define MRAM_START_ADDRESS_UTEST       (0x0C8FE000UL)
/*! @brief Implemented size (Kb) UTEST */
#define MRAM_IMPLEMENTED_SIZE_UTEST    (40UL)
/*! @brief End address UTEST */
#define MRAM_END_ADDRESS_UTEST         (MRAM_START_ADDRESS_UTEST + (MRAM_IMPLEMENTED_SIZE_UTEST * 1024UL))

/* OTA_NUM_FIXED_LPART (GPR1.GPR_RWD_0[11:6]) counts the large PARTITIONS that
 * stay FIXED when OTA_SEL==1; the swap unit is the PAIR (2 partitions), so pairs
 * = partitions/2. 0x00 = full swap (0 fixed), 0x04 = partial swap (2 pairs 0..1
 * fixed, per RM 39.3.6), 0x10 = all 16 partitions / 8 pairs fixed (no swap). */
#define MRAM_IP_OTA_NO_SWAP             (0x10U)
#define MRAM_IP_OTA_PARTIAL_SWAP        (0x04U)
#define MRAM_IP_OTA_PARTIAL_FIXED_PAIRS (MRAM_IP_OTA_PARTIAL_SWAP / 2U)
#define MRAM_IP_OTA_FULL_SWAP           (0x00U)
/*==================================================================================================
                                 ENUM TYPEDEFS
==================================================================================================*/
/*!
 * @brief          MRAM operation status codes
 * @details        Defines all possible status codes that can be returned by MRAM operations
 *                 Status codes are grouped into categories by value ranges:
 *                 - Success (0x00)
 *                 - Initialization/Deinitialization errors (0x10-0x1F)
 *                 - Read operation errors (0x20-0x2F)
 *                 - Write operation errors (0x30-0x3F)
 *                 - ECC errors (0x40-0x4F)
 *                 - Locking errors (0x50-0x5F)
 *                 - General errors (0x60-0x7F)
 */
typedef enum
{
    /*==================================================================================================
     * SUCCESS CODES (0x00-0x0F)
     *================================================================================================*/
    MRAM_IP_STATUS_SUCCESS                          = 0U,      /*!< Successful job */

    /*==================================================================================================
     * INITIALIZATION/DEINITIALIZATION ERRORS (0x10-0x1F)
     * Errors that occur during driver initialization or deinitialization
     *================================================================================================*/
    MRAM_IP_STATUS_DEINIT_ERROR                     = 0x10U,   /*!< Deinitialization error */

    /*==================================================================================================
     * READ OPERATION ERRORS (0x20-0x2F)
     * Errors that occur during memory read or compare operations
     *================================================================================================*/
    MRAM_IP_STATUS_READ_NOT_ALLOWED                 = 0x20U,   /*!< Read not allowed */
    MRAM_IP_STATUS_READ_ERROR                       = 0x21U,   /*!< Read job ended with error - Maps to: ERRSTAT[RE] */
    MRAM_IP_STATUS_COMPARE_MISMATCH                 = 0x22U,   /*!< Compare operation resulted in mismatch */
    MRAM_IP_STATUS_ECC_READ_DATA                    = 0x23U,   /*!< Encounters ECC error on read data - Maps to: F16ASM[EER], ERRSTAT[DEE] */
    MRAM_IP_STATUS_ERROR_READ_PATH                  = 0x24U,   /*!< Encounters error on read path - Maps to: ERRSTAT[RE] */
    MRAM_IP_STATUS_READ_WAIT_STATE_ERROR            = 0x25U,   /*!< Reserved - REWSC is a diagnostic field, not an error flag (currently unused) */
    MRAM_IP_STATUS_ADDRESS_ENCODE_ERROR             = 0x26U,   /*!< Invalid memory address encoding - Maps to: F16ASM[AEE] */

    /*==================================================================================================
     * WRITE OPERATION ERRORS (0x30-0x3F)
     * Errors that occur during memory write or erase operations
     *================================================================================================*/
    MRAM_IP_STATUS_WRITE_PROTECTED                  = 0x30U,   /*!< Write operation is not allowed due to protection - Maps to: F16ASM[WRP] */
    MRAM_IP_STATUS_WRITE_COLLISION_ERROR            = 0x31U,   /*!< Write collision detected - Maps to: F16ASM[WCE] */
    MRAM_IP_STATUS_WRITE_ADDRESS_ERROR              = 0x32U,   /*!< Invalid write address - Maps to: F16ASM[WAE] */
    MRAM_IP_STATUS_WRITE_ERROR                      = 0x33U,   /*!< Write job ended with error - Maps to: F16ASM[WRE], ERRSTAT[WE] */
    MRAM_IP_STATUS_WRITE_BUSY                       = 0x34U,   /*!< Current core is performing a write operation */
    MRAM_IP_STATUS_WRITE_TIMEOUT_BUSY               = 0x35U,   /*!< All variant registers are not released in a specified time */
    MRAM_IP_STATUS_WRITE_GAIN_SEMAPHORE_ERROR       = 0x36U,   /*!< Current core failed when trying to gain semaphore for destination address register */
    MRAM_IP_STATUS_WRITE_TIMEOUT_GAIN_SEMAPHORE     = 0x37U,   /*!< Current core failed to gain semaphore within specified time */
    MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR              = 0x38U,   /*!< Write operation is taking too long - Maps to: F16ASM[WTE] */
    MRAM_IP_STATUS_ERASE_OTP_NOT_ALLOWED            = 0x39U,   /*!< Erase operation not allowed in OTP region */
    MRAM_IP_STATUS_ERROR_WRITE_PATH                 = 0x3AU,   /*!< Encounters error on write path - Maps to: ERRSTAT[WE] */
    MRAM_IP_STATUS_POSTED_WRITE_ERROR               = 0x3BU,   /*!< Error on posted (bufferable) write transaction - Maps to: ERRSTAT[PWE] */
    MRAM_IP_STATUS_OTP_ALIGNMENT_ERROR              = 0x3CU,   /*!< OTP write must be a full 32-byte (256-bit / 1 page) aligned operation. The RM describes the OTP-write operation as 256 bits in size and recommends 256-bit data to match the ECC segment; partial/unaligned OTP writes are rejected because OTP is one-time-programmable and a partial page cannot be completed later without a write-verify (WRE) error. Returned when DestAddress is not 32-byte aligned or SizeInBytes is not a multiple of 32 for an OTP write. */

    /*==================================================================================================
     * ECC ERRORS (0x40-0x4F)
     * Errors related to Error Correction Code detection and handling
     *================================================================================================*/
    MRAM_IP_STATUS_ECC_UNCORRECTED                  = 0x40U,   /*!< ECC uncorrected error - Maps to: F16ASM[EER], ERRSTAT[DEE] */
    MRAM_IP_STATUS_ECC_CORRECTED                    = 0x41U,   /*!< ECC corrected error - Maps to: F16ASM[SBC], ERRSTAT[DEE] */
    MRAM_IP_STATUS_ECC_TRIPLE_BIT_ERROR             = 0x42U,   /*!< Triple bit ECC error detected - Maps to: F16ASM[TBC], ERRSTAT[DEE] */
    MRAM_IP_STATUS_ECC_DOUBLE_BIT_ERROR             = 0x43U,   /*!< Double bit ECC error detected - Maps to: F16ASM[DBC], ERRSTAT[DEE] */
    MRAM_IP_STATUS_ECC_CONTROL_ERROR                = 0x44U,   /*!< ECC error on control attributes like address - Maps to: ERRSTAT[CEE] */
    MRAM_IP_STATUS_ECC_EDC_AFTER_ECC_ERROR          = 0x45U,   /*!< EDC after ECC error from MRAM - Maps to: F16ASM[EEE], ERRSTAT[MEEE] */
    MRAM_IP_STATUS_MRAM_MACRO_ERROR                 = 0x46U,   /*!< MRAM macro reported an error - aggregate flag from ERRSTAT0[ME]. Per RM, ME fires for any of: WRE (write verify failure), EER (uncorrectable read ECC), or AEE (read address encode error). Caller should inspect MCRS for the specific cause. */

    /*==================================================================================================
     * LOCKING ERRORS (0x50-0x5F)
     * Errors related to partition or register locking operations
     *================================================================================================*/
    MRAM_IP_STATUS_LOCK_OWNERSHIP_NOT_VALID         = 0x50U,   /*!< Lock register bit ownership invalid (protect lock register field has value other than 10b) */
    MRAM_IP_STATUS_PARTITION_LOCKED                 = 0x51U,   /*!< Memory partition is locked for write operations */
    MRAM_IP_STATUS_PARTITION_UNLOCKED               = 0x52U,   /*!< Memory partition is unlocked */
    MRAM_IP_STATUS_ALREADY_LOCKED                   = 0x53U,   /*!< Register PortReadIDAssignment is already locked */
    MRAM_IP_STATUS_PARTITION_LOCK_RESTORE_FAILED    = 0x54U,   /*!< Driver could not re-lock one or more partitions it had cleared during a write/erase (STD_OFF auto-management mode). The data operation itself completed normally, but the range is now unprotected. Returned only when the data operation succeeded - if the data operation failed, that error takes priority. */

    /*==================================================================================================
     * GENERAL ERRORS (0x60-0x7F)
     * Common errors that can occur across multiple operation types
     *================================================================================================*/
    MRAM_IP_STATUS_ERROR                            = 0x60U,   /*!< Error - general code */
    MRAM_IP_STATUS_ERROR_TIMEOUT                    = 0x61U,   /*!< Error - exceeded timeout */
    MRAM_IP_STATUS_ERROR_BLANK_CHECK                = 0x62U,   /*!< Error - selected memory area is not erased */
    MRAM_IP_STATUS_ERROR_NOT_INITIALIZED            = 0x63U,   /*!< Error - MRAM device not initialized */
    MRAM_IP_STATUS_UTEST_MODE_ACTIVE                = 0x64U,   /*!< MRAM is in unit test mode */
    MRAM_IP_STATUS_ERROR_WDOG_WRONG_TIMER_PARAM     = 0x65U,   /*!< Watchdog timer parameter is incorrect */
    MRAM_IP_STATUS_ERROR_WDOG_LOCKED                = 0x66U,   /*!< Watchdog is locked, preventing further operations until next reset */
    MRAM_IP_STATUS_ERROR_INVALID_INSTANCE_ID        = 0x67U,   /*!< Error - Invalid MRAM hardware instance ID */
    MRAM_IP_STATUS_ERROR_NULL_PTR_INPUT_PARAM       = 0x68U,   /*!< Error - Null pointer input parameter */
    MRAM_IP_STATUS_ERROR_REGION_SIZE_NULL_INPUT_PARAM = 0x69U, /*!< Error - Region size to be handled is zero or invalid */
    MRAM_IP_STATUS_ERROR_ADDRESS_INPUT_PARAM        = 0x6AU,   /*!< Error - Invalid memory address input parameter */
    MRAM_IP_STATUS_ERROR_MEMORY_REGION_SIZE_EXCEEDED = 0x6BU,  /*!< Error - Requested memory region size exceeds available memory */
    MRAM_IP_STATUS_ERROR_INVALID_PORT_ID             = 0x6CU,  /*!< Error - Invalid port identifier id */
    MRAM_IP_STATUS_ERROR_INVALID_PORT_WORD_INDEX     = 0x6DU,  /*!< Error - Invalid port word index */
    MRAM_IP_STATUS_ERROR_CONTROL_PARITY              = 0x6EU,  /*!< Error - Control parity error on control attributes - Maps to: ERRSTAT[CPE] */
    MRAM_IP_STATUS_ERROR_MRAM_CONTROLLER             = 0x6FU,  /*!< Error - MRAM controller error with address decoder logic - Maps to: ERRSTAT[MCE] */
    MRAM_IP_STATUS_ERROR_USER_CONFIG                 = 0x70U,  /*!< Error - User configuration error - Maps to: ERRSTAT[UE] */
    MRAM_IP_STATUS_ERROR_REPAIR_STORAGE              = 0x71U,  /*!< Error - Memory repair information corrupted - Maps to: F16ASM[RSE] */
    MRAM_IP_STATUS_ERROR_RESET                       = 0x72U,  /*!< Error - Reset error occurred - Maps to: F16ASM[RE] */
} MRam_Ip_StatusType;

/*!
 * @brief          Error mask to status code mapping structure
 * @details        Maps hardware register bit masks to driver status codes
 */
typedef struct
{
    uint32 registerMask;            /*!< Hardware register bit mask */
    MRam_Ip_StatusType status;      /*!< Corresponding status code */
} MRam_Ip_ErrorMaskMappingType;

/*!
 * @brief          MRAM hardware instance
 * @details        Defines the available MRAM hardware instances in the system
 */
typedef enum
{
    MRAM_IP_INSTANCE_0 = 0x00U,  /*!< MRAM hardware instance 0 */
} MRam_Ip_InstanceIdType;

/*!
 * @brief          MRAM port identifiers
 * @details        Defines the available MRAM hardware ports in the system for different interconnects
 */
typedef enum
{
    MRAM_IP_PORT_ID_1 = 0x00U,  /*!< MRAM hardware port 1 - M7 inteconnect */
    MRAM_IP_PORT_ID_2 = 0x01U,  /*!< MRAM hardware port 2 - M7 inteconnect*/
    MRAM_IP_PORT_ID_3 = 0x02U   /*!< MRAM hardware port 3 - R52 inteconnect */
} MRam_Ip_PortIdType;

/**
 * @brief          MRam Address Type
 * @details        Physical memory device address type used for memory operations
 */
typedef uint32 MRam_Ip_AddressType;

/**
 * @brief          MRam Length Type
 * @details        Number of bytes used for memory operations
 */
typedef uint32 MRam_Ip_LengthType;

/*!
 * @brief          MRAM watchdog timer settings
 * @details        Defines the available watchdog timer settings for MRAM operations
 *                 Values correspond to specific hardware configuration register values
 */
typedef enum
{
    MRAM_IP_WATCHDOG_200_CLOCKS = 0x01u,  /*!< Watchdog timeout after 200 clock cycles */
    MRAM_IP_WATCHDOG_400_CLOCKS = 0x02u,  /*!< Watchdog timeout after 400 clock cycles */
    MRAM_IP_WATCHDOG_4000_CLOCKS = 0x03u, /*!< Watchdog timeout after 4000 clock cycles */
    MRAM_IP_WATCHDOG_40000_CLOCKS = 0x00u /*!< Watchdog timeout after 40000 clock cycles (default) */
} MRam_Ip_WatchdogTuneType;

/*!
 * @brief          MRAM address area types
 * @details        Defines the different memory areas within the MRAM device
 */
typedef enum
{
    MRAM_IP_ADDRESS_AREA_TYPE_NOT_EXISTS = 0u, /*!< Address is not within any valid MRAM area */
    MRAM_IP_ADDRESS_AREA_TYPE_CODE = 1u,       /*!< Address is within Code MRAM region (0x08000000-0x0C000000) */
    MRAM_IP_ADDRESS_AREA_TYPE_NS_OTP = 2u,     /*!< Address is within Non-Secure OTP region (0x0C404000-0x0C40C000) */
    MRAM_IP_ADDRESS_AREA_TYPE_DATA = 3u,       /*!< Address is within Data MRAM region (0x0C800000-0x0C840000) */
    MRAM_IP_ADDRESS_AREA_TYPE_UTEST = 4u       /*!< Address is within UTEST MRAM region */
} MRam_Ip_AddressAreaType;

/*!
 * @brief          MRAM partition types
 * @details        Defines the different partitions available in the MRAM device
 *                 Each partition can have separate access control settings
 *                 Large partitions are organized in pairs with upper and lower banks
 *                 interleaved on 32-byte boundaries
 */
typedef enum
{
    MRAM_IP_PARTITION_NOT_EXISTS = 0u,     /*!< Partition does not exist */

    /* Large partitions - lower bank */
    MRAM_IP_PARTITION_LARGE_0_LOWER = 1u,  /*!< Large partition 0 - lower bank */
    MRAM_IP_PARTITION_LARGE_1_LOWER = 2u,  /*!< Large partition 1 - lower bank */
    MRAM_IP_PARTITION_LARGE_2_LOWER = 3u,  /*!< Large partition 2 - lower bank */
    MRAM_IP_PARTITION_LARGE_3_LOWER = 4u,  /*!< Large partition 3 - lower bank */
    MRAM_IP_PARTITION_LARGE_4_LOWER = 5u,  /*!< Large partition 4 - lower bank */
    MRAM_IP_PARTITION_LARGE_5_LOWER = 6u,  /*!< Large partition 5 - lower bank */
    MRAM_IP_PARTITION_LARGE_6_LOWER = 7u,  /*!< Large partition 6 - lower bank */
    MRAM_IP_PARTITION_LARGE_7_LOWER = 8u,  /*!< Large partition 7 - lower bank */

    /* Large partitions - upper bank */
    MRAM_IP_PARTITION_LARGE_0_UPPER = 9u,  /*!< Large partition 0 - upper bank */
    MRAM_IP_PARTITION_LARGE_1_UPPER = 10u, /*!< Large partition 1 - upper bank */
    MRAM_IP_PARTITION_LARGE_2_UPPER = 11u, /*!< Large partition 2 - upper bank */
    MRAM_IP_PARTITION_LARGE_3_UPPER = 12u, /*!< Large partition 3 - upper bank */
    MRAM_IP_PARTITION_LARGE_4_UPPER = 13u, /*!< Large partition 4 - upper bank */
    MRAM_IP_PARTITION_LARGE_5_UPPER = 14u, /*!< Large partition 5 - upper bank */
    MRAM_IP_PARTITION_LARGE_6_UPPER = 15u, /*!< Large partition 6 - upper bank */
    MRAM_IP_PARTITION_LARGE_7_UPPER = 16u, /*!< Large partition 7 - upper bank */

    /* Small partitions */
    MRAM_IP_PARTITION_SMALL_LOWER0 = 17u,  /*!< Small partition 0 - lower bank */
    MRAM_IP_PARTITION_SMALL_LOWER1 = 18u,  /*!< Small partition 1 - lower bank */
    MRAM_IP_PARTITION_SMALL_UPPER0 = 19u,  /*!< Small partition 0 - upper bank */
    MRAM_IP_PARTITION_SMALL_UPPER1 = 20u,  /*!< Small partition 1 - upper bank */

    /* Other partitions */
    MRAM_IP_PARTITION_NS_OTP = 21u,        /*!< Non-Secure OTP partition */
    MRAM_IP_PARTITION_UTEST = 22u          /*!< UTEST partition */
} MRam_Ip_PartitionType;

/*==================================================================================================
                                 STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/
/**
 * @brief State of a register set in MRAM controller
 */
typedef enum {
    REGSET_STATE_IDLE,       /* Register set is not being used */
    REGSET_STATE_ACTIVE,     /* Register set is actively performing a write operation */
    REGSET_STATE_COMPLETED,  /* Register set has completed its operation */
    REGSET_STATE_ERROR       /* Register set encountered an error */
} MRam_Ip_RegSetStateType;



/**
 * @brief MRAM Interrupt Configuration
 */
typedef struct
{
    boolean enablePostedWriteErrorNotification;       /**< @brief [PWENE] Enable posted write error notifications */
    boolean enableControlParityErrorNotification;     /**< @brief [CPENE] Enable control parity error notifications */
    boolean enableControlEccErrorNotification;        /**< @brief [CEENE] Enable control ECC error notifications */
    boolean enableDataEccErrorNotification;           /**< @brief [DEENE] Enable data ECC error notifications */
    boolean enableControllerErrorNotification;        /**< @brief [MCENE] Enable MRAMC error notifications */
    boolean enableMemoryErrorNotification;            /**< @brief [MENE] Enable MRAM error notifications */
    boolean enableMemoryEdcAfterEccErrorNotification; /**< @brief [MEEENE] Enable MRAM EDC after ECC error notifications */
    boolean enableUserErrorNotification;              /**< @brief [UENE] Enable user error notifications */
} MRam_Ip_InterruptConfigType;

/* Define the callback function type with instance ID parameter */
typedef void (*MRam_Ip_ErrorCallbackType)(MRam_Ip_InstanceIdType InstanceId, MRam_Ip_InterruptConfigType ErrorStatus, MRam_Ip_AddressType MemoryErrorAddress);

/**
 * @brief MRAM IP notification configuration
 * @details Structure containing all notification callbacks for the MRAM IP driver
 */

/*!
 * @brief       MRAM UTest Array Integrity Self-Check
 * @details     Structure that stores error information and address details after performing
 *              an integrity check on the MRAM array.
 */
typedef struct
{
    boolean FLAG_ERR;                   /*!< Error flag indicating if any error was detected during integrity check */
    boolean FLAG_TBC;                   /*!< Triple Bit Correction flag - set when a triple bit error was detected */
    boolean FLAG_DBC;                   /*!< Double Bit Correction flag - set when a double bit error was detected */
    boolean FLAG_SBC;                   /*!< Single Bit Correction flag - set when a single bit error was detected */
    MRam_Ip_AddressType RADDR;     /*!< Read Address where the error was detected */
    uint32 MISR[10u];               /*!< MISR signature values from UMISR0-UMISR8 and UMISR9 */
} MRam_Ip_ArrayIntegrityCheckType;

/*!
 * @brief       MRAMC Port Read ID Assignment Configuration Structure
 * @details     Configuration structure that controls read access permissions, buffering,
 *              and domain ID masking for MRAM controller ports.
 */
typedef struct
{
    boolean Enable;                /*!< When true, enables this port's read ID assignment functionality */
    uint8   BufferEntries;         /*!< Number of buffer entries allocated to this port (affects performance) */
    uint16  MaskDomainID;          /*!< Bit mask specifying which domain IDs are permitted to access this port */
} MRam_Ip_PortReadIDAssignmentConfigType;

/*!
 * @brief       MRAMC Port Configuration Structure
 */
typedef struct
{
    MRam_Ip_PortIdType   id;        /*!< Port identifier number */
    boolean IB;        /*!< Instruction Buffer enable - When set, enables instruction buffering */
    boolean RCBFEN;    /*!< Read Command Buffer FIFO Enable - Enables command buffer FIFO for read operations */
    boolean RDBFEN;    /*!< Read Data Buffer FIFO Enable - Enables data buffer FIFO for read operations */
    boolean RCPFEN;    /*!< Read Command Prefetch FIFO Enable - Enables command prefetch for read operations */
    boolean RDPFEN;    /*!< Read Data Prefetch FIFO Enable - Enables data prefetch for read operations */
    boolean WRBFEN;    /*!< Write Buffer FIFO Enable - Enables buffer FIFO for write operations */
    MRam_Ip_PortReadIDAssignmentConfigType PortReadIDAssignmentWord0; /*!< Port read ID assignment word 0 configuration */
    MRam_Ip_PortReadIDAssignmentConfigType PortReadIDAssignmentWord1; /*!< Port read ID assignment word 1 configuration */
} MRam_Ip_PortConfigType;

/*!
 * @brief       MRAMC Large partition Configuration Structure
 * @details     Configuration structure for the 8 large memory partitions, controlling
 *              lock status and protection level for each partition
 */
typedef struct
{
    boolean LCK0;    /*!< Lock status for large partition 0: TRUE=locked, FALSE=unlocked */
    uint8   PLCK0;   /*!< Protection level for large partition 0 (bits 1-0):
                          00b/01b = LPLOCK bit can be set/cleared by any initiator
                          10b = LPLOCK bit can only be set/cleared by initiator with matching domain ID
                          11b = LPLOCK bit is permanently locked */
    boolean LCK1;    /*!< Lock status for large partition 1: TRUE=locked, FALSE=unlocked */
    uint8   PLCK1;   /*!< Protection level for large partition 1 (bits 3-2), values as PLCK0 */
    boolean LCK2;    /*!< Lock status for large partition 2: TRUE=locked, FALSE=unlocked */
    uint8   PLCK2;   /*!< Protection level for large partition 2 (bits 5-4), values as PLCK0 */
    boolean LCK3;    /*!< Lock status for large partition 3: TRUE=locked, FALSE=unlocked */
    uint8   PLCK3;   /*!< Protection level for large partition 3 (bits 7-6), values as PLCK0 */
    boolean LCK4;    /*!< Lock status for large partition 4: TRUE=locked, FALSE=unlocked */
    uint8   PLCK4;   /*!< Protection level for large partition 4 (bits 9-8), values as PLCK0 */
    boolean LCK5;    /*!< Lock status for large partition 5: TRUE=locked, FALSE=unlocked */
    uint8   PLCK5;   /*!< Protection level for large partition 5 (bits 11-10), values as PLCK0 */
    boolean LCK6;    /*!< Lock status for large partition 6: TRUE=locked, FALSE=unlocked */
    uint8   PLCK6;   /*!< Protection level for large partition 6 (bits 13-12), values as PLCK0 */
    boolean LCK7;    /*!< Lock status for large partition 7: TRUE=locked, FALSE=unlocked */
    uint8   PLCK7;   /*!< Protection level for large partition 7 (bits 15-14), values as PLCK0 */
} MRam_Ip_LargePartitionConfigType;

/*!
 * @brief       MRAMC Small partition Configuration Structure
 * @details     Configuration structure for the small memory partition, controlling
 *              lock status and protection level
 */
typedef struct
{
    boolean LCK;     /*!< Lock status for small partition: TRUE=locked, FALSE=unlocked */
    uint8   PLCK;    /*!< Protection level for small partition:
                          00b/01b = LPLOCK bit can be set/cleared by any initiator
                          10b = LPLOCK bit can only be set/cleared by initiator with matching domain ID
                          11b = LPLOCK bit is permanently locked */
} MRam_Ip_SmallPartitionConfigType;

/*!
 * @brief       MRAMC OTP partition Configuration Structure
 * @details     Configuration structure for the One-Time Programmable (OTP) memory partition,
 *              controlling lock status and protection level
 */
typedef struct
{
    boolean LCK;     /*!< Lock status for OTP partition: TRUE=locked, FALSE=unlocked */
    uint8   PLCK;    /*!< Protection level for OTP partition:
                          00b/01b = LPLOCK bit can be set/cleared by any initiator
                          10b = LPLOCK bit can only be set/cleared by initiator with matching domain ID
                          11b = LPLOCK bit is permanently locked */
} MRam_Ip_LargePartitionOTPConfigType;

/*!
 * @brief       MRAMC Watch Dog Tune Configuration Structure
 * @details     Configuration structure for the MRAM watchdog timer, which helps
 *              prevent deadlocks during MRAM operations
 */
typedef struct
{
    MRam_Ip_WatchdogTuneType watchdogTimer;        /*!< Watchdog timer setting to use (timeout period) */
    boolean                  watchdogTimerEnabled; /*!< Enables/disables the watchdog timer: TRUE=enabled, FALSE=disabled */
} MRam_Ip_WatchdogConfigType;

/*!
 * @brief       MRAMC Configuration Structure
 * @details     This structure defines the configuration settings for the MRAM Controller (MRAMC),
 *              including port setup, partition locking, and watchdog configuration.
 */
typedef struct
{
    const MRam_Ip_PortConfigType        *MRamCPortConfig;             /*!< Configuration for MRAM controller ports including buffer settings and access permissions */
    const uint8                         MRamCPortConfigCount;         /*!< Number of port configurations for the MRAM controller */
    MRam_Ip_LargePartitionConfigType    MRamCLargePartitionLockConfig; /*!< Lock configuration for the 8 large memory partitions */
    MRam_Ip_SmallPartitionConfigType    MRamCSmallPartitionLockConfig; /*!< Lock configuration for the small memory partition */
    MRam_Ip_LargePartitionOTPConfigType MRamCLargePartitionOTPLockConfig; /*!< Lock configuration for the Non-Secure One-Time Programmable memory partition */
    MRam_Ip_WatchdogConfigType          MRamCWatchdogConfig;          /*!< Watchdog timer configuration to prevent deadlocks during MRAM operations */
    const boolean                       MRamCInterruptsEnabled;       /*!< Enable/disable MRAMC-related interrupts */
    const boolean                       MRamDataErrorSuppress;        /*!< Suppress data error reporting: 0=enabled, non-zero=suppressed */
} MRam_Ip_ControllerConfigType;

/*!
 * @brief       MRAM Memory Configuration Structure
 * @details     This structure defines the operational settings for the MRAM memory itself,
 *              including verification, protection, and timing parameters.
 */
typedef struct
{
    boolean CVE;     /*!< Correction Visibility Enable: Enables certain correction-reporting features in Module Configuration Status (MCRS) and Read Address Logging (RADR). */
    boolean WPL;     /*!< Write With Power Leveling: Enables a style of writing to the MRAM that minimizes peak power and that may require more time. */
    uint8 RWSC;      /*!< Read Wait State Control: Number of wait states for read operations, affects timing and performance */
} MRam_Ip_MemoryConfigType;

/*!
 * @brief       MRAM Configuration Structure
 * @details     Top-level configuration structure that combines notification settings,
 *              controller configuration, and memory configuration for complete MRAM setup.
 *              This structure is passed to MRam_Ip_Init() to initialize the MRAM driver.
 * @implements  MRam_Ip_ConfigType_struct
 */
typedef struct
{
    MRam_Ip_ControllerConfigType          MRamControllerConfig;       /*!< Configuration for the MRAM controller including ports and partition locks */
    MRam_Ip_MemoryConfigType              MRamMemoryConfig;           /*!< Configuration for the MRAM memory operations and timing */
    /*!< Mapping table: ECUC partition index -> partition specific async ERRSTAT0 mailbox (one entry per MRAMC instance) */
    volatile uint32 * const *             AsyncErrstat0Snapshot_PartitionMap;
    uint32 * const *                      OtaNumFixed_PartitionMap;   /*!< Mapping table: ECUC partition index -> partition specific OTA configuration (OTA_NUM_FIXED_LPART) latched by MRam_Ip_Init */
} MRam_Ip_ConfigType;


/*! @brief Mutable cursor threaded through the AXI HEAD/BODY/TAIL write/erase phases
 *         (MRam_Ip_AxiOp_WriteRange). Bundled so the phase takes one in/out pointer
 *         instead of four separate address-of locals. Mutated in place. */
typedef struct
{
    MRam_Ip_StatusType  Status;          /*!< Running status; SUCCESS gates each phase, set to the error code on a port-buffer flush failure. */
    MRam_Ip_AddressType MRamAddress;     /*!< Advancing destination write cursor in MRAM; moves forward as bytes are consumed. */
    MRam_Ip_LengthType  RemainingBytes;  /*!< Number of bytes still to write/erase; counts down to 0. */
    MRam_Ip_LengthType  currentIndex;    /*!< Index of the next byte to read from the source buffer (write only). */
} MRam_Ip_AxiCursor;

/*! @brief Shared register-bus write/erase state, passed by pointer to each extracted phase
 *         (CleanSlate / OtpSetup / PageLoop / ExecutePage / Teardown). Mutated in place. */
typedef struct
{
    const uint8 *           SourceAddressPtr;  /*!< Source data buffer for a write; NULL_PTR for an erase. */
    MRam_Ip_InstanceIdType  InstanceId;        /*!< MRAM controller instance index. */
    MRam_Ip_AddressAreaType MemoryType;        /*!< MRAM region of the destination (CODE / DATA / NS_OTP / UTEST / ...). */
    boolean                 IsOtpMemory;       /*!< TRUE when the destination is OTP (single-page, watchdog-gated path). */
    boolean                 IsWriteOperation;  /*!< TRUE for a write, FALSE for an erase. */
    MRam_Ip_StatusType      Status;            /*!< Running operation status; SUCCESS gates every phase. */
    MRam_Ip_AddressType     CurrentAddress;    /*!< Advancing destination address of the page currently being programmed. */
    MRam_Ip_LengthType      RemainingBytes;    /*!< Number of bytes still to program; counts down to 0. */
    MRam_Ip_LengthType      sourceOffset;      /*!< Index of the next source byte to program (write only). */
    MRam_Ip_RegSetStateType RegSetActive[MRAM_IP_REGSET_COUNT]; /*!< Per-register-set state (IDLE / ACTIVE / COMPLETED) for each of the two HW write register sets. */
    boolean                 OtpCommitAcked;    /*!< TRUE once F16ASM has acknowledged the OTP commit request (OTP path only). */
    MRam_Ip_LengthType      bytesWritten;      /*!< Running count of bytes actually programmed, used to invalidate exactly the written cache range. Only maintained/used when MRAM_IP_CACHE_INVALIDATION == STD_ON. */
} MRam_Ip_WriteOpCtx;

/*! @brief Phase-3 OTP-write initialization state (MRam_Ip_WriteOp_OtpSetup). Mutated in place. */
typedef struct
{
    MRam_Ip_InstanceIdType InstanceId;          /*!< MRAM controller instance index. */
    boolean                IsOtpMemory;         /*!< TRUE when the destination is OTP (gates the whole phase). */
    boolean                IsWriteOperation;    /*!< TRUE for a write (an OTP erase is rejected during validation). */
    MRam_Ip_StatusType     Status;              /*!< Running status; SUCCESS gates each setup step. */
    boolean                OtpWriteAreaEntered; /*!< TRUE once the coarse cross-core OTP-write exclusive area was entered; balances the Phase-6b exit. */
    uint32                 SavedWwdog;          /*!< WWDOG register value snapshot saved before disabling the write watchdog, restored in Phase 6b. */
    boolean                WwdogWasModified;    /*!< TRUE if this phase actually disabled WWDOG (gates the Phase-6b restore). */
} MRam_Ip_OtpSetupCtx;

/*! @brief Phase-5/6 completion, lock/WWDOG restore, async-error promotion and cache-invalidate
 *         state (MRam_Ip_WriteOp_Teardown). Mutated in place. */
typedef struct
{
    MRam_Ip_InstanceIdType  InstanceId;          /*!< MRAM controller instance index. */
    MRam_Ip_AddressType     DestAddress;         /*!< Operation destination base address (used for lock restore and cache invalidate). */
    MRam_Ip_LengthType      SizeInBytes;         /*!< Operation size in bytes (lock restore range). */
    boolean                 IsOtpMemory;         /*!< TRUE when the destination is OTP. */
    boolean                 interruptsEnabled;   /*!< TRUE when the error ISR owns ERRSTAT0; drives async-mailbox error promotion at completion. */
    boolean                 LocksCleared;        /*!< TRUE if Phase 2 unlocked partitions in range; gates the re-lock. Only meaningful when MRAM_IP_PARTITION_SET_LOCK_API == STD_OFF (driver auto-manages locks). */
    boolean                 WwdogWasModified;    /*!< TRUE if Phase 3 disabled WWDOG; gates the restore below. */
    uint32                  SavedWwdog;          /*!< WWDOG register value to restore (when WwdogWasModified is TRUE). */
    boolean                 OtpWriteAreaEntered; /*!< TRUE if the OTP-write exclusive area was entered; gates its exit. */
    MRam_Ip_LengthType      bytesWritten;        /*!< Number of bytes actually programmed; cache-invalidate range. Only meaningful when MRAM_IP_CACHE_INVALIDATION == STD_ON. */
    MRam_Ip_StatusType      Status;              /*!< Final operation status returned to the caller. */
    MRam_Ip_RegSetStateType RegSetActive[MRAM_IP_REGSET_COUNT]; /*!< Per-register-set state at completion (one entry per HW write register set). */
} MRam_Ip_TeardownCtx;


#ifdef __cplusplus
}
#endif

/** @} */

#endif /* MRAM_IP_TYPES_H */
