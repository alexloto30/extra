/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : MRAM
*   Dependencies         : None
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
*   Copyright 2024 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
 * @file       Mem_43_MRAM.c
 *
 * @addtogroup MEM_43_MRAM
 * @implements Mem_43_MRAM.c_Artifact
 *
 * @{
 */

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
 *                                        INCLUDE FILES
 * 1) system and project includes
 * 2) needed interfaces from external units
 * 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Mem_43_MRAM.h"
#include "Mem_43_MRAM_Ipw.h"

#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
    #include "Det.h"
#endif
#include "SchM_Mem_43_MRAM.h"

#if ((MEM_43_MRAM_MULTICORE_ENABLED == STD_ON) || (MEM_43_MRAM_MULTIPARTITION_ENABLED == STD_ON))
#include "Mcal.h"
#endif
/*==================================================================================================
 *                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define MEM_43_MRAM_VENDOR_ID_C                      43
#define MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_C       4
#define MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_C       9
#define MEM_43_MRAM_AR_RELEASE_REVISION_VERSION_C    0
#define MEM_43_MRAM_SW_MAJOR_VERSION_C               1
#define MEM_43_MRAM_SW_MINOR_VERSION_C               0
#define MEM_43_MRAM_SW_PATCH_VERSION_C               0

/*==================================================================================================
 *                                     FILE VERSION CHECKS
==================================================================================================*/
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK

    #if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
    /* Check if current file and Det header file are of the same Autosar version */
    #if ((MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_C != DET_AR_RELEASE_MAJOR_VERSION) || \
         (MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_C != DET_AR_RELEASE_MINOR_VERSION) \
        )
        #error "AutoSar Version Numbers of Mem_43_MRAM.c and Det.h are different"
    #endif
    #endif /* MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON */

    /* Check if current file and SchM_Fls header file are of the same Autosar version */
    #if ((MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_C != SCHM_MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION) || \
         (MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_C != SCHM_MEM_43_MRAM_AR_RELEASE_MINOR_VERSION) \
        )
        #error "AutoSar Version Numbers of Mem_43_MRAM.c and SchM_Mem_43_MRAM.h are different"
    #endif

    #if (MEM_43_MRAM_MULTICORE_ENABLED == STD_ON)
    /* Check if current file  and Mcal.h are of the same version */
        #if ((MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_C != MCAL_AR_RELEASE_MAJOR_VERSION) || \
             (MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_C != MCAL_AR_RELEASE_MINOR_VERSION)    \
            )
            #error "AutoSar Version Numbers of Mem_43_MRAM.c and Mcal.h are different"
        #endif
    #endif
#endif

/* Check if current file and Mem_43_MRAM.h header file are of the same vendor */
#if (MEM_43_MRAM_VENDOR_ID_C != MEM_43_MRAM_VENDOR_ID)
    #error "Mem_43_MRAM.c and Mem_43_MRAM.h have different vendor ids"
#endif
/* Check if current file and Mem_43_MRAM.h header file are of the same Autosar version */
#if ((MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_C    != MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION) || \
     (MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_C    != MEM_43_MRAM_AR_RELEASE_MINOR_VERSION) || \
     (MEM_43_MRAM_AR_RELEASE_REVISION_VERSION_C != MEM_43_MRAM_AR_RELEASE_REVISION_VERSION) \
    )
    #error "AutoSar Version Numbers of Mem_43_MRAM.c and Mem_43_MRAM.h are different"
#endif
/* Check if current file and Mem_43_MRAM.h header file are of the same Software version */
#if ((MEM_43_MRAM_SW_MAJOR_VERSION_C != MEM_43_MRAM_SW_MAJOR_VERSION) || \
     (MEM_43_MRAM_SW_MINOR_VERSION_C != MEM_43_MRAM_SW_MINOR_VERSION) || \
     (MEM_43_MRAM_SW_PATCH_VERSION_C != MEM_43_MRAM_SW_PATCH_VERSION) \
    )
    #error "Software Version Numbers of Mem_43_MRAM.c and Mem_43_MRAM.h are different"
#endif

/* Check if current file and Mem_43_MRAM_Ipw.h header file are of the same vendor */
#if (MEM_43_MRAM_VENDOR_ID_C != MEM_43_MRAM_IPW_VENDOR_ID_H)
    #error "Mem_43_MRAM.c and Mem_43_MRAM_Ipw.h have different vendor ids"
#endif
/* Check if current file and Mem_43_MRAM_Ipw.h header file are of the same Autosar version */
#if ((MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_C    != MEM_43_MRAM_IPW_AR_RELEASE_MAJOR_VERSION_H) || \
     (MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_C    != MEM_43_MRAM_IPW_AR_RELEASE_MINOR_VERSION_H) || \
     (MEM_43_MRAM_AR_RELEASE_REVISION_VERSION_C != MEM_43_MRAM_IPW_AR_RELEASE_REVISION_VERSION_H) \
    )
    #error "AutoSar Version Numbers of Mem_43_MRAM.c and Mem_43_MRAM_Ipw.h are different"
#endif
/* Check if current file and Mem_43_MRAM_Ipw.h header file are of the same Software version */
#if ((MEM_43_MRAM_SW_MAJOR_VERSION_C != MEM_43_MRAM_IPW_SW_MAJOR_VERSION_H) || \
     (MEM_43_MRAM_SW_MINOR_VERSION_C != MEM_43_MRAM_IPW_SW_MINOR_VERSION_H) || \
     (MEM_43_MRAM_SW_PATCH_VERSION_C != MEM_43_MRAM_IPW_SW_PATCH_VERSION_H) \
    )
    #error "Software Version Numbers of Mem_43_MRAM.c and Mem_43_MRAM_Ipw.h are different"
#endif

/*==================================================================================================
 *                                      GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
 *                           LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
                                        LOCAL MACROS
==================================================================================================*/

/*! Specifies invalid mem instance index (valid ones will be in range 0 to MEM_43_MRAM_INSTANCE_COUNT-1) */
#define MEM_43_MRAM_MEM_INSTANCE_INDEX_INVALID              MEM_43_MRAM_INSTANCE_COUNT

#if ((MEM_43_MRAM_HW_COMPARE_SERVICE != STD_ON) && (MEM_43_MRAM_HW_UTEST_SERVICE != STD_ON))
#define MEM_43_MRAM_HW_SERVICE STD_OFF
#else
#define MEM_43_MRAM_HW_SERVICE STD_ON
#endif

/*==================================================================================================
                                       LOCAL VARIABLES
==================================================================================================*/
/* The accumulated CRC remainder storage is generated in Mem_43_MRAM_Cfg.c: per ECUC
   partition when multi partition support is enabled, a single shared variable otherwise. Both
   cases are reached through the partition mapping table. */

/*==================================================================================================
                                       LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
                                       LOCAL FUNCTIONS (internal usage)
==================================================================================================*/

#define MEM_43_MRAM_START_SEC_CODE
#include "Mem_43_MRAM_MemMap.h"

#if (MEM_43_MRAM_CHECK_CFG_CRC == STD_ON)
static void Mem_43_MRAM_AccumulateCRC(uint32 InputData);
static uint32 Mem_43_MRAM_UpdateCRCreminder(Mem_43_MRAM_CrcDataSizeType DataSize, uint32 CRCremainder);
static uint32 Mem_43_MRAM_GetAccCRCremainder(void);
static void Mem_43_MRAM_SetAccCRCremainder(uint32 AccCRCremainder);

static Mem_43_MRAM_CrcType Mem_43_MRAM_CalcCfgCRC(void);
#endif /* MEM_43_MRAM_CHECK_CFG_CRC */

/**
 * @brief    Retrieve the partition specific JobRuntimeInfo array
 */
static Mem_43_MRAM_JobRuntimeInfoType * Mem_43_MRAM_GetJobRuntimeInfo(void);

/**
 * @brief    Report a development error
 */
static void Mem_43_MRAM_ReportDevError(Mem_43_MRAM_InstanceIdType InstanceId,
                                        uint32 ApiId,
                                        uint32 ErrorId
                                       )
{
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
    /* Raise the development error via Det function */
    (void)Det_ReportError(MEM_43_MRAM_MODULE_ID, (uint8)InstanceId, (uint8)ApiId, (uint8)ErrorId);
#endif

    (void)InstanceId;
    (void)ApiId;
    (void)ErrorId;
}

/**
 * @brief        Retrieve the JobRuntimeInfo array for the current context.
 *
 * @details      When multi-partition support is enabled the JobRuntimeInfo array of the
 *               calling ECUC partition is returned using the partition mapping table,
 *               ensuring freedom from interference between partitions.
 *               Otherwise the shared static array is returned.
 *
 * @param[in]    void
 *
 * @return       Mem_43_MRAM_JobRuntimeInfoType *   Pointer to the JobRuntimeInfo array
 *                                                              (NULL_PTR if the calling partition is not mapped)
 *
 * @pre          None.
 */
static Mem_43_MRAM_JobRuntimeInfoType * Mem_43_MRAM_GetJobRuntimeInfo(void)
{
    Mem_43_MRAM_JobRuntimeInfoType * JobRuntimeInfo;

#if (MEM_43_MRAM_MULTIPARTITION_ENABLED == STD_ON)
    uint8 UserId = OsIf_GetUserId();

    JobRuntimeInfo = ((*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->JobRuntimeInfo_PartitionMap[UserId]);
#else
    JobRuntimeInfo = ((*Mem_43_MRAM_pConfigPtr_PartitionMap[0U])->JobRuntimeInfo_PartitionMap[0U]);
#endif

    return JobRuntimeInfo;
}

#if (MEM_43_MRAM_CHECK_CFG_CRC == STD_ON)
/**
 * @brief        Retrieve the accumulated CRC remainder for the current context.
 *
 * @details      Uses a partition specific storage location when multi-partition support
 *               is enabled, or the shared static variable otherwise.
 *
 * @param[in]    void
 *
 * @return       uint32   The accumulated CRC remainder
 *
 * @pre          None.
 */
static uint32 Mem_43_MRAM_GetAccCRCremainder(void)
{
    uint32 AccCRCremainder;

#if (MEM_43_MRAM_MULTIPARTITION_ENABLED == STD_ON)
    uint8 UserId = OsIf_GetUserId();

    AccCRCremainder = *((*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->AccCRCremainder_PartitionMap[UserId]);
#else
    AccCRCremainder = *((*Mem_43_MRAM_pConfigPtr_PartitionMap[0U])->AccCRCremainder_PartitionMap[0U]);
#endif

    return AccCRCremainder;
}

/**
 * @brief        Store the accumulated CRC remainder for the current context.
 *
 * @details      Uses a partition specific storage location when multi-partition support
 *               is enabled, or the shared static variable otherwise.
 *
 * @param[in]    AccCRCremainder   The accumulated CRC remainder to store
 *
 * @return       void
 *
 * @pre          None.
 */
static void Mem_43_MRAM_SetAccCRCremainder(uint32 AccCRCremainder)
{
#if (MEM_43_MRAM_MULTIPARTITION_ENABLED == STD_ON)
    uint8 UserId = OsIf_GetUserId();

    *((*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->AccCRCremainder_PartitionMap[UserId]) = AccCRCremainder;
#else
    *((*Mem_43_MRAM_pConfigPtr_PartitionMap[0U])->AccCRCremainder_PartitionMap[0U]) = AccCRCremainder;
#endif
}
#endif /* MEM_43_MRAM_CHECK_CFG_CRC */

#if (MEM_43_MRAM_CHECK_CFG_CRC == STD_ON)
/**
 * @brief        Function to handle cumulative CRC calculation over input data.
 *
 * @details      Handles cumulative CRC calculation over input 32-bit data, .
 *
 * @param[in]    inputData ... data to be CRC-ed
 *
 * @return       void
 * @retval       None.
 *
 * @pre          Mem_43_MRAM_SetAccCRCremainder(0U) was executed before the first call of
 *               Mem_43_MRAM_AccumulateCRC().
 *
 *
 */
static void Mem_43_MRAM_AccumulateCRC(uint32 InputData)
{
    uint32 CRCremainder;

    CRCremainder = Mem_43_MRAM_GetAccCRCremainder();

    if (0xFFFFU < InputData)
    {
        /* preparation for accumulation of higher 16 bits of the InputData */
        CRCremainder = (CRCremainder << 16U) | (InputData >> 16U);
        /* make 16-bit accumulated result (in lower 16-bits of CRCremainder) */
        CRCremainder = Mem_43_MRAM_UpdateCRCreminder(MEM_43_MRAM_CRC_16_BITS, CRCremainder);
    }

    if (0xFFU < InputData)
    {
        /* preparation for accumulation of lower 16 bits of the InputData */
        CRCremainder = (CRCremainder << 16U) | (InputData & 0x0000FFFFU);
        /* make 16-bit accumulated result (in lower 16-bits of CRCremainder) */
        CRCremainder = Mem_43_MRAM_UpdateCRCreminder(MEM_43_MRAM_CRC_16_BITS, CRCremainder);
    }
    else
    {
        /* optimization: only 8 LSB bits are processed */
        /* preparation for accumulation of lower 8 bits of the InputData */
        CRCremainder = (CRCremainder << 8U) | InputData;
        /* make 16-bit accumulated result (in lower 16-bits of CRCremainder) */
        CRCremainder = Mem_43_MRAM_UpdateCRCreminder(MEM_43_MRAM_CRC_8_BITS, CRCremainder);
    }

    Mem_43_MRAM_SetAccCRCremainder(CRCremainder);
}


/**
 * @brief        Function to perform CRC calculation over input 32-bit data.
 *
 * @details      Process 32-bit data to 16-bit reminder.
 *
 * @param[in]    accDataPtr ... ptr to data to be processed
 *
 * @return       void
 * @retval       None.
 *
 * @pre          Can be called only from Mem_43_MRAM_AccumulateCRC().
 *
 */

static uint32 Mem_43_MRAM_UpdateCRCreminder(Mem_43_MRAM_CrcDataSizeType DataSize, uint32 CRCremainder)
{
    uint32 CrcPolynomSft;
    uint32 LeadingOne;
    uint32 AccDataLoc;
    uint32 LeadingOneInitial;

    switch (DataSize)
    {
        case MEM_43_MRAM_CRC_8_BITS:
            CrcPolynomSft = 0x11021U << 7U; /* shifted CRC-16-CCITT (x.25 protocol)*/
            LeadingOneInitial = 0x10000U << 7U;
            break;

        case MEM_43_MRAM_CRC_16_BITS:
        default:
            CrcPolynomSft = 0x11021U << 15U; /* shifted CRC-16-CCITT (x.25 protocol)*/
            LeadingOneInitial = 0x10000U << 15U;
            break;
    }

    /* copy input remainder to auto (computation over static may be slow) */
    AccDataLoc = CRCremainder;

    /* CRC computation */
    for (LeadingOne = LeadingOneInitial; LeadingOne >= 0x00010000U; LeadingOne >>= 1U)
    {
        if (0U != (AccDataLoc & LeadingOne))
        {
            AccDataLoc ^= CrcPolynomSft;
        }
        CrcPolynomSft >>= 1U;
    }

    /* return the updated remainder */
    return AccDataLoc;
}

/**
 * @brief        Calculates CRC over configuration.
 *
 * @details      Calculates CRC over selected items of configuration set
 *               pointed to by ConfigPtr.
 *
 * @param[in]    ConfigPtr        Pointer to flash driver configuration set.
 *
 * @return       uint32
 * @retval       0 .. 0xFFFF (16-bit CRC using CRC-16-CCITT polynomial)
 *
 * @pre          Mem_43_MRAM_pConfigPtr must not be properly initialized.
 *
 */
static Mem_43_MRAM_CrcType Mem_43_MRAM_CalcCfgCRC(void)
{

    uint32 MemInstanceIndex;
    uint32 SectorBatchIndex;
    uint32 AccCRCremainder;
    uint8 UserId;
#if (MEM_43_MRAM_MULTIPARTITION_ENABLED == STD_ON)
    UserId = OsIf_GetUserId();
#else
    UserId = 0U;
#endif

    /* Reset the accumulated CRC value */
    Mem_43_MRAM_SetAccCRCremainder(0U);

    /* Iterate through the MemInstances params */
    for (MemInstanceIndex = 0U; MemInstanceIndex < MEM_43_MRAM_INSTANCE_COUNT; MemInstanceIndex++)
    {
        /* CRC - Accumulate InstanceId */
        Mem_43_MRAM_AccumulateCRC((uint32)((*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->MemInstances[MemInstanceIndex].InstanceId));
        /* CRC - Accumulate SectorBatchCount */
        Mem_43_MRAM_AccumulateCRC((uint32)((*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->MemInstances[MemInstanceIndex].SectorBatchCount));

        /* CRC - Accumulate SectorBatches */
        for (SectorBatchIndex =0u; SectorBatchIndex < (*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->MemInstances[MemInstanceIndex].SectorBatchCount; SectorBatchIndex++)
        {
            /* CRC - Accumulate StartAddress */
            Mem_43_MRAM_AccumulateCRC((uint32) (*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->MemInstances[MemInstanceIndex].SectorBatches[SectorBatchIndex].StartAddress);
            /* CRC - Accumulate EndAddress */
            Mem_43_MRAM_AccumulateCRC((uint32) (*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->MemInstances[MemInstanceIndex].SectorBatches[SectorBatchIndex].EndAddress);
            /* CRC - Accumulate SectorSize */
            Mem_43_MRAM_AccumulateCRC((uint32) (*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->MemInstances[MemInstanceIndex].SectorBatches[SectorBatchIndex].SectorSize);
            /* CRC - Accumulate ReadPageSize */
            Mem_43_MRAM_AccumulateCRC((uint32) (*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->MemInstances[MemInstanceIndex].SectorBatches[SectorBatchIndex].ReadPageSize);
            /* CRC - Accumulate WritePageSize */
            Mem_43_MRAM_AccumulateCRC((uint32) (*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->MemInstances[MemInstanceIndex].SectorBatches[SectorBatchIndex].WritePageSize);
            /* CRC - Accumulate EraseBurstSize */
            Mem_43_MRAM_AccumulateCRC((uint32) (*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->MemInstances[MemInstanceIndex].SectorBatches[SectorBatchIndex].EraseBurstSize);
            /* CRC - Accumulate ReadBurstSize */
            Mem_43_MRAM_AccumulateCRC((uint32) (*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->MemInstances[MemInstanceIndex].SectorBatches[SectorBatchIndex].ReadBurstSize);
            /* CRC - Accumulate WriteBurstSize */
            Mem_43_MRAM_AccumulateCRC((uint32) (*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->MemInstances[MemInstanceIndex].SectorBatches[SectorBatchIndex].WriteBurstSize);
        }
            /* CRC - Accumulate MemUnitIndex */
        Mem_43_MRAM_AccumulateCRC((uint32) (*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->MemInstances[MemInstanceIndex].MemUnitIndex);
    }

    /* Finalizes accumulated CRC computation and returns the final CRC checksum. */
    /* Add the final 0x0000 to the remainder */
    AccCRCremainder = Mem_43_MRAM_GetAccCRCremainder();
    AccCRCremainder = (AccCRCremainder << 16U);
    Mem_43_MRAM_SetAccCRCremainder(AccCRCremainder);
    /* make the final 16-bit CRC */
    AccCRCremainder = Mem_43_MRAM_UpdateCRCreminder(MEM_43_MRAM_CRC_16_BITS, AccCRCremainder);

    return (Mem_43_MRAM_CrcType)AccCRCremainder;
}
#endif /* #if (MEM_43_MRAM_CHECK_CFG_CRC == STD_ON) */


/**
 * @brief   Avoid CWE violation
 *
 */
static void Mem_43_MRAM_IncreasePtr(const Mem_43_MRAM_SectorBatchType **sectorPtr)
{
    (*sectorPtr)++;
}

/**
 * @brief    Search the list of Mem instances and returns index of instance with matching InstanceId
 */
static uint32 Mem_43_MRAM_GetInstanceIndex(const Mem_43_MRAM_InstanceIdType InstanceId)
{
    uint32 InstanceIndex = 0U;
    uint8 UserId;
#if (MEM_43_MRAM_MULTIPARTITION_ENABLED == STD_ON)
    UserId = OsIf_GetUserId();
#else
    UserId = 0U;
#endif

    /* Loop through all configured memory instances */
    for (InstanceIndex = 0U; InstanceIndex < MEM_43_MRAM_INSTANCE_COUNT; InstanceIndex++)
    {
        if (InstanceId == (*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->MemInstances[InstanceIndex].InstanceId)
        {
            /* InstanceId is matched, exit loop */
            break;
        }
    }

    /* The returned value will be INVALID if InstanceId is not matched with any InstanceIndex */
    return InstanceIndex;
}


/**
 * @brief    Search for the sector batch that contains the provided address
 */
static const Mem_43_MRAM_SectorBatchType *Mem_43_MRAM_GetSectorBatch(uint32 InstanceIndex,
                                                                       Mem_43_MRAM_AddressType Address
                                                                      )
{
    uint8 UserId;
    const Mem_43_MRAM_MemInstanceType *MemInstance;
    const Mem_43_MRAM_SectorBatchType *SectorBatch;
    Mem_43_MRAM_AddressType           StartAddressOfSector = 0U;
    Mem_43_MRAM_AddressType           EndAddressOfSector   = 0U;
    uint32 Index = 0U;

#if (MEM_43_MRAM_MULTIPARTITION_ENABLED == STD_ON)
    UserId = OsIf_GetUserId();
#else
    UserId = 0U;
#endif
    MemInstance = &((*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->MemInstances[InstanceIndex]);
    SectorBatch = MemInstance->SectorBatches;

    /* Loop through all configured sector batches of this memory instance */
    while (Index < MemInstance->SectorBatchCount)
    {
        StartAddressOfSector = (Mem_43_MRAM_AddressType)(SectorBatch->StartAddress);
        EndAddressOfSector   = (Mem_43_MRAM_AddressType)(SectorBatch->EndAddress);
        if ((StartAddressOfSector <= Address) && (Address <= EndAddressOfSector))
        {
            /* The address falls within this sector batch */
            break;
        }

        /* Move to the next sector batch */
        Mem_43_MRAM_IncreasePtr(&SectorBatch);
        Index++;
    }

    /* The returned value will be NULL_PTR if Address does not fall within any sector batch */
    if (Index >= MemInstance->SectorBatchCount)
    {
        SectorBatch = NULL_PTR;
    }

    return SectorBatch;
}

/**
 * @brief    Checks if the provided address and length are valid
 */
static uint32 Mem_43_MRAM_ValidateAddressAndLength(Mem_43_MRAM_JobRuntimeInfoType *JobRequest)
{
    uint32 ErrorId;

    JobRequest->SectorBatch = Mem_43_MRAM_GetSectorBatch(JobRequest->InstanceIndex, JobRequest->Address);
    if (NULL_PTR == JobRequest->SectorBatch)
    {
        /* Could not find the sector batch, the address is invalid */
        ErrorId = MEM_43_MRAM_E_PARAM_ADDRESS;
    }
    else if ((0U == JobRequest->Length) ||
             ((JobRequest->Address + JobRequest->Length - 1U) > JobRequest->SectorBatch->EndAddress)
            )
    {
        /* The length is invalid */
        ErrorId = MEM_43_MRAM_E_PARAM_LENGTH;
    }
    else
    {
        /* Both address and length are valid */
        ErrorId = MEM_43_MRAM_E_OK;
    }

    return ErrorId;
}

/**
 * @brief    Checks if provided InstanceId is consistent with the configuration
 */
static uint32 Mem_43_MRAM_ValidateInstanceId(Mem_43_MRAM_JobRuntimeInfoType *JobRequest)
{
    uint32 ErrorId = MEM_43_MRAM_E_OK;

    /* Get the mem index number according to the mem instance id */
    JobRequest->InstanceIndex = Mem_43_MRAM_GetInstanceIndex(JobRequest->InstanceId);

#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
    /* Only check if development error detection is enabled */
    if (MEM_43_MRAM_MEM_INSTANCE_INDEX_INVALID == JobRequest->InstanceIndex)
    {
        /* The provided InstanceId is inconsistent with the configuration */
        ErrorId = MEM_43_MRAM_E_PARAM_INSTANCE_ID;
    }
#endif

    return ErrorId;
}


/**
 * @brief    Checks if the Mem module has been initialized.
 */
static inline uint32 Mem_43_MRAM_ValidateModuleInitialized(void)
{
    uint32 ErrorId = MEM_43_MRAM_E_OK;
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
    uint8 UserId;

#if (MEM_43_MRAM_MULTIPARTITION_ENABLED == STD_ON)
    UserId = OsIf_GetUserId();
#else
    UserId = 0U;
#endif

    /* Only check if development error detection is enabled */
    if (NULL_PTR == (*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId]))
    {
        /* The Mem module has not been initialized */
        ErrorId = MEM_43_MRAM_E_UNINIT;
    }
#endif

    return ErrorId;
}


/**
 * @brief    Common checks of input parameters for driver APIs.
 */
static uint32 Mem_43_MRAM_ValidateParamJobCommon(Mem_43_MRAM_JobRuntimeInfoType *JobRequest)
{
    uint32 ErrorId;

    /* Checks if the Mem module has been initialized */
    ErrorId = Mem_43_MRAM_ValidateModuleInitialized();

    if (MEM_43_MRAM_E_OK == ErrorId)
    {
        /* Check if the provided InstanceId is consistent with the configuration */
        ErrorId = Mem_43_MRAM_ValidateInstanceId(JobRequest);
    }

    if (MEM_43_MRAM_E_OK == ErrorId)
    {
        /* Check if the address and the length are valid */
        ErrorId = Mem_43_MRAM_ValidateAddressAndLength(JobRequest);
    }

    return ErrorId;
}

/**
 * @brief    Checks if the input argument is a NULL pointer.
 */
static inline uint32 Mem_43_MRAM_ValidateDataPointer(const Mem_43_MRAM_DataType *DataPtr)
{
    uint32 ErrorId = MEM_43_MRAM_E_OK;

    if (NULL_PTR == DataPtr)
    {
        /* The DataPtr argument is a NULL pointer */
        ErrorId = MEM_43_MRAM_E_PARAM_POINTER;
    }

    return ErrorId;
}


/**
 * @brief    Checks the input parameters for data transfer jobs (read, write)
 */
static uint32 Mem_43_MRAM_ValidateParamJobDataTransfer(Mem_43_MRAM_JobRuntimeInfoType *JobRequest)
{
    uint32 ErrorId;

    /* Perform the common checking */
    ErrorId = Mem_43_MRAM_ValidateParamJobCommon(JobRequest);

    /* Perform the specific checking */
    if (MEM_43_MRAM_E_OK == ErrorId)
    {
        /* Write jobs carry the user buffer in the const SrcDataPtr field (DataPtr stays NULL),
         * while Read and the Compare hardware service use the non-const DataPtr field. Validate
         * the field that actually holds the buffer for the current job type. */
        if (MEM_43_MRAM_JOB_WRITE == JobRequest->JobType)
        {
            ErrorId = Mem_43_MRAM_ValidateDataPointer(JobRequest->SrcDataPtr);
        }
        else
        {
            ErrorId = Mem_43_MRAM_ValidateDataPointer(JobRequest->DataPtr);
        }
    }

    return ErrorId;
}

/**
 * @brief    Initialize the input parameter for the new job request
 */
static void Mem_43_MRAM_InitJobRequest(Mem_43_MRAM_JobRuntimeInfoType    *JobRequest,
                                        Mem_43_MRAM_InstanceIdType         InstanceId,
                                        Mem_43_MRAM_AddressType            Address,
                                        Mem_43_MRAM_DataType               *DataPtr,
                                        Mem_43_MRAM_LengthType             Length
                                       )
{
    /* Input value */
    JobRequest->InstanceId       = InstanceId;
    JobRequest->HwServiceIdJob   = MEM_43_MRAM_HWSERVICEID_INVALID;
    JobRequest->Address          = Address;
    JobRequest->DataPtr          = DataPtr;
    /* Const write-source pointer; only the write path sets it (see Mem_43_MRAM_Write). */
    JobRequest->SrcDataPtr       = NULL_PTR;
    JobRequest->Length           = Length;
    /* Default value */
    JobRequest->InstanceIndex    = MEM_43_MRAM_MEM_INSTANCE_INDEX_INVALID;
    JobRequest->SectorBatch      = NULL_PTR;
    /* Prepare for a new job */
    JobRequest->JobFlags         = MEM_43_MRAM_JOB_FLAG_STARTED;
    JobRequest->JobResult        = MEM_43_MRAM_JOB_PENDING;
}

/**
 * @brief    Check if the mem instance is idle and configure the new job request
 */
static uint32 Mem_43_MRAM_ConfigureJobRequest(const Mem_43_MRAM_JobRuntimeInfoType *JobRequest)
{
    uint32 ErrorId;
    Mem_43_MRAM_JobRuntimeInfoType *JobRuntimeInfo = Mem_43_MRAM_GetJobRuntimeInfo();

    /* Start of exclusive area */
    SchM_Enter_Mem_43_MRAM_MEM_EXCLUSIVE_AREA_01();

    if (MEM_43_MRAM_JOB_PENDING == JobRuntimeInfo[JobRequest->InstanceIndex].JobResult)
    {
        /* A previous job is still being processed */
        ErrorId = MEM_43_MRAM_E_JOB_PENDING;
    }
    else
    {
        /* Accept the requested job */
        ErrorId = MEM_43_MRAM_E_OK;
        /* Configure the new job */
        JobRuntimeInfo[JobRequest->InstanceIndex] = *JobRequest;
    }

    /* End of exclusive area */
    SchM_Exit_Mem_43_MRAM_MEM_EXCLUSIVE_AREA_01();

    return ErrorId;
}

#if (MEM_43_MRAM_HW_SERVICE == STD_ON)
/**
* @brief        Process the HwSpecificService job
*
* @details      Process the HwSpecificService job with the corresponding serviceID stored in the variable JobInfo.HwServiceIdJob
*
*/
static Mem_43_MRAM_JobResultType Mem_43_MRAM_ProcessHwSpecificServiceJob(uint32 InstanceIndex, Mem_43_MRAM_JobRuntimeInfoType* JobInfo)
{
    Mem_43_MRAM_JobResultType JobResult = MEM_43_MRAM_JOB_OK;

    switch (JobInfo->HwServiceIdJob)
    {
#if (MEM_43_MRAM_HW_COMPARE_SERVICE == STD_ON)
    case MEM_43_MRAM_HWSERVICEID_COMPARE:
        JobResult = Mem_43_MRAM_IPW_Compare(InstanceIndex, JobInfo);
        break;
#endif
#if (MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON)
    case MEM_43_MRAM_HWSERVICEID_UTEST_REFERENCE_RECOVERY_REFRESH:
        JobResult = Mem_43_MRAM_IPW_UTestReferenceRecoveryRefresh(InstanceIndex, JobInfo);
        break;
    case MEM_43_MRAM_HWSERVICEID_UTEST_EDC_AFTER_ECC_LOGIC_CHECK:
        JobResult = Mem_43_MRAM_IPW_EDCAfterECCLogicCheck(InstanceIndex, JobInfo);
        break;
    case MEM_43_MRAM_HWSERVICEID_UTEST_ADDRESS_ENCODE_LOGIC_CHECK:
        JobResult = Mem_43_MRAM_IPW_AddressEncodeLogicCheck(InstanceIndex, JobInfo);
        break;
    case MEM_43_MRAM_HWSERVICEID_UTEST_ECC_LOGIC_CHECK:
        JobResult = Mem_43_MRAM_IPW_ECCLogicCheck(InstanceIndex, JobInfo);
        break;
    case MEM_43_MRAM_HWSERVICEID_UTEST_ARRAY_INTEGRITY_CHECK:
        JobResult = Mem_43_MRAM_IPW_ArrayIntegrityCheck(InstanceIndex, JobInfo);
        break;
#endif
    default:
        /* Unknown hardware service id: report the job as failed */
        JobResult = MEM_43_MRAM_JOB_FAILED;
        (void)InstanceIndex;
        (void)JobInfo;
        break;
    }
    return JobResult;
}
#endif

/**
 * @brief   Decides which sub-function to call based on the job type:
 *          Modify (Write, Erase) or Read (Read, BlankCheck).
 */
static Mem_43_MRAM_JobResultType Mem_43_MRAM_DoRequestedJobs(uint32 InstanceIndex,
                                                               Mem_43_MRAM_JobRuntimeInfoType *JobInfo
                                                              )
{
    /* Assume no more data to process, previous asynchronous job completed successfully */
    Mem_43_MRAM_JobResultType JobResult = MEM_43_MRAM_JOB_OK;

    if (0U != JobInfo->Length)
    {
        /* Call Low-level driver to work with physical flash device
         * Process the maximum length depending on the hardware capabilities, or until a sector boundary
         */
        switch (JobInfo->JobType)
        {
            case MEM_43_MRAM_JOB_ERASE:
                JobResult = Mem_43_MRAM_IPW_Erase(InstanceIndex, JobInfo);
                break;

            case MEM_43_MRAM_JOB_WRITE:
                JobResult = Mem_43_MRAM_IPW_Write(InstanceIndex, JobInfo);
                break;

            case MEM_43_MRAM_JOB_READ:
                JobResult = Mem_43_MRAM_IPW_Read(InstanceIndex, JobInfo);
                break;
#if (MEM_43_MRAM_HW_SERVICE == STD_ON)
            case MEM_43_MRAM_JOB_HWSPECIFICSERVICE:
                /* Process hw specific service job */
                JobResult = Mem_43_MRAM_ProcessHwSpecificServiceJob(InstanceIndex, JobInfo);
                break;
#endif
            case MEM_43_MRAM_JOB_BLANK_CHECK:
                JobResult = Mem_43_MRAM_IPW_BlankCheck(InstanceIndex, JobInfo);
                break;

            default:  /* MEM_43_MRAM_JOB_NONE */
                JobResult = MEM_43_MRAM_JOB_FAILED;
                break;
        };
        /* if This is Read/Compare/BlankCheck Jobs */
        if (((MEM_43_MRAM_JOB_OK == JobResult) || (MEM_43_MRAM_ECC_CORRECTED == JobResult))  && (0U != JobInfo->Length))
        {
            /* The current chunk has completed but there is still data to process, need more MainFunction calls */
            JobResult = MEM_43_MRAM_JOB_PENDING;
        }
    }
    return JobResult;
}


/**
 * @brief    Process the pending job for the mem instance
 */
static void Mem_43_MRAM_ProcessRequestedJobs(uint32 InstanceIndex, Mem_43_MRAM_JobRuntimeInfoType *JobRuntimeInfo)
{
    Mem_43_MRAM_JobRuntimeInfoType *JobInfo = &(JobRuntimeInfo[InstanceIndex]);
    Mem_43_MRAM_JobResultType     JobResult = MEM_43_MRAM_JOB_OK;

    if ((JobInfo->JobFlags & MEM_43_MRAM_JOB_FLAG_STARTED) != 0U)
    {
        /* Clear flag */
        JobInfo->JobFlags &=  ~((uint8)MEM_43_MRAM_JOB_FLAG_STARTED);
    }
    else
    {
        /* Check the status of the job is being processed in the low-level driver */
        JobResult = JobInfo->JobResult;
    }
    /* The case MEM_43_MRAM_ECC_CORRECTED == JobResult can be true when enable EraseVerify/ProgramVerify of Erase/Write job */
    if (((MEM_43_MRAM_JOB_OK == JobResult) || (MEM_43_MRAM_ECC_CORRECTED == JobResult)) && (0U != JobInfo->Length))
    {
        /* The previous pending job has been done, launch new operation */
        JobResult = Mem_43_MRAM_DoRequestedJobs(InstanceIndex, JobInfo);
    }

    /* Start of exclusive area */
    SchM_Enter_Mem_43_MRAM_MEM_EXCLUSIVE_AREA_06();

    if (MEM_43_MRAM_ECC_UNCORRECTED == JobResult)
    {
        /* abort pending job */
        JobInfo->JobType = MEM_43_MRAM_JOB_NONE;
    }

    /* Update the latest job result */
    JobInfo->JobResult = JobResult;

    /* End of exclusive area */
    SchM_Exit_Mem_43_MRAM_MEM_EXCLUSIVE_AREA_06();
}

#if (MEM_43_MRAM_HW_COMPARE_SERVICE == STD_ON)
static Std_ReturnType Mem_43_MRAM_Compare(Mem_43_MRAM_InstanceIdType    InstanceId,
                                           Mem_43_MRAM_AddressType       SourceAddress,
                                           Mem_43_MRAM_DataType          *DestinationDataPtr,
                                           Mem_43_MRAM_LengthType        Length
                                          )
{
    Std_ReturnType RetVal = (Std_ReturnType)E_OK;
    uint32 ErrorId;

    /* Prepare for input parameter checking before update runtime information */
    Mem_43_MRAM_JobRuntimeInfoType JobRequest;
    Mem_43_MRAM_InitJobRequest(&JobRequest, InstanceId, SourceAddress, DestinationDataPtr, Length);

    /* Config Hardware Service job for Compare Function  */
    JobRequest.JobType        = MEM_43_MRAM_JOB_HWSPECIFICSERVICE;
    JobRequest.HwServiceIdJob = MEM_43_MRAM_HWSERVICEID_COMPARE;

    /* Perform the input parameters checking */
    ErrorId = Mem_43_MRAM_ValidateParamJobDataTransfer(&JobRequest);

    if (MEM_43_MRAM_E_OK == ErrorId)
    {
        /* Configure the new job request to global runtime variable */
        ErrorId = Mem_43_MRAM_ConfigureJobRequest(&JobRequest);

        if (MEM_43_MRAM_E_OK != ErrorId)
        {
            /* Reject the requested job */
            RetVal = (Std_ReturnType)E_NOT_OK;
            /* Report the error */
            Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_HW_SPECIFIC_SERVICE_ID, ErrorId);
        }
    }
    else
    {
        /* Reject the requested job */
        RetVal = (Std_ReturnType)E_NOT_OK;
        /* Report the error */
        Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_HW_SPECIFIC_SERVICE_ID, ErrorId);
    }

    return RetVal;
}
#endif /* MEM_43_MRAM_HW_COMPARE_SERVICE == STD_ON */

#if (MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON)
/**
 * @brief    Configure a UTest Reference Recovery/Refresh hardware specific service job.
 *
 * @details  Reference recovery and refresh is a synchronous one-shot BIST operation that takes only
 *           the instance id. It is queued as a MEM_43_MRAM_JOB_HWSPECIFICSERVICE job (using a
 *           non-zero sentinel length so the job engine schedules it) and executed later in
 *           MainFunction; the result is retrieved by the caller via Mem_43_MRAM_GetJobResult.
 */
static Std_ReturnType Mem_43_MRAM_UTestReferenceRecoveryRefresh(Mem_43_MRAM_InstanceIdType InstanceId)
{
    Std_ReturnType RetVal = (Std_ReturnType)E_OK;
    uint32 ErrorId;

    /* Prepare for input parameter checking before update runtime information */
    Mem_43_MRAM_JobRuntimeInfoType JobRequest;

    /* No address/buffer for this service. Length = 1 is a non-zero sentinel required so the job
     * engine (Mem_43_MRAM_DoRequestedJobs) actually schedules the job; the IP wrapper
     * clears it to 0 after the single call so the pending loop terminates. */
    Mem_43_MRAM_InitJobRequest(&JobRequest, InstanceId, 0U, NULL_PTR, 1U);

    /* Config Hardware Service job for Reference Recovery/Refresh Function */
    JobRequest.JobType        = MEM_43_MRAM_JOB_HWSPECIFICSERVICE;
    JobRequest.HwServiceIdJob = MEM_43_MRAM_HWSERVICEID_UTEST_REFERENCE_RECOVERY_REFRESH;

    /* Resolve the instance index only (this service has no address/buffer to validate) */
    ErrorId = Mem_43_MRAM_ValidateInstanceId(&JobRequest);

    if (MEM_43_MRAM_E_OK == ErrorId)
    {
        /* Configure the new job request to global runtime variable */
        ErrorId = Mem_43_MRAM_ConfigureJobRequest(&JobRequest);
    }

    if (MEM_43_MRAM_E_OK != ErrorId)
    {
        /* Reject the requested job */
        RetVal = (Std_ReturnType)E_NOT_OK;
        /* Report the error */
        Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_HW_SPECIFIC_SERVICE_ID, ErrorId);
    }

    return RetVal;
}

/**
 * @brief    Configure a UTest EDC-after-ECC Logic Check hardware specific service job.
 *
 * @details  Synchronous one-shot BIST. Inputs and the ResultEEE output slot are carried by the
 *           caller's Mem_43_MRAM_UTestEDCAfterECCLogicCheckConfigType (reached via dataPtr); a pointer
 *           to it is stashed in JobInfo->DataPtr. Queued as a MEM_43_MRAM_JOB_HWSPECIFICSERVICE job
 *           with a non-zero sentinel length; ResultEEE is written back by the IPW wrapper on
 *           completion, and the outcome is retrieved via Mem_43_MRAM_GetJobResult.
 */
static Std_ReturnType Mem_43_MRAM_UTestEDCAfterECCLogicCheck(Mem_43_MRAM_InstanceIdType                          InstanceId,
                                                             Mem_43_MRAM_UTestEDCAfterECCLogicCheckConfigType *pConfig)
{
    Std_ReturnType RetVal = (Std_ReturnType)E_OK;
    uint32 ErrorId;

    /* Prepare for input parameter checking before update runtime information */
    Mem_43_MRAM_JobRuntimeInfoType JobRequest;

    /* Carry the whole config (inputs + ResultEEE output slot) via DataPtr. Length = 1 is a non-zero
     * sentinel so the job engine schedules the job; the IP wrapper clears it after the single call. */
    Mem_43_MRAM_InitJobRequest(&JobRequest, InstanceId, 0U, (Mem_43_MRAM_DataType *)pConfig, 1U);

    /* Config Hardware Service job for EDC-after-ECC Logic Check Function */
    JobRequest.JobType        = MEM_43_MRAM_JOB_HWSPECIFICSERVICE;
    JobRequest.HwServiceIdJob = MEM_43_MRAM_HWSERVICEID_UTEST_EDC_AFTER_ECC_LOGIC_CHECK;

    /* Resolve the instance index only (the payload is validated at the DET stage) */
    ErrorId = Mem_43_MRAM_ValidateInstanceId(&JobRequest);

    if (MEM_43_MRAM_E_OK == ErrorId)
    {
        /* Configure the new job request to global runtime variable */
        ErrorId = Mem_43_MRAM_ConfigureJobRequest(&JobRequest);
    }

    if (MEM_43_MRAM_E_OK != ErrorId)
    {
        /* Reject the requested job */
        RetVal = (Std_ReturnType)E_NOT_OK;
        /* Report the error */
        Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_HW_SPECIFIC_SERVICE_ID, ErrorId);
    }

    return RetVal;
}

/**
 * @brief    Configure a UTest Address-Encode Logic Check hardware specific service job.
 *
 * @details  Synchronous one-shot BIST. Inputs and the ResultAEE output slot are carried by the
 *           caller's Mem_43_MRAM_UTestAddressEncodeLogicCheckConfigType (reached via dataPtr); a
 *           pointer to it is stashed in JobInfo->DataPtr. Queued as a
 *           MEM_43_MRAM_JOB_HWSPECIFICSERVICE job with a non-zero sentinel length; ResultAEE is
 *           written back by the IPW wrapper on completion, retrieved via Mem_43_MRAM_GetJobResult.
 */
static Std_ReturnType Mem_43_MRAM_UTestAddressEncodeLogicCheck(Mem_43_MRAM_InstanceIdType                             InstanceId,
                                                                Mem_43_MRAM_UTestAddressEncodeLogicCheckConfigType *pConfig)
{
    Std_ReturnType RetVal = (Std_ReturnType)E_OK;
    uint32 ErrorId;

    /* Prepare for input parameter checking before update runtime information */
    Mem_43_MRAM_JobRuntimeInfoType JobRequest;

    /* Carry the whole config (inputs + ResultAEE output slot) via DataPtr. Length = 1 is a non-zero
     * sentinel so the job engine schedules the job; the IP wrapper clears it after the single call. */
    Mem_43_MRAM_InitJobRequest(&JobRequest, InstanceId, 0U, (Mem_43_MRAM_DataType *)pConfig, 1U);

    /* Config Hardware Service job for Address-Encode Logic Check Function */
    JobRequest.JobType        = MEM_43_MRAM_JOB_HWSPECIFICSERVICE;
    JobRequest.HwServiceIdJob = MEM_43_MRAM_HWSERVICEID_UTEST_ADDRESS_ENCODE_LOGIC_CHECK;

    /* Resolve the instance index only (the payload is validated at the DET stage) */
    ErrorId = Mem_43_MRAM_ValidateInstanceId(&JobRequest);

    if (MEM_43_MRAM_E_OK == ErrorId)
    {
        /* Configure the new job request to global runtime variable */
        ErrorId = Mem_43_MRAM_ConfigureJobRequest(&JobRequest);
    }

    if (MEM_43_MRAM_E_OK != ErrorId)
    {
        /* Reject the requested job */
        RetVal = (Std_ReturnType)E_NOT_OK;
        /* Report the error */
        Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_HW_SPECIFIC_SERVICE_ID, ErrorId);
    }

    return RetVal;
}

/**
 * @brief    Configure a UTest ECC Logic Check hardware specific service job.
 *
 * @details  Synchronous one-shot BIST. Inputs and the embedded Result struct are carried by the
 *           caller's Mem_43_MRAM_UTestECCLogicCheckConfigType (reached via dataPtr); a pointer to
 *           it is stashed in JobInfo->DataPtr. Queued as a MEM_43_MRAM_JOB_HWSPECIFICSERVICE job
 *           with a non-zero sentinel length; Result is written back by the IPW wrapper on completion,
 *           retrieved via Mem_43_MRAM_GetJobResult.
 */
static Std_ReturnType Mem_43_MRAM_UTestECCLogicCheck(Mem_43_MRAM_InstanceIdType                    InstanceId,
                                                      Mem_43_MRAM_UTestECCLogicCheckConfigType *pConfig)
{
    Std_ReturnType RetVal = (Std_ReturnType)E_OK;
    uint32 ErrorId;

    /* Prepare for input parameter checking before update runtime information */
    Mem_43_MRAM_JobRuntimeInfoType JobRequest;

    /* Carry the whole config (inputs + Result output slot) via DataPtr. Length = 1 is a non-zero
     * sentinel so the job engine schedules the job; the IP wrapper clears it after the single call. */
    Mem_43_MRAM_InitJobRequest(&JobRequest, InstanceId, 0U, (Mem_43_MRAM_DataType *)pConfig, 1U);

    /* Config Hardware Service job for ECC Logic Check Function */
    JobRequest.JobType        = MEM_43_MRAM_JOB_HWSPECIFICSERVICE;
    JobRequest.HwServiceIdJob = MEM_43_MRAM_HWSERVICEID_UTEST_ECC_LOGIC_CHECK;

    /* Resolve the instance index only (the payload is validated at the DET stage) */
    ErrorId = Mem_43_MRAM_ValidateInstanceId(&JobRequest);

    if (MEM_43_MRAM_E_OK == ErrorId)
    {
        /* Configure the new job request to global runtime variable */
        ErrorId = Mem_43_MRAM_ConfigureJobRequest(&JobRequest);
    }

    if (MEM_43_MRAM_E_OK != ErrorId)
    {
        /* Reject the requested job */
        RetVal = (Std_ReturnType)E_NOT_OK;
        /* Report the error */
        Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_HW_SPECIFIC_SERVICE_ID, ErrorId);
    }

    return RetVal;
}

/**
 * @brief    Configure a UTest Array Integrity Check hardware specific service job.
 *
 * @details  Synchronous one-shot BIST. Inputs and the embedded Result struct are carried by the
 *           caller's Mem_43_MRAM_UTestArrayIntegrityCheckConfigType (reached via dataPtr); a pointer
 *           to it is stashed in JobInfo->DataPtr. Queued as a MEM_43_MRAM_JOB_HWSPECIFICSERVICE job
 *           with a non-zero sentinel length; Result is written back by the IPW wrapper on completion,
 *           retrieved via Mem_43_MRAM_GetJobResult.
 */
static Std_ReturnType Mem_43_MRAM_UTestArrayIntegrityCheck(Mem_43_MRAM_InstanceIdType                       InstanceId,
                                                            Mem_43_MRAM_UTestArrayIntegrityCheckConfigType *pConfig)
{
    Std_ReturnType RetVal = (Std_ReturnType)E_OK;
    uint32 ErrorId;

    /* Prepare for input parameter checking before update runtime information */
    Mem_43_MRAM_JobRuntimeInfoType JobRequest;

    /* Carry the whole config (inputs + Result output slot) via DataPtr. Length = 1 is a non-zero
     * sentinel so the job engine schedules the job; the IP wrapper clears it after the single call. */
    Mem_43_MRAM_InitJobRequest(&JobRequest, InstanceId, 0U, (Mem_43_MRAM_DataType *)pConfig, 1U);

    /* Config Hardware Service job for Array Integrity Check Function */
    JobRequest.JobType        = MEM_43_MRAM_JOB_HWSPECIFICSERVICE;
    JobRequest.HwServiceIdJob = MEM_43_MRAM_HWSERVICEID_UTEST_ARRAY_INTEGRITY_CHECK;

    /* Resolve the instance index only (the payload is validated at the DET stage) */
    ErrorId = Mem_43_MRAM_ValidateInstanceId(&JobRequest);

    if (MEM_43_MRAM_E_OK == ErrorId)
    {
        /* Configure the new job request to global runtime variable */
        ErrorId = Mem_43_MRAM_ConfigureJobRequest(&JobRequest);
    }

    if (MEM_43_MRAM_E_OK != ErrorId)
    {
        /* Reject the requested job */
        RetVal = (Std_ReturnType)E_NOT_OK;
        /* Report the error */
        Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_HW_SPECIFIC_SERVICE_ID, ErrorId);
    }

    return RetVal;
}
#endif /* MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON */

#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
/**
 * @brief            Check dev error common for Mem_HwSpecificService API()
 *
 * @param[in]        InstanceId            ID of the related memory driver instance
 * @param[in]        HwServiceId           Hardware specific service request identifier for dispatching the request.
 * @param[in]        DataPtr               Request specific data pointer.
 * @param[in]        LengthPtr             Size pointer of the data passed by dataPtr.
 *
 * @return           Std_ReturnType
 *                   - E_OK                   : has dev error detect.
 *                   - E_NOT_OK               : hasn't dev error detect.
 */
static Std_ReturnType Mem_43_MRAM_CheckDevErrorCommon_HwSpecificService(Mem_43_MRAM_InstanceIdType     instanceId,
                                                                         Mem_43_MRAM_HwServiceIdType    hwServiceId,
                                                                         const Mem_43_MRAM_DataType           *dataPtr,
                                                                         const Mem_43_MRAM_LengthType   *lengthPtr
                                                                        )
{
    Std_ReturnType RetVal = (Std_ReturnType)E_NOT_OK;
    uint32 ErrorId;

    /* Checks if the Mem module has been initialized */
    ErrorId = Mem_43_MRAM_ValidateModuleInitialized();

    if (MEM_43_MRAM_E_OK == ErrorId)
    {
        /* Get the mem index number according to the mem instance id */
        uint32 InstanceIndex = Mem_43_MRAM_GetInstanceIndex(instanceId);

        if (MEM_43_MRAM_INSTANCE_COUNT <= InstanceIndex)
        {
            /* The provided instanceId is inconsistent with the configuration */
            ErrorId = MEM_43_MRAM_E_PARAM_INSTANCE_ID;
        }
        else
        {
            switch (hwServiceId)
            {
#if (MEM_43_MRAM_HW_COMPARE_SERVICE == STD_ON)
                case MEM_43_MRAM_HWSERVICEID_COMPARE:
                {
                    if ((NULL_PTR == dataPtr) || (NULL_PTR == lengthPtr))
                    {
                        ErrorId = MEM_43_MRAM_E_PARAM_POINTER;
                    }
                    else if (sizeof(Mem_43_MRAM_CompareConfigType) != *lengthPtr)
                    {
                        /* The redundant "hwServiceId == HWSERVICEID_COMPARE" test was removed:
                         * inside this case hwServiceId is always the COMPARE id. */
                        ErrorId = MEM_43_MRAM_E_PARAM_LENGTH;
                    }
                    else
                    {
                         RetVal = (Std_ReturnType)E_OK;
                    }

                    break;
                }
#endif
#if (MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON)
                case MEM_43_MRAM_HWSERVICEID_UTEST_REFERENCE_RECOVERY_REFRESH:
                {
                    /* No dataPtr / lengthPtr payload is required for this service */
                    RetVal = (Std_ReturnType)E_OK;
                    break;
                }
                case MEM_43_MRAM_HWSERVICEID_UTEST_EDC_AFTER_ECC_LOGIC_CHECK:
                {
                    if ((NULL_PTR == dataPtr) || (NULL_PTR == lengthPtr))
                    {
                        ErrorId = MEM_43_MRAM_E_PARAM_POINTER;
                    }
                    else if (sizeof(Mem_43_MRAM_UTestEDCAfterECCLogicCheckConfigType) != *lengthPtr)
                    {
                        ErrorId = MEM_43_MRAM_E_PARAM_LENGTH;
                    }
                    else
                    {
                        RetVal = (Std_ReturnType)E_OK;
                    }

                    break;
                }
                case MEM_43_MRAM_HWSERVICEID_UTEST_ADDRESS_ENCODE_LOGIC_CHECK:
                {
                    if ((NULL_PTR == dataPtr) || (NULL_PTR == lengthPtr))
                    {
                        ErrorId = MEM_43_MRAM_E_PARAM_POINTER;
                    }
                    else if (sizeof(Mem_43_MRAM_UTestAddressEncodeLogicCheckConfigType) != *lengthPtr)
                    {
                        ErrorId = MEM_43_MRAM_E_PARAM_LENGTH;
                    }
                    else
                    {
                        RetVal = (Std_ReturnType)E_OK;
                    }

                    break;
                }
                case MEM_43_MRAM_HWSERVICEID_UTEST_ECC_LOGIC_CHECK:
                {
                    if ((NULL_PTR == dataPtr) || (NULL_PTR == lengthPtr))
                    {
                        ErrorId = MEM_43_MRAM_E_PARAM_POINTER;
                    }
                    else if (sizeof(Mem_43_MRAM_UTestECCLogicCheckConfigType) != *lengthPtr)
                    {
                        ErrorId = MEM_43_MRAM_E_PARAM_LENGTH;
                    }
                    else
                    {
                        RetVal = (Std_ReturnType)E_OK;
                    }

                    break;
                }
                case MEM_43_MRAM_HWSERVICEID_UTEST_ARRAY_INTEGRITY_CHECK:
                {
                    if ((NULL_PTR == dataPtr) || (NULL_PTR == lengthPtr))
                    {
                        ErrorId = MEM_43_MRAM_E_PARAM_POINTER;
                    }
                    else if (sizeof(Mem_43_MRAM_UTestArrayIntegrityCheckConfigType) != *lengthPtr)
                    {
                        ErrorId = MEM_43_MRAM_E_PARAM_LENGTH;
                    }
                    else
                    {
                        RetVal = (Std_ReturnType)E_OK;
                    }

                    break;
                }
#endif
            default:
                /* Unsupported hardware service id: leave the request rejected.
                 * Non-empty default clause is required. */
                RetVal = (Std_ReturnType)E_NOT_OK;
                break;
            }
        }
    }

    if (MEM_43_MRAM_E_OK != ErrorId)
    {
        /* Report the error */
        (void)Det_ReportError(MEM_43_MRAM_MODULE_ID, (uint8)instanceId, (uint8)MEM_43_MRAM_HW_SPECIFIC_SERVICE_ID, (uint8)ErrorId);
    }

#if (MEM_43_MRAM_HW_SERVICE != STD_ON)
    /* fix compiler warning */
    (void)instanceId;
    (void)hwServiceId;
    (void)dataPtr;
    (void)lengthPtr;
#endif

    return RetVal;
}
#endif

/*==================================================================================================
                                       GLOBAL FUNCTIONS (Synchronous Functions)
==================================================================================================*/

/**
 * @brief        The function initializes Mem_43_MRAM module.
 *
 * @details      Initialization function - initializes all variables
 *               and sets the module state to initialized.
 *
 * @param[in]    ConfigPtr        Pointer to the configuration data structure - since Mem_43_MRAM driver
 *                                is a precompile module this parameter is typically not used.
 *
 * @param[inout] None
 *
 * @param[out]   None
 *
 * @return       None
 *
 * @pre          None
 *
 * @api
 *
 * @implements   Mem_43_MRAM_Init_Activity
 */
void Mem_43_MRAM_Init(const Mem_43_MRAM_ConfigType *ConfigPtr)
{
    Mem_43_MRAM_JobResultType JobResult = MEM_43_MRAM_JOB_OK;
#if (MEM_43_MRAM_CHECK_CFG_CRC == STD_ON)
    Std_ReturnType Status = (Std_ReturnType)E_OK;
#endif
    uint32 InstanceIndex;
    Mem_43_MRAM_JobRuntimeInfoType *JobRuntimeInfo;

    if (NULL_PTR != ConfigPtr)
    {
        /* The ConfigPtr argument is not a NULL pointer */
        Mem_43_MRAM_ReportDevError(0U, MEM_43_MRAM_INIT_ID, MEM_43_MRAM_E_PARAM_POINTER);
    }
    else
    {
        /* Initialize the Mem driver internal states and set the Mem driver job processing state to MEM_43_MRAM_JOB_OK */
        uint8 UserId;
#if (MEM_43_MRAM_MULTIPARTITION_ENABLED == STD_ON)
        UserId = OsIf_GetUserId();
#else
        UserId = 0U;
#endif
        /* Store config pointer in the partition-specific slot */
#if (MEM_43_MRAM_MULTIPARTITION_ENABLED == STD_ON)
        if (NULL_PTR == Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])
        {
            /* The calling partition is not mapped to this Mem driver instance */
            Mem_43_MRAM_ReportDevError(0U, MEM_43_MRAM_INIT_ID, MEM_43_MRAM_E_PARAM_POINTER);
        }
        else
#endif
        {
            *Mem_43_MRAM_pConfigPtr_PartitionMap[UserId] = &Mem_43_MRAM_Config;

            /* Resolve the partition specific runtime storage before any access (CRC included) */
            JobRuntimeInfo = Mem_43_MRAM_GetJobRuntimeInfo();

#if (MEM_43_MRAM_CHECK_CFG_CRC == STD_ON)
            if ((*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId])->u16ConfigCrc != Mem_43_MRAM_CalcCfgCRC())
            {
                Status = (Std_ReturnType)E_NOT_OK;
            }

            if ((Std_ReturnType)E_OK == Status)
            {
#endif
                for (InstanceIndex = 0U; InstanceIndex < MEM_43_MRAM_INSTANCE_COUNT; InstanceIndex++)
                {
                    /* Initialize low-level hardware */
                    (void)Mem_43_MRAM_IPW_Init(*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId], InstanceIndex);
                }

#if (MEM_43_MRAM_CHECK_CFG_CRC == STD_ON)
            }
            else
            {
                /* Mark the driver as un-initialized */
                *Mem_43_MRAM_pConfigPtr_PartitionMap[UserId] = NULL_PTR;
                JobResult = MEM_43_MRAM_JOB_FAILED;
            }
#endif

            /* Update job result */
            for (InstanceIndex = 0U; InstanceIndex < MEM_43_MRAM_INSTANCE_COUNT; InstanceIndex++)
            {
                JobRuntimeInfo[InstanceIndex].JobResult = JobResult;
            }
        }
    }
}


/**
 * @brief        The function de-initializes the Mem_43_MRAM module.
 *
 * @details      De-initialize module. If there is still an access job pending,
 *               it is immediately terminated (using hardware cancel operation)
 *               and the Mem driver module state is set to uninitialized.
 *
 * @param[in]    None
 *
 * @param[inout] None
 *
 * @param[out]   None
 *
 * @return       None
 *
 * @api
 *
 * @pre          The Mem_43_MRAM module must be re-initialized before it will accept
 *               any new job requests after this service is processed.
 *
 * @implements   Mem_43_MRAM_DeInit_Activity
 */
void Mem_43_MRAM_DeInit(void)
{
    uint32 InstanceIndex;
    Mem_43_MRAM_JobResultType JobResult = MEM_43_MRAM_JOB_OK;
    Mem_43_MRAM_JobRuntimeInfoType *JobRuntimeInfo;

    /* Check if the driver has been initialized before */
    uint8 UserId;
#if (MEM_43_MRAM_MULTIPARTITION_ENABLED == STD_ON)
    UserId = OsIf_GetUserId();
#else
    UserId = 0U;
#endif
    if (NULL_PTR != (*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId]))
    {
        JobRuntimeInfo = Mem_43_MRAM_GetJobRuntimeInfo();
        /* Cancel any ongoing flash operations in the hardware */
        for (InstanceIndex = 0U; InstanceIndex < MEM_43_MRAM_INSTANCE_COUNT; InstanceIndex++)
        {
            /* Update job result */
            JobRuntimeInfo[InstanceIndex].JobResult = JobResult;
            /* Update job JobType to MEM_43_MRAM_JOB_NONE */
            JobRuntimeInfo[InstanceIndex].JobType   = MEM_43_MRAM_JOB_NONE;

            /* Initialize low-level hardware */
            (void)Mem_43_MRAM_IPW_DeInit(*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId], InstanceIndex);
        }
        /* Clear the partition-specific config pointer */
        *Mem_43_MRAM_pConfigPtr_PartitionMap[UserId] = NULL_PTR;

        /* De-initialize the Mem driver internal states */
    }
}


/**
 * @brief        Return the version information of the Mem module.
 *
 * @details      Version information includes:
 *               - Module Id
 *               - Vendor Id
 *               - Vendor specific version numbers
 *
 * @param[in]    None
 *
 * @param[inout] None
 *
 * @param[out]   VersionInfoPtr    Pointer to where to store the version information of this module.
 *
 * @return       None
 *
 * @api
 *
 * @implements    Mem_43_MRAM_GetVersionInfo_Activity
 */
void Mem_43_MRAM_GetVersionInfo(Std_VersionInfoType *VersionInfoPtr)
{
    if (NULL_PTR != VersionInfoPtr)
    {
        /* Return version information about Mem module */
        VersionInfoPtr->moduleID         = (uint16)MEM_43_MRAM_MODULE_ID;
        VersionInfoPtr->vendorID         = (uint16)MEM_43_MRAM_VENDOR_ID;
        VersionInfoPtr->sw_major_version =  (uint8)MEM_43_MRAM_SW_MAJOR_VERSION;
        VersionInfoPtr->sw_minor_version =  (uint8)MEM_43_MRAM_SW_MINOR_VERSION;
        VersionInfoPtr->sw_patch_version =  (uint8)MEM_43_MRAM_SW_PATCH_VERSION;
    }
    else
    {
        /* The VersionInfoPtr argument is a NULL pointer */
        Mem_43_MRAM_ReportDevError(0U, MEM_43_MRAM_GET_VERSION_INFO_ID, MEM_43_MRAM_E_PARAM_POINTER);
    }
}


/**
 * @brief        Returns the result of the most recent job.
 *
 * @details      Returns synchronously the result of the last job.
 *
 * @param[in]    InstanceId    ID of the related memory driver instance.
 *
 * @param[inout] None
 *
 * @param[out]   None
 *
 * @return       Mem_43_MRAM_JobResultType    Most recent job result. (If AUTOSAR R21-11 is used the return type will be taken from Mem driver)
 *
 * @api
 *
 * @implements   Mem_43_MRAM_GetJobResult_Activity
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_GetJobResult(Mem_43_MRAM_InstanceIdType InstanceId)
{
    uint32 InstanceIndex;
    const Mem_43_MRAM_JobRuntimeInfoType *JobRuntimeInfo;

    Mem_43_MRAM_JobResultType JobResult = MEM_43_MRAM_JOB_FAILED;

/* if AUTOSAR R23-11 and DEV_ERROR_DETECT Enabled */
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
    uint32 ErrorId;
#endif /* MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON */

    /* Get the mem index number according to the mem instance id */
    InstanceIndex = Mem_43_MRAM_GetInstanceIndex(InstanceId);
    /* Check if InstanceId is consistent with configuration */
    if (MEM_43_MRAM_MEM_INSTANCE_INDEX_INVALID != InstanceIndex)
    {
        JobRuntimeInfo = Mem_43_MRAM_GetJobRuntimeInfo();
        /* Get the most recent job result of the according driver instance */
        JobResult = JobRuntimeInfo[InstanceIndex].JobResult;
    }
/* if AUTOSAR R23-11 and DEV_ERROR_DETECT Enabled */
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
    else
    {
        /* The provided InstanceId is inconsistent with the configuration */
        ErrorId = MEM_43_MRAM_E_PARAM_INSTANCE_ID;
        /* Report the error */
        Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_GET_JOB_RESULT_ID, ErrorId);
    }
#endif /* MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON */

    return JobResult;
}

/**
 * @brief        Suspends active memory operation using hardware mechanism.
 *
 * @details      If the suspend mechanism is not supported by hardware,
 *               implementation based on physical segmentation.
 *
 * @param[in]    InstanceId    ID of the related memory driver instance.
 *
 * @param[inout] None
 *
 * @param[out]   None
 *
 * @return       None
 *
 * @api
 *
 * @implements   Mem_43_MRAM_Suspend_Activity
 */
Std_ReturnType Mem_43_MRAM_Suspend(Mem_43_MRAM_InstanceIdType InstanceId)
{
    (void)InstanceId;

    return E_MEM_SERVICE_NOT_AVAIL;
}


/**
 * @brief        Resumes suspended memory operation using hardware mechanism.
 *
 * @details      Resumes suspended memory operation using hardware mechanism.
 *
 * @param[in]    InstanceId    ID of the related memory driver instance.
 *
 * @param[inout] None
 *
 * @param[out]   None
 *
 * @return       None
 *
 * @api
 *
 * @implements   Mem_43_MRAM_Resume_Activity
 */
Std_ReturnType Mem_43_MRAM_Resume(Mem_43_MRAM_InstanceIdType InstanceId)
{
    (void)InstanceId;

    return E_MEM_SERVICE_NOT_AVAIL;
}

/*==================================================================================================
                                       GLOBAL FUNCTIONS (Asynchronous Functions)
==================================================================================================*/

/**
 * @brief            Reads from flash memory.
 *
 * @details          Triggers a read job to copy the from the source address into the referenced destination data
 *                   buffer. The result of this service can be retrieved using the Mem_GetJobResult API. If the read
 *                   operation was successful, the result of the job is MEM_43_MRAM_JOB_OK. If the read operation failed,
 *                   the result of the job is either MEM_43_MRAM_JOB_FAILED in case of a general error or MEM_ECC_
 *                   CORRECTED/MEM_ECC_UNCORRECTED in case of a correctable/uncorrectable ECC error.
 *
 * @param[in]        InstanceId            ID of the related memory driver instance
 * @param[in]        SourceAddress         Physical address to read data from.
 * @param[in]        Length                Read length in bytes.
 *
 * @param[out]       DestinationDataPtr    Destination memory pointer to store the read data
 *
 * @return           Std_ReturnType
 *                   - E_OK                   : The requested job has been accepted by the module.
 *                   - E_NOT_OK               : The requested job has not been accepted by the module.
 *                   - E_MEM_SERVICE_NOT_AVAIL: The service function is not implemented.
 *
 * @api
 *
 * @pre              The module has to be initialized.
 *
 * @implements       Mem_43_MRAM_Read_Activity
 */
Std_ReturnType Mem_43_MRAM_Read(Mem_43_MRAM_InstanceIdType    InstanceId,
                                 Mem_43_MRAM_AddressType       SourceAddress,
                                 Mem_43_MRAM_DataType          *DestinationDataPtr,
                                 Mem_43_MRAM_LengthType        Length
                                )
{
    Std_ReturnType RetVal = (Std_ReturnType)E_OK;
    uint32 ErrorId;

    /* Prepare for input parameter checking before update runtime information */
    Mem_43_MRAM_JobRuntimeInfoType JobRequest;
    JobRequest.JobType = MEM_43_MRAM_JOB_READ;
    Mem_43_MRAM_InitJobRequest(&JobRequest, InstanceId, SourceAddress, DestinationDataPtr, Length);

    /* Perform the input parameters checking */
    ErrorId = Mem_43_MRAM_ValidateParamJobDataTransfer(&JobRequest);

    if (MEM_43_MRAM_E_OK == ErrorId)
    {
        /* Configure the new job request to global runtime variable */
        ErrorId = Mem_43_MRAM_ConfigureJobRequest(&JobRequest);

        if (MEM_43_MRAM_E_OK != ErrorId)
        {
            /* Reject the requested job */
            RetVal = (Std_ReturnType)E_NOT_OK;
            /* Report the error */
            Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_READ_ID, ErrorId);
        }
    }
    else
    {
        /* Reject the requested job */
        RetVal = (Std_ReturnType)E_NOT_OK;
        /* Report the error */
        Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_READ_ID, ErrorId);
    }

    return RetVal;
}


/**
 * @brief            Writes to flash memory.
 *
 * @details          Triggers a write job to store the passed data to the provided address area with given address
 *                   and length. The result of this service can be retrieved using the Mem_GetJobResult API. If the
 *                   write operation was successful, the job result is MEM_43_MRAM_JOB_OK. If there was an issue writing
 *                   the data, the result is MEM_FAILED.
 *
 * @param[in]        InstanceId            ID of the related memory driver instance
 * @param[in]        TargetAddress         Physical write address (aligned to page size).
 * @param[in]        SourceDataPtr         Source data pointer (aligned to page size).
 * @param[in]        Length                Write length in bytes (aligned to page size).
 *
 * @return           Std_ReturnType
 *                   - E_OK                   : The requested job has been accepted by the module.
 *                   - E_NOT_OK               : The requested job has not been accepted by the module.
 *                   - E_MEM_SERVICE_NOT_AVAIL: The service function is not implemented.
 *
 * @api
 *
 * @pre              The module has to be initialized.
 *
 * @implements       Mem_43_MRAM_Write_Activity
 */
Std_ReturnType Mem_43_MRAM_Write(Mem_43_MRAM_InstanceIdType     InstanceId,
                                  Mem_43_MRAM_AddressType        TargetAddress,
                                  const Mem_43_MRAM_DataType     *SourceDataPtr,
                                  Mem_43_MRAM_LengthType         Length
                                 )
{
    Std_ReturnType RetVal = (Std_ReturnType)E_OK;
    uint32 ErrorId;

    /* Prepare for input parameter checking before update runtime information */
    Mem_43_MRAM_JobRuntimeInfoType JobRequest;
    JobRequest.JobType = MEM_43_MRAM_JOB_WRITE;

    /* The write source stays const-qualified end to end: it is carried in the dedicated const
     * SrcDataPtr field rather than the non-const DataPtr, so no const-removing cast is needed
     * here. DataPtr is left NULL for write jobs. */
    Mem_43_MRAM_InitJobRequest(&JobRequest, InstanceId, TargetAddress, NULL_PTR, Length);
    JobRequest.SrcDataPtr = SourceDataPtr;

    /* Perform the input parameters checking */
    ErrorId = Mem_43_MRAM_ValidateParamJobDataTransfer(&JobRequest);

    if (MEM_43_MRAM_E_OK == ErrorId)
    {
        /* Configure the new job request to global runtime variable */
        ErrorId = Mem_43_MRAM_ConfigureJobRequest(&JobRequest);

        if (MEM_43_MRAM_E_OK != ErrorId)
        {
            /* Reject the requested job */
            RetVal = (Std_ReturnType)E_NOT_OK;
            /* Report the error */
            Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_WRITE_ID, ErrorId);
        }
    }
    else
    {
        /* Reject the requested job */
        RetVal = (Std_ReturnType)E_NOT_OK;
        /* Report the error */
        Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_WRITE_ID, ErrorId);
    }

    return RetVal;
}


/**
 * @brief            Erase one or more complete flash sectors.
 *
 * @details          Triggers an erase job of the given sector/sector batch defined by targetAddress and length.
 *                   The result of this service can be retrieved using the Mem_GetJobResult API. If the erase operation
 *                   was successful, the result of the job is MEM_43_MRAM_JOB_OK. If the erase operation failed, e.g. due to
 *                   a hardware issue, the result of the job is MEM_43_MRAM_JOB_FAILED.
 *
 * @param[in]        InstanceId            ID of the related memory driver instance
 * @param[in]        TargetAddress         Physical erase address (aligned to sector size).
 * @param[in]        Length                Erase length in bytes (aligned to sector size).
 *
 * @param[out]       None
 *
 * @return           Std_ReturnType
 *                   - E_OK                   : The requested job has been accepted by the module.
 *                   - E_NOT_OK               : The requested job has not been accepted by the module.
 *                   - E_MEM_SERVICE_NOT_AVAIL: The service function is not implemented.
 *
 * @api
 *
 * @pre              The module has to be initialized.
 *
 * @implements       Mem_43_MRAM_Erase_Activity
 */
Std_ReturnType Mem_43_MRAM_Erase(Mem_43_MRAM_InstanceIdType    InstanceId,
                                  Mem_43_MRAM_AddressType       TargetAddress,
                                  Mem_43_MRAM_LengthType        Length
                                 )
{
    Std_ReturnType RetVal = (Std_ReturnType)E_OK;
    uint32 ErrorId;

    /* Prepare for input parameter checking before update runtime information */
    Mem_43_MRAM_JobRuntimeInfoType JobRequest;
    JobRequest.JobType = MEM_43_MRAM_JOB_ERASE;
    Mem_43_MRAM_InitJobRequest(&JobRequest, InstanceId, TargetAddress, NULL_PTR, Length);

    /* Perform the input parameters checking */
    ErrorId = Mem_43_MRAM_ValidateParamJobCommon(&JobRequest);

    if (MEM_43_MRAM_E_OK == ErrorId)
    {
        /* Configure the new job request to global runtime variable */
        ErrorId = Mem_43_MRAM_ConfigureJobRequest(&JobRequest);

        if (MEM_43_MRAM_E_OK != ErrorId)
        {
            /* Reject the requested job */
            RetVal = (Std_ReturnType)E_NOT_OK;
            /* Report the error */
            Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_ERASE_ID, ErrorId);
        }
    }
    else
    {
        /* Reject the requested job */
        RetVal = (Std_ReturnType)E_NOT_OK;
        /* Report the error */
        Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_ERASE_ID, ErrorId);
    }

    return RetVal;
}


/**
 * @brief            Verify whether a given memory area has been erased but not (yet) programmed.
 *
 * @details          Triggers a job to check the erased state of the page which is referenced by targetAddress.
 *                   The result of this service can be retrieved using the Mem_GetJobResult API. If the checked page is
 *                   blank, the result of the job is MEM_43_MRAM_JOB_OK. Otherwise, if the page is not blank, the result is
 *                   MEM_INCONSISTENT.
 *
 * @param[in]        InstanceId            ID of the related memory driver instance
 * @param[in]        TargetAddress         Physical blank check address.
 * @param[in]        Length                Blank check length.
 *
 * @param[out]       None
 *
 * @return           Std_ReturnType
 *                   - E_OK                   : The requested job has been accepted by the module.
 *                   - E_NOT_OK               : The requested job has not been accepted by the module.
 *                   - E_MEM_SERVICE_NOT_AVAIL: The service function is not implemented.
 *
 * @api
 *
 * @pre              The module has to be initialized.
 *
 * @implements       Mem_43_MRAM_BlankCheck_Activity
 */
Std_ReturnType Mem_43_MRAM_BlankCheck(Mem_43_MRAM_InstanceIdType    InstanceId,
                                       Mem_43_MRAM_AddressType       TargetAddress,
                                       Mem_43_MRAM_LengthType        Length
                                      )
{
    Std_ReturnType RetVal = (Std_ReturnType)E_OK;
    uint32 ErrorId;

    /* Prepare for input parameter checking before update runtime information */
    Mem_43_MRAM_JobRuntimeInfoType JobRequest;
    JobRequest.JobType = MEM_43_MRAM_JOB_BLANK_CHECK;
    Mem_43_MRAM_InitJobRequest(&JobRequest, InstanceId, TargetAddress, NULL_PTR, Length);

    /* Perform the input parameters checking */
    ErrorId = Mem_43_MRAM_ValidateParamJobCommon(&JobRequest);

    if (MEM_43_MRAM_E_OK == ErrorId)
    {
        /* Configure the new job request to global runtime variable */
        ErrorId = Mem_43_MRAM_ConfigureJobRequest(&JobRequest);

        if (MEM_43_MRAM_E_OK != ErrorId)
        {
            /* Reject the requested job */
            RetVal = (Std_ReturnType)E_NOT_OK;
            /* Report the error */
            Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_BLANK_CHECK_ID, ErrorId);
        }
    }
    else
    {
        /* Reject the requested job */
        RetVal = (Std_ReturnType)E_NOT_OK;
        /* Report the error */
        Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_BLANK_CHECK_ID, ErrorId);
    }

    return RetVal;
}


/**
 * @brief            Trigger a hardware specific service.
 *
 * @details          Triggers a hardware specific memory driver job. DataPtr can be used to pass and return data to/
 *                   from this service. This service is just a dispatcher to the hardware specific service
 *                   implementation referenced by HwServiceId. The result of this service can be retrieved using the
 *                   Mem_GetJobResult API. If the hardware specific operation was successful, the result of the job
 *                   is MEM_43_MRAM_JOB_OK. If the hardware specific operation failed, the result of the job is MEM_43_MRAM_JOB_FAILED.
 *
 * @param[in]        InstanceId            ID of the related memory driver instance
 * @param[in]        HwServiceId           Hardware specific service request identifier for dispatching the request.
 * @param[in]        DataPtr               Request specific data pointer.
 * @param[in]        LengthPtr             Size pointer of the data passed by dataPtr.
 *
 * @param[out]       None
 *
 * @return           Std_ReturnType
 *                   - E_OK                   : The requested job has been accepted by the module.
 *                   - E_NOT_OK               : The requested job has not been accepted by the module.
 *                   - E_MEM_SERVICE_NOT_AVAIL: The service function is not implemented.
 *
 * @api
 *
 * @pre              The module has to be initialized.
 *
 * @implements       Mem_43_MRAM_HwSpecificService_Activity
 */
Std_ReturnType Mem_43_MRAM_HwSpecificService(Mem_43_MRAM_InstanceIdType     instanceId,
                                              Mem_43_MRAM_HwServiceIdType    hwServiceId,
                                              Mem_43_MRAM_DataType           *dataPtr,
                                              Mem_43_MRAM_LengthType         *lengthPtr
                                             )
{
    Std_ReturnType RetVal = (Std_ReturnType)E_OK;

#if (MEM_43_MRAM_HW_COMPARE_SERVICE == STD_ON)
    const Mem_43_MRAM_CompareConfigType*  pCompareConfig;
#endif
#if (MEM_43_MRAM_HW_SERVICE == STD_ON)
    switch (hwServiceId)
    {
#if (MEM_43_MRAM_HW_COMPARE_SERVICE == STD_ON)
        case MEM_43_MRAM_HWSERVICEID_COMPARE:
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
            /* Perform the input parameters checking */
            RetVal = Mem_43_MRAM_CheckDevErrorCommon_HwSpecificService(instanceId, hwServiceId, dataPtr, lengthPtr);
            if ((Std_ReturnType)E_OK == RetVal)
            {
#endif
                pCompareConfig = (Mem_43_MRAM_CompareConfigType *)((uint32)dataPtr);
                RetVal = Mem_43_MRAM_Compare(instanceId, pCompareConfig->CompareAddr, pCompareConfig->DataSourcePtr, pCompareConfig->Length);
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
            }
#endif
            break;
#endif /* MEM_43_MRAM_HW_COMPARE_SERVICE == STD_ON */
#if (MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON)
        case MEM_43_MRAM_HWSERVICEID_UTEST_REFERENCE_RECOVERY_REFRESH:
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
            /* Perform the input parameters checking */
            RetVal = Mem_43_MRAM_CheckDevErrorCommon_HwSpecificService(instanceId, hwServiceId, dataPtr, lengthPtr);
            if ((Std_ReturnType)E_OK == RetVal)
            {
#endif
                /* This service takes only the instance id (no dataPtr payload) */
                RetVal = Mem_43_MRAM_UTestReferenceRecoveryRefresh(instanceId);
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
            }
#endif
            break;
        case MEM_43_MRAM_HWSERVICEID_UTEST_EDC_AFTER_ECC_LOGIC_CHECK:
        {
            Mem_43_MRAM_UTestEDCAfterECCLogicCheckConfigType *pEdcConfig;
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
            /* Perform the input parameters checking */
            RetVal = Mem_43_MRAM_CheckDevErrorCommon_HwSpecificService(instanceId, hwServiceId, dataPtr, lengthPtr);
            if ((Std_ReturnType)E_OK == RetVal)
            {
#endif
                /* dataPtr carries inputs + the ResultEEE output slot (written back on completion) */
                pEdcConfig = (Mem_43_MRAM_UTestEDCAfterECCLogicCheckConfigType *)dataPtr;
                RetVal = Mem_43_MRAM_UTestEDCAfterECCLogicCheck(instanceId, pEdcConfig);
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
            }
#endif
        }
            break;
        case MEM_43_MRAM_HWSERVICEID_UTEST_ADDRESS_ENCODE_LOGIC_CHECK:
        {
            Mem_43_MRAM_UTestAddressEncodeLogicCheckConfigType *pAeeConfig;
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
            /* Perform the input parameters checking */
            RetVal = Mem_43_MRAM_CheckDevErrorCommon_HwSpecificService(instanceId, hwServiceId, dataPtr, lengthPtr);
            if ((Std_ReturnType)E_OK == RetVal)
            {
#endif
                /* dataPtr carries inputs + the ResultAEE output slot (written back on completion) */
                pAeeConfig = (Mem_43_MRAM_UTestAddressEncodeLogicCheckConfigType *)dataPtr;
                RetVal = Mem_43_MRAM_UTestAddressEncodeLogicCheck(instanceId, pAeeConfig);
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
            }
#endif
        }
            break;
        case MEM_43_MRAM_HWSERVICEID_UTEST_ECC_LOGIC_CHECK:
        {
            Mem_43_MRAM_UTestECCLogicCheckConfigType *pEccConfig;
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
            /* Perform the input parameters checking */
            RetVal = Mem_43_MRAM_CheckDevErrorCommon_HwSpecificService(instanceId, hwServiceId, dataPtr, lengthPtr);
            if ((Std_ReturnType)E_OK == RetVal)
            {
#endif
                /* dataPtr carries inputs + the embedded Result output slot (written back on completion) */
                pEccConfig = (Mem_43_MRAM_UTestECCLogicCheckConfigType *)dataPtr;
                RetVal = Mem_43_MRAM_UTestECCLogicCheck(instanceId, pEccConfig);
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
            }
#endif
        }
            break;
        case MEM_43_MRAM_HWSERVICEID_UTEST_ARRAY_INTEGRITY_CHECK:
        {
            Mem_43_MRAM_UTestArrayIntegrityCheckConfigType *pAicConfig;
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
            /* Perform the input parameters checking */
            RetVal = Mem_43_MRAM_CheckDevErrorCommon_HwSpecificService(instanceId, hwServiceId, dataPtr, lengthPtr);
            if ((Std_ReturnType)E_OK == RetVal)
            {
#endif
                /* dataPtr carries inputs + the embedded Result output slot (written back on completion) */
                pAicConfig = (Mem_43_MRAM_UTestArrayIntegrityCheckConfigType *)dataPtr;
                RetVal = Mem_43_MRAM_UTestArrayIntegrityCheck(instanceId, pAicConfig);
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
            }
#endif
        }
            break;
#endif /* MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON */
        default:
            RetVal = E_MEM_SERVICE_NOT_AVAIL;
            break;
    }
#endif /* MEM_43_MRAM_HW_SERVICE == STD_ON */

#if (MEM_43_MRAM_HW_SERVICE != STD_ON)
    (void)instanceId;
    (void)hwServiceId;
    (void)dataPtr;
    (void)lengthPtr;
    RetVal = E_MEM_SERVICE_NOT_AVAIL;
#elif (MEM_43_MRAM_DEV_ERROR_DETECT != STD_ON)
    /* lengthPtr is consumed only by the development-error checks; when those are
       compiled out reference it explicitly so it is not reported as unused. */
    (void)lengthPtr;
#endif

    return RetVal;
}


/**
 * @brief        Propagates an ECC error to the memory upper layers
 *
 * @details      This service can be used to report an access error in case
 *               the Mem driver cannot provide the access error information - typically for ECC faults.
 *               It is called by the system ECC handler to propagate an ECC error to the memory upper layers.
 *
 * @param[in]    InstanceId    ID of the related memory driver instance.
 *
 * @param[inout] None
 *
 * @param[out]   None
 *
 * @return       None
 *
 * @api
 *
 * @implements   Mem_43_MRAM_PropagateError_Activity
 */
void Mem_43_MRAM_PropagateError(Mem_43_MRAM_InstanceIdType InstanceId)
{
    uint32 Index;
    Mem_43_MRAM_JobRuntimeInfoType *JobRuntimeInfo;
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
    uint32 ErrorId;
    /* Checks if the Mem module has been initialized */
    ErrorId = Mem_43_MRAM_ValidateModuleInitialized();

    if (MEM_43_MRAM_E_OK == ErrorId)
    {
#endif /* MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON */
        /* Check if InstanceId is consistent with configuration */
        /* Get the mem index number according to the mem instance id */
        Index = Mem_43_MRAM_GetInstanceIndex(InstanceId);
#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
        if (MEM_43_MRAM_MEM_INSTANCE_INDEX_INVALID == Index)
        {
            /* The provided InstanceId is inconsistent with the configuration */
            ErrorId = MEM_43_MRAM_E_PARAM_INSTANCE_ID;
        }
    }

    if (MEM_43_MRAM_E_OK != ErrorId)
    {
        /* Report the error */
        Mem_43_MRAM_ReportDevError(InstanceId, MEM_43_MRAM_PROPAGATE_ERROR_ID, ErrorId);
    }
    else
    {
#endif /* MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON */
        JobRuntimeInfo = Mem_43_MRAM_GetJobRuntimeInfo();
        if (Index < MEM_43_MRAM_MEM_INSTANCE_INDEX_INVALID)
        {
            /* Start of exclusive area */
            SchM_Enter_Mem_43_MRAM_MEM_EXCLUSIVE_AREA_05();

            JobRuntimeInfo[Index].JobType = MEM_43_MRAM_JOB_NONE;
            /* Set the job result code to MEM_ECC_UNCORRECTED */
            JobRuntimeInfo[Index].JobResult = MEM_43_MRAM_ECC_UNCORRECTED;

            /* End of exclusive area */
            SchM_Exit_Mem_43_MRAM_MEM_EXCLUSIVE_AREA_05();
        }

#if (MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON)
    }
#endif /* MEM_43_MRAM_DEV_ERROR_DETECT == STD_ON */
}
/*==================================================================================================
                                       GLOBAL FUNCTIONS (Scheduled Functions)
==================================================================================================*/

/**
 * @brief            Service to handle the requested jobs and the internal management operations.
 *
 * @details          Service to handle the requested jobs and the internal management operations.
 *
 * @param[in]    None
 *
 * @param[inout] None
 *
 * @param[out]   None
 *
 * @return       None
 *
 * @api
 *
 * @pre              The module has to be initialized.
 *
 * @note             This function have to be called cyclically by the Basic Software Module;
 *                   it will do nothing if there aren't pending job.
 *
 * @implements       Mem_43_MRAM_MainFunction_Activity
 */
void Mem_43_MRAM_MainFunction(void)
{
    uint32 InstanceIndex;
    Mem_43_MRAM_JobRuntimeInfoType *JobRuntimeInfo;

    /* SWS_BSW_00037 - If the module is not initialized and the main function is executed
       then no error shall be reported and the main function shall return immediately.
    */
    uint8 UserId;
#if (MEM_43_MRAM_MULTIPARTITION_ENABLED == STD_ON)
    UserId = OsIf_GetUserId();
#else
    UserId = 0U;
#endif
    if (NULL_PTR != (*Mem_43_MRAM_pConfigPtr_PartitionMap[UserId]))
    {
        JobRuntimeInfo = Mem_43_MRAM_GetJobRuntimeInfo();
        for (InstanceIndex = 0U; InstanceIndex < MEM_43_MRAM_INSTANCE_COUNT; InstanceIndex++)
        {
            /* Check if there was a pending job in each instance */
            if (MEM_43_MRAM_JOB_PENDING == JobRuntimeInfo[InstanceIndex].JobResult)
            {
                /* Process the requested job for this mem instance */
                Mem_43_MRAM_ProcessRequestedJobs(InstanceIndex, JobRuntimeInfo);
            }
        }
    }
}


#define MEM_43_MRAM_STOP_SEC_CODE
#include "Mem_43_MRAM_MemMap.h"


#ifdef __cplusplus
}
#endif

/** @} */

