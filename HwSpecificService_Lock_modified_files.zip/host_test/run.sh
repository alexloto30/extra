#!/bin/bash
# Host test of the OTA-related code in MRam_Ip.c (ARTDCMEM-2418): OTA decode (MRam_Ip_GetOtaNumFixed),
# Code MRAM data sections mapping (MRam_Ip_GetRebasedAddress and MRAM_IP_REBASED_ADDRESS: last size bytes of
# the active and of the passive half, +/- one half while swapped) and the F16ASM LOCK0 fixed-pair decode.
# - Extracts MRam_Ip.c from MRam_Ip_GetOtaNumFixed's comment to the end of MRam_Ip_CheckF16asmLockLarge.
# - Renders the MRAM_IP_DATA_IN_CODE_MRAM_*_U32 macros from the EB template MRam_Ip_Cfg.h.
# - Builds the C test with the feature ON for several sizes and once with the feature OFF,
#   then evaluates the XDM validations (xdm_check.py, lxml).
# Usage: ./run.sh   (from any directory)
set -e
D=$(cd "$(dirname "$0")" && pwd)
PKG="$D/../Mem_43_MRAM_TS_T40D85M10I0R0"
# LOCAL MACROS: the MRAM_IP_DATA_IN_CODE_MRAM #if/#else block (offsets and MRAM_IP_OTA_* macros)
tr -d '\r' < "$PKG/src/MRam_Ip.c" | awk '
  /^#define MRAM_IP_BITS_PER_BYTE/ {f=1; next}
  f {print}
  f && /^#endif \/\* STD_ON == MRAM_IP_DATA_IN_CODE_MRAM \*\// {exit}' > "$D/macros.c"
tr -d '\r' < "$PKG/src/MRam_Ip.c" | awk '
  /^ \* @brief   Read the OTA configuration/ {f=1; print "/**"}
  f {print}
  f && /^static boolean MRam_Ip_CheckF16asmLockLarge\(/ {g=1}
  g && /^}$/ {exit}' > "$D/block.c"
CC="gcc -std=c99 -Wall -Wextra -Wconversion -Wno-sign-compare -Wno-unused-function"
for sz in 0x2800 0x100000 0x800000 0xC00000; do
  tr -d '\r' < "$PKG/generate_PC/include/MRam_Ip_Cfg.h" \
    | grep -E '^#define MRAM_IP_DATA_IN_CODE_MRAM_[A-Z]+_U32' \
    | sed "s/\[!\"num:inttohex(MemAutosarExt\/MemDataInMRamCodeSize)\"!\]/$sz/" > "$D/cfg_gen.h"
  $CC -DFEATURE_ON -o "$D/ota_rebase_test" "$D/ota_rebase_test.c"
  echo "=== feature ON, region size $sz"; "$D/ota_rebase_test"
done
$CC -o "$D/ota_rebase_test" "$D/ota_rebase_test.c"
echo "=== feature OFF"; "$D/ota_rebase_test"
# The mapping is an involution, so it must be applied once per request: the data APIs and the public lock APIs
# rebase the requested address; the lock workers (...AtAddress) and ConfigureLocksInRange get an already rebased
# address (from ProcessOperation or from the public lock API) and must not rebase it again.
body() { tr -d '\r' < "$PKG/src/MRam_Ip.c" | awk -v f="$1" '$0 ~ ("^(static )?MRam_Ip_StatusType " f "\\(") {g=1} g {print} g && /^}$/ {exit}'; }
for f in MRam_Ip_GetLock MRam_Ip_ClearLock MRam_Ip_SetLock; do
  if [ "$(body $f | grep -c "MRAM_IP_REBASED_ADDRESS(Address)")" != 1 ] || [ "$(body $f | grep -c "${f}AtAddress(")" != 1 ]; then
    echo "FAIL $f does not rebase exactly once into ${f}AtAddress"; exit 1; fi
  if body "${f}AtAddress" | grep -q "MRAM_IP_REBASED_ADDRESS"; then echo "FAIL ${f}AtAddress rebases the address"; exit 1; fi
done
if body MRam_Ip_ConfigureLocksInRange | grep -q "MRAM_IP_REBASED_ADDRESS\|MRam_Ip_[GCS][a-z]*Lock("; then
  echo "FAIL ConfigureLocksInRange rebases or calls a public lock API"; exit 1; fi
n=$(grep -c "MRAM_IP_REBASED_ADDRESS(" "$PKG/src/MRam_Ip.c")
if [ "$n" = 10 ]; then echo "ok   MRAM_IP_REBASED_ADDRESS: 2 definitions + 5 data API + 3 public lock API call sites, none in the lock workers"
else echo "FAIL MRAM_IP_REBASED_ADDRESS occurrences: $n (expected 10)"; exit 1; fi
python3 "$D/xdm_check.py"
