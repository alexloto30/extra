/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : MRAM
*   Dependencies         : None
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
*   Copyright 2024 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
 * @file       Mem_43_MRAM_Ipw.c
 *
 * @addtogroup MEM_43_MRAM Driver
 * implement   Mem_43_MRAM_Ipw.c_Artifact
 *
 * @{
 */

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
                                         INCLUDE FILES
 1) system and project includes
 2) needed interfaces from external units
 3) internal and external interfaces from this unit
==================================================================================================*/
#include "Mem_43_MRAM.h"
#include "Mem_43_MRAM_Ipw.h"
#include "MRam_Ip.h"
/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define MEM_43_MRAM_IPW_VENDOR_ID_C                           43
#define MEM_43_MRAM_IPW_AR_RELEASE_MAJOR_VERSION_C            4
#define MEM_43_MRAM_IPW_AR_RELEASE_MINOR_VERSION_C            9
#define MEM_43_MRAM_IPW_AR_RELEASE_REVISION_VERSION_C         0
#define MEM_43_MRAM_IPW_SW_MAJOR_VERSION_C                    1
#define MEM_43_MRAM_IPW_SW_MINOR_VERSION_C                    0
#define MEM_43_MRAM_IPW_SW_PATCH_VERSION_C                    0

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if current file and Mem_43_MRAM.h header file are of the same vendor */
#if (MEM_43_MRAM_IPW_VENDOR_ID_C != MEM_43_MRAM_VENDOR_ID)
    #error "Mem_43_MRAM_Ipw.c and Mem_43_MRAM.h have different vendor ids"
#endif
/* Check if current file and Mem_43_MRAM.h header file are of the same Autosar version */
#if ((MEM_43_MRAM_IPW_AR_RELEASE_MAJOR_VERSION_C    != MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION) || \
     (MEM_43_MRAM_IPW_AR_RELEASE_MINOR_VERSION_C    != MEM_43_MRAM_AR_RELEASE_MINOR_VERSION) || \
     (MEM_43_MRAM_IPW_AR_RELEASE_REVISION_VERSION_C != MEM_43_MRAM_AR_RELEASE_REVISION_VERSION) \
    )
    #error "AutoSar Version Numbers of Mem_43_MRAM_Ipw.c and Mem_43_MRAM.h are different"
#endif
/* Check if current file and Mem_43_MRAM.h header file are of the same Software version */
#if ((MEM_43_MRAM_IPW_SW_MAJOR_VERSION_C != MEM_43_MRAM_SW_MAJOR_VERSION) || \
     (MEM_43_MRAM_IPW_SW_MINOR_VERSION_C != MEM_43_MRAM_SW_MINOR_VERSION) || \
     (MEM_43_MRAM_IPW_SW_PATCH_VERSION_C != MEM_43_MRAM_SW_PATCH_VERSION) \
    )
    #error "Software Version Numbers of Mem_43_MRAM_Ipw.c and Mem_43_MRAM.h are different"
#endif

/* Check if current file and Mem_43_MRAM_Ipw.h header file are of the same vendor */
#if (MEM_43_MRAM_IPW_VENDOR_ID_C != MEM_43_MRAM_IPW_VENDOR_ID_H)
    #error "Mem_43_MRAM_Ipw.c and Mem_43_MRAM_Ipw.h have different vendor ids"
#endif
/* Check if current file and Mem_43_MRAM_Ipw.h header file are of the same Autosar version */
#if ((MEM_43_MRAM_IPW_AR_RELEASE_MAJOR_VERSION_C    != MEM_43_MRAM_IPW_AR_RELEASE_MAJOR_VERSION_H) || \
     (MEM_43_MRAM_IPW_AR_RELEASE_MINOR_VERSION_C    != MEM_43_MRAM_IPW_AR_RELEASE_MINOR_VERSION_H) || \
     (MEM_43_MRAM_IPW_AR_RELEASE_REVISION_VERSION_C != MEM_43_MRAM_IPW_AR_RELEASE_REVISION_VERSION_H) \
    )
    #error "AutoSar Version Numbers of Mem_43_MRAM_Ipw.c and Mem_43_MRAM_Ipw.h are different"
#endif
/* Check if current file and Mem_43_MRAM_Ipw.h header file are of the same Software version */
#if ((MEM_43_MRAM_IPW_SW_MAJOR_VERSION_C != MEM_43_MRAM_IPW_SW_MAJOR_VERSION_H) || \
     (MEM_43_MRAM_IPW_SW_MINOR_VERSION_C != MEM_43_MRAM_IPW_SW_MINOR_VERSION_H) || \
     (MEM_43_MRAM_IPW_SW_PATCH_VERSION_C != MEM_43_MRAM_IPW_SW_PATCH_VERSION_H) \
    )
    #error "Software Version Numbers of Mem_43_MRAM_Ipw.c and Mem_43_MRAM_Ipw.h are different"
#endif

/* Check if current file and MRam_Ip.h header file are of the same vendor */
#if (MEM_43_MRAM_IPW_VENDOR_ID_C != MRAM_IP_VENDOR_ID_H)
    #error "Mem_43_MRAM_Ipw.c and MRam_Ip.h have different vendor ids"
#endif
/* Check if current file and MRam_Ip.h header file are of the same Autosar version */
#if ((MEM_43_MRAM_IPW_AR_RELEASE_MAJOR_VERSION_C    != MRAM_IP_AR_RELEASE_MAJOR_VERSION_H) || \
     (MEM_43_MRAM_IPW_AR_RELEASE_MINOR_VERSION_C    != MRAM_IP_AR_RELEASE_MINOR_VERSION_H) || \
     (MEM_43_MRAM_IPW_AR_RELEASE_REVISION_VERSION_C != MRAM_IP_AR_RELEASE_REVISION_VERSION_H) \
    )
    #error "AutoSar Version Numbers of Mem_43_MRAM_Ipw.c and MRam_Ip.h are different"
#endif
/* Check if current file and MRam_Ip.h header file are of the same Software version */
#if ((MEM_43_MRAM_IPW_SW_MAJOR_VERSION_C != MRAM_IP_SW_MAJOR_VERSION_H) || \
     (MEM_43_MRAM_IPW_SW_MINOR_VERSION_C != MRAM_IP_SW_MINOR_VERSION_H) || \
     (MEM_43_MRAM_IPW_SW_PATCH_VERSION_C != MRAM_IP_SW_PATCH_VERSION_H) \
    )
    #error "Software Version Numbers of Mem_43_MRAM_Ipw.c and MRam_Ip.h are different"
#endif

/*==================================================================================================
                                       GLOBAL VARIABLES
==================================================================================================*/

/*==================================================================================================
 *                           LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/

/*==================================================================================================
                                        LOCAL MACROS
==================================================================================================*/

/*==================================================================================================
                                       LOCAL VARIABLES
==================================================================================================*/

/*==================================================================================================
                                       LOCAL CONSTANTS
==================================================================================================*/

/*==================================================================================================
                                   LOCAL FUNCTION PROTOTYPES
==================================================================================================*/

/*==================================================================================================
                                       LOCAL FUNCTIONS
==================================================================================================*/

#define MEM_43_MRAM_START_SEC_CODE
#include "Mem_43_MRAM_MemMap.h"

/*
 * Description:    Update the job status after processing a chunk
 */
static void Mem_43_MRAM_IPW_UpdateJobProcessedLength(
    Mem_43_MRAM_JobRuntimeInfoType   *JobInfo,
    Mem_43_MRAM_LengthType            TransferLength
)
{
    /* Move to the next chunk of job */
    JobInfo->Address += TransferLength;
    JobInfo->Length  -= TransferLength;

    /* Update data buffer pointer if required (Read / Compare use DataPtr) */
    if (NULL_PTR != JobInfo->DataPtr)
    {
        JobInfo->DataPtr = &(JobInfo->DataPtr[TransferLength]);
    }

    /* Advance the const write-source pointer as well so multi-chunk writes stay consistent
     * (Write jobs carry the buffer in SrcDataPtr while DataPtr is left NULL). */
    if (NULL_PTR != JobInfo->SrcDataPtr)
    {
        JobInfo->SrcDataPtr = &(JobInfo->SrcDataPtr[TransferLength]);
    }
}

/**
 * @brief    Translate the return code from IP layer to high-level driver status.
 * @details  Maps low-level MRAM IP status codes to higher-level memory driver result codes,
 *           preserving important error information while standardizing the interface.
 *
 * @param[in] IpReturnValue  Status code returned from MRAM IP driver
 * @return    Mem_43_MRAM_JobResultType  Translated status code for high-level driver
 */
static Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_TranslateReturnCode(MRam_Ip_StatusType IpReturnValue)
{
    Mem_43_MRAM_JobResultType JobResult;

    /* Translate IP layer status to high-level driver status */
    switch (IpReturnValue)
    {
        /* Successful operation */
        case MRAM_IP_STATUS_SUCCESS:
            /* The job has completed successfully */
            JobResult = MEM_43_MRAM_JOB_OK;
            break;

        /* Operation in progress */
        case MRAM_IP_STATUS_WRITE_BUSY:
            /* The job is still being processed */
            JobResult = MEM_43_MRAM_JOB_PENDING;
            break;

        /* ECC errors */
        case MRAM_IP_STATUS_ECC_UNCORRECTED:
        case MRAM_IP_STATUS_ECC_TRIPLE_BIT_ERROR:
        case MRAM_IP_STATUS_ECC_DOUBLE_BIT_ERROR:
        case MRAM_IP_STATUS_ECC_READ_DATA:
        case MRAM_IP_STATUS_ECC_EDC_AFTER_ECC_ERROR:
            /* Uncorrectable ECC error detected during memory access */
            JobResult = MEM_43_MRAM_ECC_UNCORRECTED;
            break;

        case MRAM_IP_STATUS_ECC_CORRECTED:
        case MRAM_IP_STATUS_ECC_CONTROL_ERROR:
            /* Correctable ECC error detected during memory access */
            JobResult = MEM_43_MRAM_ECC_CORRECTED;
            break;

        /* Comparison mismatches */
        case MRAM_IP_STATUS_COMPARE_MISMATCH:
            /* Data comparison resulted in mismatch */
            JobResult = MEM_43_MRAM_INCONSISTENT;
            break;

        /* Write protection errors */
        case MRAM_IP_STATUS_WRITE_PROTECTED:
        case MRAM_IP_STATUS_PARTITION_LOCKED:
        case MRAM_IP_STATUS_ERASE_OTP_NOT_ALLOWED:
            /* Memory area is protected from modification */
            JobResult = MEM_43_MRAM_JOB_FAILED;
            break;

        /* Read errors */
        case MRAM_IP_STATUS_READ_ERROR:
        case MRAM_IP_STATUS_READ_NOT_ALLOWED:
        case MRAM_IP_STATUS_ERROR_READ_PATH:
        case MRAM_IP_STATUS_READ_WAIT_STATE_ERROR:
        case MRAM_IP_STATUS_ADDRESS_ENCODE_ERROR:
            /* Error occurred during read operation */
            JobResult = MEM_43_MRAM_JOB_FAILED;
            break;

        /* Write errors */
        case MRAM_IP_STATUS_WRITE_ERROR:
        case MRAM_IP_STATUS_WRITE_COLLISION_ERROR:
        case MRAM_IP_STATUS_WRITE_ADDRESS_ERROR:
        case MRAM_IP_STATUS_WRITE_TIMEOUT_ERROR:
        case MRAM_IP_STATUS_ERROR_WRITE_PATH:
        case MRAM_IP_STATUS_POSTED_WRITE_ERROR:
            /* Error occurred during write operation */
            JobResult = MEM_43_MRAM_JOB_FAILED;
            break;

        /* Timeout errors */
        case MRAM_IP_STATUS_WRITE_TIMEOUT_BUSY:
        case MRAM_IP_STATUS_WRITE_TIMEOUT_GAIN_SEMAPHORE:
        case MRAM_IP_STATUS_ERROR_TIMEOUT:
            /* Operation timed out */
            JobResult = MEM_43_MRAM_JOB_FAILED;
            break;

        /* Blank check specific errors */
        case MRAM_IP_STATUS_ERROR_BLANK_CHECK:
            /* Memory area is not blank */
            JobResult = MEM_43_MRAM_INCONSISTENT;
            break;

        /* Default case for any other errors */
        default:
            /* Unhandled status code - consider adding explicit handling if this occurs frequently */
            JobResult = MEM_43_MRAM_JOB_FAILED;
            break;
    }

    return JobResult;
}

/*==================================================================================================
                                       GLOBAL FUNCTIONS
==================================================================================================*/

/**
 * @brief        Initialize MRAM memory devices
 * @details      Initializes all internal memory units configured for the MRAM driver
 *               by calling the IP layer initialization for each configured unit.
 *
 * @param[in]    InstanceIndex  Index of the MRAM instance to initialize
 *
 * @return       Std_ReturnType
 * @retval       E_OK           Initialization completed successfully
 * @retval       E_NOT_OK       Unit configuration is missing
 */
Std_ReturnType Mem_43_MRAM_IPW_Init(uint32 InstanceIndex)
{
    const Mem_43_MRAM_InternalUnitType *InternalUnits = Mem_43_MRAM_pConfigPtr->MemDevices->InternalUnits;
    Std_ReturnType RetVal = (Std_ReturnType)E_OK;
    MRam_Ip_InstanceIdType instanceId = (MRam_Ip_InstanceIdType)InstanceIndex;
    uint32 Unit;

    /* Initialize each configured internal unit.
     * Well-formed loop: the counter Unit is the only object modified in the loop expression
     * and it is the only object tested in the controlling expression. Early termination on a
     * missing configuration is handled by the break below. */
    for (Unit = 0U; Unit < MEM_43_MRAM_INTERNAL_UNIT_COUNT; Unit++)
    {
        if (NULL_PTR != InternalUnits[Unit].InternalConfig)
        {
            /* Use configuration "InternalConfig" to initialize IP driver */
            MRam_Ip_Init(InternalUnits[Unit].InternalConfig, (MRam_Ip_InstanceIdType)instanceId);
        }
        else
        {
            /* Missing configuration for this unit */
            RetVal = (Std_ReturnType)E_NOT_OK;
            break;
        }
    }


    return RetVal;
}

/**
 * @brief        Deinitialize MRAM memory devices
 * @details      Deinitializes all internal memory units configured for the MRAM driver
 *               by calling the IP layer deinitialization for each configured unit.
 *
 * @param[in]    InstanceIndex  Index of the MRAM instance to deinitialize
 *
 * @return       void
 */
void Mem_43_MRAM_IPW_DeInit(uint32 InstanceIndex)
{
    const Mem_43_MRAM_InternalUnitType *InternalUnits = Mem_43_MRAM_pConfigPtr->MemDevices->InternalUnits;
    MRam_Ip_InstanceIdType instanceId = (MRam_Ip_InstanceIdType)InstanceIndex;
    uint32 Unit;

    /* Deinitialize each configured internal unit */
    for (Unit = 0U; Unit < MEM_43_MRAM_INTERNAL_UNIT_COUNT; Unit++)
    {
        if (NULL_PTR != InternalUnits[Unit].InternalConfig)
        {
            /* Deinitialize the IP driver for this instance (no per-unit config needed) */
            MRam_Ip_DeInit((MRam_Ip_InstanceIdType)instanceId);
        }
    }
}

/**
 * @brief          IP wrapper read function.
 * @details        Routes read operations to the appropriate low level IP function.
 *                 Handles job state updates and error translation.
 *
 * @param[in]      InstanceIndex       Index of the memory instance to use
 * @param[in,out]  JobInfo             Pointer to job information structure containing address,
 *                                     data buffer pointer, and length information
 *
 * @return         Mem_43_MRAM_JobResultType
 * @retval         MEM_43_MRAM_JOB_OK          Read operation completed successfully
 * @retval         MEM_43_MRAM_JOB_PENDING     Device is busy, try again later
 * @retval         MEM_43_MRAM_JOB_FAILED      Read operation failed
 * @retval         MEM_43_MRAM_ECC_CORRECTED   Correctable ECC error occurred
 * @retval         MEM_43_MRAM_ECC_UNCORRECTED Uncorrectable ECC error occurred
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_Read(
    uint32                           InstanceIndex,
    Mem_43_MRAM_JobRuntimeInfoType  *JobInfo
)
{
    Mem_43_MRAM_JobResultType JobResult = MEM_43_MRAM_JOB_OK; /* Initialize */
    Mem_43_MRAM_LengthType TransferLength = 0U;
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    MRam_Ip_InstanceIdType instanceId = (MRam_Ip_InstanceIdType)InstanceIndex;

    /* Calculate length of data transfer */
    TransferLength = (Mem_43_MRAM_LengthType)JobInfo->Length;

    if (0U == TransferLength)
    {
        /* Nothing to read, consider job complete */
        JobResult = MEM_43_MRAM_JOB_OK;
    }
    else
    {
        /* Read data from MRAM memory device */
        Status = MRam_Ip_Read(JobInfo->Address, JobInfo->DataPtr, TransferLength, instanceId);

        /* Translate IP status to high-level driver status */
        JobResult = Mem_43_MRAM_IPW_TranslateReturnCode(Status);

        /* Update job length only for successful read operations */
        if ((MEM_43_MRAM_JOB_OK == JobResult) || (MEM_43_MRAM_ECC_CORRECTED == JobResult))
        {
            Mem_43_MRAM_IPW_UpdateJobProcessedLength(JobInfo, TransferLength);
        }
    }

    return JobResult;
}

#if (MEM_43_MRAM_HW_COMPARE_SERVICE == STD_ON)
/**
 * @brief          IP wrapper comparison check function.
 * @details        Routes memory comparison operations to the appropriate low level IP function.
 *                 Compares memory content with provided data buffer and translates hardware
 *                 status codes to high-level results.
 *
 * @param[in]      InstanceIndex       Index of the memory instance to use
 * @param[in,out]  JobInfo             Pointer to job information structure containing address,
 *                                     data buffer pointer, and length information
 *
 * @return         Mem_43_MRAM_JobResultType
 * @retval         MEM_43_MRAM_JOB_OK          Comparison completed successfully, data matches
 * @retval         MEM_43_MRAM_JOB_PENDING     Device is busy, try again later
 * @retval         MEM_43_MRAM_INCONSISTENT    Data comparison mismatch detected
 * @retval         MEM_43_MRAM_ECC_CORRECTED   Correctable ECC error occurred
 * @retval         MEM_43_MRAM_ECC_UNCORRECTED Uncorrectable ECC error occurred
 * @retval         MEM_43_MRAM_JOB_FAILED      Comparison operation failed
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_Compare(
    uint32                             InstanceIndex,
    Mem_43_MRAM_JobRuntimeInfoType  * JobInfo
)
{
    Mem_43_MRAM_JobResultType JobResult = MEM_43_MRAM_JOB_OK; /* Initialize */
    Mem_43_MRAM_LengthType TransferLength = 0U;
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    MRam_Ip_InstanceIdType instanceId = (MRam_Ip_InstanceIdType)InstanceIndex;

    /* length of data transfer */
    TransferLength = (Mem_43_MRAM_LengthType)JobInfo->Length;

    if (0U == TransferLength)
    {
        /* Nothing to compare, consider job complete */
        JobResult = MEM_43_MRAM_JOB_OK;
    }
    else
    {
        /* Perform comparison operation */
        Status = MRam_Ip_Compare(JobInfo->Address, JobInfo->DataPtr, TransferLength, instanceId);

        /* Translate IP status to high-level driver status */
        JobResult = Mem_43_MRAM_IPW_TranslateReturnCode(Status);

        /* Update job length only for successful comparison operations */

        if ((MEM_43_MRAM_JOB_OK == JobResult) || (MEM_43_MRAM_ECC_CORRECTED == JobResult))
        {
            Mem_43_MRAM_IPW_UpdateJobProcessedLength(JobInfo, TransferLength);
        }
    }

    return JobResult;
}
#endif /* MEM_43_MRAM_HW_COMPARE_SERVICE == STD_ON */

#if (MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON)
/**
 * @brief          IP wrapper UTest Reference Recovery/Refresh function.
 * @details        Executes the synchronous one-shot MRam_Ip_UTestReferenceRecoveryRefresh BIST
 *                 operation. This service has no byte length; the sentinel Length set by the builder
 *                 is cleared here so the asynchronous pending loop terminates after this single call.
 *
 * @param[in]      InstanceIndex       Index of the memory instance to use
 * @param[in,out]  JobInfo             Job runtime information (Length is cleared on completion)
 *
 * @return         Mem_43_MRAM_JobResultType
 * @retval         MEM_43_MRAM_JOB_OK        Operation completed successfully
 * @retval         MEM_43_MRAM_JOB_FAILED    Operation failed (including timeout / busy)
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_UTestReferenceRecoveryRefresh(
    uint32                          InstanceIndex,
    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
)
{
    MRam_Ip_InstanceIdType instanceId = (MRam_Ip_InstanceIdType)InstanceIndex;
    MRam_Ip_StatusType Status;
    Mem_43_MRAM_JobResultType JobResult;

    /* Synchronous one-shot BIST operation: no address, no buffer, no chunking.
     * MRam_Ip_UTestReferenceRecoveryRefresh handles Enable/Disable UTest internally. */
    Status = MRam_Ip_UTestReferenceRecoveryRefresh(instanceId);

    /* Clear the sentinel length so the asynchronous pending loop terminates after this single call. */
    JobInfo->Length = 0U;

    /* Terminal mapping: SUCCESS -> JOB_OK, anything else (including WRITE_TIMEOUT_BUSY) -> JOB_FAILED.
     * Deliberately NOT using Mem_43_MRAM_IPW_TranslateReturnCode, whose
     * MRAM_IP_STATUS_WRITE_TIMEOUT_BUSY -> JOB_PENDING mapping would strand this one-shot job forever. */
    if (MRAM_IP_STATUS_SUCCESS == Status)
    {
        JobResult = MEM_43_MRAM_JOB_OK;
    }
    else
    {
        JobResult = MEM_43_MRAM_JOB_FAILED;
    }

    return JobResult;
}
#endif /* MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON */

#if (MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON)
/**
 * @brief          IP wrapper UTest EDC-after-ECC Logic Check function.
 * @details        Runs the synchronous one-shot MRam_Ip_UTestEDCAfterECCLogicCheck BIST. Inputs and the
 *                 ResultEEE output slot are carried by the caller's config struct reached via
 *                 JobInfo->DataPtr; ResultEEE is written back in place. The sentinel Length is cleared
 *                 so the asynchronous pending loop terminates after this single call.
 *                 UTest mode is enabled internally before the BIST operation.
 *
 * @param[in]      InstanceIndex       Index of the memory instance to use
 * @param[in,out]  JobInfo             Job runtime information (DataPtr -> config struct; Length cleared)
 *
 * @return         Mem_43_MRAM_JobResultType
 * @retval         MEM_43_MRAM_JOB_OK        Check completed successfully
 * @retval         MEM_43_MRAM_JOB_FAILED    Operation failed (including timeout / busy)
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_EDCAfterECCLogicCheck(
    uint32                          InstanceIndex,
    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
)
{
    MRam_Ip_InstanceIdType instanceId = (MRam_Ip_InstanceIdType)InstanceIndex;
    MRam_Ip_StatusType Status;
    Mem_43_MRAM_UTestEDCAfterECCLogicCheckConfigType *pConfig =
        (Mem_43_MRAM_UTestEDCAfterECCLogicCheckConfigType *)JobInfo->DataPtr;
    Mem_43_MRAM_JobResultType JobResult;

    /* Inputs come from the caller's config struct; ResultEEE is written back in place.
     * MRam_Ip_UTestEDCAfterECCLogicCheck handles Enable/Disable UTest internally. */
    Status = MRam_Ip_UTestEDCAfterECCLogicCheck(pConfig->Address,
                                                pConfig->DataValues,
                                                pConfig->DataLength,
                                                &pConfig->ResultEEE,
                                                instanceId);

    /* Clear the sentinel length so the asynchronous pending loop terminates after this single call. */
    JobInfo->Length = 0U;

    if (MRAM_IP_STATUS_SUCCESS == Status)
    {
        JobResult = MEM_43_MRAM_JOB_OK;
    }
    else
    {
        JobResult = MEM_43_MRAM_JOB_FAILED;
    }

    return JobResult;
}
#endif /* MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON */

#if (MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON)
/**
 * @brief          IP wrapper UTest Address-Encode Logic Check function.
 * @details        Runs the synchronous one-shot MRam_Ip_UTestAddressEncodeLogicCheck BIST. Inputs and
 *                 the ResultAEE output slot are carried by the caller's config struct reached via
 *                 JobInfo->DataPtr; ResultAEE is written back in place. The sentinel Length is cleared
 *                 so the asynchronous pending loop terminates after this single call.
 *                 UTest mode is enabled internally before the BIST operation.
 *
 * @param[in]      InstanceIndex       Index of the memory instance to use
 * @param[in,out]  JobInfo             Job runtime information (DataPtr -> config struct; Length cleared)
 *
 * @return         Mem_43_MRAM_JobResultType
 * @retval         MEM_43_MRAM_JOB_OK        Check completed successfully
 * @retval         MEM_43_MRAM_JOB_FAILED    Operation failed (including timeout / busy)
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_AddressEncodeLogicCheck(
    uint32                          InstanceIndex,
    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
)
{
    MRam_Ip_InstanceIdType instanceId = (MRam_Ip_InstanceIdType)InstanceIndex;
    MRam_Ip_StatusType Status;
    Mem_43_MRAM_UTestAddressEncodeLogicCheckConfigType *pConfig =
        (Mem_43_MRAM_UTestAddressEncodeLogicCheckConfigType *)JobInfo->DataPtr;
    Mem_43_MRAM_JobResultType JobResult;

    /* Inputs come from the caller's config struct; ResultAEE is written back in place.
     * MRam_Ip_UTestAddressEncodeLogicCheck handles Enable/Disable UTest internally. */
    Status = MRam_Ip_UTestAddressEncodeLogicCheck(pConfig->Address,
                                                  pConfig->AeisValue,
                                                  pConfig->AeiValue,
                                                  pConfig->AeicValue,
                                                  pConfig->AeioValue,
                                                  &pConfig->ResultAEE,
                                                  instanceId);

    /* Clear the sentinel length so the asynchronous pending loop terminates after this single call. */
    JobInfo->Length = 0U;

    if (MRAM_IP_STATUS_SUCCESS == Status)
    {
        JobResult = MEM_43_MRAM_JOB_OK;
    }
    else
    {
        JobResult = MEM_43_MRAM_JOB_FAILED;
    }

    return JobResult;
}
#endif /* MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON */

#if (MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON)
/**
 * @brief          IP wrapper UTest ECC Logic Check function.
 * @details        Runs the synchronous one-shot MRam_Ip_UTestECCLogicCheck BIST. Inputs and the
 *                 embedded Result struct are carried by the caller's config reached via
 *                 JobInfo->DataPtr; Result is written back in place. The sentinel Length is cleared
 *                 so the asynchronous pending loop terminates after this single call.
 *                 UTest mode is enabled internally before the BIST operation.
 *
 * @param[in]      InstanceIndex       Index of the memory instance to use
 * @param[in,out]  JobInfo             Job runtime information (DataPtr -> config struct; Length cleared)
 *
 * @return         Mem_43_MRAM_JobResultType
 * @retval         MEM_43_MRAM_JOB_OK        Check completed successfully
 * @retval         MEM_43_MRAM_JOB_FAILED    Operation failed (including timeout / busy)
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_ECCLogicCheck(
    uint32                          InstanceIndex,
    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
)
{
    MRam_Ip_InstanceIdType instanceId = (MRam_Ip_InstanceIdType)InstanceIndex;
    MRam_Ip_StatusType Status;
    Mem_43_MRAM_UTestECCLogicCheckConfigType *pConfig =
        (Mem_43_MRAM_UTestECCLogicCheckConfigType *)JobInfo->DataPtr;
    Mem_43_MRAM_JobResultType JobResult;

    /* Inputs come from the caller's config struct; the embedded Result is written back in place.
     * MRam_Ip_UTestECCLogicCheck handles Enable/Disable UTest internally. */
    Status = MRam_Ip_UTestECCLogicCheck(pConfig->Address,
                                        pConfig->DataValues,
                                        pConfig->DataLength,
                                        &pConfig->Result,
                                        instanceId);

    /* Clear the sentinel length so the asynchronous pending loop terminates after this single call. */
    JobInfo->Length = 0U;

    if (MRAM_IP_STATUS_SUCCESS == Status)
    {
        JobResult = MEM_43_MRAM_JOB_OK;
    }
    else
    {
        JobResult = MEM_43_MRAM_JOB_FAILED;
    }

    return JobResult;
}
#endif /* MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON */

#if (MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON)
/**
 * @brief          IP wrapper UTest Array Integrity Check function.
 * @details        Runs the synchronous one-shot MRam_Ip_UTestArrayIntegrityCheck BIST. This IP function
 *                 RETURNS the MRam_Ip_ArrayIntegrityCheckType BY VALUE and has NO status enum, so the
 *                 result is copied into the caller's embedded Result slot and the Mem job result is
 *                 DERIVED from the result flags. The sentinel Length is cleared so the asynchronous
 *                 pending loop terminates after this single call.
 *                 UTest mode is enabled internally before the BIST operation.
 *
 * @param[in]      InstanceIndex       Index of the memory instance to use
 * @param[in,out]  JobInfo             Job runtime information (DataPtr -> config struct; Length cleared)
 *
 * @return         Mem_43_MRAM_JobResultType
 * @retval         MEM_43_MRAM_JOB_OK           No error/correction flag set
 * @retval         MEM_43_MRAM_ECC_CORRECTED    Single-bit correction detected (FLAG_SBC)
 * @retval         MEM_43_MRAM_ECC_UNCORRECTED  Double/triple-bit correction detected (FLAG_DBC/FLAG_TBC)
 * @retval         MEM_43_MRAM_JOB_FAILED       Integrity-check error detected (FLAG_ERR)
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_ArrayIntegrityCheck(
    uint32                          InstanceIndex,
    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
)
{
    MRam_Ip_InstanceIdType instanceId = (MRam_Ip_InstanceIdType)InstanceIndex;
    Mem_43_MRAM_JobResultType JobResult;
    Mem_43_MRAM_UTestArrayIntegrityCheckConfigType *pConfig =
        (Mem_43_MRAM_UTestArrayIntegrityCheckConfigType *)JobInfo->DataPtr;

    /* This IP function returns the result struct BY VALUE; copy it into the caller's config in place.
     * MRam_Ip_UTestArrayIntegrityCheck handles Enable/Disable UTest internally. */
    pConfig->Result = MRam_Ip_UTestArrayIntegrityCheck(pConfig->Address,
                                                       pConfig->SequentialAddressing,
                                                       pConfig->ArrayValuesMISR,
                                                       pConfig->ArrayLengthMISR,
                                                       pConfig->EnableBreakpoints,
                                                       instanceId);

    /* Clear the sentinel length so the asynchronous pending loop terminates after this single call. */
    JobInfo->Length = 0U;

    /* No IP status enum: derive the job result from the result flags (full flags remain in Result). */
    if (pConfig->Result.FLAG_ERR)
    {
        JobResult = MEM_43_MRAM_JOB_FAILED;
    }
    else if ((pConfig->Result.FLAG_TBC) || (pConfig->Result.FLAG_DBC))
    {
        JobResult = MEM_43_MRAM_ECC_UNCORRECTED;
    }
    else if (pConfig->Result.FLAG_SBC)
    {
        JobResult = MEM_43_MRAM_ECC_CORRECTED;
    }
    else
    {
        JobResult = MEM_43_MRAM_JOB_OK;
    }

    return JobResult;
}
#endif /* MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON */

#if (MEM_43_MRAM_HW_LOCK_SERVICE == STD_ON)
/**
 * @brief          IP wrapper partition Lock function.
 * @details        Executes MRam_Ip_SetLock / MRam_Ip_ClearLock / MRam_Ip_GetLock as selected by the
 *                 caller's Mem_43_MRAM_LockConfigType (JobInfo->DataPtr). For Get, IsLocked is written back
 *                 in place. The sentinel Length is cleared so the pending loop ends after this single call.
 *
 * @param[in]      InstanceIndex       Index of the memory instance to use
 * @param[in,out]  JobInfo             Job runtime information (Length is cleared on completion)
 *
 * @return         Mem_43_MRAM_JobResultType
 * @retval         MEM_43_MRAM_JOB_OK        Operation completed (Get: IsLocked is valid)
 * @retval         MEM_43_MRAM_JOB_FAILED    Operation rejected or failed (e.g. lock owned by another domain)
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_Lock(
    uint32                          InstanceIndex,
    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
)
{
    MRam_Ip_InstanceIdType instanceId = (MRam_Ip_InstanceIdType)InstanceIndex;
    Mem_43_MRAM_LockConfigType *pConfig = (Mem_43_MRAM_LockConfigType *)JobInfo->DataPtr;
    Mem_43_MRAM_JobResultType JobResult = MEM_43_MRAM_JOB_FAILED;
    MRam_Ip_StatusType Status;

    switch (pConfig->Operation)
    {
        case MEM_43_MRAM_LOCK_OP_SET:
            /* Lock the partition containing the address for the requesting domain */
            Status = MRam_Ip_SetLock(pConfig->Address, pConfig->DomainId, instanceId);
            if (MRAM_IP_STATUS_SUCCESS == Status)
            {
                JobResult = MEM_43_MRAM_JOB_OK;
            }
            break;
        case MEM_43_MRAM_LOCK_OP_CLEAR:
            /* Unlock the partition containing the address for the requesting domain */
            Status = MRam_Ip_ClearLock(pConfig->Address, pConfig->DomainId, instanceId);
            if (MRAM_IP_STATUS_SUCCESS == Status)
            {
                JobResult = MEM_43_MRAM_JOB_OK;
            }
            break;
        case MEM_43_MRAM_LOCK_OP_GET:
            /* Read the lock state; both LOCKED and UNLOCKED are a successful read */
            Status = MRam_Ip_GetLock(pConfig->Address, instanceId);
            if ((MRAM_IP_STATUS_PARTITION_LOCKED == Status) || (MRAM_IP_STATUS_PARTITION_UNLOCKED == Status))
            {
                pConfig->IsLocked = (MRAM_IP_STATUS_PARTITION_LOCKED == Status) ? (boolean)TRUE : (boolean)FALSE;
                JobResult = MEM_43_MRAM_JOB_OK;
            }
            break;
        default:
            /* Unknown operation: the job fails (rejected at DET level when enabled) */
            break;
    }

    /* Clear the sentinel length so the asynchronous pending loop terminates after this single call. */
    JobInfo->Length = 0U;

    return JobResult;
}
#endif /* MEM_43_MRAM_HW_LOCK_SERVICE == STD_ON */

/**
 * @brief          IP wrapper blank check function.
 * @details        Verifies that the specified memory region is in erased state by comparing
 *                 memory contents with the erased value pattern. Processes data in chunks
 *                 if the requested length exceeds the maximum operation size.
 *
 * @param[in]      InstanceIndex       Index of the memory instance to use
 * @param[in,out]  JobInfo             Pointer to job information structure containing address,
 *                                     length and other job-related data
 *
 * @return         Mem_43_MRAM_JobResultType
 * @retval         MEM_43_MRAM_JOB_OK              Blank check completed successfully, memory is erased
 * @retval         MEM_43_MRAM_JOB_PENDING         Operation is still in progress or more chunks need to be processed
 * @retval         MEM_43_MRAM_BLOCK_INCONSISTENT  Memory is not blank (contains non-erased values)
 * @retval         MEM_43_MRAM_ECC_CORRECTED       Correctable ECC error occurred
 * @retval         MEM_43_MRAM_ECC_UNCORRECTED     Uncorrectable ECC error occurred
 * @retval         MEM_43_MRAM_JOB_FAILED          Operation failed
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_BlankCheck(
    uint32                          InstanceIndex,
    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
)
{
    Mem_43_MRAM_JobResultType JobResult = MEM_43_MRAM_JOB_OK; /* Initialize */
    Mem_43_MRAM_LengthType TransferLength = 0U;
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    MRam_Ip_InstanceIdType instanceId = (MRam_Ip_InstanceIdType)InstanceIndex;

    /* length of data transfer */
    TransferLength = (Mem_43_MRAM_LengthType)JobInfo->Length;

    if (0U == TransferLength)
    {
        /* Nothing to check, consider job complete */
        JobResult = MEM_43_MRAM_JOB_OK;
    }
    else
    {
        /* Compare memory contents with erased state pattern */
        Status = MRam_Ip_Compare(JobInfo->Address,
                                NULL_PTR,
                                TransferLength,
                                instanceId);

        /* Process status result */
        /* Translate status code using the central function */
        JobResult = Mem_43_MRAM_IPW_TranslateReturnCode(Status);

        /* For successful operations, update the job info */
        if ((MEM_43_MRAM_JOB_OK == JobResult) || (MEM_43_MRAM_ECC_CORRECTED == JobResult))
        {
            Mem_43_MRAM_IPW_UpdateJobProcessedLength(JobInfo, TransferLength);
        }
    }

    return JobResult;
}

/**
 * @brief          IP wrapper sector erase function.
 * @details        Routes erase operations to the appropriate low level IP function.
 *                 Erases a memory sector at the specified address and handles status
 *                 translation and job state updates consistently.
 *
 * @param[in]      InstanceIndex     Index of the memory instance to use
 * @param[in,out]  JobInfo           Pointer to job information structure containing address,
 *                                   length and other job-related data
 *
 * @return         Mem_43_MRAM_JobResultType
 * @retval         MEM_43_MRAM_JOB_OK          Erase operation completed successfully
 * @retval         MEM_43_MRAM_JOB_PENDING     Erase operation is in progress
 * @retval         MEM_43_MRAM_JOB_FAILED      Erase operation failed (write protection, etc.)
 * @retval         MEM_43_MRAM_ECC_CORRECTED   Correctable ECC error occurred
 * @retval         MEM_43_MRAM_ECC_UNCORRECTED Uncorrectable ECC error occurred
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_Erase(
    uint32 InstanceIndex,
    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
)
{
    Mem_43_MRAM_JobResultType JobResult = MEM_43_MRAM_JOB_OK; /* Initialize */
    Mem_43_MRAM_LengthType TransferLength = 0U;
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    MRam_Ip_InstanceIdType instanceId = (MRam_Ip_InstanceIdType)InstanceIndex;

    /* length of data transfer */
    TransferLength = (Mem_43_MRAM_LengthType)JobInfo->Length;

    /* Call IP routine to erase MRAM memory sector */
#if (STD_OFF == MEM_43_MRAM_USE_AXI_INTERFACE)
        Status = MRam_Ip_Erase(JobInfo->Address, TransferLength, instanceId);
#else
        Status = MRam_Ip_Erase_AXI(JobInfo->Address, TransferLength, instanceId);
#endif

    /* Translate IP status to high-level driver status */
    JobResult = Mem_43_MRAM_IPW_TranslateReturnCode(Status);

    /* Process the erase operation result */
    if ((MEM_43_MRAM_JOB_OK == JobResult) || (MEM_43_MRAM_ECC_CORRECTED == JobResult))
    {
        /* For successful operations, update job state - TRUE indicates asynchronous mode */
        Mem_43_MRAM_IPW_UpdateJobProcessedLength(JobInfo, TransferLength);
    }

    return JobResult;
}

/**
 * @brief          IP wrapper sector write function.
 * @details        Routes write operations to the appropriate low level IP function.
 *                 Handles job state updates and error translation.
 *
 * @param[in]      InstanceIndex       Index of the memory instance to use
 * @param[in,out]  JobInfo             Pointer to job information structure containing address,
 *                                     data buffer pointer, and length information
 *
 * @return         Mem_43_MRAM_JobResultType
 * @retval         MEM_43_MRAM_JOB_OK          Write operation completed successfully
 * @retval         MEM_43_MRAM_JOB_PENDING     Write operation is in progress
 * @retval         MEM_43_MRAM_JOB_FAILED      Write operation failed
 * @retval         MEM_43_MRAM_ECC_CORRECTED   Correctable ECC error occurred
 * @retval         MEM_43_MRAM_ECC_UNCORRECTED Uncorrectable ECC error occurred
 */
Mem_43_MRAM_JobResultType Mem_43_MRAM_IPW_Write(
    uint32 InstanceIndex,
    Mem_43_MRAM_JobRuntimeInfoType *JobInfo
)
{
    Mem_43_MRAM_JobResultType JobResult = MEM_43_MRAM_JOB_OK; /* Initialize */
    MRam_Ip_StatusType Status = MRAM_IP_STATUS_SUCCESS;
    Mem_43_MRAM_LengthType TransferLength = 0U;
    MRam_Ip_InstanceIdType instanceId = (MRam_Ip_InstanceIdType)InstanceIndex;

    /* length of data transfer */
    TransferLength = (Mem_43_MRAM_LengthType)JobInfo->Length;

    /* Call IP routine to write data to MRAM memory. The write source is carried in the dedicated
     * const SrcDataPtr field (DataPtr stays NULL for write jobs); both IP write entry points take a
     * const source pointer, so no const-removing cast is needed here. */
#if (STD_OFF == MEM_43_MRAM_USE_AXI_INTERFACE)
        Status = MRam_Ip_Write(JobInfo->Address, JobInfo->SrcDataPtr, TransferLength, instanceId);
#else
        Status = MRam_Ip_Write_AXI(JobInfo->Address, JobInfo->SrcDataPtr, TransferLength, instanceId);
#endif

    /* Translate IP status to high-level driver status */
    JobResult = Mem_43_MRAM_IPW_TranslateReturnCode(Status);

    /* For successful operations, update job information */
    if ((MEM_43_MRAM_JOB_OK == JobResult) || (MEM_43_MRAM_ECC_CORRECTED == JobResult))
    {
        /* Process job after execution - TRUE indicates asynchronous mode */
        Mem_43_MRAM_IPW_UpdateJobProcessedLength(JobInfo, TransferLength);
    }

    return JobResult;
}

#define MEM_43_MRAM_STOP_SEC_CODE
#include "Mem_43_MRAM_MemMap.h"


#ifdef __cplusplus
}
#endif

/** @} */

