/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : MRAM
*   Dependencies         : None
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
*   Copyright 2024 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

#ifndef MEM_43_MRAM_TYPES_H
#define MEM_43_MRAM_TYPES_H

/**
 * @file       Mem_43_MRAMTypes.h
 *
 * @addtogroup MEM_43_MRAM
 * implement   Mem_43_MRAM_Types.h_Artifact
 *
 * @{
 */

#ifdef __cplusplus
extern "C"
{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "MRam_Ip_Types.h"
#include "Mem_43_MRAM_CfgDefines.h"
#if (MEM_43_MRAM_MEMACC_USED == STD_ON)
    /* Include MemAcc_GeneralTypes.h */
    #include "MemAcc_GeneralTypes.h"
#endif
/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define MEM_43_MRAM_TYPES_VENDOR_ID                      43
#define MEM_43_MRAM_TYPES_AR_RELEASE_MAJOR_VERSION       4
#define MEM_43_MRAM_TYPES_AR_RELEASE_MINOR_VERSION       9
#define MEM_43_MRAM_TYPES_AR_RELEASE_REVISION_VERSION    0
#define MEM_43_MRAM_TYPES_SW_MAJOR_VERSION               1
#define MEM_43_MRAM_TYPES_SW_MINOR_VERSION               0
#define MEM_43_MRAM_TYPES_SW_PATCH_VERSION               0

/*==================================================================================================
                                    FILE VERSION CHECKS
==================================================================================================*/
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    /* Check if current file and Std_Types header file are of the same Autosar version */
    #if ((MEM_43_MRAM_TYPES_AR_RELEASE_MAJOR_VERSION != STD_AR_RELEASE_MAJOR_VERSION) || \
         (MEM_43_MRAM_TYPES_AR_RELEASE_MINOR_VERSION != STD_AR_RELEASE_MINOR_VERSION) \
        )
        #error "AutoSar Version Numbers of Mem_43_MRAM_Types.h and Std_Types.h are different"
    #endif
#if (MEM_43_MRAM_MEMACC_USED == STD_ON)
    /* Check if current file and MemAcc_GeneralTypes.h file are of the same version */
    #if ((MEM_43_MRAM_TYPES_AR_RELEASE_MAJOR_VERSION != MEMACC_GENERALTYPES_AR_RELEASE_MAJOR_VERSION) || \
         (MEM_43_MRAM_TYPES_AR_RELEASE_MINOR_VERSION != MEMACC_GENERALTYPES_AR_RELEASE_MINOR_VERSION)\
        )
        #error "AutoSar Version Numbers of Mem_43_MRAM_Types.h and MemAcc_GeneralTypes.h are different"
    #endif
#endif
#endif

/* Check if current file and MRam_Ip_Types.h header file are of the same vendor */
#if (MEM_43_MRAM_TYPES_VENDOR_ID != MRAM_IP_TYPES_VENDOR_ID)
    #error "Mem_43_MRAMTypes.h and MRam_Ip_Types.h have different vendor ids"
#endif
/* Check if current file and MRam_Ip_Types.h header file are of the same Autosar version */
#if ((MEM_43_MRAM_TYPES_AR_RELEASE_MAJOR_VERSION    != MRAM_IP_TYPES_AR_RELEASE_MAJOR_VERSION) || \
     (MEM_43_MRAM_TYPES_AR_RELEASE_MINOR_VERSION    != MRAM_IP_TYPES_AR_RELEASE_MINOR_VERSION) || \
     (MEM_43_MRAM_TYPES_AR_RELEASE_REVISION_VERSION != MRAM_IP_TYPES_AR_RELEASE_REVISION_VERSION) \
    )
    #error "AutoSar Version Numbers of Mem_43_MRAMTypes.h and MRam_Ip_Types.h are different"
#endif
/* Check if current file and MRam_Ip_Types.h header file are of the same Software version */
#if ((MEM_43_MRAM_TYPES_SW_MAJOR_VERSION != MRAM_IP_TYPES_SW_MAJOR_VERSION) || \
     (MEM_43_MRAM_TYPES_SW_MINOR_VERSION != MRAM_IP_TYPES_SW_MINOR_VERSION) || \
     (MEM_43_MRAM_TYPES_SW_PATCH_VERSION != MRAM_IP_TYPES_SW_PATCH_VERSION) \
    )
    #error "Software Version Numbers of Mem_43_MRAMTypes.h and MRam_Ip_Types.h are different"
#endif

/* Check if current file and Mem_43_MRAM_CfgDefines.h header file are of the same vendor */
#if (MEM_43_MRAM_TYPES_VENDOR_ID != MEM_43_MRAM_VENDOR_ID_CFG_DEFINES)
    #error "Mem_43_MRAMTypes.h and Mem_43_MRAM_CfgDefines.h have different vendor ids"
#endif
/* Check if current file and Mem_43_MRAM_CfgDefines.h header file are of the same Autosar version */
#if ((MEM_43_MRAM_TYPES_AR_RELEASE_MAJOR_VERSION    != MEM_43_MRAM_AR_RELEASE_MAJOR_VERSION_CFG_DEFINES) || \
     (MEM_43_MRAM_TYPES_AR_RELEASE_MINOR_VERSION    != MEM_43_MRAM_AR_RELEASE_MINOR_VERSION_CFG_DEFINES) || \
     (MEM_43_MRAM_TYPES_AR_RELEASE_REVISION_VERSION != MEM_43_MRAM_AR_RELEASE_REVISION_VERSION_CFG_DEFINES) \
    )
    #error "AutoSar Version Numbers of Mem_43_MRAMTypes.h and Mem_43_MRAM_CfgDefines.h are different"
#endif
/* Check if current file and Mem_43_MRAM_CfgDefines.h header file are of the same Software version */
#if ((MEM_43_MRAM_TYPES_SW_MAJOR_VERSION != MEM_43_MRAM_SW_MAJOR_VERSION_CFG_DEFINES) || \
     (MEM_43_MRAM_TYPES_SW_MINOR_VERSION != MEM_43_MRAM_SW_MINOR_VERSION_CFG_DEFINES) || \
     (MEM_43_MRAM_TYPES_SW_PATCH_VERSION != MEM_43_MRAM_SW_PATCH_VERSION_CFG_DEFINES) \
    )
    #error "Software Version Numbers of Mem_43_MRAMTypes.h and Mem_43_MRAM_CfgDefines.h are different"
#endif

/*==================================================================================================
*                                      DEFINES AND MACROS
==================================================================================================*/

#define E_MEM_SERVICE_NOT_AVAIL    0x02U /* To do: remove after base merged*/
/**
*  @brief    AUTOSAR module identification
*/
#define MEM_43_MRAM_MODULE_ID            91U

/**
 *  Development error codes (passed to DET)
 */
/**
 * @brief       API service called without module initialization
 * @implements  MEM_43_MRAM_E_UNINIT_define
 */
#define MEM_43_MRAM_E_UNINIT                0x01U

/**
 * @brief       API service called with NULL pointer
 * @implements  MEM_43_MRAM_E_PARAM_POINTER_define
 */
#define MEM_43_MRAM_E_PARAM_POINTER         0x02U

/**
 * @brief       API service called with an invalid address
 * @implements  MEM_43_MRAM_E_PARAM_ADDRESS_define
 */
#define MEM_43_MRAM_E_PARAM_ADDRESS         0x03U

/**
 * @brief       API service called with an invalid length
 * @implements  MEM_43_MRAM_E_PARAM_LENGTH_define
*/
#define MEM_43_MRAM_E_PARAM_LENGTH          0x04U

/**
 * @brief       API service called with an invalid driver instance ID
 * @implements  MEM_43_MRAM_E_PARAM_INSTANCE_ID_define
*/
#define MEM_43_MRAM_E_PARAM_INSTANCE_ID     0x05U

/**
 * @brief       API service called while a job request is still in progress
 * @implements  MEM_43_MRAM_E_JOB_PENDING_define
*/
#define MEM_43_MRAM_E_JOB_PENDING           0x06U

/**
 * @brief       API service called while check on partition assigned for correctness or out of bounds accesses
*/
#define MEM_43_MRAM_E_PARAM_CONFIG           0x07U

/**
 * @brief       API service called without errors
 * @implements  MEM_43_MRAM_E_OK_define
*/
#define MEM_43_MRAM_E_OK                    0xFFU
/**
 *  END Development error codes
 */


/**
 *  All service IDs (passed to DET)
 */
/* Synchronous Functions */
/**
 * @brief   Service ID of function Mem_43_MRAM_DeInit
 * @note    DeInit is not implemented by this driver; service ID 0x0B is reserved and left undefined.
*/

/**
 * @brief   Service ID of function Mem_43_MRAM_Init
*/
#define MEM_43_MRAM_INIT_ID                 0x01U

/**
 * @brief   Service ID of function Mem_43_MRAM_GetVersionInfo
*/
#define MEM_43_MRAM_GET_VERSION_INFO_ID     0x02U

/**
 * @brief   Service ID of function Mem_43_MRAM_GetJobResult
*/
#define MEM_43_MRAM_GET_JOB_RESULT_ID       0x04U

/**
 * @brief   Service ID of function Mem_43_MRAM_PropagateError
*/
#define MEM_43_MRAM_PROPAGATE_ERROR_ID      0x08U

/**
 * @brief   Service ID of function Mem_43_MRAM_Suspend
 * @note    Suspend is not implemented by this driver; service ID 0x0C is reserved and left undefined.
*/

/**
 * @brief   Service ID of function Mem_43_MRAM_Resume
 * @note    Resume is not implemented by this driver; service ID 0x0D is reserved and left undefined.
*/


/* Asynchronous Functions */
/**
 * @brief   Service ID of function Mem_43_MRAM_Read
*/
#define MEM_43_MRAM_READ_ID                 0x05U

/**
 * @brief   Service ID of function Mem_43_MRAM_Write
*/
#define MEM_43_MRAM_WRITE_ID                0x06U

/**
 * @brief   Service ID of function Mem_43_MRAM_Erase
*/
#define MEM_43_MRAM_ERASE_ID                0x07U

/**
 * @brief   Service ID of function Mem_43_MRAM_BlankCheck
*/
#define MEM_43_MRAM_BLANK_CHECK_ID          0x09U

/**
 * @brief   Service ID of function Mem_43_MRAM_MainFunction
*/
#define MEM_43_MRAM_MAIN_FUNCTION_ID  0x0AU

/**
 * @brief   Service ID of function Mem_43_MRAM_HwSpecificService
*/
#define MEM_43_MRAM_HW_SPECIFIC_SERVICE_ID  0x0BU

/**
 *   Hardware specific service request identifier
 */

/**
 * @brief    Define ServiceId for Compare feature
*/
#define MEM_43_MRAM_HWSERVICEID_COMPARE     0x11U

/**
 * @brief    Define ServiceId for UTest Reference Recovery/Refresh feature
*/
#define MEM_43_MRAM_HWSERVICEID_UTEST_REFERENCE_RECOVERY_REFRESH     0x12U

/**
 * @brief    Define ServiceId for UTest EDC-after-ECC Logic Check feature
*/
#define MEM_43_MRAM_HWSERVICEID_UTEST_EDC_AFTER_ECC_LOGIC_CHECK     0x14U

/**
 * @brief    Define ServiceId for UTest Address-Encode Logic Check feature
*/
#define MEM_43_MRAM_HWSERVICEID_UTEST_ADDRESS_ENCODE_LOGIC_CHECK     0x15U

/**
 * @brief    Define ServiceId for UTest ECC Logic Check feature
*/
#define MEM_43_MRAM_HWSERVICEID_UTEST_ECC_LOGIC_CHECK     0x16U

/**
 * @brief    Define ServiceId for UTest Array Integrity Check feature
*/
#define MEM_43_MRAM_HWSERVICEID_UTEST_ARRAY_INTEGRITY_CHECK     0x17U

/**
 * @brief    Define ServiceId for the partition Lock feature (Set / Clear / Get, see Mem_43_MRAM_LockConfigType)
*/
#define MEM_43_MRAM_HWSERVICEID_LOCK     0x18U

/**
 * @brief    Define ServiceId Invalid
*/
#define MEM_43_MRAM_HWSERVICEID_INVALID     0xFFU

/**
 * END All service IDs
*/

/**
 * @brief   Indicates that new job has been accepted
*/
#define MEM_43_MRAM_JOB_FLAG_STARTED        0x01U

/* Define support for 32 or 64Bit address type */
#if (MEM_43_MRAM_MEMACC_USED == STD_ON)
#define MEM_43_MRAM_ADDRESSTYPE                          MemAcc_AddressType
#define MEM_43_MRAM_LENGTHTYPE                           MemAcc_LengthType
#else
#define MEM_43_MRAM_ADDRESSTYPE                          uint32
#define MEM_43_MRAM_LENGTHTYPE                           uint32
#endif
/*==================================================================================================
                                                TYPEDEFS
==================================================================================================*/


/**
 * @brief          Mem Instance Id Type
 * @details        Mem Instance Id Type
 * @implements     Mem_43_MRAM_InstanceIdType_typedef
 */
typedef uint32 Mem_43_MRAM_InstanceIdType;

/**
* @brief          Mem Address Type
* @details        Physical memory device address type
* @implements     Mem_43_MRAM_AddressType_typedef
*/
typedef MEM_43_MRAM_ADDRESSTYPE Mem_43_MRAM_AddressType;

/**
 * @brief          Mem Length Type
 * @details        Physical memory device length type
 * @implements     Mem_43_MRAM_LengthType_typedef
 */
typedef MEM_43_MRAM_LENGTHTYPE Mem_43_MRAM_LengthType;

/**
 * @brief          Mem Data Type
 * @details        Read data user buffer type
 * @implements     Mem_43_MRAM_DataType_typedef
 */
typedef uint8 Mem_43_MRAM_DataType;

/**
* brief          Size of data to be processeed by CRC.
*/
typedef enum
{
    MEM_43_MRAM_CRC_8_BITS = 0,
    MEM_43_MRAM_CRC_16_BITS
} Mem_43_MRAM_CrcDataSizeType;

/**
 * @brief          Mem CRC Type
 * @details        CRC computed over config set
 *                 (will be implement in next feature)
 *                 Mem_43_MRAM_CrcType_typedef
 */
 typedef uint16 Mem_43_MRAM_CrcType;

/**
 * @brief          Mem Hardware Service Id Type
 * @details        Hardware specific service request identifier type
 * @implements     Mem_43_MRAM_HwServiceIdType_typedef
 */
typedef uint32 Mem_43_MRAM_HwServiceIdType;

/*==================================================================================================
                                                ENUMS
==================================================================================================*/

#if (MEM_43_MRAM_MEMACC_USED == STD_OFF)
/**
* @brief        Mem job result type
* @implements   Mem_43_MRAM_JobResultType_enum
*/
typedef enum
{
    MEM_43_MRAM_JOB_OK                 = 0x00,    /* The last job has been finished successfully                                    */
    MEM_43_MRAM_JOB_PENDING            = 0x01,    /* A job is currently being processed                                             */
    MEM_43_MRAM_JOB_FAILED             = 0x02,    /* Job failed for some unspecific reason                                          */
    MEM_43_MRAM_INCONSISTENT           = 0x03,    /* The checked page is not blank                                                  */
    MEM_43_MRAM_ECC_UNCORRECTED        = 0x04,    /* Uncorrectable ECC errors occurred during memory access                         */
    MEM_43_MRAM_ECC_CORRECTED          = 0x05     /* Correctable ECC errors occurred during memory access                           */
} Mem_43_MRAM_JobResultType;

#else
/**
* @brief          Define JobResultType follow to MemAcc mem job result type
* @implements     Mem_43_MRAM_JobResultType_enum
*
*/
#define Mem_43_MRAM_JobResultType     MemAcc_MemJobResultType
/* Re-define for Job Result Type */
#define MEM_43_MRAM_JOB_OK            MEM_JOB_OK
#define MEM_43_MRAM_JOB_PENDING       MEM_JOB_PENDING
#define MEM_43_MRAM_JOB_FAILED        MEM_JOB_FAILED
#define MEM_43_MRAM_INCONSISTENT      MEM_INCONSISTENT
#define MEM_43_MRAM_ECC_UNCORRECTED   MEM_ECC_UNCORRECTED
#define MEM_43_MRAM_ECC_CORRECTED     MEM_ECC_CORRECTED
#endif


/**
 * @brief          Type of job currently executed by Mem_43_MRAM_MainFunction.
 */
typedef enum
{
    MEM_43_MRAM_JOB_NONE               = 0x00,    /* no job executed                                                                */
    MEM_43_MRAM_JOB_ERASE              = 0x01,    /* erase one or more complete flash sectors                                       */
    MEM_43_MRAM_JOB_WRITE              = 0x02,    /* write one or more complete flash pages                                         */
    MEM_43_MRAM_JOB_READ               = 0x03,    /* read one or more bytes from flash memory                                       */
    MEM_43_MRAM_JOB_BLANK_CHECK        = 0x04,    /* check content of erased flash memory area                                      */
    MEM_43_MRAM_JOB_HWSPECIFICSERVICE  = 0x05     /* hardware specific service                                                      */
} Mem_43_MRAM_JobType;


/*==================================================================================================
                                        CONFIGURATION STRUCTURES
==================================================================================================*/

/**
 * @brief          Mem Internal Flash Type
 * @details        Configuration structure of internal flash.
 */
typedef MRam_Ip_ConfigType Mem_43_MRAM_InternalConfigType;

/**
 * @brief          Mem internal unit type
 * @details        Mem internal unit config data structure
 *                 Mem_43_MRAM_InternalUnitType_struct
 */
typedef struct
{
    const Mem_43_MRAM_InternalConfigType *InternalConfig;      /* Pointer to configuration structure internal flash */
} Mem_43_MRAM_InternalUnitType;

/**
 * @brief          Mem device config type
 * @details        Mem device config data structure
 *                 Mem_43_MRAM_MemDeviceType_struct
 */
typedef struct
{
    const Mem_43_MRAM_InternalUnitType    *InternalUnits;      /* Point to first element in array of internal flash unit configurations */
} Mem_43_MRAM_MemDeviceType;


/**
 * @brief          Sector Batch Type
 * @details        Sector Batch data structure for group of identical sectors
 *                 Note: burst sizes equal to normal sizes in case burst disabled
 *                 Mem_43_MRAM_SectorBatchType_struct
 */
typedef struct
{
    const Mem_43_MRAM_AddressType    StartAddress;       /* Physical start address of the sector batch                              */
    const Mem_43_MRAM_AddressType    EndAddress;         /* Physical end address of the sector batch                                */
    const uint32                      SectorSize;         /* Size of a sector in bytes in this sector batch (smallest erasable unit) */
    const uint32                      ReadPageSize;       /* Size of a read page of this sector in bytes (smallest readable unit)    */
    const uint32                      WritePageSize;      /* Size of a write page of this sector in bytes (smallest writeable unit)  */
    const uint32                      EraseBurstSize;     /* Size of sector erase burst in bytes (for improved performance)          */
    const uint32                      ReadBurstSize;      /* Size of page read burst in bytes (for improved performance)             */
    const uint32                      WriteBurstSize;     /* Size of page write/program burst in bytes (for improved performance)    */
} Mem_43_MRAM_SectorBatchType;

/**
 * @brief          Mem Instance Type
 * @details        Mem Instance data structure
 *                 Mem_43_MRAM_MemInstanceType_struct
 */
typedef struct
{
    const Mem_43_MRAM_InstanceIdType     InstanceId;          /* Unique numeric identifier for each a Mem driver instance           */
    const uint32                          SectorBatchCount;    /* Number of sector batches in this Mem instance                      */
    const Mem_43_MRAM_SectorBatchType   *SectorBatches;       /* Point to first element in array of sector batches configurations   */
    const uint8                           MemUnitIndex;        /* Index of flash memory unit used for this Mem instance              */
} Mem_43_MRAM_MemInstanceType;

/**
 * @brief          Mem Configuration Type
 * @details        Mem module initialization data structure
 * @implements     Mem_43_MRAM_ConfigType_struct
 */
typedef struct
{
    const Mem_43_MRAM_MemInstanceType   *MemInstances;            /* Point to first element in array of mem instances configurations    */
    const Mem_43_MRAM_MemDeviceType     *MemDevices;              /* Mem devices configurations used by the mem instance                */
#if (STD_ON == MEM_43_MRAM_CHECK_CFG_CRC)
    Mem_43_MRAM_CrcType u16ConfigCrc;
#endif
} Mem_43_MRAM_ConfigType;

/**
* @brief          Mem_43_MRAM Compare Configuration Type
* @details        Mem_43_MRAM Compare data structure for dataPtr of HwSpecificService
*
*                 Mem_43_MRAM_CompareConfigType
*/
typedef struct
{
    Mem_43_MRAM_AddressType    CompareAddr;
    Mem_43_MRAM_DataType      *DataSourcePtr;
    Mem_43_MRAM_LengthType     Length;
} Mem_43_MRAM_CompareConfigType;

#if (MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON)
/**
* @brief          Mem_43_MRAM UTest EDC-after-ECC Logic Check Configuration Type
* @details        Parameter/result carrier for dataPtr of HwSpecificService
*                 (HWSERVICEID_UTEST_EDC_AFTER_ECC_LOGIC_CHECK). Address/DataValues/DataLength are
*                 inputs; ResultEEE is written back by the driver and is valid after the job completes.
*
*                 Mem_43_MRAM_UTestEDCAfterECCLogicCheckConfigType
*/
typedef struct
{
    Mem_43_MRAM_AddressType    Address;        /* Memory address to test                      */
    uint32                              *DataValues;     /* Data/check-bit values to read (UD9..UD17)   */
    uint8                                DataLength;     /* Length of DataValues (max 9)                */
    boolean                              ResultEEE;      /* OUT: EEE flag result (valid after job done) */
} Mem_43_MRAM_UTestEDCAfterECCLogicCheckConfigType;

/**
* @brief          Mem_43_MRAM UTest Address-Encode Logic Check Configuration Type
* @details        Parameter/result carrier for dataPtr of HwSpecificService
*                 (HWSERVICEID_UTEST_ADDRESS_ENCODE_LOGIC_CHECK). Address and the four Aei* register
*                 values are inputs; ResultAEE is written back and is valid after the job completes.
*
*                 Mem_43_MRAM_UTestAddressEncodeLogicCheckConfigType
*/
typedef struct
{
    Mem_43_MRAM_AddressType    Address;      /* Memory address to test                      */
    uint32                               AeisValue;    /* UA0[AEIS] address-encode invert selector    */
    uint32                               AeiValue;     /* UA0[AEI]  address-encode invert             */
    uint32                               AeicValue;    /* UA1[AEIC] address-encode invert complement  */
    uint32                               AeioValue;    /* UA1[AEIO] address-encode invert output      */
    boolean                              ResultAEE;    /* OUT: AEE flag result (valid after job done) */
} Mem_43_MRAM_UTestAddressEncodeLogicCheckConfigType;

/**
* @brief          Mem_43_MRAM UTest ECC Logic Check Configuration Type
* @details        Parameter/result carrier for dataPtr of HwSpecificService
*                 (HWSERVICEID_UTEST_ECC_LOGIC_CHECK). Address/DataValues/DataLength are inputs; the
*                 embedded Result (flags, RADDR, MISR) is written back and valid after the job completes.
*
*                 Mem_43_MRAM_UTestECCLogicCheckConfigType
*/
typedef struct
{
    Mem_43_MRAM_AddressType    Address;      /* Memory address to test                       */
    uint32                              *DataValues;   /* Data/check-bit values to read (UD0..UD8)     */
    uint8                                DataLength;   /* Length of DataValues (max 9)                 */
    MRam_Ip_ArrayIntegrityCheckType      Result;       /* OUT: flags/RADDR/MISR (valid after job done) */
} Mem_43_MRAM_UTestECCLogicCheckConfigType;

/**
* @brief          Mem_43_MRAM UTest Array Integrity Check Configuration Type
* @details        Parameter/result carrier for dataPtr of HwSpecificService
*                 (HWSERVICEID_UTEST_ARRAY_INTEGRITY_CHECK). Address/SequentialAddressing/ArrayValuesMISR/
*                 ArrayLengthMISR/EnableBreakpoints are inputs; the embedded Result (flags, RADDR, MISR
*                 signature) is written back and valid after the job completes.
*
*                 Mem_43_MRAM_UTestArrayIntegrityCheckConfigType
*/
typedef struct
{
    Mem_43_MRAM_AddressType    Address;               /* First address of the partition to check      */
    boolean                              SequentialAddressing;  /* TRUE = sequential addressing mode            */
    uint32                              *ArrayValuesMISR;       /* Initial MISR seed values (may be NULL)        */
    uint8                                ArrayLengthMISR;       /* Length of ArrayValuesMISR (<= 10)            */
    boolean                              EnableBreakpoints;     /* TRUE = enable breakpoints on ECC errors      */
    MRam_Ip_ArrayIntegrityCheckType      Result;                /* OUT: flags/RADDR/MISR (valid after job done) */
} Mem_43_MRAM_UTestArrayIntegrityCheckConfigType;
#endif /* (MEM_43_MRAM_HW_UTEST_SERVICE == STD_ON) */

#if (MEM_43_MRAM_HW_LOCK_SERVICE == STD_ON)
/**
* @brief          Mem_43_MRAM partition Lock operation
* @details        Selects the operation of the HWSERVICEID_LOCK hardware specific service.
*/
typedef enum
{
    MEM_43_MRAM_LOCK_OP_SET = 0U,          /* Lock the partition containing Address   */
    MEM_43_MRAM_LOCK_OP_CLEAR,             /* Unlock the partition containing Address */
    MEM_43_MRAM_LOCK_OP_GET                /* Read the lock state into IsLocked       */
} Mem_43_MRAM_LockOperationType;

/**
* @brief          Mem_43_MRAM partition Lock Configuration Type
* @details        Parameter/result carrier for dataPtr of HwSpecificService (HWSERVICEID_LOCK).
*                 Operation/Address/DomainId are inputs; IsLocked is written back by the driver for
*                 MEM_43_MRAM_LOCK_OP_GET and is valid after the job completes. Address must be inside a
*                 sector batch of the instance.
*
*                 Mem_43_MRAM_LockConfigType
*/
typedef struct
{
    Mem_43_MRAM_LockOperationType  Operation;  /* Set, Clear or Get                                  */
    Mem_43_MRAM_AddressType        Address;    /* Any address inside the partition                   */
    uint8                          DomainId;   /* Domain ID of the requester (Set / Clear only)      */
    boolean                        IsLocked;   /* OUT: lock state (Get only, valid after job done)   */
} Mem_43_MRAM_LockConfigType;
#endif /* (MEM_43_MRAM_HW_LOCK_SERVICE == STD_ON) */
/*==================================================================================================
                                        INTERNAL TYPES
==================================================================================================*/

/**
 * @brief          Mem job runtime information Type
 * @details        This structure contains runtime information the current processing job of each Mem instance.
 *                 Mem_43_MRAM_JobRuntimeInfoType_struct
 */
typedef struct
{
    /* Input information */
    Mem_43_MRAM_InstanceIdType            InstanceId;         /* Unique numeric identifier for each a Mem driver instance           */
    Mem_43_MRAM_JobType                   JobType;            /* Type of currently executed job (Erase, Write, or Read)             */
    Mem_43_MRAM_HwServiceIdType           HwServiceIdJob;     /* Type of currently executed job HwServiceId (Compare)       ..      */
    Mem_43_MRAM_AddressType               Address;            /* Last physical address to be processed                              */
    Mem_43_MRAM_DataType                 *DataPtr;            /* Pointer to user data buffer (Read destination, HwSpecificService)  */
    const Mem_43_MRAM_DataType           *SrcDataPtr;         /* Const source data buffer pointer (used in Write)                   */
    Mem_43_MRAM_LengthType                Length;             /* Remaining bytes of data to be processed                            */

    /* Output result of the parameter checking stage */
    uint32                                 InstanceIndex;      /* The mem index number according to the mem instance id              */
    const Mem_43_MRAM_SectorBatchType    *SectorBatch;        /* The sector batch to be worked with the request job                 */
    /* Runtime information */
    Mem_43_MRAM_JobResultType             JobResult;          /* The result of the most recent job                                  */
    uint8                                  JobFlags;           /* Job information (Started state, burst mode)                        */
#if (MEM_43_MRAM_MULTICORE_ENABLED == STD_ON)
    uint8                                  PartitionId;        /* Running PartitionId                                                */
#endif
} Mem_43_MRAM_JobRuntimeInfoType;

#ifdef __cplusplus
}
#endif

/** @}*/

#endif /* MEM_43_MRAM_TYPES_H */
