/*==================================================================================================
*   Project              : RTD AUTOSAR 4.9
*   Platform             : CORTEXM
*   Peripheral           : S32K56XM7
*   Dependencies         : none
*
*   Autosar Version      : 4.9.0
*   Autosar Revision     : ASR_REL_4_9_REV_0000
*   Autosar Conf.Variant :
*   SW Version           : 1.0.0
*   Build Version        : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
*   Copyright 2024 - 2026 NXP
*
*   NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/

/**
*   @file Eth_MemMap.h
*   @implements     MemMap.h_Artifact
*   @brief   Memory mapping specification.
*   @details This document specifies mechanisms for the mapping of code and data to specific
*            memory sections via memory mapping file. For many ECUs and microcontroller platforms
*            it is of utmost necessity to be able to map code, variables and constants module
*            wise to specific memory sections.
*            This file contains sample code only. It is not part of the production code deliverables.
*   @addtogroup BASENXP_COMPONENT
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                        INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "CompilerDefinition.h"

/*==================================================================================================
*                               SOURCE FILE VERSION INFORMATION
==================================================================================================*/
/**
* @{
* @brief Parameters that shall be published within the memory map header file and also in the
*       module's description file
*/
#define ETH_MEMMAP_VENDOR_ID                    43
#define ETH_MEMMAP_AR_RELEASE_MAJOR_VERSION     4
#define ETH_MEMMAP_AR_RELEASE_MINOR_VERSION     9
#define ETH_MEMMAP_AR_RELEASE_REVISION_VERSION  0
#define ETH_MEMMAP_SW_MAJOR_VERSION             1
#define ETH_MEMMAP_SW_MINOR_VERSION             0
#define ETH_MEMMAP_SW_PATCH_VERSION             0
/**@}*/
/*==================================================================================================
                                      FILE VERSION CHECKS
==================================================================================================*/

/*==================================================================================================
                                           CONSTANTS
==================================================================================================*/

/*==================================================================================================
                                       DEFINES AND MACROS
==================================================================================================*/


/**
* @brief Symbol used for checking correctness of the includes
*/
#define MEMMAP_ERROR


/**************************************************************************************************/
/****************************************** FOR ALL COMPILERS *************************************/
/**************************************************************************************************/

/**************************************** ETH *******************************/
#ifdef ETH_START_SEC_CONFIG_DATA_8
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CONFIG_DATA_8
    #define ENTERED_ETH_START_SEC_CONFIG_DATA_8
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CONFIG_DATA_8
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section rodata=".mcal_const_cfg"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=".mcal_const_cfg"
        #else
            #pragma section CONST ".mcal_const_cfg"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG mcal_const_cfg
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_const_cfg" a
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata ".mcal_const_cfg"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rodata=".mcal_const_cfg"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_const_cfg"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=".mcal_const_cfg"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=".mcal_const_cfg"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=".mcal_const_cfg"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CONFIG_DATA_8
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CONFIG_DATA_8
        #undef ENTERED_ETH_START_SEC_CONFIG_DATA_8
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CONFIG_DATA_8
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section CONST
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_CONFIG_DATA_16
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CONFIG_DATA_16
    #define ENTERED_ETH_START_SEC_CONFIG_DATA_16
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CONFIG_DATA_16
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section rodata=".mcal_const_cfg"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=".mcal_const_cfg"
        #else
            #pragma section CONST ".mcal_const_cfg"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG mcal_const_cfg
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_const_cfg" a
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata ".mcal_const_cfg"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rodata=".mcal_const_cfg"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_const_cfg"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=".mcal_const_cfg"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=".mcal_const_cfg"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=".mcal_const_cfg"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CONFIG_DATA_16
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CONFIG_DATA_16
        #undef ENTERED_ETH_START_SEC_CONFIG_DATA_16
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CONFIG_DATA_16
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section CONST
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_CONFIG_DATA_32
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CONFIG_DATA_32
    #define ENTERED_ETH_START_SEC_CONFIG_DATA_32
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CONFIG_DATA_32
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section rodata=".mcal_const_cfg"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=".mcal_const_cfg"
        #else
            #pragma section CONST ".mcal_const_cfg"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG mcal_const_cfg
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_const_cfg" a
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata ".mcal_const_cfg"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rodata=".mcal_const_cfg"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_const_cfg"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=".mcal_const_cfg"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=".mcal_const_cfg"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=".mcal_const_cfg"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CONFIG_DATA_32
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CONFIG_DATA_32
        #undef ENTERED_ETH_START_SEC_CONFIG_DATA_32
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CONFIG_DATA_32
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section CONST
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_CONFIG_DATA_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CONFIG_DATA_UNSPECIFIED
    #define ENTERED_ETH_START_SEC_CONFIG_DATA_UNSPECIFIED
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CONFIG_DATA_UNSPECIFIED
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section rodata=".mcal_const_cfg"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=".mcal_const_cfg"
        #else
            #pragma section CONST ".mcal_const_cfg"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG mcal_const_cfg
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_const_cfg" a
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata ".mcal_const_cfg"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rodata=".mcal_const_cfg"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_const_cfg"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=".mcal_const_cfg"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=".mcal_const_cfg"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=".mcal_const_cfg"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CONFIG_DATA_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CONFIG_DATA_UNSPECIFIED
        #undef ENTERED_ETH_START_SEC_CONFIG_DATA_UNSPECIFIED
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CONFIG_DATA_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section CONST
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_CONFIG_DATA_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CONFIG_DATA_8_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_CONFIG_DATA_8_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CONFIG_DATA_8_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section rodata=".mcal_const_no_cacheable"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=".mcal_const_no_cacheable"
        #else
            #pragma section CONST ".mcal_const_no_cacheable"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG .mcal_const_no_cacheable
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_const_cfg" a
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata ".mcal_const_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rodata=".mcal_const_no_cacheable"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_const_no_cacheable"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=".mcal_const_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=".mcal_const_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=".mcal_const_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CONFIG_DATA_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CONFIG_DATA_8_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_CONFIG_DATA_8_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CONFIG_DATA_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_CONFIG_DATA_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CONFIG_DATA_16_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_CONFIG_DATA_16_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CONFIG_DATA_16_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section rodata=".mcal_const_no_cacheable"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=".mcal_const_no_cacheable"
        #else
            #pragma section CONST ".mcal_const_no_cacheable"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG .mcal_const_no_cacheable
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_const_cfg" a
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata ".mcal_const_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rodata=".mcal_const_no_cacheable"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_const_no_cacheable"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=".mcal_const_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=".mcal_const_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=".mcal_const_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CONFIG_DATA_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CONFIG_DATA_16_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_CONFIG_DATA_16_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CONFIG_DATA_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_CONFIG_DATA_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CONFIG_DATA_32_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_CONFIG_DATA_32_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CONFIG_DATA_32_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section rodata=".mcal_const_no_cacheable"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=".mcal_const_no_cacheable"
        #else
            #pragma section CONST ".mcal_const_no_cacheable"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG .mcal_const_no_cacheable
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_const_cfg" a
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata ".mcal_const_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rodata=".mcal_const_no_cacheable"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_const_no_cacheable"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=".mcal_const_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=".mcal_const_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=".mcal_const_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CONFIG_DATA_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CONFIG_DATA_32_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_CONFIG_DATA_32_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CONFIG_DATA_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_CONFIG_DATA_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CONFIG_DATA_UNSPECIFIED_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_CONFIG_DATA_UNSPECIFIED_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CONFIG_DATA_UNSPECIFIED_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section rodata=".mcal_const_no_cacheable"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=".mcal_const_no_cacheable"
        #else
            #pragma section CONST ".mcal_const_no_cacheable"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG .mcal_const_no_cacheable
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_const_cfg" a
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata ".mcal_const_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rodata=".mcal_const_no_cacheable"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_const_no_cacheable"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=".mcal_const_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=".mcal_const_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=".mcal_const_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CONFIG_DATA_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CONFIG_DATA_UNSPECIFIED_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_CONFIG_DATA_UNSPECIFIED_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CONFIG_DATA_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_CONST_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CONST_BOOLEAN
    #define ENTERED_ETH_START_SEC_CONST_BOOLEAN
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CONST_BOOLEAN
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section rodata=".mcal_const"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=".mcal_const"
        #else
            #pragma section CONST ".mcal_const"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG mcal_const
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_const" a
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata ".mcal_const"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rodata=".mcal_const"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_const"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=".mcal_const"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=".mcal_const"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=".mcal_const"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CONST_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CONST_BOOLEAN
        #undef ENTERED_ETH_START_SEC_CONST_BOOLEAN
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CONST_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section CONST
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_CONST_8
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CONST_8
    #define ENTERED_ETH_START_SEC_CONST_8
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CONST_8
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section rodata=".mcal_const"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=".mcal_const"
        #else
            #pragma section CONST ".mcal_const"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG mcal_const
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_const" a
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata ".mcal_const"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rodata=".mcal_const"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_const"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=".mcal_const"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=".mcal_const"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=".mcal_const"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CONST_8
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CONST_8
        #undef ENTERED_ETH_START_SEC_CONST_8
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CONST_8
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section CONST
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_CONST_16
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CONST_16
    #define ENTERED_ETH_START_SEC_CONST_16
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CONST_16
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section rodata=".mcal_const"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=".mcal_const"
        #else
            #pragma section CONST ".mcal_const"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG mcal_const
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_const" a
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata ".mcal_const"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rodata=".mcal_const"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_const"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=".mcal_const"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=".mcal_const"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=".mcal_const"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CONST_16
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CONST_16
        #undef ENTERED_ETH_START_SEC_CONST_16
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CONST_16
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section CONST
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_CONST_32
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CONST_32
    #define ENTERED_ETH_START_SEC_CONST_32
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CONST_32
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section rodata=".mcal_const"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=".mcal_const"
        #else
            #pragma section CONST ".mcal_const"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG mcal_const
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_const" a
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata ".mcal_const"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rodata=".mcal_const"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_const"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=".mcal_const"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=".mcal_const"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=".mcal_const"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CONST_32
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CONST_32
        #undef ENTERED_ETH_START_SEC_CONST_32
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CONST_32
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section CONST
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_CONST_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CONST_UNSPECIFIED
    #define ENTERED_ETH_START_SEC_CONST_UNSPECIFIED
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CONST_UNSPECIFIED
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section rodata=".mcal_const"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=".mcal_const"
        #else
            #pragma section CONST ".mcal_const"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG mcal_const
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_const" a
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata ".mcal_const"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rodata=".mcal_const"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_const"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=".mcal_const"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=".mcal_const"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=".mcal_const"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CONST_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CONST_UNSPECIFIED
        #undef ENTERED_ETH_START_SEC_CONST_UNSPECIFIED
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CONST_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section CONST
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CONST_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section rodata
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section rodata=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section rodata=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section rodata=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_CODE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CODE
    #define ENTERED_ETH_START_SEC_CODE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CODE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section text=".mcal_text"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata="" text=".mcal_text"
        #else
            /* no definition -> default compiler settings are used */
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CODE_SEG mcal_text
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_text" avx
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section text ".mcal_text"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section code=".mcal_text"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_function_attributes = @ ".mcal_text"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section text=".mcal_text"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section text=".mcal_text"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section text=".mcal_text"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CODE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CODE
        #undef ENTERED_ETH_START_SEC_CODE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CODE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata="" text=""
        #else
            /* no definition -> default compiler settings are used */
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CODE_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section text
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_function_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section text=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section text=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section text=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_RAMCODE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_RAMCODE
    #define ENTERED_ETH_START_SEC_RAMCODE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_RAMCODE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section text=".ramcode"
        #pragma ghs inlineprologue
        #pragma ghs callmode=far
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata="" text=".ramcode"
        #else
            #pragma section CODE ".ramcode" far-absolute
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CODE_SEG ramcode
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".ramcode" avx
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section text ".ramcode"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section code=".ramcode"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_function_attributes = @ ".ramcode"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section text=".ramcode"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section text=".ramcode"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section text=".ramcode"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_RAMCODE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_RAMCODE
        #undef ENTERED_ETH_START_SEC_RAMCODE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_RAMCODE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
        #pragma ghs noinlineprologue
        #pragma ghs callmode=default
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        /* default section for CODE */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata="" text=""
        #else
            #pragma section CODE
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CODE_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section text
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_function_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section text=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section text=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section text=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_CODE_AC
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_CODE_AC
    #define ENTERED_ETH_START_SEC_CODE_AC
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_CODE_AC
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section text=".aceth_code_rom"
        #pragma ghs inlineprologue
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        /* use code relative addressing mode to ensure Position-independent Code (PIC) */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata="" text=".aceth_code_rom"
        #else
            #pragma section CODE ".aceth_code_rom" far-code
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CODE_SEG aceth_code_rom
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".aceth_code_rom" avx
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section text ".acfls_code_rom"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section code=".aceth_code_rom"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_function_attributes = @ ".aceth_code_rom"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section text=".acfls_code_rom"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section text=".acfls_code_rom"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section text=".acfls_code_rom"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_CODE_AC
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_CODE_AC
        #undef ENTERED_ETH_START_SEC_CODE_AC
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_CODE_AC
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
        #pragma ghs noinlineprologue
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        /* default section for CODE */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata="" text=""
        #else
            #pragma section CODE
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma CODE_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section text
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_function_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section text=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section text=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section text=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_BOOLEAN
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_BOOLEAN
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_BOOLEAN
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss" data=".mcal_data" rodata=""
        #else
            #pragma section DATA ".mcal_data" ".mcal_bss"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_BOOLEAN
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_BOOLEAN
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_8
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_8
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_8
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_8
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss" data=".mcal_data" rodata=""
        #else
            #pragma section DATA ".mcal_data" ".mcal_bss"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_8
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_8
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_8
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_8
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_16
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_16
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_16
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_16
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss" data=".mcal_data" rodata=""
        #else
            #pragma section DATA ".mcal_data" ".mcal_bss"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_16
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_16
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_16
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_16
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_32
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_32
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_32
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_32
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss" data=".mcal_data" rodata=""
        #else
            #pragma section DATA ".mcal_data" ".mcal_bss"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_32
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_32
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_32
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_32
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_UNSPECIFIED
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_UNSPECIFIED
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_UNSPECIFIED
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss" data=".mcal_data" rodata=""
        #else
            #pragma section DATA ".mcal_data" ".mcal_bss"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_UNSPECIFIED
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_UNSPECIFIED
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_BOOLEAN
    #define ENTERED_ETH_START_SEC_VAR_INIT_BOOLEAN
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_BOOLEAN
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data" bss=".mcal_bss"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss" data=".mcal_data" rodata=""
        #else
            #pragma section DATA ".mcal_data" ".mcal_bss"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data"
        #pragma GCC section bss ".mcal_bss"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_BOOLEAN
        #undef ENTERED_ETH_START_SEC_VAR_INIT_BOOLEAN
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_8
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_8
    #define ENTERED_ETH_START_SEC_VAR_INIT_8
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_8
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data" bss=".mcal_bss"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss" data=".mcal_data" rodata=""
        #else
            #pragma section DATA ".mcal_data" ".mcal_bss"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data"
        #pragma GCC section bss ".mcal_bss"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_8
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_8
        #undef ENTERED_ETH_START_SEC_VAR_INIT_8
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_8
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_16
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_16
    #define ENTERED_ETH_START_SEC_VAR_INIT_16
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_16
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data" bss=".mcal_bss"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss" data=".mcal_data" rodata=""
        #else
            #pragma section DATA ".mcal_data" ".mcal_bss"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data"
        #pragma GCC section bss ".mcal_bss"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_16
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_16
        #undef ENTERED_ETH_START_SEC_VAR_INIT_16
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_16
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_32
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_32
    #define ENTERED_ETH_START_SEC_VAR_INIT_32
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_32
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data" bss=".mcal_bss"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss" data=".mcal_data" rodata=""
        #else
            #pragma section DATA ".mcal_data" ".mcal_bss"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data"
        #pragma GCC section bss ".mcal_bss"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_32
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_32
        #undef ENTERED_ETH_START_SEC_VAR_INIT_32
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_32
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_UNSPECIFIED
    #define ENTERED_ETH_START_SEC_VAR_INIT_UNSPECIFIED
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_UNSPECIFIED
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data" bss=".mcal_bss"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss" data=".mcal_data" rodata=""
        #else
            #pragma section DATA ".mcal_data" ".mcal_bss"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data"
        #pragma GCC section bss ".mcal_bss"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data"
        #pragma clang section bss=".mcal_bss"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_UNSPECIFIED
        #undef ENTERED_ETH_START_SEC_VAR_INIT_UNSPECIFIED
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_BOOLEAN_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_BOOLEAN_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_BOOLEAN_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable" data=".mcal_data_no_cacheable" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable" ".mcal_bss_no_cacheable"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_BOOLEAN_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_BOOLEAN_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_8_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_8_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_8_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable" data=".mcal_data_no_cacheable" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable" ".mcal_bss_no_cacheable"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_8_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_8_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_16_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_16_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_16_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable" data=".mcal_data_no_cacheable" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable" ".mcal_bss_no_cacheable"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_16_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_16_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_32_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_32_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_32_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable" data=".mcal_data_no_cacheable" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable" ".mcal_bss_no_cacheable"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_32_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_32_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_UNSPECIFIED_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_UNSPECIFIED_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_UNSPECIFIED_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable" data=".mcal_data_no_cacheable" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable" ".mcal_bss_no_cacheable"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_UNSPECIFIED_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_UNSPECIFIED_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_BOOLEAN_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_BOOLEAN_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_BOOLEAN_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable" bss=".mcal_bss_no_cacheable"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable" data=".mcal_data_no_cacheable" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable" ".mcal_bss_no_cacheable"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable"
        #pragma GCC section bss ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_BOOLEAN_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_BOOLEAN_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_8_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_8_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_8_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable" bss=".mcal_bss_no_cacheable"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable" data=".mcal_data_no_cacheable" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable" ".mcal_bss_no_cacheable"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable"
        #pragma GCC section bss ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_8_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_8_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_16_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_16_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_16_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable" bss=".mcal_bss_no_cacheable"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable" data=".mcal_data_no_cacheable" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable" ".mcal_bss_no_cacheable"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable"
        #pragma GCC section bss ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_16_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_16_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_32_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_32_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_32_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable" bss=".mcal_bss_no_cacheable"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable" data=".mcal_data_no_cacheable" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable" ".mcal_bss_no_cacheable"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable"
        #pragma GCC section bss ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_32_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_32_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable" bss=".mcal_bss_no_cacheable"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable" data=".mcal_data_no_cacheable" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable" ".mcal_bss_no_cacheable"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable"
        #pragma GCC section bss ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable"
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_UNSPECIFIED_AE_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_UNSPECIFIED_AE_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_UNSPECIFIED_AE_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".dma_dest_buffer_bss" data=".dma_dest_buffer"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".dma_dest_buffer_bss" data=".dma_dest_buffer" rodata=""
        #else
            #pragma section DATA ".dma_dest_buffer" ".dma_dest_buffer_bss"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG dma_dest_buffer_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".dma_dest_buffer_bss" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".dma_dest_buffer_bss"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".dma_dest_buffer_bss"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_UNSPECIFIED_AE_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_UNSPECIFIED_AE_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_UNSPECIFIED_AE_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_UNSPECIFIED_AE_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_UNSPECIFIED_AE_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".dma_dest_buffer_bss" data=".dma_dest_buffer"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".dma_dest_buffer_bss" data=".dma_dest_buffer" rodata=""
        #else
            #pragma section DATA ".dma_dest_buffer" ".dma_dest_buffer_bss"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG dma_dest_buffer
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".dma_dest_buffer" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".dma_dest_buffer"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".dma_dest_buffer"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_UNSPECIFIED_AE_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_UNSPECIFIED_AE_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
         #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_SHARED_INIT_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_SHARED_INIT_UNSPECIFIED_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_SHARED_INIT_UNSPECIFIED_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_SHARED_INIT_UNSPECIFIED_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_shared_data" bss=".mcal_shared_bss"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_shared_bss" data=".mcal_shared_data" rodata=""
        #else
            #pragma section DATA ".mcal_shared_data" ".mcal_shared_bss"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG .mcal_shared_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_shared_data" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_shared_data"
        #pragma GCC section bss ".mcal_shared_bss"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_shared_data"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_shared_data"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_shared_data"
        #pragma clang section bss=".mcal_shared_bss"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_shared_data"
        #pragma clang section bss=".mcal_shared_bss"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_shared_data"
        #pragma clang section bss=".mcal_shared_bss"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_SHARED_INIT_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_SHARED_INIT_UNSPECIFIED_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_SHARED_INIT_UNSPECIFIED_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_SHARED_INIT_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=""
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=""
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=""
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_SHARED_CLEARED_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_SHARED_CLEARED_UNSPECIFIED_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_SHARED_CLEARED_UNSPECIFIED_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_SHARED_CLEARED_UNSPECIFIED_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_shared_bss"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_shared_bss" data=".mcal_shared_data" rodata=""
        #else
            #pragma section DATA ".mcal_shared_data" ".mcal_shared_bss"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG .mcal_shared_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_shared_bss" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_shared_bss"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_shared_bss"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_shared_bss"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_shared_bss"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_shared_bss"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_shared_bss"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_SHARED_CLEARED_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_SHARED_CLEARED_UNSPECIFIED_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_SHARED_CLEARED_UNSPECIFIED_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_SHARED_CLEARED_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

/* Define memory sections if multipartition support is enabled */

/*=============== Define memory sections for EcuCPartition_0================== */

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_0" data=".mcal_data_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_0" ".mcal_bss_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_0" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_0"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_8
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_8
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_8
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_8
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_0" data=".mcal_data_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_0" ".mcal_bss_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_0" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_0"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_8
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_8
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_8
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_8
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_16
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_16
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_16
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_16
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_0" data=".mcal_data_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_0" ".mcal_bss_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_0" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_0"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_16
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_16
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_16
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_16
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_32
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_32
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_32
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_32
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_0" data=".mcal_data_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_0" ".mcal_bss_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_0" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_0"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_32
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_32
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_32
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_32
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_0" data=".mcal_data_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_0" ".mcal_bss_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_0" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_0"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_0" bss=".mcal_bss_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_0" data=".mcal_data_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_0" ".mcal_bss_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_0" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_0"
        #pragma GCC section bss ".mcal_bss_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_0"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_8
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_8
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_8
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_8
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_0" bss=".mcal_bss_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_0" data=".mcal_data_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_0" ".mcal_bss_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_0" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_0"
        #pragma GCC section bss ".mcal_bss_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_0"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_8
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_8
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_8
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_8
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_16
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_16
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_16
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_16
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_0" bss=".mcal_bss_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_0" data=".mcal_data_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_0" ".mcal_bss_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_0" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_0"
        #pragma GCC section bss ".mcal_bss_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_0"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_16
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_16
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_16
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_16
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_32
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_32
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_32
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_32
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_0" bss=".mcal_bss_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_0" data=".mcal_data_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_0" ".mcal_bss_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_0" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_0"
        #pragma GCC section bss ".mcal_bss_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_0"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_32
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_32
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_32
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_32
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_0" bss=".mcal_bss_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_0" data=".mcal_data_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_0" ".mcal_bss_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_0" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_0"
        #pragma GCC section bss ".mcal_bss_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_0"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_0"
        #pragma clang section bss=".mcal_bss_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_0" data=".mcal_data_no_cacheable_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_0" ".mcal_bss_no_cacheable_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_0" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_8_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_8_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_8_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_0" data=".mcal_data_no_cacheable_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_0" ".mcal_bss_no_cacheable_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_0" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_8_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_8_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_16_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_16_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_16_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_0" data=".mcal_data_no_cacheable_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_0" ".mcal_bss_no_cacheable_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_0" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_16_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_16_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_32_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_32_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_32_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_0" data=".mcal_data_no_cacheable_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_0" ".mcal_bss_no_cacheable_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_0" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_32_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_32_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_0" data=".mcal_data_no_cacheable_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_0" ".mcal_bss_no_cacheable_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_0" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_0" bss=".mcal_bss_no_cacheable_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_0" data=".mcal_data_no_cacheable_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_0" ".mcal_bss_no_cacheable_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_0"
        #pragma GCC section bss ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_8_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_8_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_8_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_0" bss=".mcal_bss_no_cacheable_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_0" data=".mcal_data_no_cacheable_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_0" ".mcal_bss_no_cacheable_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_0"
        #pragma GCC section bss ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_8_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_8_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_16_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_16_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_16_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_0" bss=".mcal_bss_no_cacheable_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_0" data=".mcal_data_no_cacheable_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_0" ".mcal_bss_no_cacheable_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_0"
        #pragma GCC section bss ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_16_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_16_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_32_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_32_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_32_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_0" bss=".mcal_bss_no_cacheable_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_0" data=".mcal_data_no_cacheable_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_0" ".mcal_bss_no_cacheable_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_0"
        #pragma GCC section bss ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_32_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_32_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_0" bss=".mcal_bss_no_cacheable_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_0" data=".mcal_data_no_cacheable_0" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_0" ".mcal_bss_no_cacheable_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_0"
        #pragma GCC section bss ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_0"
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".dma_dest_buffer_3_bss_0" data=".dma_dest_buffer_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".dma_dest_buffer_3_bss_0" data=".dma_dest_buffer_0" rodata=""
        #else
            #pragma section DATA ".dma_dest_buffer_0" ".dma_dest_buffer_3_bss_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG dma_dest_buffer_3_bss_3
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".dma_dest_buffer_3_bss_0" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".dma_dest_buffer_3_bss_0"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".dma_dest_buffer_3_bss_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".dma_dest_buffer_3_bss_0" data=".dma_dest_buffer_0"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".dma_dest_buffer_3_bss_0" data=".dma_dest_buffer_0" rodata=""
        #else
            #pragma section DATA ".dma_dest_buffer_0" ".dma_dest_buffer_3_bss_0"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG dma_dest_buffer_3
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".dma_dest_buffer_0" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_0"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".dma_dest_buffer_0"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".dma_dest_buffer_0"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_0"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_0"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_0"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION0_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
         #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

/* Define memory sections if multipartition support is enabled */

/*=============== Define memory sections for EcuCPartition_1================== */

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_1" data=".mcal_data_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_1" ".mcal_bss_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_1" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_1"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_8
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_8
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_8
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_8
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_1" data=".mcal_data_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_1" ".mcal_bss_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_1" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_1"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_8
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_8
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_8
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_8
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_16
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_16
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_16
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_16
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_1" data=".mcal_data_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_1" ".mcal_bss_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_1" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_1"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_16
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_16
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_16
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_16
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_32
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_32
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_32
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_32
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_1" data=".mcal_data_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_1" ".mcal_bss_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_1" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_1"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_32
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_32
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_32
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_32
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_1" data=".mcal_data_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_1" ".mcal_bss_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_1" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_1"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_1" bss=".mcal_bss_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_1" data=".mcal_data_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_1" ".mcal_bss_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_1" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_1"
        #pragma GCC section bss ".mcal_bss_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_1"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_8
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_8
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_8
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_8
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_1" bss=".mcal_bss_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_1" data=".mcal_data_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_1" ".mcal_bss_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_1" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_1"
        #pragma GCC section bss ".mcal_bss_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_1"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_8
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_8
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_8
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_8
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_16
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_16
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_16
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_16
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_1" bss=".mcal_bss_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_1" data=".mcal_data_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_1" ".mcal_bss_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_1" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_1"
        #pragma GCC section bss ".mcal_bss_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_1"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_16
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_16
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_16
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_16
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_32
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_32
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_32
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_32
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_1" bss=".mcal_bss_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_1" data=".mcal_data_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_1" ".mcal_bss_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_1" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_1"
        #pragma GCC section bss ".mcal_bss_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_1"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_32
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_32
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_32
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_32
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_1" bss=".mcal_bss_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_1" data=".mcal_data_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_1" ".mcal_bss_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_1" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_1"
        #pragma GCC section bss ".mcal_bss_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_1"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_1"
        #pragma clang section bss=".mcal_bss_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_1" data=".mcal_data_no_cacheable_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_1" ".mcal_bss_no_cacheable_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_1" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_8_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_8_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_8_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_1" data=".mcal_data_no_cacheable_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_1" ".mcal_bss_no_cacheable_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_1" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_8_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_8_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_16_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_16_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_16_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_1" data=".mcal_data_no_cacheable_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_1" ".mcal_bss_no_cacheable_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_1" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_16_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_16_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_32_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_32_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_32_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_1" data=".mcal_data_no_cacheable_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_1" ".mcal_bss_no_cacheable_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_1" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_32_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_32_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_1" data=".mcal_data_no_cacheable_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_1" ".mcal_bss_no_cacheable_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_1" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_1" bss=".mcal_bss_no_cacheable_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_1" data=".mcal_data_no_cacheable_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_1" ".mcal_bss_no_cacheable_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_1"
        #pragma GCC section bss ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_8_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_8_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_8_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_1" bss=".mcal_bss_no_cacheable_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_1" data=".mcal_data_no_cacheable_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_1" ".mcal_bss_no_cacheable_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_1"
        #pragma GCC section bss ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_8_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_8_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_16_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_16_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_16_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_1" bss=".mcal_bss_no_cacheable_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_1" data=".mcal_data_no_cacheable_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_1" ".mcal_bss_no_cacheable_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_1"
        #pragma GCC section bss ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_16_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_16_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_32_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_32_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_32_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_1" bss=".mcal_bss_no_cacheable_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_1" data=".mcal_data_no_cacheable_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_1" ".mcal_bss_no_cacheable_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_1"
        #pragma GCC section bss ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_32_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_32_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_1" bss=".mcal_bss_no_cacheable_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_1" data=".mcal_data_no_cacheable_1" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_1" ".mcal_bss_no_cacheable_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_1"
        #pragma GCC section bss ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_1"
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".dma_dest_buffer_3_bss_1" data=".dma_dest_buffer_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".dma_dest_buffer_3_bss_1" data=".dma_dest_buffer_1" rodata=""
        #else
            #pragma section DATA ".dma_dest_buffer_1" ".dma_dest_buffer_3_bss_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG dma_dest_buffer_3_bss_3
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".dma_dest_buffer_3_bss_1" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".dma_dest_buffer_3_bss_1"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".dma_dest_buffer_3_bss_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".dma_dest_buffer_3_bss_1" data=".dma_dest_buffer_1"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".dma_dest_buffer_3_bss_1" data=".dma_dest_buffer_1" rodata=""
        #else
            #pragma section DATA ".dma_dest_buffer_1" ".dma_dest_buffer_3_bss_1"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG dma_dest_buffer_3
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".dma_dest_buffer_1" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_1"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".dma_dest_buffer_1"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".dma_dest_buffer_1"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_1"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_1"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_1"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION1_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
         #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

/* Define memory sections if multipartition support is enabled */

/*=============== Define memory sections for EcuCPartition_2================== */

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_2" data=".mcal_data_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_2" ".mcal_bss_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_2" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_2"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_8
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_8
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_8
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_8
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_2" data=".mcal_data_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_2" ".mcal_bss_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_2" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_2"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_8
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_8
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_8
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_8
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_16
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_16
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_16
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_16
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_2" data=".mcal_data_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_2" ".mcal_bss_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_2" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_2"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_16
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_16
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_16
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_16
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_32
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_32
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_32
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_32
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_2" data=".mcal_data_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_2" ".mcal_bss_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_2" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_2"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_32
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_32
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_32
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_32
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_2" data=".mcal_data_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_2" ".mcal_bss_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_2" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_2"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_2" bss=".mcal_bss_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_2" data=".mcal_data_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_2" ".mcal_bss_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_2" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_2"
        #pragma GCC section bss ".mcal_bss_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_2"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_8
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_8
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_8
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_8
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_2" bss=".mcal_bss_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_2" data=".mcal_data_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_2" ".mcal_bss_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_2" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_2"
        #pragma GCC section bss ".mcal_bss_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_2"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_8
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_8
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_8
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_8
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_16
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_16
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_16
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_16
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_2" bss=".mcal_bss_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_2" data=".mcal_data_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_2" ".mcal_bss_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_2" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_2"
        #pragma GCC section bss ".mcal_bss_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_2"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_16
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_16
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_16
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_16
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_32
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_32
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_32
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_32
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_2" bss=".mcal_bss_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_2" data=".mcal_data_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_2" ".mcal_bss_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_2" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_2"
        #pragma GCC section bss ".mcal_bss_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_2"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_32
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_32
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_32
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_32
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_2" bss=".mcal_bss_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_2" data=".mcal_data_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_2" ".mcal_bss_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_2" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_2"
        #pragma GCC section bss ".mcal_bss_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_2"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_2"
        #pragma clang section bss=".mcal_bss_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_2" data=".mcal_data_no_cacheable_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_2" ".mcal_bss_no_cacheable_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_2" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_8_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_8_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_8_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_2" data=".mcal_data_no_cacheable_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_2" ".mcal_bss_no_cacheable_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_2" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_8_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_8_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_16_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_16_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_16_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_2" data=".mcal_data_no_cacheable_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_2" ".mcal_bss_no_cacheable_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_2" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_16_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_16_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_32_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_32_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_32_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_2" data=".mcal_data_no_cacheable_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_2" ".mcal_bss_no_cacheable_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_2" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_32_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_32_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_2" data=".mcal_data_no_cacheable_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_2" ".mcal_bss_no_cacheable_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_2" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_2" bss=".mcal_bss_no_cacheable_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_2" data=".mcal_data_no_cacheable_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_2" ".mcal_bss_no_cacheable_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_2"
        #pragma GCC section bss ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_8_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_8_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_8_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_2" bss=".mcal_bss_no_cacheable_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_2" data=".mcal_data_no_cacheable_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_2" ".mcal_bss_no_cacheable_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_2"
        #pragma GCC section bss ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_8_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_8_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_16_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_16_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_16_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_2" bss=".mcal_bss_no_cacheable_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_2" data=".mcal_data_no_cacheable_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_2" ".mcal_bss_no_cacheable_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_2"
        #pragma GCC section bss ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_16_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_16_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_32_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_32_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_32_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_2" bss=".mcal_bss_no_cacheable_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_2" data=".mcal_data_no_cacheable_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_2" ".mcal_bss_no_cacheable_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_2"
        #pragma GCC section bss ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_32_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_32_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_2" bss=".mcal_bss_no_cacheable_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_2" data=".mcal_data_no_cacheable_2" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_2" ".mcal_bss_no_cacheable_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_2"
        #pragma GCC section bss ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_2"
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".dma_dest_buffer_3_bss_2" data=".dma_dest_buffer_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".dma_dest_buffer_3_bss_2" data=".dma_dest_buffer_2" rodata=""
        #else
            #pragma section DATA ".dma_dest_buffer_2" ".dma_dest_buffer_3_bss_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG dma_dest_buffer_3_bss_3
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".dma_dest_buffer_3_bss_2" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".dma_dest_buffer_3_bss_2"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".dma_dest_buffer_3_bss_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".dma_dest_buffer_3_bss_2" data=".dma_dest_buffer_2"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".dma_dest_buffer_3_bss_2" data=".dma_dest_buffer_2" rodata=""
        #else
            #pragma section DATA ".dma_dest_buffer_2" ".dma_dest_buffer_3_bss_2"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG dma_dest_buffer_3
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".dma_dest_buffer_2" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_2"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".dma_dest_buffer_2"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".dma_dest_buffer_2"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_2"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_2"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_2"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION2_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
         #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

/* Define memory sections if multipartition support is enabled */

/*=============== Define memory sections for EcuCPartition_3================== */

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_3" data=".mcal_data_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_3" ".mcal_bss_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_3" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_3"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_8
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_8
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_8
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_8
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_3" data=".mcal_data_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_3" ".mcal_bss_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_3" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_3"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_8
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_8
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_8
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_8
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_16
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_16
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_16
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_16
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_3" data=".mcal_data_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_3" ".mcal_bss_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_3" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_3"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_16
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_16
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_16
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_16
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_32
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_32
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_32
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_32
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_3" data=".mcal_data_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_3" ".mcal_bss_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_3" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_3"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_32
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_32
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_32
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_32
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_3" data=".mcal_data_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_3" ".mcal_bss_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_3" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".mcal_bss_3"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_3" bss=".mcal_bss_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_3" data=".mcal_data_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_3" ".mcal_bss_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_3" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_3"
        #pragma GCC section bss ".mcal_bss_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_3"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_8
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_8
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_8
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_8
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_3" bss=".mcal_bss_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_3" data=".mcal_data_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_3" ".mcal_bss_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_3" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_3"
        #pragma GCC section bss ".mcal_bss_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_3"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_8
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_8
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_8
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_8
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_16
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_16
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_16
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_16
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_3" bss=".mcal_bss_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_3" data=".mcal_data_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_3" ".mcal_bss_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_3" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_3"
        #pragma GCC section bss ".mcal_bss_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_3"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_16
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_16
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_16
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_16
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_32
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_32
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_32
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_32
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_3" bss=".mcal_bss_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_3" data=".mcal_data_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_3" ".mcal_bss_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_3" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_3"
        #pragma GCC section bss ".mcal_bss_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_3"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_32
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_32
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_32
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_32
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_3" bss=".mcal_bss_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_3" data=".mcal_data_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_3" ".mcal_bss_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_data_3" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_3"
        #pragma GCC section bss ".mcal_bss_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".mcal_data_3"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_3"
        #pragma clang section bss=".mcal_bss_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_3" data=".mcal_data_no_cacheable_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_3" ".mcal_bss_no_cacheable_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_3" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_8_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_8_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_8_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_3" data=".mcal_data_no_cacheable_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_3" ".mcal_bss_no_cacheable_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_3" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_8_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_8_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_16_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_16_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_16_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_3" data=".mcal_data_no_cacheable_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_3" ".mcal_bss_no_cacheable_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_3" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_16_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_16_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_32_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_32_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_32_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_3" data=".mcal_data_no_cacheable_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_3" ".mcal_bss_no_cacheable_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_3" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_32_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_32_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".mcal_bss_no_cacheable_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_3" data=".mcal_data_no_cacheable_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_3" ".mcal_bss_no_cacheable_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".mcal_bss_no_cacheable_3" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_3" bss=".mcal_bss_no_cacheable_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_3" data=".mcal_data_no_cacheable_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_3" ".mcal_bss_no_cacheable_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_3"
        #pragma GCC section bss ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_BOOLEAN_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_8_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_8_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_8_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_3" bss=".mcal_bss_no_cacheable_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_3" data=".mcal_data_no_cacheable_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_3" ".mcal_bss_no_cacheable_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_3"
        #pragma GCC section bss ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_8_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_8_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_8_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_16_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_16_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_16_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_3" bss=".mcal_bss_no_cacheable_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_3" data=".mcal_data_no_cacheable_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_3" ".mcal_bss_no_cacheable_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_3"
        #pragma GCC section bss ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_16_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_16_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_16_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_32_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_32_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_32_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_3" bss=".mcal_bss_no_cacheable_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_3" data=".mcal_data_no_cacheable_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_3" ".mcal_bss_no_cacheable_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_3"
        #pragma GCC section bss ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_32_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_32_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_32_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section data=".mcal_data_no_cacheable_3" bss=".mcal_bss_no_cacheable_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".mcal_bss_no_cacheable_3" data=".mcal_data_no_cacheable_3" rodata=""
        #else
            #pragma section DATA ".mcal_data_no_cacheable_3" ".mcal_bss_no_cacheable_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_data
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_3"
        #pragma GCC section bss ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".mcal_data_no_cacheable_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_3"
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
         /* not supported by HighTec */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".dma_dest_buffer_3_bss_3" data=".dma_dest_buffer_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".dma_dest_buffer_3_bss_3" data=".dma_dest_buffer_3" rodata=""
        #else
            #pragma section DATA ".dma_dest_buffer_3" ".dma_dest_buffer_3_bss_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG dma_dest_buffer_3_bss_3
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".dma_dest_buffer_3_bss_3" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".mcal_bss_no_cacheable_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section zidata=".dma_dest_buffer_3_bss_3"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".dma_dest_buffer_3_bss_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=".mcal_bss_no_cacheable_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_CLEARED_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section bss=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
    #define ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".dma_dest_buffer_3_bss_3" data=".dma_dest_buffer_3"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".dma_dest_buffer_3_bss_3" data=".dma_dest_buffer_3" rodata=""
        #else
            #pragma section DATA ".dma_dest_buffer_3" ".dma_dest_buffer_3_bss_3"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG dma_dest_buffer_3
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".dma_dest_buffer_3" aws
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data ".mcal_data_no_cacheable_3"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        #pragma arm section rwdata=".dma_dest_buffer_3"
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".dma_dest_buffer_3"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=".mcal_data_no_cacheable_3"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=".mcal_data_no_cacheable_3"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=".mcal_data_no_cacheable_3"
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
        #undef ENTERED_ETH_START_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_INIT_ECUCPARTITION3_UNSPECIFIED_AE_NO_CACHEABLE
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
         #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section data
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section data=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section data=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_START_SEC_VAR_NO_INIT_PERSISTENT_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef ETH_START_SEC_VAR_NO_INIT_PERSISTENT_UNSPECIFIED
    #define ENTERED_ETH_START_SEC_VAR_NO_INIT_PERSISTENT_UNSPECIFIED
    #ifndef MEMMAP_MATCH_ERROR
        #define MEMMAP_MATCH_ERROR
    #else
        #ifndef ETH_STOP_SEC_VAR_NO_INIT_PERSISTENT_UNSPECIFIED
        #error "MemMap.h, no valid matching start-stop section defined."
        #endif
    #endif
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section bss=".standby_data"
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss=".standby_data" data="" rodata=""
        #else
            #pragma section DATA "" ".standby_data"
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG mcal_bss
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        #pragma section ".standby_data" awsB
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss ".standby_data"
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes = @ ".standby_data"
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=".standby_data"
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=".standby_data"
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

#ifdef ETH_STOP_SEC_VAR_NO_INIT_PERSISTENT_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #ifdef ENTERED_ETH_START_SEC_VAR_NO_INIT_PERSISTENT_UNSPECIFIED
        #undef ENTERED_ETH_START_SEC_VAR_NO_INIT_PERSISTENT_UNSPECIFIED
    #else
        #error "MemMap.h, no valid matching start-stop section defined."
    #endif
    #ifdef MEMMAP_MATCH_ERROR
        #undef MEMMAP_MATCH_ERROR
    #endif
    #undef ETH_STOP_SEC_VAR_NO_INIT_PERSISTENT_UNSPECIFIED
    /**
    * @file Eth_MemMap.h
    */
    #undef MEMMAP_ERROR
    #ifdef _GREENHILLS_C_S32K5XX_             /* GREENHILLS  */
        #pragma ghs section
    #elif defined _DIABDATA_C_S32K5XX_      /* DIAB        */
        #ifdef __clang__
            #pragma clang section bss="" data="" rodata=""
        #else
            #pragma section DATA
        #endif
    #elif defined _CODEWARRIOR_C_S32K5XX_      /* CODEWARRIOR */
        #pragma DATA_SEG DEFAULT
    #elif defined _HITECH_C_S32K5XX_      /* HighTec     */
        /* no definition -> default compiler settings are used */
    #elif defined _GCC_C_S32K5XX_      /* GCC         */
        #pragma GCC section bss
    #elif defined _ARM_DS5_C_S32K5XX_      /* DS5         */
        /* no definition -> default compiler settings are used */
    #elif defined _IAR_C_S32K5XX_      /* IAR         */
        #pragma default_variable_attributes =
    #elif defined _ARM_DS6_S32K5XX_      /* ARM-DS6     */
        #pragma clang section bss=""
    #elif defined _ZEN_V_S32K5XX_      /* ZEN-V       */
        #pragma clang section bss=""
    #elif defined _XTENSA_S32K5XX_     /* XTENSA      */
        #pragma clang section data=""
    #else
        #error "Incorrect compiler selection, please refer to chapter Compiler Options in Release Note"
    #endif
#endif

/**************************************************************************************************/
/****************************************** Report error ******************************************/
/**************************************************************************************************/
#ifdef MEMMAP_ERROR
    #error "MemMap.h, no valid memory mapping symbol defined."
#endif

/*==================================================================================================
*                                            ENUMS
==================================================================================================*/

/*==================================================================================================
*                                 STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                 GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                     FUNCTION PROTOTYPES
==================================================================================================*/

#ifdef __cplusplus
}
#endif

/** @} */

