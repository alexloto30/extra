/*==================================================================================================
* Project : RTD AUTOSAR 4.9
* Platform : CORTEXM
* Peripheral : S32K56XM7
* Dependencies : none
*
* Autosar Version : 4.9.0
* Autosar Revision : ASR_REL_4_9_REV_0000
* Autosar Conf.Variant :
* SW Version : 1.0.0
* Build Version : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
* Copyright 2024 - 2026 NXP
*
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/
/**
*   @file OsIf_Cfg.h
*   @version 1.0.0
*
*   @brief   BaseNXP - Driver header file.
*   @details Specific driver header file.
*
*   @addtogroup osif_drv
*   @{
*/

#ifndef OSIF_CFG_H
#define OSIF_CFG_H

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/
#include "OsIf_ArchCfg.h"
#include "Std_Types.h"

[!NOCODE!][!// Include specific header file
[!IF "node:exists(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative)"!][!//
    [!IF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k312')"!][!//
[!CODE!][!WS "0"!]#include "S32K312_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K312_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k311')"!][!//
[!CODE!][!WS "0"!]#include "S32K311_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K311_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k310')"!][!//
[!CODE!][!WS "0"!]#include "S32K311_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K311_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k314')"!][!//
[!CODE!][!WS "0"!]#include "S32K314_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K314_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k324')"!][!//
[!CODE!][!WS "0"!]#include "S32K324_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K324_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k342')"!][!//
[!CODE!][!WS "0"!]#include "S32K342_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K342_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k344')"!][!//
[!CODE!][!WS "0"!]#include "S32K344_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K344_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k341')"!][!//
[!CODE!][!WS "0"!]#include "S32K341_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K341_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k322')"!][!//
[!CODE!][!WS "0"!]#include "S32K322_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K322_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k39')"!][!//
[!CODE!][!WS "0"!]#include "S32K39_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K39_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k36')"!][!//
[!CODE!][!WS "0"!]#include "S32K36_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K36_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k37')"!][!//
[!CODE!][!WS "0"!]#include "S32K37_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K37_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k358')"!][!//
[!CODE!][!WS "0"!]#include "S32K358_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K358_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k328')"!][!//
[!CODE!][!WS "0"!]#include "S32K358_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K358_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k338')"!][!//
[!CODE!][!WS "0"!]#include "S32K358_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K358_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k348')"!][!//
[!CODE!][!WS "0"!]#include "S32K358_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K358_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k356')"!][!//
[!CODE!][!WS "0"!]#include "S32K356_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K356_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k388')"!][!//
[!CODE!][!WS "0"!]#include "S32K388_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K388_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k389')"!][!//
[!CODE!][!WS "0"!]#include "S32K389_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K389_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "text:match(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32m27')"!][!//
[!CODE!][!WS "0"!]#include "S32M27x_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32M27x_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32g2')"!][!//
[!CODE!][!WS "0"!]#include "S32G274A_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32G274A_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32g3')"!][!//
[!CODE!][!WS "0"!]#include "S32G399A_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32G399A_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32r45')"!][!//
[!CODE!][!WS "0"!]#include "S32R45_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32R45_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32r41')"!][!//
[!CODE!][!WS "0"!]#include "S32R41_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32R41_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 'saf84')"!][!//
[!CODE!][!WS "0"!]#include "SAF84xx_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "SAF84xx_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 'saf85')"!][!//
[!CODE!][!WS "0"!]#include "SAF85xx_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "SAF85xx_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 'saf86')"!][!//
[!CODE!][!WS "0"!]#include "SAF86xx_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "SAF86xx_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k116')"!][!//
[!CODE!][!WS "0"!]#include "S32K116_SYSTICK.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k118')"!][!//
[!CODE!][!WS "0"!]#include "S32K118_SYSTICK.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k142w')"!][!//
[!CODE!][!WS "0"!]#include "S32K142W_SYSTICK.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k142')"!][!//
[!CODE!][!WS "0"!]#include "S32K142_SYSTICK.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k144w')"!][!//
[!CODE!][!WS "0"!]#include "S32K144W_SYSTICK.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k144')"!][!//
[!CODE!][!WS "0"!]#include "S32K144_SYSTICK.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k146')"!][!//
[!CODE!][!WS "0"!]#include "S32K146_SYSTICK.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k148')"!][!//
[!CODE!][!WS "0"!]#include "S32K148_SYSTICK.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32m24')"!][!//
[!CODE!][!WS "0"!]#include "S32M24x_SYSTICK.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32e')"!][!//
[!CODE!][!WS "0"!]#include "S32E2_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32E2_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32z')"!][!//
[!CODE!][!WS "0"!]#include "S32Z2_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32Z2_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32n5')"!][!//
[!CODE!][!WS "0"!]#include "S32N55_SYSTICK.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32n79')"!][!//
[!CODE!][!WS "0"!]#include "S32N79_SYSTICK.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32n75')"!][!//
[!CODE!][!WS "0"!]#include "S32N75_SYSTICK.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 'sja')"!][!//
[!CODE!][!WS "0"!]#include "SJA1110.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k566')"!][!//
[!CODE!][!WS "0"!]#include "S32K566_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32K566_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 'saf9')"!][!//
[!CODE!][!WS "0"!]#include "SAF9000_SYSTICK.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32a20')"!][!//
[!CODE!][!WS "0"!]#include "S32A20_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]/* #include "S32A20_MSCM.h" */[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32r47')"!][!//
[!CODE!][!WS "0"!]#include "S32R47_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32R47_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32r43')"!][!//
[!CODE!][!WS "0"!]#include "S32R47_SYSTICK.h"[!CR!][!ENDCODE!][!//
[!CODE!][!WS "0"!]#include "S32R47_MSCM.h"[!CR!][!ENDCODE!][!//
    [!ELSEIF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32k12')"!][!//
[!CODE!][!WS "0"!]#include "S32K12_SYSTICK.h"[!CR!][!ENDCODE!][!//
    [!ENDIF!][!//
[!ELSE!][!//
    [!ERROR "The Resource plugin or ResourceSubderivative field is not available for header file inclusion."!][!//
[!ENDIF!][!//
[!ENDNOCODE!][!//
/*==================================================================================================
*                                 SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define OSIF_CFG_VENDOR_ID                    43
#define OSIF_CFG_AR_RELEASE_MAJOR_VERSION     4
#define OSIF_CFG_AR_RELEASE_MINOR_VERSION     9
#define OSIF_CFG_AR_RELEASE_REVISION_VERSION  0
#define OSIF_CFG_SW_MAJOR_VERSION             1
#define OSIF_CFG_SW_MINOR_VERSION             0
#define OSIF_CFG_SW_PATCH_VERSION             0

/*==================================================================================================
*                                       FILE VERSION CHECKS
==================================================================================================*/
/* Check if OsIf_Cfg.h file and OsIf_ArchCfg.h file are of the same vendor */
#if (OSIF_CFG_VENDOR_ID != OSIF_ARCHCFG_VENDOR_ID)
    #error "OsIf_Cfg.h and OsIf_ArchCfg.h have different vendor ids"
#endif
/* Check if OsIf_Cfg.h file and OsIf_ArchCfg.h file are of the same Autosar version */
#if ((OSIF_CFG_AR_RELEASE_MAJOR_VERSION    != OSIF_ARCHCFG_AR_RELEASE_MAJOR_VERSION) || \
     (OSIF_CFG_AR_RELEASE_MINOR_VERSION    != OSIF_ARCHCFG_AR_RELEASE_MINOR_VERSION) || \
     (OSIF_CFG_AR_RELEASE_REVISION_VERSION != OSIF_ARCHCFG_AR_RELEASE_REVISION_VERSION))
     #error "AUTOSAR Version Numbers of OsIf_Cfg.h and OsIf_ArchCfg.h are different"
#endif
/* Check if OsIf_Cfg.h file and OsIf_ArchCfg.h file are of the same Software version */
#if ((OSIF_CFG_SW_MAJOR_VERSION != OSIF_ARCHCFG_SW_MAJOR_VERSION) || \
     (OSIF_CFG_SW_MINOR_VERSION != OSIF_ARCHCFG_SW_MINOR_VERSION) || \
     (OSIF_CFG_SW_PATCH_VERSION != OSIF_ARCHCFG_SW_PATCH_VERSION))
    #error "Software Version Numbers of OsIf_Cfg.h and OsIf_ArchCfg.h are different"
#endif

/* Check if OsIf_Cfg.h file and Std_Types.h file are of the same Autosar version */
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    #if ((OSIF_CFG_AR_RELEASE_MAJOR_VERSION != STD_AR_RELEASE_MAJOR_VERSION) || \
         (OSIF_CFG_AR_RELEASE_MINOR_VERSION != STD_AR_RELEASE_MINOR_VERSION))
        #error "AutoSar Version Numbers of OsIf_Cfg.h and Std_Types.h are different"
    #endif
#endif /* DISABLE_MCAL_INTERMODULE_ASR_CHECK */

/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/

/* General OSIF configuration */
#define OSIF_MODULE_ID                   (255U)

#define OSIF_DRIVER_INSTANCE             ([!"OsIfGeneral/OsIfInstanceId"!]U)

#define OSIF_ENABLE_USER_MODE_SUPPORT    ([!IF "OsIfGeneral/OsIfEnableUserModeSupport"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])

#ifndef MCAL_ENABLE_USER_MODE_SUPPORT
    #if (STD_ON == OSIF_ENABLE_USER_MODE_SUPPORT)
        #error MCAL_ENABLE_USER_MODE_SUPPORT is not enabled. For running OsIf in user mode, MCAL_ENABLE_USER_MODE_SUPPORT needs to be defined.
    #endif /* (STD_ON == OSIF_ENABLE_USER_MODE_SUPPORT */
#endif /* ifndef MCAL_ENABLE_USER_MODE_SUPPORT */

#define OSIF_ENABLE_MULTICORE_SUPPORT    ([!IF "OsIfGeneral/OsIfMulticoreSupport"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])

#define OSIF_MAX_COREIDX_SUPPORTED       ([!IF "OsIfGeneral/OsIfMulticoreSupport"!][!"num:i(node:fallback("->num:max(as:modconf('EcuC')/EcucHardware/EcucCoreDefinition/*/EcucCoreId) + 1", 1))"!][!ELSE!]1[!ENDIF!]U)

[!NOCODE!]
[!VAR "maxNumPartition" = "num:i(0)"!]
[!IF "node:value(OsIfGeneral/OsIfMulticoreSupport)='true'"!]
[!IF "node:exists(as:modconf("EcuC")[1]/EcucPartitionCollection/EcucPartition)"!]
    [!VAR "maxNumPartition" = "num:i(count(as:modconf("EcuC")[1]/EcucPartitionCollection/EcucPartition/*))"!]
[!ENDIF!]
[!ENDIF!]
[!IF "$maxNumPartition = 0"!][!VAR "maxNumPartition" = "num:i(1)"!][!ENDIF!]
[!ENDNOCODE!]
#define OSIF_MAX_NUM_PARTITION_SUPPORTED ([!"num:i($maxNumPartition)"!]U)

#define OSIF_MAX_APPIDX_SUPPORTED        ([!IF "OsIfGeneral/OsIfMulticoreSupport"!][!"num:i(count(as:modconf('Os')[1]/OsApplication/*))"!][!ELSE!]1[!ENDIF!]U)

#define OSIF_DEV_ERROR_DETECT            ([!IF "OsIfGeneral/OsIfDevErrorDetect"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])

[!NOCODE!]
[!IF "node:exists(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative)"!][!//
    [!CODE!]#define USING_COHORT_DOMAIN_ID           ([!IF "contains(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative, 's32n')"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])[!ENDCODE!]
[!ELSE!][!//
    [!CODE!]#define USING_COHORT_DOMAIN_ID           (STD_OFF)[!ENDCODE!]
[!ENDIF!][!//
[!ENDNOCODE!]

[!NOCODE!]

[!IF "node:containsValue(OsIfGeneral/OsIfOperatingSystemType/@name, 'OsIfAutosarOsType')"!]
[!CODE!]#define USING_OS_AUTOSAROS[!ENDCODE!]
[!ENDIF!]

[!IF "node:containsValue(OsIfGeneral/OsIfOperatingSystemType/@name, 'OsIfBaremetalType')"!]
[!CODE!]#define USING_OS_BAREMETAL[!ENDCODE!]
[!ENDIF!]

[!IF "node:containsValue(OsIfGeneral/OsIfOperatingSystemType/@name, 'OsIfFreeRtosType')"!]
[!CODE!]#define USING_OS_FREERTOS[!ENDCODE!]
[!ENDIF!]

[!IF "node:containsValue(OsIfGeneral/OsIfOperatingSystemType/@name, 'OsIfZephyrOsType')"!]
[!CODE!]#define USING_OS_ZEPHYR[!ENDCODE!]
[!ENDIF!]

[!IF "node:containsValue(OsIfGeneral/OsIfOperatingSystemType/@name, 'OsIfPx5RtosType')"!]
[!CODE!]#define USING_OS_PX5_RTOS[!ENDCODE!]
[!ENDIF!]

[!ENDNOCODE!]

[!NOCODE!]

[!IF "node:containsValue(OsIfGeneral/OsIfUseGetUserId, 'GET_PARTITION_ID')"!]
[!CODE!]#define USING_GET_PARTITION_ID[!ENDCODE!]
[!ENDIF!]

[!IF "node:containsValue(OsIfGeneral/OsIfUseGetUserId, 'GET_CORE_ID')"!]
[!CODE!]#define USING_GET_CORE_ID[!ENDCODE!]
[!ENDIF!]

[!IF "node:containsValue(OsIfGeneral/OsIfUseGetUserId, 'GET_CUSTOM_ID')"!]
[!CODE!]#define USING_GET_CUSTOM_ID[!ENDCODE!]
[!ENDIF!]

[!ENDNOCODE!]

#define OSIF_USE_SYSTEM_TIMER            ([!IF "node:containsValue(OsIfGeneral/OsIfUseSystemTimer, 'true')"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])

#define OSIF_USE_CUSTOM_TIMER            ([!IF "node:containsValue(OsIfGeneral/OsIfUseCustomTimer, 'true')"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])


#define OSIF_GET_PHYSICAL_CORE_ID_ENABLE  ([!IF "OsIfGeneral/OsIfGetPhysicalCoreIdEnable"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])
[!IF "OsIfGeneral/OsIfGetPhysicalCoreIdEnable"!]
[!VAR "getPhysicalCoreIdRuntime" = "'STD_OFF'"!]
[!VAR "getPhysicalCoreIdRuntime" = "'STD_ON'"!]
#ifdef MCAL_PLATFORM_ARM
#if (MCAL_PLATFORM_ARM == MCAL_ARM_RARCH)
#define OSIF_MPIDR_AFF0_MASK              (0x000000FFUL)
#define OSIF_MPIDR_AFF0_SHIFT             (0UL)
#endif /* #if (MCAL_PLATFORM_ARM == MCAL_ARM_RARCH) */
#endif /* #ifdef MCAL_PLATFORM_ARM */
#define OSIF_GET_PHYSICAL_CORE_ID_RUNTIME ([!"$getPhysicalCoreIdRuntime"!])
[!IF "$getPhysicalCoreIdRuntime = 'STD_OFF'"!]
#define OSIF_PHYSICAL_CORE_ID             (0U)
[!ENDIF!]
[!ENDIF!]

#define OSIF_SOFTWARE_SEMAPHORE_ENABLE  ([!IF "OsIfGeneral/OsIfSoftwareSemaphoredEnable"!]STD_ON[!ELSE!]STD_OFF[!ENDIF!])


/* Autosar OS Specific */


/* Baremetal Specific */
[!NOCODE!]
[!IF "node:containsValue(OsIfGeneral/OsIfOperatingSystemType/@name, 'OsIfBaremetalType') or node:containsValue(OsIfGeneral/OsIfOperatingSystemType/@name, 'OsIfFreeRtosType') or node:containsValue(OsIfGeneral/OsIfOperatingSystemType/@name, 'OsIfPx5RtosType')"!]
[!CODE!][!//
#ifdef MCAL_PLATFORM_ARM
#if (MCAL_PLATFORM_ARM == MCAL_ARM_MARCH)
    #define OSIF_USE_SYSTICK                 (STD_ON)
#elif ((MCAL_PLATFORM_ARM == MCAL_ARM_AARCH32) || (MCAL_PLATFORM_ARM == MCAL_ARM_AARCH64) || (MCAL_PLATFORM_ARM == MCAL_ARM_RARCH))
    #define OSIF_USE_GENERICTIMER            (STD_ON)
#endif
#else
#ifdef MCAL_PLATFORM_ZENV
/* TODO: Support machine timer */
#endif
#ifdef MCAL_PLATFORM_XTENSA
#define OSIF_USE_XTIMER            (STD_ON)
#endif
#endif
[!ENDCODE!]
[!ENDIF!]
[!ENDNOCODE!]


/*==================================================================================================
*                                              ENUMS
==================================================================================================*/

/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* OSIF_CFG_H */

/** @} */
