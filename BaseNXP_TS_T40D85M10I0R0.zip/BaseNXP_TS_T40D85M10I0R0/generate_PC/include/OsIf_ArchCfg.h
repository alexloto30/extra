/*==================================================================================================
* Project : RTD AUTOSAR 4.9
* Platform : CORTEXM
* Peripheral : S32K56XM7
* Dependencies : none
*
* Autosar Version : 4.9.0
* Autosar Revision : ASR_REL_4_9_REV_0000
* Autosar Conf.Variant :
* SW Version : 1.0.0
* Build Version : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
* Copyright 2024 - 2026 NXP
*
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/
/**
*   @file OsIf_ArchCfg.h
*   @version 1.0.0
*
*   @brief   BaseNXP - Driver header file.
*   @details Specific driver header file.
*
*   @addtogroup osif_drv
*   @{
*/

#ifndef OSIF_ARCHCFG_H
#define OSIF_ARCHCFG_H

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                          INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/

/*==================================================================================================
*                                 SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define OSIF_ARCHCFG_VENDOR_ID                    43
#define OSIF_ARCHCFG_AR_RELEASE_MAJOR_VERSION     4
#define OSIF_ARCHCFG_AR_RELEASE_MINOR_VERSION     9
#define OSIF_ARCHCFG_AR_RELEASE_REVISION_VERSION  0
#define OSIF_ARCHCFG_SW_MAJOR_VERSION             1
#define OSIF_ARCHCFG_SW_MINOR_VERSION             0
#define OSIF_ARCHCFG_SW_PATCH_VERSION             0

/*==================================================================================================
*                                       FILE VERSION CHECKS
==================================================================================================*/

/*==================================================================================================
*                                            CONSTANTS
==================================================================================================*/
#define MCAL_ARM_MARCH      (16)  /* for ARM M4 Thumb2      */
#define MCAL_ARM_AARCH32    (32)  /* for ARM ARCH32         */
#define MCAL_ARM_AARCH64    (64)  /* for ARM ARCH64         */
#define MCAL_ARM_RARCH      (52)  /* for ARM R platform     */
#define MCAL_RISCV_ZV       (27)  /* for RISCV ZV series    */
#define MCAL_XTENSA_LX      (8)   /* for XTENSA LX series   */


/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/

/* ARM_MIXT - is used to specify the ARM architecture MCAL_MARCH, MCAL_RARCH, MCAL_AARCH32, MCAL_AARCH64 */
 [!SELECT "as:modconf('Resource')[1]"!][!//
                            [!IF "(ResourceGeneral/ARM_CoreArchitecture = 'ARM_A64_ARCH')"!][!//
                                #define MCAL_PLATFORM_ARM  MCAL_ARM_AARCH64
                            [!ELSEIF "(ResourceGeneral/ARM_CoreArchitecture = 'ARM_A32_ARCH')"!][!//
                                #define MCAL_PLATFORM_ARM  MCAL_ARM_AARCH32
                            [!ELSEIF "(ResourceGeneral/ARM_CoreArchitecture = 'ARM_M_ARCH')"!][!//
                                #define MCAL_PLATFORM_ARM  MCAL_ARM_MARCH
                            [!ELSEIF "(ResourceGeneral/ARM_CoreArchitecture = 'ARM_M_M7_ARCH')"!][!//
                                #define MCAL_PLATFORM_ARM_M7
                                #define MCAL_PLATFORM_ARM  MCAL_ARM_MARCH
                            [!ELSEIF "(ResourceGeneral/ARM_CoreArchitecture = 'ARM_M_M4_ARCH')"!][!//
                                #define MCAL_PLATFORM_ARM_M4
                                #define MCAL_PLATFORM_ARM  MCAL_ARM_MARCH
                            [!ELSEIF "(ResourceGeneral/ARM_CoreArchitecture = 'ARM_R_ARCH')"!][!//
                                #define MCAL_PLATFORM_ARM  MCAL_ARM_RARCH
                            [!ELSEIF "(ResourceGeneral/ARM_CoreArchitecture = 'ZENV_RISCV_ARCH')"!][!//
                                #define MCAL_PLATFORM_ZENV MCAL_RISCV_ZV
                            [!ELSEIF "(ResourceGeneral/ARM_CoreArchitecture = 'XTENSA_HIFI_ARCH')"!][!//
                                #define MCAL_PLATFORM_XTENSA MCAL_XTENSA_LX
                            [!ELSEIF "(ResourceGeneral/ARM_CoreArchitecture = 'ARM_M_CM0PLUS_ARCH')"!][!//
                                #define MCAL_PLATFORM_ARM_M0PLUS
                                #define MCAL_PLATFORM_ARM  MCAL_ARM_MARCH

                            [!ENDIF!][!//
                        [!ENDSELECT!][!//







/*==================================================================================================
*                                              ENUMS
==================================================================================================*/

/*==================================================================================================
*                                  STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                  GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                       FUNCTION PROTOTYPES
==================================================================================================*/


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* OSIF_ARCHCFG_H */

/** @} */
