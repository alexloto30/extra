/*==================================================================================================
* Project : RTD AUTOSAR 4.9
* Platform : CORTEXM
* Peripheral : S32K56XM7
* Dependencies : none
*
* Autosar Version : 4.9.0
* Autosar Revision : ASR_REL_4_9_REV_0000
* Autosar Conf.Variant :
* SW Version : 1.0.0
* Build Version : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
* Copyright 2024 - 2026 NXP
*
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/
/**
*   @file    DeviceDefinition.h
*   @version 1.0.0
*
*   @brief   BaseNXP - Project configuration.
*   @details Header file contains the specific derivative, sub derivative and platform definitions.
*
*   @addtogroup BASENXP_COMPONENT
*   @{
*/

#ifndef DEVICEDEFINITION_H
#define DEVICEDEFINITION_H

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
*                                         INCLUDE FILES
* 1) system and project includes
* 2) needed interfaces from external units
* 3) internal and external interfaces from this unit
==================================================================================================*/

/*==================================================================================================
*                               SOURCE FILE VERSION INFORMATION
==================================================================================================*/

/**
@{
* @brief Parameters that shall be published within the modules header file.
*       The integration of incompatible files shall be avoided.
*/
#define DEVICEDEFINITION_VENDOR_ID_H                     43
#define DEVICEDEFINITION_MODULE_ID_H                     0
#define DEVICEDEFINITION_AR_RELEASE_MAJOR_VERSION_H      4
#define DEVICEDEFINITION_AR_RELEASE_MINOR_VERSION_H      9
#define DEVICEDEFINITION_AR_RELEASE_REVISION_VERSION_H   0
#define DEVICEDEFINITION_SW_MAJOR_VERSION_H              1
#define DEVICEDEFINITION_SW_MINOR_VERSION_H              0
#define DEVICEDEFINITION_SW_PATCH_VERSION_H              0
/**@}*/
/*==================================================================================================
*                                      FILE VERSION CHECKS
==================================================================================================*/

/*==================================================================================================
*                                           CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                       DEFINES AND MACROS
==================================================================================================*/
[!NOCODE!][!//
[!IF "node:exists(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative)"!][!//
    [!VAR "DerivativeName" = "text:toupper(substring-before(as:modconf("Resource")[1]/ResourceGeneral/ResourceSubderivative,'_'))"!]
        [!CODE!][!WS "0"!]
/**
* @brief This macro define specific derivative and sub derivative.
*/
        [!CR!][!ENDCODE!][!//
    [!IF "contains($DerivativeName, 'S32K566')"!][!//
        [!CODE!][!WS "0"!]
#ifndef S32K566
#define S32K566
#endif

#ifndef DERIVATIVE_S32K566
#define DERIVATIVE_S32K566
#endif

        [!CR!][!ENDCODE!][!//
    [!ENDIF!][!//


        [!CODE!][!WS "0"!]

/**
* @brief This macro define specific platform.
*/
#ifndef S32K5XX
#define S32K5XX
#endif
        [!CR!][!ENDCODE!][!//

[!ENDIF!][!//
[!ENDNOCODE!][!//

/*==================================================================================================
*                                             ENUMS
==================================================================================================*/

/*==================================================================================================
*                                 STRUCTURES AND OTHER TYPEDEFS
==================================================================================================*/

/*==================================================================================================
*                                 GLOBAL VARIABLE DECLARATIONS
==================================================================================================*/

/*==================================================================================================
*                                     FUNCTION PROTOTYPES
==================================================================================================*/

#ifdef __cplusplus
}
#endif

#endif /* DDEVICEDEFINITION_H */

/** @} */

