/*==================================================================================================
* Project : RTD AUTOSAR 4.9
* Platform : CORTEXM
* Peripheral : S32K56XM7
* Dependencies : none
*
* Autosar Version : 4.9.0
* Autosar Revision : ASR_REL_4_9_REV_0000
* Autosar Conf.Variant :
* SW Version : 1.0.0
* Build Version : S32K5_RTD_1_0_0_D2610_ASR_REL_4_9_REV_0000_20261027
*
* Copyright 2024 - 2026 NXP
*
* NXP Confidential and Proprietary. This software is owned or controlled by NXP and may only be
*   used strictly in accordance with the applicable license terms. By expressly
*   accepting such terms or by downloading, installing, activating and/or otherwise
*   using the software, you are agreeing that you have read, and that you agree to
*   comply with and are bound by, such license terms. If you do not agree to be
*   bound by the applicable license terms, then you may not retain, install,
*   activate or otherwise use the software.
==================================================================================================*/
/**
*   @file       OsIf_Cfg.c
*   @version 1.0.0
*
*   @brief   BaseNXP - Driver configuration file.
*   @details Precompile structure configuration for the driver initialization.
*
*   @addtogroup OSIF_DRIVER
*   @{
*/

#ifdef __cplusplus
extern "C"{
#endif

/*==================================================================================================
                                         INCLUDE FILES
 1) system and project includes
 2) needed interfaces from external units
 3) internal and external interfaces from this unit
==================================================================================================*/
#include "OsIf_Cfg.h"
#include "OsIf_Cfg_TypesDef.h"

#if defined(USING_OS_AUTOSAROS)
#include "Os.h"
#endif /* defined(USING_OS_AUTOSAROS) */

/*==================================================================================================
*                              SOURCE FILE VERSION INFORMATION
==================================================================================================*/
#define OSIF_CFG_VENDOR_ID_C                    43
#define OSIF_CFG_AR_RELEASE_MAJOR_VERSION_C     4
#define OSIF_CFG_AR_RELEASE_MINOR_VERSION_C     9
#define OSIF_CFG_AR_RELEASE_REVISION_VERSION_C  0
#define OSIF_CFG_SW_MAJOR_VERSION_C             1
#define OSIF_CFG_SW_MINOR_VERSION_C             0
#define OSIF_CFG_SW_PATCH_VERSION_C             0

/*==================================================================================================
*                                     FILE VERSION CHECKS
==================================================================================================*/
/* Check if OsIf_Cfg.c file and OsIf_Cfg.h file are of the same vendor */
#if (OSIF_CFG_VENDOR_ID_C != OSIF_CFG_VENDOR_ID)
    #error "OsIf_Cfg.c and OsIf_Cfg.h have different vendor ids"
#endif
/* Check if OsIf_Cfg.c file and OsIf_Cfg.h file are of the same Autosar version */
#if ((OSIF_CFG_AR_RELEASE_MAJOR_VERSION_C    != OSIF_CFG_AR_RELEASE_MAJOR_VERSION) || \
     (OSIF_CFG_AR_RELEASE_MINOR_VERSION_C    != OSIF_CFG_AR_RELEASE_MINOR_VERSION) || \
     (OSIF_CFG_AR_RELEASE_REVISION_VERSION_C != OSIF_CFG_AR_RELEASE_REVISION_VERSION))
    #error "AUTOSAR Version Numbers of OsIf_Cfg.c and OsIf_Cfg.h are different"
#endif
/* Check if OsIf_Cfg.c file and OsIf_Cfg.h file are of the same Software version */
#if ((OSIF_CFG_SW_MAJOR_VERSION_C != OSIF_CFG_SW_MAJOR_VERSION) || \
     (OSIF_CFG_SW_MINOR_VERSION_C != OSIF_CFG_SW_MINOR_VERSION) || \
     (OSIF_CFG_SW_PATCH_VERSION_C != OSIF_CFG_SW_PATCH_VERSION) \
    )
    #error "Software Version Numbers of OsIf_Cfg.c and OsIf_Cfg.h are different"
#endif

/* Check if OsIf_Cfg.c file and OsIf_Cfg_TypesDef.h file are of the same vendor */
#if (OSIF_CFG_VENDOR_ID_C != OSIF_CFG_TYPESDEF_VENDOR_ID)
    #error "OsIf_Cfg.c and OsIf_Cfg_TypesDef.h have different vendor ids"
#endif
/* Check if OsIf_Cfg.c file and OsIf_Cfg_TypesDef.h file are of the same Autosar version */
#if ((OSIF_CFG_AR_RELEASE_MAJOR_VERSION_C    != OSIF_CFG_TYPESDEF_AR_RELEASE_MAJOR_VERSION) || \
     (OSIF_CFG_AR_RELEASE_MINOR_VERSION_C    != OSIF_CFG_TYPESDEF_AR_RELEASE_MINOR_VERSION) || \
     (OSIF_CFG_AR_RELEASE_REVISION_VERSION_C != OSIF_CFG_TYPESDEF_AR_RELEASE_REVISION_VERSION))
    #error "AUTOSAR Version Numbers of OsIf_Cfg.c and OsIf_Cfg_TypesDef.h are different"
#endif
/* Check if OsIf_Cfg.c file and OsIf_Cfg_TypesDef.h file are of the same Software version */
#if ((OSIF_CFG_SW_MAJOR_VERSION_C != OSIF_CFG_TYPESDEF_SW_MAJOR_VERSION) || \
     (OSIF_CFG_SW_MINOR_VERSION_C != OSIF_CFG_TYPESDEF_SW_MINOR_VERSION) || \
     (OSIF_CFG_SW_PATCH_VERSION_C != OSIF_CFG_TYPESDEF_SW_PATCH_VERSION) \
    )
    #error "Software Version Numbers of OsIf_Cfg.c and OsIf_Cfg_TypesDef.h are different"
#endif

#if defined(USING_OS_AUTOSAROS)
/* Check if OsIf_Cfg.c file and Os.h file are of the same Autosar version */
#ifndef DISABLE_MCAL_INTERMODULE_ASR_CHECK
    #if ((OSIF_CFG_AR_RELEASE_MAJOR_VERSION_C != OS_AR_RELEASE_MAJOR_VERSION) || \
         (OSIF_CFG_AR_RELEASE_MINOR_VERSION_C != OS_AR_RELEASE_MINOR_VERSION))
        #error "AutoSar Version Numbers of OsIf_Cfg.c and Os.h are different"
    #endif
#endif /* DISABLE_MCAL_INTERMODULE_ASR_CHECK */
#endif /* defined(USING_OS_AUTOSAROS) */

/*==================================================================================================
*                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/

/*==================================================================================================
*                                      LOCAL MACROS
==================================================================================================*/
[!NOCODE!]
[!MACRO "GetOsCounterFrequency", "EcucPartitionRef"!][!//
[!NOCODE!]
    [!VAR "CounterFrequency" = "string(null)"!]
    [!LOOP "as:modconf('BaseNXP')[1]/OsIfGeneral/OsIfCounterConfig/*"!]
        [!IF "$EcucPartitionRef != string(null)"!]
            [!IF "node:exists(OsIfCounterEcucPartitionRef) and node:refvalid(OsIfCounterEcucPartitionRef)"!]
                [!IF "node:value(OsIfCounterEcucPartitionRef) = $EcucPartitionRef"!]
                    [!IF "(node:name(../../OsIfOperatingSystemType) = 'OsIfAutosarOsType')"!]
                        [!IF "node:refvalid(OsIfOsCounterRef)"!]
                            [!IF "not(node:exists(node:ref(OsIfOsCounterRef)/OsSecondsPerTick))"!]
                                [!ERROR!]Parameter [!"OsIfOsCounterRef"!]/OsSecondsPerTick is required for counter objects that count timing related information.[!ENDERROR!]
                            [!ENDIF!]
                            [!VAR "CounterFrequency" = "num:i(round(1.0 div node:ref(OsIfOsCounterRef)/OsSecondsPerTick))"!]
                        [!ENDIF!]
                    [!ELSEIF "(node:name(../../OsIfOperatingSystemType) = 'OsIfFreeRtosType')"!]
                        [!VAR "CounterFrequency" = "num:i(0)"!]
                    [!ELSEIF "(node:name(../../OsIfOperatingSystemType) = 'OsIfZephyrOsType')"!]
                        [!VAR "CounterFrequency" = "num:i(0)"!]
                    [!ELSEIF "(node:name(../../OsIfOperatingSystemType) = 'OsIfBaremetalType') or (node:name(../../OsIfOperatingSystemType) = 'OsIfPx5RtosType')"!]
                        [!IF "node:refvalid(OsIfSystemTimerClockRef)"!]
                            [!VAR "CounterFrequency" = "num:i(node:ref(OsIfSystemTimerClockRef)/McuClockReferencePointFrequency)"!]
                        [!ELSEIF "node:exists(OsIfSystemTimerClockFreq)"!]
                            [!VAR "CounterFrequency" = "num:i(OsIfSystemTimerClockFreq)"!]
                        [!ENDIF!]
                    [!ENDIF!]
                    [!BREAK!]
                [!ENDIF!]
            [!ENDIF!]
        [!ELSE!]
            [!BREAK!]
        [!ENDIF!]
    [!ENDLOOP!]
    [!IF "$CounterFrequency = string(null)"!][!ERROR!]Unknown or unsupported OS Counter Frequency! ([!"node:name(../../OsIfOperatingSystemType)"!])[!ENDERROR!][!ENDIF!]
    [!CODE!][!"$CounterFrequency"!]U[!ENDCODE!]
[!ENDNOCODE!][!//
[!ENDMACRO!][!//

[!MACRO "GetOsCounterFrequencySingleCore"!][!//
[!NOCODE!]
    [!VAR "CounterFrequency" = "string(null)"!]

    [!IF "(node:name(../../OsIfOperatingSystemType) = 'OsIfAutosarOsType')"!]
        [!IF "node:refvalid(OsIfOsCounterRef)"!]
            [!IF "not(node:exists(node:ref(OsIfOsCounterRef)/OsSecondsPerTick))"!]
                [!ERROR!]Parameter [!"OsIfOsCounterRef"!]/OsSecondsPerTick is required for counter objects that count timing related information.[!ENDERROR!]
            [!ENDIF!]
            [!VAR "CounterFrequency" = "num:i(round(1.0 div node:ref(OsIfOsCounterRef)/OsSecondsPerTick))"!]
        [!ENDIF!]
    [!ELSEIF "(node:name(../../OsIfOperatingSystemType) = 'OsIfFreeRtosType')"!]
        [!VAR "CounterFrequency" = "num:i(0)"!]
    [!ELSEIF "(node:name(../../OsIfOperatingSystemType) = 'OsIfZephyrOsType')"!]
        [!VAR "CounterFrequency" = "num:i(0)"!]
    [!ELSEIF "(node:name(../../OsIfOperatingSystemType) = 'OsIfBaremetalType') or (node:name(../../OsIfOperatingSystemType) = 'OsIfPx5RtosType')"!]
        [!IF "node:refvalid(OsIfSystemTimerClockRef)"!]
            [!VAR "CounterFrequency" = "num:i(node:ref(OsIfSystemTimerClockRef)/McuClockReferencePointFrequency)"!]
        [!ELSEIF "node:exists(OsIfSystemTimerClockFreq)"!]
            [!VAR "CounterFrequency" = "num:i(OsIfSystemTimerClockFreq)"!]
        [!ENDIF!]
    [!ENDIF!]

    [!IF "$CounterFrequency = string(null)"!][!ERROR!]Unknown or unsupported OS Counter Frequency! ([!"node:name(../../OsIfOperatingSystemType)"!])[!ENDERROR!][!ENDIF!]
    [!CODE!][!"$CounterFrequency"!]U[!ENDCODE!]
[!ENDNOCODE!][!//
[!ENDMACRO!][!//

[!MACRO "GetOsCounterId", "EcucPartitionRef"!][!//
[!NOCODE!]
    [!VAR "CounterId" = "string(null)"!]

    [!LOOP "as:modconf('BaseNXP')[1]/OsIfGeneral/OsIfCounterConfig/*"!]
        [!IF "$EcucPartitionRef != string(null)"!]
            [!IF "node:exists(OsIfCounterEcucPartitionRef) and node:refvalid(OsIfCounterEcucPartitionRef)"!]
                [!IF "node:value(OsIfCounterEcucPartitionRef) = $EcucPartitionRef"!]
                    [!IF "(node:name(../../OsIfOperatingSystemType) = 'OsIfAutosarOsType')"!]
                        [!IF "node:refvalid(OsIfOsCounterRef)"!]
                            [!VAR "CounterId" = "node:ref(OsIfOsCounterRef)/@name"!]
                        [!ENDIF!]
                    [!ELSEIF "(node:name(../../OsIfOperatingSystemType) = 'OsIfFreeRtosType')"!]
                        [!VAR "CounterId" = "num:i(@index)"!]
                    [!ELSEIF "(node:name(../../OsIfOperatingSystemType) = 'OsIfPx5RtosType')"!]
                        [!VAR "CounterId" = "num:i(@index)"!]
                    [!ELSEIF "(node:name(../../OsIfOperatingSystemType) = 'OsIfZephyrOsType')"!]
                        [!VAR "CounterId" = "num:i(@index)"!]
                    [!ELSEIF "(node:name(../../OsIfOperatingSystemType) = 'OsIfBaremetalType')"!]
                        [!VAR "CounterId" = "num:i(@index)"!]
                    [!ENDIF!]
                    [!BREAK!]
                [!ENDIF!]
            [!ENDIF!]
        [!ELSE!]
            [!BREAK!]
        [!ENDIF!]
    [!ENDLOOP!]
    [!IF "$CounterId = string(null)"!][!ERROR!]Unknown or unsupported OS Counter ID![!ENDERROR!][!ENDIF!]
    [!CODE!][!"$CounterId"!][!ENDCODE!]
[!ENDNOCODE!][!//
[!ENDMACRO!][!//

[!MACRO "GetOsCounterIdSingleCore"!][!//
[!NOCODE!]
    [!VAR "CounterId" = "string(null)"!]

    [!IF "(node:name(../../OsIfOperatingSystemType) = 'OsIfAutosarOsType')"!]
        [!IF "node:refvalid(OsIfOsCounterRef)"!]
            [!VAR "CounterId" = "node:ref(OsIfOsCounterRef)/@name"!]
        [!ENDIF!]
    [!ELSEIF "(node:name(../../OsIfOperatingSystemType) = 'OsIfFreeRtosType')"!]
        [!VAR "CounterId" = "num:i(@index)"!]
    [!ELSEIF "(node:name(../../OsIfOperatingSystemType) = 'OsIfPx5RtosType')"!]
        [!VAR "CounterId" = "num:i(@index)"!]
    [!ELSEIF "(node:name(../../OsIfOperatingSystemType) = 'OsIfZephyrOsType')"!]
        [!VAR "CounterId" = "num:i(@index)"!]
    [!ELSEIF "(node:name(../../OsIfOperatingSystemType) = 'OsIfBaremetalType')"!]
        [!VAR "CounterId" = "num:i(@index)"!]
    [!ENDIF!]

    [!IF "$CounterId = string(null)"!][!ERROR!]Unknown or unsupported OS Counter ID! ([!"node:name(../../OsIfOperatingSystemType)"!])[!ENDERROR!][!ENDIF!]
    [!CODE!][!"$CounterId"!][!ENDCODE!]
[!ENDNOCODE!][!//
[!ENDMACRO!][!//

[!MACRO "GetEcucPartitionRef", "CoreId"!][!//
[!NOCODE!]
    [!VAR "EcucPartitionRef" = "string(null)"!]
    [!SELECT "as:modconf('Os')[1]/OsApplication/*/OsApplicationCoreRef"!]
        [!IF "node:refvalid(.) "!]
            [!IF "num:i($CoreId) = num:i(node:value(node:ref(.)/EcucCoreId))"!]
                [!VAR "EcucPartitionRef" = "node:value(../OsAppEcucPartitionRef)"!]
            [!ENDIF!]
        [!ENDIF!]
    [!ENDSELECT!]

    [!CODE!][!"$EcucPartitionRef"!][!ENDCODE!]
[!ENDNOCODE!][!//
[!ENDMACRO!][!//

[!MACRO "GetConfigStructName", "EcucPartitionRef"!][!//
[!NOCODE!]
    [!VAR "ConfigStructureName" = "'NULL_PTR'"!]
    [!LOOP "OsIfGeneral/OsIfCounterConfig/*"!]
        [!IF "node:exists(OsIfCounterEcucPartitionRef) and node:refvalid(OsIfCounterEcucPartitionRef)"!]
            [!IF "node:value(OsIfCounterEcucPartitionRef) = $EcucPartitionRef"!]
                [!VAR "CntrPartitionShortName" = "node:name(node:ref(OsIfCounterEcucPartitionRef))"!]
                [!VAR "ConfigStructureName"    = "concat('&OsIf_xPredefinedConfig_', $CntrPartitionShortName)"!]
                [!BREAK!]
            [!ENDIF!]
        [!ENDIF!]
    [!ENDLOOP!]

    [!IF "$ConfigStructureName != 'NULL_PTR'"!][!VAR "ResolvedCoreCount" = "$ResolvedCoreCount+1"!][!ENDIF!]
    [!CODE!][!"$ConfigStructureName"!][!ENDCODE!]
[!ENDNOCODE!][!//
[!ENDMACRO!][!//
[!ENDNOCODE!][!//

/*==================================================================================================
*                                      LOCAL CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                      LOCAL VARIABLES
==================================================================================================*/

/*==================================================================================================
*                                      GLOBAL CONSTANTS
==================================================================================================*/

/*==================================================================================================
*                                      GLOBAL VARIABLES
==================================================================================================*/
#if (OSIF_USE_SYSTEM_TIMER == STD_ON)
[!NOCODE!]
[!MACRO "GenerateSingleCoreConfig"!][!//
[!NOCODE!]
    [!VAR "NumOfOsCntrs" = "count(OsIfGeneral/OsIfCounterConfig/*)"!]
    [!IF "$NumOfOsCntrs > 0"!]
        [!SELECT "OsIfGeneral/OsIfCounterConfig/*[1]"!]
[!CODE!]
#define BASENXP_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"

static const OsIf_ConfigType OsIf_xPredefinedConfig =
{
    /*.counterId */         [!CALL "GetOsCounterIdSingleCore"!],
    /*.counterFrequency */  [!CALL "GetOsCounterFrequencySingleCore"!]
};

#define BASENXP_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"

#define BASENXP_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"

const OsIf_ConfigType *const OsIf_apxPredefinedConfig[OSIF_MAX_COREIDX_SUPPORTED] =
{
    &OsIf_xPredefinedConfig
};

#define BASENXP_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"
[!ENDCODE!]
        [!ENDSELECT!]
    [!ENDIF!][!// $NumOfOsCntrs > 0
[!ENDNOCODE!][!//
[!ENDMACRO!][!//

[!MACRO "GenerateMultiCorePartitionConfig"!][!//
[!NOCODE!]
    [!LOOP "OsIfGeneral/OsIfEcucPartitionRef/*"!]
        [!VAR "partitionShortName" = "node:name(node:ref(.))"!]
[!CODE!]
#define BASENXP_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"

static const OsIf_ConfigType OsIf_xPredefinedConfig_[!"$partitionShortName"!] =
{
    /*.counterId */         [!CALL "GetOsCounterId", "EcucPartitionRef" = "node:value(.)"!],
    /*.counterFrequency */  [!CALL "GetOsCounterFrequency", "EcucPartitionRef" = "node:value(.)"!]
};

#define BASENXP_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"
[!ENDCODE!]
    [!ENDLOOP!]
[!ENDNOCODE!][!//
[!ENDMACRO!][!//

[!MACRO "GenerateMultiCorePredefinedConfig"!][!//
[!NOCODE!]
[!CODE!]
#define BASENXP_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"

const OsIf_ConfigType *const OsIf_apxPredefinedConfig[OSIF_MAX_COREIDX_SUPPORTED] =
{
[!ENDCODE!]
    [!VAR "MaxCoreIdx"!][!"num:i(node:fallback("->num:max(as:modconf('EcuC')/EcucHardware/EcucCoreDefinition/*/EcucCoreId)", -1))"!][!ENDVAR!]
    [!VAR "ResolvedCoreCount" = "0"!]
    [!FOR "CoreIdx" = "0" TO "$MaxCoreIdx"!]
        [!VAR "OsEcucPartitionRef"!][!CALL "GetEcucPartitionRef", "CoreId" = "$CoreIdx"!][!ENDVAR!]
[!CODE!]
    [!CALL "GetConfigStructName", "EcucPartitionRef" = "$OsEcucPartitionRef"!][!IF "$CoreIdx!=$MaxCoreIdx"!],[!ELSE!] [!ENDIF!] /*EcucCoreId = [!"$CoreIdx"!] */[!IF "($CoreIdx = $MaxCoreIdx) and ($ResolvedCoreCount = 0)"!][!ERROR!]OsIf: OsIfMulticoreSupport is enabled and OsIfEcucPartitionRef is configured, but no ECUC partition could be resolved to a core. Every OsIf_apxPredefinedConfig entry would be NULL_PTR and OsIf_Timer_System_Init() would fail at run time. Configure Os/OsApplication/*/OsApplicationCoreRef for the OsApplications that implement the referenced ECUC partitions.[!ENDERROR!][!ENDIF!][!//
[!ENDCODE!]
    [!ENDFOR!][!// CoreIdx
[!CODE!]
};

#define BASENXP_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"
[!ENDCODE!]
[!ENDNOCODE!][!//
[!ENDMACRO!][!//

[!MACRO "GenerateMultiPartitionPredefinedConfig"!][!//
[!NOCODE!]
[!CODE!]
#define BASENXP_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"

const uint8 OsIf_apxMultiPartitionPredefinedConfig[OSIF_MAX_APPIDX_SUPPORTED] =
{
[!ENDCODE!]
[!VAR "MaxOsAppIdx" = "num:i(count(as:modconf('Os')[1]/OsApplication/*))"!][!//
[!IF "$MaxOsAppIdx != 0"!][!//
    [!LOOP "as:modconf('Os')[1]/OsApplication/*"!][!//
        [!VAR "OsAppIdx" = "node:pos(.)"!][!//
        [!IF "node:refvalid(./OsAppEcucPartitionRef)"!][!//
            [!VAR "OsAppPartRef" = "node:name(node:ref(./OsAppEcucPartitionRef))"!][!//
            [!VAR "OsAppPartId" = "0"!][!//
            [!VAR "OsAppPartRef" = "text:toupper($OsAppPartRef)"!][!//
            [!LOOP "as:modconf('EcuC')[1]/EcucPartitionCollection/EcucPartition/*"!][!//
                [!VAR "EcucPartValue" = "node:name(.)"!][!//
                [!VAR "EcucPartValue" = "text:toupper($EcucPartValue)"!][!//
                [!IF "$OsAppPartRef = $EcucPartValue"!][!//
                    [!VAR "OsAppPartId" = "node:pos(.)"!][!//
                [!ENDIF!][!//
            [!ENDLOOP!][!//
        [!CODE!]
        ([!"$OsAppPartId"!]U)[!IF "$OsAppIdx!=$MaxOsAppIdx - 1"!],[!ELSE!] [!ENDIF!] /*Application [!"$OsAppIdx"!] mapped to Partition [!"$OsAppPartId"!] */[!//
        [!ENDCODE!]
        [!ELSE!]
        [!CODE!]
        OSIF_INVALID_PART_ID[!IF "$OsAppIdx!=$MaxOsAppIdx - 1"!],[!ELSE!] [!ENDIF!] /*Application [!"$OsAppIdx"!] not mapped to any partition */[!//
        [!ENDCODE!]
        [!ENDIF!][!//
    [!ENDLOOP!][!//
[!ELSE!]
    [!CODE!]
    OSIF_INVALID_PART_ID /* No application defined in OS module */[!//
    [!ENDCODE!]
[!ENDIF!][!//
[!CODE!]
};

#define BASENXP_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"
[!ENDCODE!]
[!ENDNOCODE!][!//
[!ENDMACRO!][!//

[!IF "OsIfGeneral/OsIfMulticoreSupport = 'true'"!]
    [!CALL "GenerateMultiCorePartitionConfig"!]
    [!CALL "GenerateMultiCorePredefinedConfig"!]
    [!IF "OsIfGeneral/OsIfUseGetUserId = 'GET_PARTITION_ID'"!]
        [!CALL "GenerateMultiPartitionPredefinedConfig"!]
    [!ENDIF!]
[!ELSE!]
    [!CALL "GenerateSingleCoreConfig"!]
[!ENDIF!]

/* Variable indicate multi-partition feature enabled */
[!VAR "MultiPartitionEnabled" = "0"!]

[!IF "node:value(OsIfGeneral/OsIfMulticoreSupport)='true'"!]
    [!VAR "MultiPartitionEnabled" = "1"!]
[!ENDIF!]

/* Variable storing number of maximum partitions using in configuration */
[!VAR "numPartition" = "0"!]

[!IF "$MultiPartitionEnabled = 1"!]
[!LOOP "OsIfGeneral/OsIfEcucPartitionRef/*"!]
        [!VAR "partitionShortName" = "node:name(node:ref(.))"!]
        [!LOOP "as:modconf("EcuC")[1]/EcucPartitionCollection/EcucPartition/*"!]
            [!IF "$partitionShortName = node:name(.)"!]
                [!VAR "partitionID" = "node:pos(.)"!]
            [!ENDIF!]
        [!ENDLOOP!]
[!CODE!]
/***************************************Generate_OsIf_InitStatus_For_Each_Partitions***************************/

/*======================================Partition [!"$partitionShortName"!]=======================*/
#if (STD_ON == OSIF_DEV_ERROR_DETECT)
#define BASENXP_START_SEC_VAR_CLEARED_ECUCPARTITION[!"$partitionID"!]_BOOLEAN
#include "BaseNXP_MemMap.h"

static boolean OsIf_abMdlInit_[!"$partitionShortName"!];

#define BASENXP_STOP_SEC_VAR_CLEARED_ECUCPARTITION[!"$partitionID"!]_BOOLEAN
#include "BaseNXP_MemMap.h"
#endif /* (STD_ON == OSIF_DEV_ERROR_DETECT) */


/***************************************Generate_OsIf_InternalFrequencies_For_Each_Partitions***************************/

/*======================================Partition [!"$partitionShortName"!]=======================*/
#define BASENXP_START_SEC_VAR_CLEARED_ECUCPARTITION[!"$partitionID"!]_32
#include "BaseNXP_MemMap.h"

static uint32 OsIf_au32InternalFrequencies_[!"$partitionShortName"!];

#define BASENXP_STOP_SEC_VAR_CLEARED_ECUCPARTITION[!"$partitionID"!]_32
#include "BaseNXP_MemMap.h"
[!ENDCODE!]
[!ENDLOOP!][!//

[!CODE!]
/***************************************Generate_OsIf_InitStatusArray**************************/
#if (STD_ON == OSIF_DEV_ERROR_DETECT)
#define BASENXP_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"

boolean *const OsIf_apxMdlInitArray[OSIF_MAX_NUM_PARTITION_SUPPORTED] =
{
[!NOCODE!]
    [!VAR "numPartition" = "num:i(count(as:modconf("EcuC")[1]/EcucPartitionCollection/EcucPartition/*))"!]
    [!FOR "CurrentPartitionId" = "0" TO "$numPartition - 1"!]
        [!VAR "PartitionIdConfigured" = "0"!]
        [!LOOP "OsIfGeneral/OsIfEcucPartitionRef/*"!]
            [!VAR "PartitionRefName" = "node:value(.)"!]
            [!VAR "CurrentPartitionShortName" = "substring-after(substring-after(substring-after(substring-after(node:value(.), '/'), '/'), '/'), '/')"!]
            [!LOOP "as:modconf("EcuC")[1]/EcucPartitionCollection/EcucPartition/*"!]
                [!IF "$CurrentPartitionShortName = node:name(.)"!]
                    [!IF "$CurrentPartitionId = node:pos(.)"!]
                        [!VAR "PartitionIdConfigured" = "1"!]
                        [!VAR "PartitionShortName" = "$CurrentPartitionShortName"!]
                    [!ENDIF!]
                [!ENDIF!]
            [!ENDLOOP!]
        [!ENDLOOP!]
    [!IF "$PartitionIdConfigured = 1"!]
        [!CODE!][!WS "4"!]&OsIf_abMdlInit_[!"$PartitionShortName"!][!IF "$CurrentPartitionId < ($numPartition - 1)"!], [!ENDIF!][!CR!][!ENDCODE!]
    [!ELSE!]
        [!CODE!][!WS "4"!]NULL_PTR[!IF "$CurrentPartitionId < ($numPartition - 1)"!],[!ENDIF!][!CR!][!ENDCODE!]
    [!ENDIF!]
    [!ENDFOR!]
[!ENDNOCODE!]
};
#define BASENXP_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"
#endif /* (STD_ON == OSIF_DEV_ERROR_DETECT) */

/***************************************Generate_OsIf_InternalFrequenciesArray**************************/
#define BASENXP_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"

uint32 *const OsIf_apxInternalFrequenciesArray[OSIF_MAX_NUM_PARTITION_SUPPORTED] =
{
[!NOCODE!]
    [!VAR "numPartition" = "num:i(count(as:modconf("EcuC")[1]/EcucPartitionCollection/EcucPartition/*))"!]
    [!FOR "CurrentPartitionId" = "0" TO "$numPartition - 1"!]
        [!VAR "PartitionIdConfigured" = "0"!]
        [!LOOP "OsIfGeneral/OsIfEcucPartitionRef/*"!]
            [!VAR "PartitionRefName" = "node:value(.)"!]
            [!VAR "CurrentPartitionShortName" = "substring-after(substring-after(substring-after(substring-after(node:value(.), '/'), '/'), '/'), '/')"!]
            [!LOOP "as:modconf("EcuC")[1]/EcucPartitionCollection/EcucPartition/*"!]
                [!IF "$CurrentPartitionShortName = node:name(.)"!]
                    [!IF "$CurrentPartitionId = node:pos(.)"!]
                        [!VAR "PartitionIdConfigured" = "1"!]
                        [!VAR "PartitionShortName" = "$CurrentPartitionShortName"!]
                    [!ENDIF!]
                [!ENDIF!]
            [!ENDLOOP!]
        [!ENDLOOP!]
    [!IF "$PartitionIdConfigured = 1"!]
        [!CODE!][!WS "4"!]&OsIf_au32InternalFrequencies_[!"$PartitionShortName"!][!IF "$CurrentPartitionId < ($numPartition - 1)"!], [!ENDIF!][!CR!][!ENDCODE!]
    [!ELSE!]
        [!CODE!][!WS "4"!]NULL_PTR[!IF "$CurrentPartitionId < ($numPartition - 1)"!],[!ENDIF!][!CR!][!ENDCODE!]
    [!ENDIF!]
    [!ENDFOR!]
[!ENDNOCODE!]
};

#define BASENXP_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"

[!ENDCODE!]
[!ELSE!] /* $MultiPartitionEnabled = 0 */
[!CODE!]
#if (STD_ON == OSIF_DEV_ERROR_DETECT)
#define BASENXP_START_SEC_VAR_CLEARED_BOOLEAN
#include "BaseNXP_MemMap.h"

static boolean OsIf_abMdlInit;

#define BASENXP_STOP_SEC_VAR_CLEARED_BOOLEAN
#include "BaseNXP_MemMap.h"

#define BASENXP_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"

boolean *const OsIf_apxMdlInitArray[1U] =
{
    &OsIf_abMdlInit
};

#define BASENXP_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"
#endif /* (STD_ON == OSIF_DEV_ERROR_DETECT) */

#define BASENXP_START_SEC_VAR_CLEARED_32
#include "BaseNXP_MemMap.h"

static uint32 OsIf_au32InternalFrequencies;

#define BASENXP_STOP_SEC_VAR_CLEARED_32
#include "BaseNXP_MemMap.h"

#define BASENXP_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"

uint32 *const OsIf_apxInternalFrequenciesArray[1U] =
{
    &OsIf_au32InternalFrequencies
};

#define BASENXP_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "BaseNXP_MemMap.h"
[!ENDCODE!]
[!ENDIF!]
[!ENDNOCODE!][!//
#endif /* (OSIF_USE_SYSTEM_TIMER == STD_ON) */

/*==================================================================================================
*                                    LOCAL FUNCTION PROTOTYPES
==================================================================================================*/

/*==================================================================================================
*                                       LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
*                                       GLOBAL FUNCTIONS
==================================================================================================*/

/*================================================================================================*/

#ifdef __cplusplus
}
#endif /* __cplusplus */

/** @} */
