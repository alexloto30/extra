/*
** ###################################################################
**     Processor:           S32K566_M7
**     Compiler:            Keil ARM C/C++ Compiler
**     Reference manual:    S32K5 RM Rev 3
**     Version:             rev. 2.7, 2026-09-09
**     Build:               b260908
**
**     Abstract:
**         Peripheral Access Layer for S32K566_M7
**
**     Copyright 1997-2016 Freescale Semiconductor, Inc.
**     Copyright 2016-2026 NXP
**
**     NXP Confidential and Proprietary. This software is owned or controlled
**     by NXP and may only be used strictly in accordance with the applicable
**     license terms. By expressly accepting such terms or by downloading,
**     installing, activating and/or otherwise using the software, you are
**     agreeing that you have read, and that you agree to comply with and are
**     bound by, such license terms. If you do not agree to be bound by the
**     applicable license terms, then you may not retain, install, activate
**     or otherwise use the software.
**
**     http:                 www.nxp.com
**     mail:                 support@nxp.com
**
**     Revisions:
**     - rev. 2.7 (2026-09-09)
**         Release based on RM Rev.3
**
** ###################################################################
*/

/*!
 * @file S32K566.h
 * @version 2.7
 * @date 2026-09-09
 * @brief Peripheral Access Layer for S32K566
 *
 * This file contains register definitions and macros for easy access to their
 * bit fields.
 *
 * This file assumes LITTLE endian system.
 */

/* Prevention from multiple including the same memory map */
#if !defined(S32K566_H_)  /* Check if memory map has not been already included */
#define S32K566_H_

/* ----------------------------------------------------------------------------
   -- IP Header Files
   ---------------------------------------------------------------------------- */

/* IP Header Files List */
#include "S32K566_AN_MMD.h"
#include "S32K566_ARDB.h"
#include "S32K566_BCTU.h"
#include "S32K566_CANXL.h"
#include "S32K566_CANXL_DSC_CONTROL.h"
#include "S32K566_CANXL_FILTER_BANK.h"
#include "S32K566_CANXL_GRP_CONTROL.h"
#include "S32K566_CANXL_MRU.h"
#include "S32K566_CANXL_MSG_DESCRIPTORS.h"
#include "S32K566_CANXL_RAMECC.h"
#include "S32K566_CANXL_RXFIFO.h"
#include "S32K566_CANXL_RXFIFO_CONTROL.h"
#include "S32K566_CANXL_SIC.h"
#include "S32K566_CAN_HUB.h"
#include "S32K566_CMU_FC.h"
#include "S32K566_CPE_LLC_0.h"
#include "S32K566_CPE_LLC_0_FSC.h"
#include "S32K566_CPE_LLC_1.h"
#include "S32K566_CPE_LLC_1_FSC.h"
#include "S32K566_CPE_MRU0.h"
#include "S32K566_CPE_MRU1.h"
#include "S32K566_CPE_MRU2.h"
#include "S32K566_CPE_MRU3.h"
#include "S32K566_CPE_PMC.h"
#include "S32K566_CPE_VFCCU.h"
#include "S32K566_CPE_XRDC.h"
#include "S32K566_CRC.h"
#include "S32K566_CSTCU.h"
#include "S32K566_CXPI.h"
#include "S32K566_DMAMUX.h"
#include "S32K566_DMA_CRC.h"
#include "S32K566_DSPI.h"
#include "S32K566_EIM.h"
#include "S32K566_EMDIO_GLOBAL.h"
#include "S32K566_EMDIO_PCI_HDR_TYPE0.h"
#include "S32K566_EMIOS.h"
#include "S32K566_ENETC_BASE.h"
#include "S32K566_ENETC_COMMON.h"
#include "S32K566_ENETC_GLOBAL.h"
#include "S32K566_ENETC_PCI_HDR_TYPE0.h"
#include "S32K566_ENETC_PORT.h"
#include "S32K566_ENETC_PSEUDO_MAC_PORT.h"
#include "S32K566_ENETC_PSI.h"
#include "S32K566_ENETC_VSI.h"
#include "S32K566_ERM.h"
#include "S32K566_F16ASM.h"
#include "S32K566_FLEXCAN.h"
#include "S32K566_FLEXIO.h"
#include "S32K566_FLEXRAY.h"
#include "S32K566_FRO_SE.h"
#include "S32K566_FTM.h"
#include "S32K566_FXOSC.h"
#include "S32K566_IEPRC_IERB.h"
#include "S32K566_IEPRC_PCI.h"
#include "S32K566_IEPRC_PRB.h"
#include "S32K566_INTC.h"
#include "S32K566_K566_DSP_GPR.h"
#include "S32K566_K566_GPR0.h"
#include "S32K566_K566_GPR1.h"
#include "S32K566_K566_LPE_GPR0.h"
#include "S32K566_K566_LPE_GPR1.h"
#include "S32K566_K566_RTU_GPR.h"
#include "S32K566_LCU.h"
#include "S32K566_LMEM_CACHE.h"
#include "S32K566_LOCK.h"
#include "S32K566_LPCMP.h"
#include "S32K566_LPE_EDMA_MP.h"
#include "S32K566_LPE_EDMA_TCD.h"
#include "S32K566_LPE_MCM.h"
#include "S32K566_LPE_VFCCU.h"
#include "S32K566_LPE_XRDC.h"
#include "S32K566_LPI2C.h"
#include "S32K566_LPSPI.h"
#include "S32K566_LPUART.h"
#include "S32K566_LSTCU.h"
#include "S32K566_MACSEC.h"
#include "S32K566_MAX_CORE.h"
#include "S32K566_MCM.h"
#include "S32K566_MC_CGM.h"
#include "S32K566_MC_ME.h"
#include "S32K566_MC_RGM.h"
#include "S32K566_MRAMC.h"
#include "S32K566_MRU.h"
#include "S32K566_MSCM.h"
#include "S32K566_MSGINTR.h"
#include "S32K566_MU.h"
#include "S32K566_NETC_EMDIO_BASE.h"
#include "S32K566_NETC_ETH_LINK.h"
#include "S32K566_NETC_IERB.h"
#include "S32K566_NETC_PRIV.h"
#include "S32K566_NETC_SW_BASE.h"
#include "S32K566_NETC_SW_COMMON.h"
#include "S32K566_NETC_TMR_BASE.h"
#include "S32K566_NETC_VF_PCI_HDR_TYPE0.h"
#include "S32K566_OMU.h"
#include "S32K566_PHY_CTRL_EX.h"
#include "S32K566_PIT.h"
#include "S32K566_PLL.h"
#include "S32K566_PMA_MMD.h"
#include "S32K566_PMC.h"
#include "S32K566_POR_GEN.h"
#include "S32K566_RDC.h"
#include "S32K566_RTC.h"
#include "S32K566_RXLUT.h"
#include "S32K566_SAI.h"
#include "S32K566_SARADC.h"
#include "S32K566_SEMA42.h"
#include "S32K566_SENT.h"
#include "S32K566_SINC.h"
#include "S32K566_SIUL2.h"
#include "S32K566_SPP_DMA5_MP.h"
#include "S32K566_SPP_DMA5_TCD.h"
#include "S32K566_SRAMCTL.h"
#include "S32K566_SRAMCTL_0.h"
#include "S32K566_SRAMCTL_1.h"
#include "S32K566_SRAMCTL_2.h"
#include "S32K566_SRAMCTL_CPE.h"
#include "S32K566_SSI_0_MASTER.h"
#include "S32K566_SSI_0_SLAVE.h"
#include "S32K566_SSI_1_MASTER.h"
#include "S32K566_SSI_1_SLAVE.h"
#include "S32K566_SSI_2_MASTER.h"
#include "S32K566_SSI_2_SLAVE.h"
#include "S32K566_SSI_3_MASTER.h"
#include "S32K566_SSI_3_SLAVE.h"
#include "S32K566_STM.h"
#include "S32K566_SWT.h"
#include "S32K566_SW_GLOBAL.h"
#include "S32K566_SW_PCI_HDR_TYPE0.h"
#include "S32K566_SW_PORT.h"
#include "S32K566_SW_PSEUDO_MAC_PORT.h"
#include "S32K566_SXOSC.h"
#include "S32K566_TEMPSENSE.h"
#include "S32K566_TENBASET_PHY.h"
#include "S32K566_TMR_GLOBAL.h"
#include "S32K566_TMR_MEDIA_CHANNEL_GLOBAL.h"
#include "S32K566_TMR_MEDIA_CHANNEL_PCI_HDR_TYPE0.h"
#include "S32K566_TMR_PCI_HDR_TYPE0.h"
#include "S32K566_TRGMUX.h"
#include "S32K566_TSPC.h"
#include "S32K566_USDHC.h"
#include "S32K566_VFCCU_0.h"
#include "S32K566_VFCCU_1.h"
#include "S32K566_VFCCU_2.h"
#include "S32K566_VFCCU_3.h"
#include "S32K566_VIRT_WRAP.h"
#include "S32K566_VS_MII_MMD.h"
#include "S32K566_VS_MMD1.h"
#include "S32K566_WKPU.h"
#include "S32K566_X2.h"
#include "S32K566_XBIC.h"
#include "S32K566_XRDC_A.h"
#include "S32K566_XRDC_B.h"
#include "S32K566_XRDC_C.h"
#include "S32K566_XSPI.h"
#include "S32K566_XS_PCS_MMD.h"
#include "S32K566_XS_PMA_MMD.h"
#include "S32K566_ZDV_GPR.h"

#endif  /* #if !defined(S32K566_H_) */
