/*
** ###################################################################
**     Processor:           S32K566_M7
**     Compiler:            Keil ARM C/C++ Compiler
**     Reference manual:    S32K5 RM Rev 3
**     Version:             rev. 2.7, 2026-09-09
**     Build:               b260908
**
**     Abstract:
**         Peripheral Access Layer for S32K566_M7
**
**     Copyright 1997-2016 Freescale Semiconductor, Inc.
**     Copyright 2016-2026 NXP
**
**     NXP Confidential and Proprietary. This software is owned or controlled
**     by NXP and may only be used strictly in accordance with the applicable
**     license terms. By expressly accepting such terms or by downloading,
**     installing, activating and/or otherwise using the software, you are
**     agreeing that you have read, and that you agree to comply with and are
**     bound by, such license terms. If you do not agree to be bound by the
**     applicable license terms, then you may not retain, install, activate
**     or otherwise use the software.
**
**     http:                 www.nxp.com
**     mail:                 support@nxp.com
**
** ###################################################################
*/

/*!
 * @file S32K566_EMDIO_PCI_HDR_TYPE0.h
 * @version 2.7
 * @date 2026-09-09
 * @brief Peripheral Access Layer for S32K566_EMDIO_PCI_HDR_TYPE0
 *
 * This file contains register definitions and macros for easy access to their
 * bit fields.
 *
 * This file assumes LITTLE endian system.
 */

/**
* @page misra_violations MISRA-C:2012 violations
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.3, local typedef not referenced
* The SoC header defines typedef for all modules.
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.5, local macro not referenced
* The SoC header defines macros for all modules and registers.
*
* @section [global]
* Violates MISRA 2012 Advisory Directive 4.9, Function-like macro
* These are generated macros used for accessing the bit-fields from registers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.1, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.2, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.4, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.5, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 21.1, defined macro '__I' is reserved to the compiler
* This type qualifier is needed to ensure correct I/O access and addressing.
*/

/* Prevention from multiple including the same memory map */
#if !defined(S32K566_EMDIO_PCI_HDR_TYPE0_H_)  /* Check if memory map has not been already included */
#define S32K566_EMDIO_PCI_HDR_TYPE0_H_

#include "S32K566_COMMON.h"

/* ----------------------------------------------------------------------------
   -- EMDIO_PCI_HDR_TYPE0 Peripheral Access Layer
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup EMDIO_PCI_HDR_TYPE0_Peripheral_Access_Layer EMDIO_PCI_HDR_TYPE0 Peripheral Access Layer
 * @{
 */

/** EMDIO_PCI_HDR_TYPE0 - Size of Registers Arrays */
#define EMDIO_PCI_HDR_TYPE0_NUM_EA_COUNT          2u

/** EMDIO_PCI_HDR_TYPE0 - Register Layout Typedef */
typedef struct EMDIO_PCI_HDR_TYPE0_Struct {
  __I  uint32_t PCI_CFH_DID_VID;                   /**< PCI device ID and vendor ID register, offset: 0x0 */
  __IO uint16_t PCI_CFH_CMD;                       /**< PCI command register, offset: 0x4 */
  __I  uint16_t PCI_CFH_STAT;                      /**< PCI status register, offset: 0x6 */
  __I  uint32_t PCI_CFH_REVID_CLASSCODE;           /**< PCI revision ID and classcode register, offset: 0x8 */
  __IO uint8_t PCI_CFH_CL_SIZE;                    /**< PCI cache line size register, offset: 0xC */
  uint8_t RESERVED_0[1];
  __I  uint8_t PCI_CFH_HDR_TYPE;                   /**< PCI header type register, offset: 0xE */
  uint8_t RESERVED_1[1];
  __I  uint32_t PCI_CFH_BAR0;                      /**< PCI base address register 0, offset: 0x10 */
  __I  uint32_t PCI_CFH_BAR1;                      /**< PCI base address register 1, offset: 0x14 */
  __I  uint32_t PCI_CFH_BAR2;                      /**< PCI base address register 2, offset: 0x18 */
  __I  uint32_t PCI_CFH_BAR3;                      /**< PCI base address register 3, offset: 0x1C */
  __I  uint32_t PCI_CFH_BAR4;                      /**< PCI base address register 4, offset: 0x20 */
  __I  uint32_t PCI_CFH_BAR5;                      /**< PCI base address register 5, offset: 0x24 */
  uint8_t RESERVED_2[4];
  __I  uint16_t PCI_CFH_SUBSYS_VID;                /**< PCI subsystem vendor ID register, offset: 0x2C */
  __I  uint16_t PCI_CFH_SUBSYS_ID;                 /**< PCI subsystem ID register, offset: 0x2E */
  uint8_t RESERVED_3[4];
  __I  uint8_t PCI_CFH_CAP_PTR;                    /**< PCI capabilities pointer register, offset: 0x34 */
  uint8_t RESERVED_4[11];
  __I  uint16_t PCI_CFC_PCIE_CAP_LIST;             /**< PCI PCIe capabilities list register, offset: 0x40 */
  __I  uint16_t PCI_CFC_PCIE_CAP;                  /**< PCI PCIe capabilities register, offset: 0x42 */
  __I  uint32_t PCI_CFC_PCIE_DEV_CAP;              /**< PCI PCIe device capabilities register, offset: 0x44 */
  __IO uint16_t PCI_CFC_PCIE_DEV_CTL;              /**< PCI PCIe device control register, offset: 0x48 */
  __I  uint16_t PCI_CFC_PCIE_DEV_STAT;             /**< PCI PCIe device status register, offset: 0x4A */
  uint8_t RESERVED_5[24];
  __I  uint32_t PCI_CFC_PCIE_DEV_CAP2;             /**< PCI PCIe device capabilities 2 register, offset: 0x64 */
  __I  uint16_t PCI_CFC_PCIE_DEV_CTL2;             /**< PCI PCIe device control 2 register, offset: 0x68 */
  uint8_t RESERVED_6[22];
  __I  uint16_t PCI_CFC_MSIX_CAP_LIST;             /**< PCI MSI-X capabilities list register, offset: 0x80 */
  __IO uint16_t PCI_CFC_MSIX_MSG_CTL;              /**< PCI MSI-X message control register, offset: 0x82 */
  __I  uint32_t PCI_CFC_MSIX_TABLE_OFF_BIR;        /**< PCI MSI-X table offset/BIR register, offset: 0x84 */
  __I  uint32_t PCI_CFC_MSIX_PBA_OFF_BIR;          /**< PCI MSI-X PBA offset/BIR register, offset: 0x88 */
  uint8_t RESERVED_7[4];
  __I  uint16_t PCI_CFC_PCIPM_CAP_LIST;            /**< PCI PCI-PM capabilities list register, offset: 0x90 */
  __I  uint16_t PCI_CFC_PCIPM_CAP;                 /**< PCI PCI-PM capabilities register, offset: 0x92 */
  __IO uint16_t PCI_CFC_PCIPM_CTL_STAT;            /**< PCI PCI-PM control and status register, offset: 0x94 */
  uint8_t RESERVED_8[1];
  __I  uint8_t PCI_CFC_PCIPM_DATA;                 /**< PCI PCI-PM capabilities data register, offset: 0x97 */
  uint8_t RESERVED_9[4];
  __I  uint16_t PCI_CFC_EA_CAP_LIST;               /**< PCI EA capabilities list register, offset: 0x9C */
  __I  uint16_t PCI_CFC_EA_CAP;                    /**< PCI EA capabilities register, offset: 0x9E */
  struct EMDIO_PCI_HDR_TYPE0_NUM_EA {              /* offset: 0xA0, array step: 0x10 */
    __I  uint32_t PCI_CFC_EA_PE_FMT;                 /**< PCI EA per-entry 0 format register..PCI EA per-entry 1 format register, array offset: 0xA0, array step: 0x10 */
    __I  uint32_t PCI_CFC_EA_PE_BASE;                /**< PCI EA per-entry 0 base register..PCI EA per-entry 1 base register, array offset: 0xA4, array step: 0x10 */
    __I  uint32_t PCI_CFC_EA_PE_MAXOFF;              /**< PCI EA per-entry 0 max offset register..PCI EA per-entry 1 max offset register, array offset: 0xA8, array step: 0x10 */
    __I  uint32_t PCI_CFC_EA_PE_EXT_BASE;            /**< PCI EA per-entry 0 extended base register..PCI EA per-entry 1 extended base register, array offset: 0xAC, array step: 0x10 */
  } NUM_EA[EMDIO_PCI_HDR_TYPE0_NUM_EA_COUNT];
  uint8_t RESERVED_10[64];
  __I  uint32_t PCIE_CFC_AER_EXT_CAP_HDR;          /**< PCIe AER extended capability header, offset: 0x100 */
  __IO uint32_t PCIE_CFC_AER_UCORR_ERR_STAT;       /**< PCIe AER uncorrectable error status register, offset: 0x104 */
  __IO uint32_t PCIE_CFC_AER_UCORR_ERR_MASK;       /**< PCIe AER uncorrectable error mask register, offset: 0x108 */
  __IO uint32_t PCIE_CFC_AER_UCORR_ERR_SEV;        /**< PCIe AER uncorrectable error severity register, offset: 0x10C */
  __IO uint32_t PCIE_CFC_AER_CORR_ERR_STAT;        /**< PCIe AER correctable error status register, offset: 0x110 */
  __IO uint32_t PCIE_CFC_AER_CORR_ERR_MASK;        /**< PCIe AER correctable error mask register, offset: 0x114 */
  __I  uint32_t PCIE_CFC_AER_CAP_CTL;              /**< PCIe AER capabilities and control register, offset: 0x118 */
  uint8_t RESERVED_11[20];
  __I  uint32_t PCIE_CFC_ACS_CAP_HDR;              /**< PCIe ACS capability header, offset: 0x130 */
  __I  uint16_t PCIE_CFC_ACS_CAP;                  /**< PCIe ACS capability register, offset: 0x134 */
  __I  uint16_t PCIE_CFC_ACS_CTL;                  /**< PCIe ACS control register, offset: 0x136 */
  uint8_t RESERVED_12[8];
  __I  uint32_t PCIE_CFC_RTR_CAP_HDR;              /**< PCIe readiness time reporting capability header, offset: 0x140 */
  __I  uint32_t PCIE_CFC_RTR_RTR1;                 /**< PCIe RTR readiness time reporting 1 register, offset: 0x144 */
  __I  uint32_t PCIE_CFC_RTR_RTR2;                 /**< PCIe RTR readiness time reporting 2 register, offset: 0x148 */
} EMDIO_PCI_HDR_TYPE0_Type, *EMDIO_PCI_HDR_TYPE0_MemMapPtr;

/** Number of instances of the EMDIO_PCI_HDR_TYPE0 module. */
#define EMDIO_PCI_HDR_TYPE0_INSTANCE_COUNT       (1u)

/* EMDIO_PCI_HDR_TYPE0 - Peripheral instance base addresses */
/** Peripheral NETC__EMDIO0_PCI_HDR_TYPE0 base address */
#define IP_NETC__EMDIO0_PCI_HDR_TYPE0_BASE       (0x6D404000u)
/** Peripheral NETC__EMDIO0_PCI_HDR_TYPE0 base pointer */
#define IP_NETC__EMDIO0_PCI_HDR_TYPE0            ((EMDIO_PCI_HDR_TYPE0_Type *)IP_NETC__EMDIO0_PCI_HDR_TYPE0_BASE)
/** Array initializer of EMDIO_PCI_HDR_TYPE0 peripheral base addresses */
#define IP_EMDIO_PCI_HDR_TYPE0_BASE_ADDRS        { IP_NETC__EMDIO0_PCI_HDR_TYPE0_BASE }
/** Array initializer of EMDIO_PCI_HDR_TYPE0 peripheral base pointers */
#define IP_EMDIO_PCI_HDR_TYPE0_BASE_PTRS         { IP_NETC__EMDIO0_PCI_HDR_TYPE0 }

/* ----------------------------------------------------------------------------
   -- EMDIO_PCI_HDR_TYPE0 Register Masks
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup EMDIO_PCI_HDR_TYPE0_Register_Masks EMDIO_PCI_HDR_TYPE0 Register Masks
 * @{
 */

/*! @name PCI_CFH_DID_VID - PCI device ID and vendor ID register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_DID_VID_VENDOR_ID_MASK (0xFFFFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_DID_VID_VENDOR_ID_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_DID_VID_VENDOR_ID_WIDTH (16U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_DID_VID_VENDOR_ID(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_DID_VID_VENDOR_ID_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_DID_VID_VENDOR_ID_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_DID_VID_DEVICE_ID_MASK (0xFFFF0000U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_DID_VID_DEVICE_ID_SHIFT (16U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_DID_VID_DEVICE_ID_WIDTH (16U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_DID_VID_DEVICE_ID(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_DID_VID_DEVICE_ID_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_DID_VID_DEVICE_ID_MASK)
/*! @} */

/*! @name PCI_CFH_CMD - PCI command register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CMD_MEM_ACCESS_MASK (0x2U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CMD_MEM_ACCESS_SHIFT (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CMD_MEM_ACCESS_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CMD_MEM_ACCESS(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_CMD_MEM_ACCESS_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_CMD_MEM_ACCESS_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CMD_BUS_MASTER_EN_MASK (0x4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CMD_BUS_MASTER_EN_SHIFT (2U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CMD_BUS_MASTER_EN_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CMD_BUS_MASTER_EN(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_CMD_BUS_MASTER_EN_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_CMD_BUS_MASTER_EN_MASK)
/*! @} */

/*! @name PCI_CFH_STAT - PCI status register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_STAT_CAP_LIST_MASK (0x10U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_STAT_CAP_LIST_SHIFT (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_STAT_CAP_LIST_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_STAT_CAP_LIST(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_STAT_CAP_LIST_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_STAT_CAP_LIST_MASK)
/*! @} */

/*! @name PCI_CFH_REVID_CLASSCODE - PCI revision ID and classcode register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_REVID_CLASSCODE_REV_ID_MASK (0xFFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_REVID_CLASSCODE_REV_ID_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_REVID_CLASSCODE_REV_ID_WIDTH (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_REVID_CLASSCODE_REV_ID(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_REVID_CLASSCODE_REV_ID_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_REVID_CLASSCODE_REV_ID_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_REVID_CLASSCODE_CLASS_CODE_MASK (0xFFFFFF00U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_REVID_CLASSCODE_CLASS_CODE_SHIFT (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_REVID_CLASSCODE_CLASS_CODE_WIDTH (24U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_REVID_CLASSCODE_CLASS_CODE(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_REVID_CLASSCODE_CLASS_CODE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_REVID_CLASSCODE_CLASS_CODE_MASK)
/*! @} */

/*! @name PCI_CFH_CL_SIZE - PCI cache line size register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CL_SIZE_CACHE_LINE_SIZE_MASK (0xFFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CL_SIZE_CACHE_LINE_SIZE_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CL_SIZE_CACHE_LINE_SIZE_WIDTH (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CL_SIZE_CACHE_LINE_SIZE(x) (((uint8_t)(((uint8_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_CL_SIZE_CACHE_LINE_SIZE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_CL_SIZE_CACHE_LINE_SIZE_MASK)
/*! @} */

/*! @name PCI_CFH_HDR_TYPE - PCI header type register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_HDR_TYPE_HDR_TYPE_MASK (0x7FU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_HDR_TYPE_HDR_TYPE_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_HDR_TYPE_HDR_TYPE_WIDTH (7U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_HDR_TYPE_HDR_TYPE(x) (((uint8_t)(((uint8_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_HDR_TYPE_HDR_TYPE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_HDR_TYPE_HDR_TYPE_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_HDR_TYPE_MULT_FUNC_DEV_MASK (0x80U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_HDR_TYPE_MULT_FUNC_DEV_SHIFT (7U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_HDR_TYPE_MULT_FUNC_DEV_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_HDR_TYPE_MULT_FUNC_DEV(x) (((uint8_t)(((uint8_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_HDR_TYPE_MULT_FUNC_DEV_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_HDR_TYPE_MULT_FUNC_DEV_MASK)
/*! @} */

/*! @name PCI_CFH_BAR0 - PCI base address register 0 */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_MEM_IO_IND_MASK (0x1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_MEM_IO_IND_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_MEM_IO_IND_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_MEM_IO_IND(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_MEM_IO_IND_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_MEM_IO_IND_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_MEM_TYPE_MASK (0x6U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_MEM_TYPE_SHIFT (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_MEM_TYPE_WIDTH (2U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_MEM_TYPE(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_MEM_TYPE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_MEM_TYPE_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_PF_MEM_MASK (0x8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_PF_MEM_SHIFT (3U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_PF_MEM_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_PF_MEM(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_PF_MEM_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_PF_MEM_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_ADDR_MASK (0xFFFFFFF0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_ADDR_SHIFT (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_ADDR_WIDTH (28U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_ADDR(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_ADDR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR0_ADDR_MASK)
/*! @} */

/*! @name PCI_CFH_BAR1 - PCI base address register 1 */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_MEM_IO_IND_MASK (0x1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_MEM_IO_IND_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_MEM_IO_IND_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_MEM_IO_IND(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_MEM_IO_IND_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_MEM_IO_IND_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_MEM_TYPE_MASK (0x6U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_MEM_TYPE_SHIFT (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_MEM_TYPE_WIDTH (2U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_MEM_TYPE(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_MEM_TYPE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_MEM_TYPE_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_PF_MEM_MASK (0x8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_PF_MEM_SHIFT (3U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_PF_MEM_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_PF_MEM(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_PF_MEM_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_PF_MEM_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_ADDR_MASK (0xFFFFFFF0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_ADDR_SHIFT (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_ADDR_WIDTH (28U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_ADDR(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_ADDR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR1_ADDR_MASK)
/*! @} */

/*! @name PCI_CFH_BAR2 - PCI base address register 2 */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_MEM_IO_IND_MASK (0x1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_MEM_IO_IND_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_MEM_IO_IND_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_MEM_IO_IND(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_MEM_IO_IND_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_MEM_IO_IND_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_MEM_TYPE_MASK (0x6U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_MEM_TYPE_SHIFT (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_MEM_TYPE_WIDTH (2U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_MEM_TYPE(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_MEM_TYPE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_MEM_TYPE_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_PF_MEM_MASK (0x8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_PF_MEM_SHIFT (3U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_PF_MEM_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_PF_MEM(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_PF_MEM_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_PF_MEM_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_ADDR_MASK (0xFFFFFFF0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_ADDR_SHIFT (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_ADDR_WIDTH (28U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_ADDR(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_ADDR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR2_ADDR_MASK)
/*! @} */

/*! @name PCI_CFH_BAR3 - PCI base address register 3 */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_MEM_IO_IND_MASK (0x1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_MEM_IO_IND_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_MEM_IO_IND_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_MEM_IO_IND(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_MEM_IO_IND_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_MEM_IO_IND_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_MEM_TYPE_MASK (0x6U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_MEM_TYPE_SHIFT (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_MEM_TYPE_WIDTH (2U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_MEM_TYPE(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_MEM_TYPE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_MEM_TYPE_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_PF_MEM_MASK (0x8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_PF_MEM_SHIFT (3U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_PF_MEM_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_PF_MEM(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_PF_MEM_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_PF_MEM_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_ADDR_MASK (0xFFFFFFF0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_ADDR_SHIFT (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_ADDR_WIDTH (28U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_ADDR(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_ADDR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR3_ADDR_MASK)
/*! @} */

/*! @name PCI_CFH_BAR4 - PCI base address register 4 */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_MEM_IO_IND_MASK (0x1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_MEM_IO_IND_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_MEM_IO_IND_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_MEM_IO_IND(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_MEM_IO_IND_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_MEM_IO_IND_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_MEM_TYPE_MASK (0x6U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_MEM_TYPE_SHIFT (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_MEM_TYPE_WIDTH (2U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_MEM_TYPE(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_MEM_TYPE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_MEM_TYPE_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_PF_MEM_MASK (0x8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_PF_MEM_SHIFT (3U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_PF_MEM_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_PF_MEM(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_PF_MEM_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_PF_MEM_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_ADDR_MASK (0xFFFFFFF0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_ADDR_SHIFT (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_ADDR_WIDTH (28U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_ADDR(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_ADDR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR4_ADDR_MASK)
/*! @} */

/*! @name PCI_CFH_BAR5 - PCI base address register 5 */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_MEM_IO_IND_MASK (0x1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_MEM_IO_IND_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_MEM_IO_IND_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_MEM_IO_IND(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_MEM_IO_IND_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_MEM_IO_IND_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_MEM_TYPE_MASK (0x6U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_MEM_TYPE_SHIFT (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_MEM_TYPE_WIDTH (2U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_MEM_TYPE(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_MEM_TYPE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_MEM_TYPE_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_PF_MEM_MASK (0x8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_PF_MEM_SHIFT (3U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_PF_MEM_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_PF_MEM(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_PF_MEM_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_PF_MEM_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_ADDR_MASK (0xFFFFFFF0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_ADDR_SHIFT (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_ADDR_WIDTH (28U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_ADDR(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_ADDR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_BAR5_ADDR_MASK)
/*! @} */

/*! @name PCI_CFH_SUBSYS_VID - PCI subsystem vendor ID register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_SUBSYS_VID_SUBSYSTEM_VENDOR_ID_MASK (0xFFFFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_SUBSYS_VID_SUBSYSTEM_VENDOR_ID_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_SUBSYS_VID_SUBSYSTEM_VENDOR_ID_WIDTH (16U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_SUBSYS_VID_SUBSYSTEM_VENDOR_ID(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_SUBSYS_VID_SUBSYSTEM_VENDOR_ID_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_SUBSYS_VID_SUBSYSTEM_VENDOR_ID_MASK)
/*! @} */

/*! @name PCI_CFH_SUBSYS_ID - PCI subsystem ID register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_SUBSYS_ID_SUBSYSTEM_ID_MASK (0xFFFFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_SUBSYS_ID_SUBSYSTEM_ID_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_SUBSYS_ID_SUBSYSTEM_ID_WIDTH (16U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_SUBSYS_ID_SUBSYSTEM_ID(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_SUBSYS_ID_SUBSYSTEM_ID_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_SUBSYS_ID_SUBSYSTEM_ID_MASK)
/*! @} */

/*! @name PCI_CFH_CAP_PTR - PCI capabilities pointer register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CAP_PTR_CAP_PTR_MASK (0xFFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CAP_PTR_CAP_PTR_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CAP_PTR_CAP_PTR_WIDTH (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFH_CAP_PTR_CAP_PTR(x) (((uint8_t)(((uint8_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFH_CAP_PTR_CAP_PTR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFH_CAP_PTR_CAP_PTR_MASK)
/*! @} */

/*! @name PCI_CFC_PCIE_CAP_LIST - PCI PCIe capabilities list register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_LIST_CAP_ID_MASK (0xFFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_LIST_CAP_ID_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_LIST_CAP_ID_WIDTH (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_LIST_CAP_ID(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_LIST_CAP_ID_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_LIST_CAP_ID_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_LIST_NEXT_CAP_PTR_MASK (0xFF00U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_LIST_NEXT_CAP_PTR_SHIFT (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_LIST_NEXT_CAP_PTR_WIDTH (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_LIST_NEXT_CAP_PTR(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_LIST_NEXT_CAP_PTR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_LIST_NEXT_CAP_PTR_MASK)
/*! @} */

/*! @name PCI_CFC_PCIE_CAP - PCI PCIe capabilities register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_CAP_VER_MASK (0xFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_CAP_VER_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_CAP_VER_WIDTH (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_CAP_VER(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_CAP_VER_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_CAP_VER_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_DEV_PORT_TYPE_MASK (0xF0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_DEV_PORT_TYPE_SHIFT (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_DEV_PORT_TYPE_WIDTH (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_DEV_PORT_TYPE(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_DEV_PORT_TYPE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_DEV_PORT_TYPE_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_INT_MSG_NUM_MASK (0x3E00U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_INT_MSG_NUM_SHIFT (9U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_INT_MSG_NUM_WIDTH (5U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_INT_MSG_NUM(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_INT_MSG_NUM_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_CAP_INT_MSG_NUM_MASK)
/*! @} */

/*! @name PCI_CFC_PCIE_DEV_CAP - PCI PCIe device capabilities register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP_FLR_CAP_MASK (0x10000000U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP_FLR_CAP_SHIFT (28U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP_FLR_CAP_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP_FLR_CAP(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP_FLR_CAP_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP_FLR_CAP_MASK)
/*! @} */

/*! @name PCI_CFC_PCIE_DEV_CTL - PCI PCIe device control register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL_INIT_FLR_MASK (0x8000U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL_INIT_FLR_SHIFT (15U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL_INIT_FLR_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL_INIT_FLR(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL_INIT_FLR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL_INIT_FLR_MASK)
/*! @} */

/*! @name PCI_CFC_PCIE_DEV_STAT - PCI PCIe device status register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_STAT_TRANS_PEND_MASK (0x20U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_STAT_TRANS_PEND_SHIFT (5U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_STAT_TRANS_PEND_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_STAT_TRANS_PEND(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_STAT_TRANS_PEND_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_STAT_TRANS_PEND_MASK)
/*! @} */

/*! @name PCI_CFC_PCIE_DEV_CAP2 - PCI PCIe device capabilities 2 register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP2_CMPL_TO_RNG_SUPP_MASK (0xFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP2_CMPL_TO_RNG_SUPP_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP2_CMPL_TO_RNG_SUPP_WIDTH (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP2_CMPL_TO_RNG_SUPP(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP2_CMPL_TO_RNG_SUPP_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP2_CMPL_TO_RNG_SUPP_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP2_CMPL_TO_DIS_SUPP_MASK (0x10U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP2_CMPL_TO_DIS_SUPP_SHIFT (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP2_CMPL_TO_DIS_SUPP_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP2_CMPL_TO_DIS_SUPP(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP2_CMPL_TO_DIS_SUPP_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CAP2_CMPL_TO_DIS_SUPP_MASK)
/*! @} */

/*! @name PCI_CFC_PCIE_DEV_CTL2 - PCI PCIe device control 2 register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL2_CMPL_TO_VALUE_MASK (0xFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL2_CMPL_TO_VALUE_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL2_CMPL_TO_VALUE_WIDTH (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL2_CMPL_TO_VALUE(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL2_CMPL_TO_VALUE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL2_CMPL_TO_VALUE_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL2_CMPL_TO_EN_MASK (0x10U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL2_CMPL_TO_EN_SHIFT (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL2_CMPL_TO_EN_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL2_CMPL_TO_EN(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL2_CMPL_TO_EN_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIE_DEV_CTL2_CMPL_TO_EN_MASK)
/*! @} */

/*! @name PCI_CFC_MSIX_CAP_LIST - PCI MSI-X capabilities list register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_CAP_LIST_CAP_ID_MASK (0xFFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_CAP_LIST_CAP_ID_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_CAP_LIST_CAP_ID_WIDTH (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_CAP_LIST_CAP_ID(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_CAP_LIST_CAP_ID_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_CAP_LIST_CAP_ID_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_CAP_LIST_NEXT_CAP_PTR_MASK (0xFF00U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_CAP_LIST_NEXT_CAP_PTR_SHIFT (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_CAP_LIST_NEXT_CAP_PTR_WIDTH (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_CAP_LIST_NEXT_CAP_PTR(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_CAP_LIST_NEXT_CAP_PTR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_CAP_LIST_NEXT_CAP_PTR_MASK)
/*! @} */

/*! @name PCI_CFC_MSIX_MSG_CTL - PCI MSI-X message control register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_TABLE_SIZE_MASK (0x7FFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_TABLE_SIZE_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_TABLE_SIZE_WIDTH (11U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_TABLE_SIZE(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_TABLE_SIZE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_TABLE_SIZE_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_FUNC_MASK_MASK (0x4000U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_FUNC_MASK_SHIFT (14U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_FUNC_MASK_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_FUNC_MASK(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_FUNC_MASK_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_FUNC_MASK_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_MSIX_EN_MASK (0x8000U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_MSIX_EN_SHIFT (15U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_MSIX_EN_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_MSIX_EN(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_MSIX_EN_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_MSG_CTL_MSIX_EN_MASK)
/*! @} */

/*! @name PCI_CFC_MSIX_TABLE_OFF_BIR - PCI MSI-X table offset/BIR register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_TABLE_OFF_BIR_TABLE_BIR_MASK (0x7U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_TABLE_OFF_BIR_TABLE_BIR_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_TABLE_OFF_BIR_TABLE_BIR_WIDTH (3U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_TABLE_OFF_BIR_TABLE_BIR(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_TABLE_OFF_BIR_TABLE_BIR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_TABLE_OFF_BIR_TABLE_BIR_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_TABLE_OFF_BIR_TABLE_OFFSET_MASK (0xFFFFFFF8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_TABLE_OFF_BIR_TABLE_OFFSET_SHIFT (3U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_TABLE_OFF_BIR_TABLE_OFFSET_WIDTH (29U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_TABLE_OFF_BIR_TABLE_OFFSET(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_TABLE_OFF_BIR_TABLE_OFFSET_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_TABLE_OFF_BIR_TABLE_OFFSET_MASK)
/*! @} */

/*! @name PCI_CFC_MSIX_PBA_OFF_BIR - PCI MSI-X PBA offset/BIR register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_PBA_OFF_BIR_PBA_BIR_MASK (0x7U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_PBA_OFF_BIR_PBA_BIR_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_PBA_OFF_BIR_PBA_BIR_WIDTH (3U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_PBA_OFF_BIR_PBA_BIR(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_PBA_OFF_BIR_PBA_BIR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_PBA_OFF_BIR_PBA_BIR_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_PBA_OFF_BIR_PBA_OFFSET_MASK (0xFFFFFFF8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_PBA_OFF_BIR_PBA_OFFSET_SHIFT (3U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_PBA_OFF_BIR_PBA_OFFSET_WIDTH (29U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_PBA_OFF_BIR_PBA_OFFSET(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_PBA_OFF_BIR_PBA_OFFSET_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_MSIX_PBA_OFF_BIR_PBA_OFFSET_MASK)
/*! @} */

/*! @name PCI_CFC_PCIPM_CAP_LIST - PCI PCI-PM capabilities list register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_LIST_CAP_ID_MASK (0xFFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_LIST_CAP_ID_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_LIST_CAP_ID_WIDTH (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_LIST_CAP_ID(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_LIST_CAP_ID_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_LIST_CAP_ID_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_LIST_NEXT_CAP_PTR_MASK (0xFF00U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_LIST_NEXT_CAP_PTR_SHIFT (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_LIST_NEXT_CAP_PTR_WIDTH (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_LIST_NEXT_CAP_PTR(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_LIST_NEXT_CAP_PTR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_LIST_NEXT_CAP_PTR_MASK)
/*! @} */

/*! @name PCI_CFC_PCIPM_CAP - PCI PCI-PM capabilities register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_VERSION_MASK (0x7U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_VERSION_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_VERSION_WIDTH (3U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_VERSION(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_VERSION_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_VERSION_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_PME_SUPPORT_MASK (0xF800U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_PME_SUPPORT_SHIFT (11U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_PME_SUPPORT_WIDTH (5U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_PME_SUPPORT(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_PME_SUPPORT_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CAP_PME_SUPPORT_MASK)
/*! @} */

/*! @name PCI_CFC_PCIPM_CTL_STAT - PCI PCI-PM control and status register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CTL_STAT_PWR_STATE_MASK (0x3U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CTL_STAT_PWR_STATE_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CTL_STAT_PWR_STATE_WIDTH (2U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CTL_STAT_PWR_STATE(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CTL_STAT_PWR_STATE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CTL_STAT_PWR_STATE_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CTL_STAT_NO_SOFT_RST_MASK (0x8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CTL_STAT_NO_SOFT_RST_SHIFT (3U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CTL_STAT_NO_SOFT_RST_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CTL_STAT_NO_SOFT_RST(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CTL_STAT_NO_SOFT_RST_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_PCIPM_CTL_STAT_NO_SOFT_RST_MASK)
/*! @} */

/*! @name PCI_CFC_EA_CAP_LIST - PCI EA capabilities list register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_LIST_CAP_ID_MASK (0xFFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_LIST_CAP_ID_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_LIST_CAP_ID_WIDTH (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_LIST_CAP_ID(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_LIST_CAP_ID_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_LIST_CAP_ID_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_LIST_NEXT_CAP_PTR_MASK (0xFF00U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_LIST_NEXT_CAP_PTR_SHIFT (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_LIST_NEXT_CAP_PTR_WIDTH (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_LIST_NEXT_CAP_PTR(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_LIST_NEXT_CAP_PTR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_LIST_NEXT_CAP_PTR_MASK)
/*! @} */

/*! @name PCI_CFC_EA_CAP - PCI EA capabilities register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_NUM_ENTRIES_MASK (0x3FU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_NUM_ENTRIES_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_NUM_ENTRIES_WIDTH (6U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_NUM_ENTRIES(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_NUM_ENTRIES_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_CAP_NUM_ENTRIES_MASK)
/*! @} */

/*! @name PCI_CFC_EA_PE_FMT - PCI EA per-entry 0 format register..PCI EA per-entry 1 format register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_ENTRY_SIZE_MASK (0x7U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_ENTRY_SIZE_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_ENTRY_SIZE_WIDTH (3U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_ENTRY_SIZE(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_ENTRY_SIZE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_ENTRY_SIZE_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_BEI_MASK (0xF0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_BEI_SHIFT (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_BEI_WIDTH (4U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_BEI(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_BEI_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_BEI_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_PRIM_PROP_MASK (0xFF00U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_PRIM_PROP_SHIFT (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_PRIM_PROP_WIDTH (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_PRIM_PROP(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_PRIM_PROP_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_PRIM_PROP_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_SEC_PROP_MASK (0xFF0000U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_SEC_PROP_SHIFT (16U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_SEC_PROP_WIDTH (8U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_SEC_PROP(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_SEC_PROP_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_SEC_PROP_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_WRITABLE_MASK (0x40000000U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_WRITABLE_SHIFT (30U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_WRITABLE_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_WRITABLE(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_WRITABLE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_WRITABLE_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_ENABLE_MASK (0x80000000U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_ENABLE_SHIFT (31U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_ENABLE_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_ENABLE(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_ENABLE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_FMT_ENABLE_MASK)
/*! @} */

/*! @name PCI_CFC_EA_PE_BASE - PCI EA per-entry 0 base register..PCI EA per-entry 1 base register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_BASE_S_MASK (0x2U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_BASE_S_SHIFT (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_BASE_S_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_BASE_S(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_BASE_S_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_BASE_S_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_BASE_BASE_MASK (0xFFFFFFFCU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_BASE_BASE_SHIFT (2U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_BASE_BASE_WIDTH (30U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_BASE_BASE(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_BASE_BASE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_BASE_BASE_MASK)
/*! @} */

/*! @name PCI_CFC_EA_PE_MAXOFF - PCI EA per-entry 0 max offset register..PCI EA per-entry 1 max offset register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_MAXOFF_S_MASK (0x2U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_MAXOFF_S_SHIFT (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_MAXOFF_S_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_MAXOFF_S(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_MAXOFF_S_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_MAXOFF_S_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_MAXOFF_MAX_OFFSET_MASK (0xFFFFFFFCU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_MAXOFF_MAX_OFFSET_SHIFT (2U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_MAXOFF_MAX_OFFSET_WIDTH (30U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_MAXOFF_MAX_OFFSET(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_MAXOFF_MAX_OFFSET_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_MAXOFF_MAX_OFFSET_MASK)
/*! @} */

/*! @name PCI_CFC_EA_PE_EXT_BASE - PCI EA per-entry 0 extended base register..PCI EA per-entry 1 extended base register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_EXT_BASE_BASE_MASK (0xFFFFFFFFU)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_EXT_BASE_BASE_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_EXT_BASE_BASE_WIDTH (32U)
#define EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_EXT_BASE_BASE(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_EXT_BASE_BASE_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCI_CFC_EA_PE_EXT_BASE_BASE_MASK)
/*! @} */

/*! @name PCIE_CFC_AER_EXT_CAP_HDR - PCIe AER extended capability header */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_PCIE_EXT_CAP_ID_MASK (0xFFFFU)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_PCIE_EXT_CAP_ID_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_PCIE_EXT_CAP_ID_WIDTH (16U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_PCIE_EXT_CAP_ID(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_PCIE_EXT_CAP_ID_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_PCIE_EXT_CAP_ID_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_CAP_VER_MASK (0xF0000U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_CAP_VER_SHIFT (16U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_CAP_VER_WIDTH (4U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_CAP_VER(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_CAP_VER_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_CAP_VER_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_NEXT_CAP_OFF_MASK (0xFFF00000U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_NEXT_CAP_OFF_SHIFT (20U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_NEXT_CAP_OFF_WIDTH (12U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_NEXT_CAP_OFF(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_NEXT_CAP_OFF_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_EXT_CAP_HDR_NEXT_CAP_OFF_MASK)
/*! @} */

/*! @name PCIE_CFC_AER_UCORR_ERR_STAT - PCIe AER uncorrectable error status register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_STAT_ACS_VIOLATION_STAT_MASK (0x200000U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_STAT_ACS_VIOLATION_STAT_SHIFT (21U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_STAT_ACS_VIOLATION_STAT_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_STAT_ACS_VIOLATION_STAT(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_STAT_ACS_VIOLATION_STAT_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_STAT_ACS_VIOLATION_STAT_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_STAT_UCORR_INT_ERR_MASK (0x400000U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_STAT_UCORR_INT_ERR_SHIFT (22U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_STAT_UCORR_INT_ERR_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_STAT_UCORR_INT_ERR(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_STAT_UCORR_INT_ERR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_STAT_UCORR_INT_ERR_MASK)
/*! @} */

/*! @name PCIE_CFC_AER_UCORR_ERR_MASK - PCIe AER uncorrectable error mask register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_MASK_UCORR_INT_ERR_MASK_MASK (0x400000U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_MASK_UCORR_INT_ERR_MASK_SHIFT (22U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_MASK_UCORR_INT_ERR_MASK_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_MASK_UCORR_INT_ERR_MASK(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_MASK_UCORR_INT_ERR_MASK_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_MASK_UCORR_INT_ERR_MASK_MASK)
/*! @} */

/*! @name PCIE_CFC_AER_UCORR_ERR_SEV - PCIe AER uncorrectable error severity register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_SEV_UCORR_INT_SEV_MASK (0x400000U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_SEV_UCORR_INT_SEV_SHIFT (22U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_SEV_UCORR_INT_SEV_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_SEV_UCORR_INT_SEV(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_SEV_UCORR_INT_SEV_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_UCORR_ERR_SEV_UCORR_INT_SEV_MASK)
/*! @} */

/*! @name PCIE_CFC_AER_CORR_ERR_STAT - PCIe AER correctable error status register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CORR_ERR_STAT_CORR_INT_ERR_MASK (0x4000U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CORR_ERR_STAT_CORR_INT_ERR_SHIFT (14U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CORR_ERR_STAT_CORR_INT_ERR_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CORR_ERR_STAT_CORR_INT_ERR(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CORR_ERR_STAT_CORR_INT_ERR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CORR_ERR_STAT_CORR_INT_ERR_MASK)
/*! @} */

/*! @name PCIE_CFC_AER_CORR_ERR_MASK - PCIe AER correctable error mask register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CORR_ERR_MASK_CORR_INT_MASK_MASK (0x4000U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CORR_ERR_MASK_CORR_INT_MASK_SHIFT (14U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CORR_ERR_MASK_CORR_INT_MASK_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CORR_ERR_MASK_CORR_INT_MASK(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CORR_ERR_MASK_CORR_INT_MASK_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CORR_ERR_MASK_CORR_INT_MASK_MASK)
/*! @} */

/*! @name PCIE_CFC_AER_CAP_CTL - PCIe AER capabilities and control register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CAP_CTL_FIRST_ERR_PTR_MASK (0x1FU)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CAP_CTL_FIRST_ERR_PTR_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CAP_CTL_FIRST_ERR_PTR_WIDTH (5U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CAP_CTL_FIRST_ERR_PTR(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CAP_CTL_FIRST_ERR_PTR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_AER_CAP_CTL_FIRST_ERR_PTR_MASK)
/*! @} */

/*! @name PCIE_CFC_ACS_CAP_HDR - PCIe ACS capability header */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_PCIE_EXT_CAP_ID_MASK (0xFFFFU)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_PCIE_EXT_CAP_ID_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_PCIE_EXT_CAP_ID_WIDTH (16U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_PCIE_EXT_CAP_ID(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_PCIE_EXT_CAP_ID_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_PCIE_EXT_CAP_ID_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_CAP_VER_MASK (0xF0000U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_CAP_VER_SHIFT (16U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_CAP_VER_WIDTH (4U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_CAP_VER(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_CAP_VER_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_CAP_VER_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_NEXT_CAP_OFF_MASK (0xFFF00000U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_NEXT_CAP_OFF_SHIFT (20U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_NEXT_CAP_OFF_WIDTH (12U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_NEXT_CAP_OFF(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_NEXT_CAP_OFF_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_HDR_NEXT_CAP_OFF_MASK)
/*! @} */

/*! @name PCIE_CFC_ACS_CAP - PCIe ACS capability register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_TRANS_BLOCK_MASK (0x2U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_TRANS_BLOCK_SHIFT (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_TRANS_BLOCK_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_TRANS_BLOCK(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_TRANS_BLOCK_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_TRANS_BLOCK_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_P2P_REQ_REDIR_MASK (0x4U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_P2P_REQ_REDIR_SHIFT (2U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_P2P_REQ_REDIR_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_P2P_REQ_REDIR(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_P2P_REQ_REDIR_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_P2P_REQ_REDIR_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_DIR_TRANS_P2P_MASK (0x40U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_DIR_TRANS_P2P_SHIFT (6U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_DIR_TRANS_P2P_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_DIR_TRANS_P2P(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_DIR_TRANS_P2P_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CAP_ACS_DIR_TRANS_P2P_MASK)
/*! @} */

/*! @name PCIE_CFC_ACS_CTL - PCIe ACS control register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_TRANS_BLOCK_EN_MASK (0x2U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_TRANS_BLOCK_EN_SHIFT (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_TRANS_BLOCK_EN_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_TRANS_BLOCK_EN(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_TRANS_BLOCK_EN_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_TRANS_BLOCK_EN_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_P2P_REQ_REDIR_EN_MASK (0x4U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_P2P_REQ_REDIR_EN_SHIFT (2U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_P2P_REQ_REDIR_EN_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_P2P_REQ_REDIR_EN(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_P2P_REQ_REDIR_EN_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_P2P_REQ_REDIR_EN_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_DIR_TRANS_P2P_EN_MASK (0x40U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_DIR_TRANS_P2P_EN_SHIFT (6U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_DIR_TRANS_P2P_EN_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_DIR_TRANS_P2P_EN(x) (((uint16_t)(((uint16_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_DIR_TRANS_P2P_EN_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_ACS_CTL_ACS_DIR_TRANS_P2P_EN_MASK)
/*! @} */

/*! @name PCIE_CFC_RTR_CAP_HDR - PCIe readiness time reporting capability header */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_PCIE_EXT_CAP_ID_MASK (0xFFFFU)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_PCIE_EXT_CAP_ID_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_PCIE_EXT_CAP_ID_WIDTH (16U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_PCIE_EXT_CAP_ID(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_PCIE_EXT_CAP_ID_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_PCIE_EXT_CAP_ID_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_CAP_VER_MASK (0xF0000U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_CAP_VER_SHIFT (16U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_CAP_VER_WIDTH (4U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_CAP_VER(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_CAP_VER_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_CAP_VER_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_NEXT_CAP_OFF_MASK (0xFFF00000U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_NEXT_CAP_OFF_SHIFT (20U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_NEXT_CAP_OFF_WIDTH (12U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_NEXT_CAP_OFF(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_NEXT_CAP_OFF_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_CAP_HDR_NEXT_CAP_OFF_MASK)
/*! @} */

/*! @name PCIE_CFC_RTR_RTR1 - PCIe RTR readiness time reporting 1 register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR1_RESET_TIME_MASK (0xFFFU)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR1_RESET_TIME_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR1_RESET_TIME_WIDTH (12U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR1_RESET_TIME(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR1_RESET_TIME_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR1_RESET_TIME_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR1_VALID_MASK (0x80000000U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR1_VALID_SHIFT (31U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR1_VALID_WIDTH (1U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR1_VALID(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR1_VALID_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR1_VALID_MASK)
/*! @} */

/*! @name PCIE_CFC_RTR_RTR2 - PCIe RTR readiness time reporting 2 register */
/*! @{ */

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR2_FLR_TIME_MASK (0xFFFU)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR2_FLR_TIME_SHIFT (0U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR2_FLR_TIME_WIDTH (12U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR2_FLR_TIME(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR2_FLR_TIME_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR2_FLR_TIME_MASK)

#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR2_D3HOT_D0_TIME_MASK (0xFFF000U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR2_D3HOT_D0_TIME_SHIFT (12U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR2_D3HOT_D0_TIME_WIDTH (12U)
#define EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR2_D3HOT_D0_TIME(x) (((uint32_t)(((uint32_t)(x)) << EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR2_D3HOT_D0_TIME_SHIFT)) & EMDIO_PCI_HDR_TYPE0_PCIE_CFC_RTR_RTR2_D3HOT_D0_TIME_MASK)
/*! @} */

/*!
 * @}
 */ /* end of group EMDIO_PCI_HDR_TYPE0_Register_Masks */

/*!
 * @}
 */ /* end of group EMDIO_PCI_HDR_TYPE0_Peripheral_Access_Layer */

#endif  /* #if !defined(S32K566_EMDIO_PCI_HDR_TYPE0_H_) */
