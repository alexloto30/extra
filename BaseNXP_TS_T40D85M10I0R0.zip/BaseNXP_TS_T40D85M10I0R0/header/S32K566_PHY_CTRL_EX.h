/*
** ###################################################################
**     Processor:           S32K566_M7
**     Compiler:            Keil ARM C/C++ Compiler
**     Reference manual:    S32K5 RM Rev 3
**     Version:             rev. 2.7, 2026-09-09
**     Build:               b260908
**
**     Abstract:
**         Peripheral Access Layer for S32K566_M7
**
**     Copyright 1997-2016 Freescale Semiconductor, Inc.
**     Copyright 2016-2026 NXP
**
**     NXP Confidential and Proprietary. This software is owned or controlled
**     by NXP and may only be used strictly in accordance with the applicable
**     license terms. By expressly accepting such terms or by downloading,
**     installing, activating and/or otherwise using the software, you are
**     agreeing that you have read, and that you agree to comply with and are
**     bound by, such license terms. If you do not agree to be bound by the
**     applicable license terms, then you may not retain, install, activate
**     or otherwise use the software.
**
**     http:                 www.nxp.com
**     mail:                 support@nxp.com
**
** ###################################################################
*/

/*!
 * @file S32K566_PHY_CTRL_EX.h
 * @version 2.7
 * @date 2026-09-09
 * @brief Peripheral Access Layer for S32K566_PHY_CTRL_EX
 *
 * This file contains register definitions and macros for easy access to their
 * bit fields.
 *
 * This file assumes LITTLE endian system.
 */

/**
* @page misra_violations MISRA-C:2012 violations
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.3, local typedef not referenced
* The SoC header defines typedef for all modules.
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.5, local macro not referenced
* The SoC header defines macros for all modules and registers.
*
* @section [global]
* Violates MISRA 2012 Advisory Directive 4.9, Function-like macro
* These are generated macros used for accessing the bit-fields from registers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.1, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.2, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.4, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.5, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 21.1, defined macro '__I' is reserved to the compiler
* This type qualifier is needed to ensure correct I/O access and addressing.
*/

/* Prevention from multiple including the same memory map */
#if !defined(S32K566_PHY_CTRL_EX_H_)  /* Check if memory map has not been already included */
#define S32K566_PHY_CTRL_EX_H_

#include "S32K566_COMMON.h"

/* ----------------------------------------------------------------------------
   -- PHY_CTRL_EX Peripheral Access Layer
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup PHY_CTRL_EX_Peripheral_Access_Layer PHY_CTRL_EX Peripheral Access Layer
 * @{
 */

/** PHY_CTRL_EX - Register Layout Typedef */
typedef struct PHY_CTRL_EX_Struct {
  uint8_t RESERVED_0[276];
  __IO uint16_t GLOBAL_CTRL_EX_0;                  /**< PHY Global extra control register, offset: 0x114 */
  uint8_t RESERVED_1[2];
  __IO uint16_t GLOBAL_CTRL_EX_1;                  /**< PHY Global extra control register, offset: 0x118 */
  uint8_t RESERVED_2[2];
  __IO uint16_t GLOBAL_CTRL_EX_2;                  /**< PHY Global extra control register, offset: 0x11C */
  uint8_t RESERVED_3[2];
  __IO uint16_t GLOBAL_CTRL_EX_3;                  /**< PHY Global extra control register, offset: 0x120 */
  uint8_t RESERVED_4[2];
  __IO uint16_t GLOBAL_CTRL_EX_4;                  /**< PHY Global extra control register, offset: 0x124 */
  uint8_t RESERVED_5[2];
  __IO uint16_t GLOBAL_CTRL_EX_5;                  /**< PHY Global extra control register, offset: 0x128 */
  uint8_t RESERVED_6[130946];
  __IO uint16_t MPLLA_CTRL_EX_0;                   /**< MPLLA extra control register, offset: 0x200AC */
  uint8_t RESERVED_7[2];
  __IO uint16_t MPLLA_CTRL_EX_1;                   /**< MPLLA extra control register, offset: 0x200B0 */
  uint8_t RESERVED_8[2];
  __IO uint16_t MPLLA_CTRL_EX_2;                   /**< MPLLA extra control register, offset: 0x200B4 */
  uint8_t RESERVED_9[131062];
  __IO uint16_t MPLLB_CTRL_EX_0;                   /**< MPLLB extra control register, offset: 0x400AC */
  uint8_t RESERVED_10[2];
  __IO uint16_t MPLLB_CTRL_EX_1;                   /**< MPLLB extra control register, offset: 0x400B0 */
  uint8_t RESERVED_11[2];
  __IO uint16_t MPLLB_CTRL_EX_2;                   /**< MPLLB extra control register, offset: 0x400B4 */
  uint8_t RESERVED_12[132434];
  __IO uint16_t LANE0_CTRL_EX_0;                   /**< LANE0 extra control register, offset: 0x60608 */
  uint8_t RESERVED_13[2];
  __IO uint16_t LANE0_CTRL_EX_1;                   /**< LANE0 extra control register, offset: 0x6060C */
  uint8_t RESERVED_14[2];
  __IO uint16_t LANE0_CTRL_EX_2;                   /**< LANE0 extra control register, offset: 0x60610 */
  uint8_t RESERVED_15[2];
  __IO uint16_t LANE0_CTRL_EX_3;                   /**< LANE0 extra control register, offset: 0x60614 */
  uint8_t RESERVED_16[2];
  __IO uint16_t LANE0_CTRL_EX_4;                   /**< LANE0 extra control register, offset: 0x60618 */
  uint8_t RESERVED_17[2];
  __IO uint16_t MAC_ADAPTER_0_ERROR_EVENT;         /**< Error Event for FIFO, offset: 0x6061C */
} PHY_CTRL_EX_Type, *PHY_CTRL_EX_MemMapPtr;

/** Number of instances of the PHY_CTRL_EX module. */
#define PHY_CTRL_EX_INSTANCE_COUNT               (1u)

/* PHY_CTRL_EX - Peripheral instance base addresses */
/** Peripheral NETC_ENET_PHY_PHY_CTRL_EX_LOCK__PHY_CTRL_EX base address */
#define IP_NETC_ENET_PHY_PHY_CTRL_EX_LOCK__PHY_CTRL_EX_BASE (0xC00000u)
/** Peripheral NETC_ENET_PHY_PHY_CTRL_EX_LOCK__PHY_CTRL_EX base pointer */
#define IP_NETC_ENET_PHY_PHY_CTRL_EX_LOCK__PHY_CTRL_EX ((PHY_CTRL_EX_Type *)IP_NETC_ENET_PHY_PHY_CTRL_EX_LOCK__PHY_CTRL_EX_BASE)
/** Array initializer of PHY_CTRL_EX peripheral base addresses */
#define IP_PHY_CTRL_EX_BASE_ADDRS                { IP_NETC_ENET_PHY_PHY_CTRL_EX_LOCK__PHY_CTRL_EX_BASE }
/** Array initializer of PHY_CTRL_EX peripheral base pointers */
#define IP_PHY_CTRL_EX_BASE_PTRS                 { IP_NETC_ENET_PHY_PHY_CTRL_EX_LOCK__PHY_CTRL_EX }

/* ----------------------------------------------------------------------------
   -- PHY_CTRL_EX Register Masks
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup PHY_CTRL_EX_Register_Masks PHY_CTRL_EX Register Masks
 * @{
 */

/*! @name GLOBAL_CTRL_EX_0 - PHY Global extra control register */
/*! @{ */

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_PHY_SRAM_BYPASS_MASK (0x1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_PHY_SRAM_BYPASS_SHIFT (0U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_PHY_SRAM_BYPASS_WIDTH (1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_PHY_SRAM_BYPASS(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_0_PHY_SRAM_BYPASS_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_0_PHY_SRAM_BYPASS_MASK)

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_XPCS0_SEL_MASK (0x10U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_XPCS0_SEL_SHIFT (4U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_XPCS0_SEL_WIDTH (1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_XPCS0_SEL(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_0_XPCS0_SEL_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_0_XPCS0_SEL_MASK)

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_XPCS1_SEL_MASK (0x20U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_XPCS1_SEL_SHIFT (5U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_XPCS1_SEL_WIDTH (1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_XPCS1_SEL(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_0_XPCS1_SEL_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_0_XPCS1_SEL_MASK)

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_MPLLA_SEL_MASK (0x40U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_MPLLA_SEL_SHIFT (6U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_MPLLA_SEL_WIDTH (1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_MPLLA_SEL(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_0_MPLLA_SEL_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_0_MPLLA_SEL_MASK)

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_MPLLB_SEL_MASK (0x80U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_MPLLB_SEL_SHIFT (7U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_MPLLB_SEL_WIDTH (1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_MPLLB_SEL(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_0_MPLLB_SEL_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_0_MPLLB_SEL_MASK)

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_PHY_SUP_MISC_MASK (0xFF00U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_PHY_SUP_MISC_SHIFT (8U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_PHY_SUP_MISC_WIDTH (8U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_0_PHY_SUP_MISC(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_0_PHY_SUP_MISC_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_0_PHY_SUP_MISC_MASK)
/*! @} */

/*! @name GLOBAL_CTRL_EX_1 - PHY Global extra control register */
/*! @{ */

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_1_PHY_TEST_FLYOVER_EN_MASK (0x1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_1_PHY_TEST_FLYOVER_EN_SHIFT (0U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_1_PHY_TEST_FLYOVER_EN_WIDTH (1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_1_PHY_TEST_FLYOVER_EN(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_1_PHY_TEST_FLYOVER_EN_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_1_PHY_TEST_FLYOVER_EN_MASK)

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_1_PHY_TEST_STOP_CLK_EN_MASK (0x10U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_1_PHY_TEST_STOP_CLK_EN_SHIFT (4U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_1_PHY_TEST_STOP_CLK_EN_WIDTH (1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_1_PHY_TEST_STOP_CLK_EN(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_1_PHY_TEST_STOP_CLK_EN_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_1_PHY_TEST_STOP_CLK_EN_MASK)
/*! @} */

/*! @name GLOBAL_CTRL_EX_2 - PHY Global extra control register */
/*! @{ */

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_2_PHY_TXDN_TERM_OFFSET_MASK (0x1FFU)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_2_PHY_TXDN_TERM_OFFSET_SHIFT (0U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_2_PHY_TXDN_TERM_OFFSET_WIDTH (9U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_2_PHY_TXDN_TERM_OFFSET(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_2_PHY_TXDN_TERM_OFFSET_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_2_PHY_TXDN_TERM_OFFSET_MASK)
/*! @} */

/*! @name GLOBAL_CTRL_EX_3 - PHY Global extra control register */
/*! @{ */

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_3_PHY_TXUP_TERM_OFFSET_MASK (0x1FFU)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_3_PHY_TXUP_TERM_OFFSET_SHIFT (0U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_3_PHY_TXUP_TERM_OFFSET_WIDTH (9U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_3_PHY_TXUP_TERM_OFFSET(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_3_PHY_TXUP_TERM_OFFSET_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_3_PHY_TXUP_TERM_OFFSET_MASK)
/*! @} */

/*! @name GLOBAL_CTRL_EX_4 - PHY Global extra control register */
/*! @{ */

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PCS_PWR_STABLE_MASK (0x100U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PCS_PWR_STABLE_SHIFT (8U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PCS_PWR_STABLE_WIDTH (1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PCS_PWR_STABLE(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PCS_PWR_STABLE_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PCS_PWR_STABLE_MASK)

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PG_MODE_EN_MASK (0x400U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PG_MODE_EN_SHIFT (10U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PG_MODE_EN_WIDTH (1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PG_MODE_EN(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PG_MODE_EN_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PG_MODE_EN_MASK)

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PG_RESET_MASK (0x1000U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PG_RESET_SHIFT (12U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PG_RESET_WIDTH (1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PG_RESET(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PG_RESET_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PG_RESET_MASK)

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PMA_PWR_STABLE_MASK (0x4000U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PMA_PWR_STABLE_SHIFT (14U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PMA_PWR_STABLE_WIDTH (1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PMA_PWR_STABLE(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PMA_PWR_STABLE_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_4_PHY_PMA_PWR_STABLE_MASK)
/*! @} */

/*! @name GLOBAL_CTRL_EX_5 - PHY Global extra control register */
/*! @{ */

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_REF_CLKDET_EN_MASK (0x1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_REF_CLKDET_EN_SHIFT (0U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_REF_CLKDET_EN_WIDTH (1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_REF_CLKDET_EN(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_REF_CLKDET_EN_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_REF_CLKDET_EN_MASK)

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_RST_N_OVRD_MASK (0x100U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_RST_N_OVRD_SHIFT (8U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_RST_N_OVRD_WIDTH (1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_RST_N_OVRD(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_RST_N_OVRD_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_RST_N_OVRD_MASK)

#define PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_RST_N_OVRD_EN_MASK (0x200U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_RST_N_OVRD_EN_SHIFT (9U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_RST_N_OVRD_EN_WIDTH (1U)
#define PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_RST_N_OVRD_EN(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_RST_N_OVRD_EN_SHIFT)) & PHY_CTRL_EX_GLOBAL_CTRL_EX_5_PHY_RST_N_OVRD_EN_MASK)
/*! @} */

/*! @name MPLLA_CTRL_EX_0 - MPLLA extra control register */
/*! @{ */

#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_FORCE_EN_MASK (0x1U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_FORCE_EN_SHIFT (0U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_FORCE_EN_WIDTH (1U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_FORCE_EN(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_FORCE_EN_SHIFT)) & PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_FORCE_EN_MASK)

#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_RECAL_BANK_SEL_MASK (0x6U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_RECAL_BANK_SEL_SHIFT (1U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_RECAL_BANK_SEL_WIDTH (2U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_RECAL_BANK_SEL(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_RECAL_BANK_SEL_SHIFT)) & PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_RECAL_BANK_SEL_MASK)

#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_TX_CLK_DIV_MASK (0x18U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_TX_CLK_DIV_SHIFT (3U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_TX_CLK_DIV_WIDTH (2U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_TX_CLK_DIV(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_TX_CLK_DIV_SHIFT)) & PHY_CTRL_EX_MPLLA_CTRL_EX_0_PHY_MPLLA_TX_CLK_DIV_MASK)

#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_MPLLA_CFG_DRIVER_MASK (0xF00U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_MPLLA_CFG_DRIVER_SHIFT (8U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_MPLLA_CFG_DRIVER_WIDTH (4U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_MPLLA_CFG_DRIVER(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLA_CTRL_EX_0_MPLLA_CFG_DRIVER_SHIFT)) & PHY_CTRL_EX_MPLLA_CTRL_EX_0_MPLLA_CFG_DRIVER_MASK)

#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_WHOAMI_MASK  (0xF000U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_WHOAMI_SHIFT (12U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_WHOAMI_WIDTH (4U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_0_WHOAMI(x)    (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLA_CTRL_EX_0_WHOAMI_SHIFT)) & PHY_CTRL_EX_MPLLA_CTRL_EX_0_WHOAMI_MASK)
/*! @} */

/*! @name MPLLA_CTRL_EX_1 - MPLLA extra control register */
/*! @{ */

#define PHY_CTRL_EX_MPLLA_CTRL_EX_1_PHY_MPLLA_SSC_FREQ_CNT_INIT_MASK (0xFFFU)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_1_PHY_MPLLA_SSC_FREQ_CNT_INIT_SHIFT (0U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_1_PHY_MPLLA_SSC_FREQ_CNT_INIT_WIDTH (12U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_1_PHY_MPLLA_SSC_FREQ_CNT_INIT(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLA_CTRL_EX_1_PHY_MPLLA_SSC_FREQ_CNT_INIT_SHIFT)) & PHY_CTRL_EX_MPLLA_CTRL_EX_1_PHY_MPLLA_SSC_FREQ_CNT_INIT_MASK)
/*! @} */

/*! @name MPLLA_CTRL_EX_2 - MPLLA extra control register */
/*! @{ */

#define PHY_CTRL_EX_MPLLA_CTRL_EX_2_PHY_MPLLA_SSC_FREQ_CNT_PEAK_MASK (0xFFU)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_2_PHY_MPLLA_SSC_FREQ_CNT_PEAK_SHIFT (0U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_2_PHY_MPLLA_SSC_FREQ_CNT_PEAK_WIDTH (8U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_2_PHY_MPLLA_SSC_FREQ_CNT_PEAK(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLA_CTRL_EX_2_PHY_MPLLA_SSC_FREQ_CNT_PEAK_SHIFT)) & PHY_CTRL_EX_MPLLA_CTRL_EX_2_PHY_MPLLA_SSC_FREQ_CNT_PEAK_MASK)

#define PHY_CTRL_EX_MPLLA_CTRL_EX_2_PHY_MPLLA_SSC_UP_SPREAD_MASK (0x100U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_2_PHY_MPLLA_SSC_UP_SPREAD_SHIFT (8U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_2_PHY_MPLLA_SSC_UP_SPREAD_WIDTH (1U)
#define PHY_CTRL_EX_MPLLA_CTRL_EX_2_PHY_MPLLA_SSC_UP_SPREAD(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLA_CTRL_EX_2_PHY_MPLLA_SSC_UP_SPREAD_SHIFT)) & PHY_CTRL_EX_MPLLA_CTRL_EX_2_PHY_MPLLA_SSC_UP_SPREAD_MASK)
/*! @} */

/*! @name MPLLB_CTRL_EX_0 - MPLLB extra control register */
/*! @{ */

#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_FORCE_EN_MASK (0x1U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_FORCE_EN_SHIFT (0U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_FORCE_EN_WIDTH (1U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_FORCE_EN(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_FORCE_EN_SHIFT)) & PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_FORCE_EN_MASK)

#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_RECAL_BANK_SEL_MASK (0x6U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_RECAL_BANK_SEL_SHIFT (1U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_RECAL_BANK_SEL_WIDTH (2U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_RECAL_BANK_SEL(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_RECAL_BANK_SEL_SHIFT)) & PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_RECAL_BANK_SEL_MASK)

#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_TX_CLK_DIV_MASK (0x18U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_TX_CLK_DIV_SHIFT (3U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_TX_CLK_DIV_WIDTH (2U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_TX_CLK_DIV(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_TX_CLK_DIV_SHIFT)) & PHY_CTRL_EX_MPLLB_CTRL_EX_0_PHY_MPLLB_TX_CLK_DIV_MASK)

#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_MPLLB_CFG_DRIVER_MASK (0xF00U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_MPLLB_CFG_DRIVER_SHIFT (8U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_MPLLB_CFG_DRIVER_WIDTH (4U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_MPLLB_CFG_DRIVER(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLB_CTRL_EX_0_MPLLB_CFG_DRIVER_SHIFT)) & PHY_CTRL_EX_MPLLB_CTRL_EX_0_MPLLB_CFG_DRIVER_MASK)

#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_WHOAMI_MASK  (0xF000U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_WHOAMI_SHIFT (12U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_WHOAMI_WIDTH (4U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_0_WHOAMI(x)    (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLB_CTRL_EX_0_WHOAMI_SHIFT)) & PHY_CTRL_EX_MPLLB_CTRL_EX_0_WHOAMI_MASK)
/*! @} */

/*! @name MPLLB_CTRL_EX_1 - MPLLB extra control register */
/*! @{ */

#define PHY_CTRL_EX_MPLLB_CTRL_EX_1_PHY_MPLLB_SSC_FREQ_CNT_INIT_MASK (0xFFFU)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_1_PHY_MPLLB_SSC_FREQ_CNT_INIT_SHIFT (0U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_1_PHY_MPLLB_SSC_FREQ_CNT_INIT_WIDTH (12U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_1_PHY_MPLLB_SSC_FREQ_CNT_INIT(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLB_CTRL_EX_1_PHY_MPLLB_SSC_FREQ_CNT_INIT_SHIFT)) & PHY_CTRL_EX_MPLLB_CTRL_EX_1_PHY_MPLLB_SSC_FREQ_CNT_INIT_MASK)
/*! @} */

/*! @name MPLLB_CTRL_EX_2 - MPLLB extra control register */
/*! @{ */

#define PHY_CTRL_EX_MPLLB_CTRL_EX_2_PHY_MPLLB_SSC_FREQ_CNT_PEAK_MASK (0xFFU)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_2_PHY_MPLLB_SSC_FREQ_CNT_PEAK_SHIFT (0U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_2_PHY_MPLLB_SSC_FREQ_CNT_PEAK_WIDTH (8U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_2_PHY_MPLLB_SSC_FREQ_CNT_PEAK(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLB_CTRL_EX_2_PHY_MPLLB_SSC_FREQ_CNT_PEAK_SHIFT)) & PHY_CTRL_EX_MPLLB_CTRL_EX_2_PHY_MPLLB_SSC_FREQ_CNT_PEAK_MASK)

#define PHY_CTRL_EX_MPLLB_CTRL_EX_2_PHY_MPLLB_SSC_UP_SPREAD_MASK (0x100U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_2_PHY_MPLLB_SSC_UP_SPREAD_SHIFT (8U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_2_PHY_MPLLB_SSC_UP_SPREAD_WIDTH (1U)
#define PHY_CTRL_EX_MPLLB_CTRL_EX_2_PHY_MPLLB_SSC_UP_SPREAD(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MPLLB_CTRL_EX_2_PHY_MPLLB_SSC_UP_SPREAD_SHIFT)) & PHY_CTRL_EX_MPLLB_CTRL_EX_2_PHY_MPLLB_SSC_UP_SPREAD_MASK)
/*! @} */

/*! @name LANE0_CTRL_EX_0 - LANE0 extra control register */
/*! @{ */

#define PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_IN_PROG_MASK (0x1U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_IN_PROG_SHIFT (0U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_IN_PROG_WIDTH (1U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_IN_PROG(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_IN_PROG_SHIFT)) & PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_IN_PROG_MASK)

#define PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_MODE_MASK (0x30U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_MODE_SHIFT (4U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_MODE_WIDTH (2U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_MODE(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_MODE_SHIFT)) & PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_MODE_MASK)

#define PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_SEL_MASK (0x100U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_SEL_SHIFT (8U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_SEL_WIDTH (1U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_SEL(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_SEL_SHIFT)) & PHY_CTRL_EX_LANE0_CTRL_EX_0_PHY_RX_ADAPT_SEL_MASK)
/*! @} */

/*! @name LANE0_CTRL_EX_1 - LANE0 extra control register */
/*! @{ */

#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_PPM_MAX_MASK (0x1FU)
#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_PPM_MAX_SHIFT (0U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_PPM_MAX_WIDTH (5U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_PPM_MAX(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_PPM_MAX_SHIFT)) & PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_PPM_MAX_MASK)

#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_FREQBAND_MASK (0xC0U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_FREQBAND_SHIFT (6U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_FREQBAND_WIDTH (2U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_FREQBAND(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_FREQBAND_SHIFT)) & PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_FREQBAND_MASK)

#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_STEP_CTRL_MASK (0x100U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_STEP_CTRL_SHIFT (8U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_STEP_CTRL_WIDTH (1U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_STEP_CTRL(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_STEP_CTRL_SHIFT)) & PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_STEP_CTRL_MASK)

#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_TEMP_COMP_EN_MASK (0x1000U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_TEMP_COMP_EN_SHIFT (12U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_TEMP_COMP_EN_WIDTH (1U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_TEMP_COMP_EN(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_TEMP_COMP_EN_SHIFT)) & PHY_CTRL_EX_LANE0_CTRL_EX_1_PHY_RX_CDR_VCO_TEMP_COMP_EN_MASK)
/*! @} */

/*! @name LANE0_CTRL_EX_2 - LANE0 extra control register */
/*! @{ */

#define PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_DELTA_IQ_MASK (0xFU)
#define PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_DELTA_IQ_SHIFT (0U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_DELTA_IQ_WIDTH (4U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_DELTA_IQ(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_DELTA_IQ_SHIFT)) & PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_DELTA_IQ_MASK)

#define PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_DFE_BYPASS_MASK (0x10U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_DFE_BYPASS_SHIFT (4U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_DFE_BYPASS_WIDTH (1U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_DFE_BYPASS(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_DFE_BYPASS_SHIFT)) & PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_DFE_BYPASS_MASK)

#define PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_MARGIN_IQ_MASK (0x7F00U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_MARGIN_IQ_SHIFT (8U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_MARGIN_IQ_WIDTH (7U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_MARGIN_IQ(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_MARGIN_IQ_SHIFT)) & PHY_CTRL_EX_LANE0_CTRL_EX_2_PHY_RX_MARGIN_IQ_MASK)
/*! @} */

/*! @name LANE0_CTRL_EX_3 - LANE0 extra control register */
/*! @{ */

#define PHY_CTRL_EX_LANE0_CTRL_EX_3_PHY_RX_TERM_OFFSET_MASK (0x1FU)
#define PHY_CTRL_EX_LANE0_CTRL_EX_3_PHY_RX_TERM_OFFSET_SHIFT (0U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_3_PHY_RX_TERM_OFFSET_WIDTH (5U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_3_PHY_RX_TERM_OFFSET(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_LANE0_CTRL_EX_3_PHY_RX_TERM_OFFSET_SHIFT)) & PHY_CTRL_EX_LANE0_CTRL_EX_3_PHY_RX_TERM_OFFSET_MASK)

#define PHY_CTRL_EX_LANE0_CTRL_EX_3_PHY_RX_MISC_MASK (0xFF00U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_3_PHY_RX_MISC_SHIFT (8U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_3_PHY_RX_MISC_WIDTH (8U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_3_PHY_RX_MISC(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_LANE0_CTRL_EX_3_PHY_RX_MISC_SHIFT)) & PHY_CTRL_EX_LANE0_CTRL_EX_3_PHY_RX_MISC_MASK)
/*! @} */

/*! @name LANE0_CTRL_EX_4 - LANE0 extra control register */
/*! @{ */

#define PHY_CTRL_EX_LANE0_CTRL_EX_4_PHY_TX0_INVERT_MASK (0x1U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_4_PHY_TX0_INVERT_SHIFT (0U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_4_PHY_TX0_INVERT_WIDTH (1U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_4_PHY_TX0_INVERT(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_LANE0_CTRL_EX_4_PHY_TX0_INVERT_SHIFT)) & PHY_CTRL_EX_LANE0_CTRL_EX_4_PHY_TX0_INVERT_MASK)

#define PHY_CTRL_EX_LANE0_CTRL_EX_4_PHY_TX_MISC_MASK (0xFF00U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_4_PHY_TX_MISC_SHIFT (8U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_4_PHY_TX_MISC_WIDTH (8U)
#define PHY_CTRL_EX_LANE0_CTRL_EX_4_PHY_TX_MISC(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_LANE0_CTRL_EX_4_PHY_TX_MISC_SHIFT)) & PHY_CTRL_EX_LANE0_CTRL_EX_4_PHY_TX_MISC_MASK)
/*! @} */

/*! @name MAC_ADAPTER_0_ERROR_EVENT - Error Event for FIFO */
/*! @{ */

#define PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_SGMII_RX_FIFO_OVF_MASK (0x1U)
#define PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_SGMII_RX_FIFO_OVF_SHIFT (0U)
#define PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_SGMII_RX_FIFO_OVF_WIDTH (1U)
#define PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_SGMII_RX_FIFO_OVF(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_SGMII_RX_FIFO_OVF_SHIFT)) & PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_SGMII_RX_FIFO_OVF_MASK)

#define PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_SGMII_TX_FIFO_UDF_MASK (0x10U)
#define PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_SGMII_TX_FIFO_UDF_SHIFT (4U)
#define PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_SGMII_TX_FIFO_UDF_WIDTH (1U)
#define PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_SGMII_TX_FIFO_UDF(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_SGMII_TX_FIFO_UDF_SHIFT)) & PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_SGMII_TX_FIFO_UDF_MASK)

#define PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_MAC_SOFT_RST_MASK (0x100U)
#define PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_MAC_SOFT_RST_SHIFT (8U)
#define PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_MAC_SOFT_RST_WIDTH (1U)
#define PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_MAC_SOFT_RST(x) (((uint16_t)(((uint16_t)(x)) << PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_MAC_SOFT_RST_SHIFT)) & PHY_CTRL_EX_MAC_ADAPTER_0_ERROR_EVENT_MAC_SOFT_RST_MASK)
/*! @} */

/*!
 * @}
 */ /* end of group PHY_CTRL_EX_Register_Masks */

/*!
 * @}
 */ /* end of group PHY_CTRL_EX_Peripheral_Access_Layer */

#endif  /* #if !defined(S32K566_PHY_CTRL_EX_H_) */
