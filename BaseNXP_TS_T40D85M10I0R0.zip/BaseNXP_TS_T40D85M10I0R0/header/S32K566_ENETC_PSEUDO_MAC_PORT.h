/*
** ###################################################################
**     Processor:           S32K566_M7
**     Compiler:            Keil ARM C/C++ Compiler
**     Reference manual:    S32K5 RM Rev 3
**     Version:             rev. 2.7, 2026-09-09
**     Build:               b260908
**
**     Abstract:
**         Peripheral Access Layer for S32K566_M7
**
**     Copyright 1997-2016 Freescale Semiconductor, Inc.
**     Copyright 2016-2026 NXP
**
**     NXP Confidential and Proprietary. This software is owned or controlled
**     by NXP and may only be used strictly in accordance with the applicable
**     license terms. By expressly accepting such terms or by downloading,
**     installing, activating and/or otherwise using the software, you are
**     agreeing that you have read, and that you agree to comply with and are
**     bound by, such license terms. If you do not agree to be bound by the
**     applicable license terms, then you may not retain, install, activate
**     or otherwise use the software.
**
**     http:                 www.nxp.com
**     mail:                 support@nxp.com
**
** ###################################################################
*/

/*!
 * @file S32K566_ENETC_PSEUDO_MAC_PORT.h
 * @version 2.7
 * @date 2026-09-09
 * @brief Peripheral Access Layer for S32K566_ENETC_PSEUDO_MAC_PORT
 *
 * This file contains register definitions and macros for easy access to their
 * bit fields.
 *
 * This file assumes LITTLE endian system.
 */

/**
* @page misra_violations MISRA-C:2012 violations
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.3, local typedef not referenced
* The SoC header defines typedef for all modules.
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.5, local macro not referenced
* The SoC header defines macros for all modules and registers.
*
* @section [global]
* Violates MISRA 2012 Advisory Directive 4.9, Function-like macro
* These are generated macros used for accessing the bit-fields from registers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.1, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.2, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.4, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.5, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 21.1, defined macro '__I' is reserved to the compiler
* This type qualifier is needed to ensure correct I/O access and addressing.
*/

/* Prevention from multiple including the same memory map */
#if !defined(S32K566_ENETC_PSEUDO_MAC_PORT_H_)  /* Check if memory map has not been already included */
#define S32K566_ENETC_PSEUDO_MAC_PORT_H_

#include "S32K566_COMMON.h"

/* ----------------------------------------------------------------------------
   -- ENETC_PSEUDO_MAC_PORT Peripheral Access Layer
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup ENETC_PSEUDO_MAC_PORT_Peripheral_Access_Layer ENETC_PSEUDO_MAC_PORT Peripheral Access Layer
 * @{
 */

/** ENETC_PSEUDO_MAC_PORT - Size of Registers Arrays */
#define ENETC_PSEUDO_MAC_PORT_PPMROCR_COUNT       2u
#define ENETC_PSEUDO_MAC_PORT_PPMRUFCR_COUNT      2u
#define ENETC_PSEUDO_MAC_PORT_PPMRMFCR_COUNT      2u
#define ENETC_PSEUDO_MAC_PORT_PPMRBFCR_COUNT      2u
#define ENETC_PSEUDO_MAC_PORT_PPMTOCR_COUNT       2u
#define ENETC_PSEUDO_MAC_PORT_PPMTUFCR_COUNT      2u
#define ENETC_PSEUDO_MAC_PORT_PPMTMFCR_COUNT      2u
#define ENETC_PSEUDO_MAC_PORT_PPMTBFCR_COUNT      2u

/** ENETC_PSEUDO_MAC_PORT - Register Layout Typedef */
typedef struct ENETC_PSEUDO_MAC_PORT_Struct {
  __I  uint32_t PPMSR;                             /**< Port pseudo MAC status register, offset: 0x0 */
  uint8_t RESERVED_0[12];
  __IO uint32_t PPMCR;                             /**< Port pseudo MAC configuration register, offset: 0x10 */
  uint8_t RESERVED_1[108];
  __I  uint32_t PPMROCR[ENETC_PSEUDO_MAC_PORT_PPMROCR_COUNT]; /**< Port pseudo MAC receive octets counter, array offset: 0x80, array step: 0x4 */
  __I  uint32_t PPMRUFCR[ENETC_PSEUDO_MAC_PORT_PPMRUFCR_COUNT]; /**< Port pseudo MAC receive unicast frame counter register, array offset: 0x88, array step: 0x4 */
  __I  uint32_t PPMRMFCR[ENETC_PSEUDO_MAC_PORT_PPMRMFCR_COUNT]; /**< Port pseudo MAC receive multicast frame counter register, array offset: 0x90, array step: 0x4 */
  __I  uint32_t PPMRBFCR[ENETC_PSEUDO_MAC_PORT_PPMRBFCR_COUNT]; /**< Port pseudo MAC receive broadcast frame counter register, array offset: 0x98, array step: 0x4 */
  uint8_t RESERVED_2[32];
  __I  uint32_t PPMTOCR[ENETC_PSEUDO_MAC_PORT_PPMTOCR_COUNT]; /**< Port pseudo MAC transmit octets counter, array offset: 0xC0, array step: 0x4 */
  __I  uint32_t PPMTUFCR[ENETC_PSEUDO_MAC_PORT_PPMTUFCR_COUNT]; /**< Port pseudo MAC transmit unicast frame counter register, array offset: 0xC8, array step: 0x4 */
  __I  uint32_t PPMTMFCR[ENETC_PSEUDO_MAC_PORT_PPMTMFCR_COUNT]; /**< Port pseudo MAC transmit multicast frame counter register, array offset: 0xD0, array step: 0x4 */
  __I  uint32_t PPMTBFCR[ENETC_PSEUDO_MAC_PORT_PPMTBFCR_COUNT]; /**< Port pseudo MAC transmit broadcast frame counter register, array offset: 0xD8, array step: 0x4 */
  __IO uint32_t PPM_IEVENT;                        /**< Port pseudo MAC Interrupt Event register, offset: 0xE0 */
  __IO uint32_t PPM_IMASK;                         /**< Port pseudo MAC Interrupt Mask register, offset: 0xE4 */
  uint8_t RESERVED_3[8];
  __I  uint32_t PPMRERR;                           /**< Port pseudo MAC receive frame error counter register, offset: 0xF0 */
} ENETC_PSEUDO_MAC_PORT_Type, *ENETC_PSEUDO_MAC_PORT_MemMapPtr;

/** Number of instances of the ENETC_PSEUDO_MAC_PORT module. */
#define ENETC_PSEUDO_MAC_PORT_INSTANCE_COUNT     (2u)

/* ENETC_PSEUDO_MAC_PORT - Peripheral instance base addresses */
/** Peripheral NETC__ENETC0_PSEUDO_MAC_PORT base address */
#define IP_NETC__ENETC0_PSEUDO_MAC_PORT_BASE     (0x6D095000u)
/** Peripheral NETC__ENETC0_PSEUDO_MAC_PORT base pointer */
#define IP_NETC__ENETC0_PSEUDO_MAC_PORT          ((ENETC_PSEUDO_MAC_PORT_Type *)IP_NETC__ENETC0_PSEUDO_MAC_PORT_BASE)
/** Peripheral NETC__ENETC1_PSEUDO_MAC_PORT base address */
#define IP_NETC__ENETC1_PSEUDO_MAC_PORT_BASE     (0x6D0D5000u)
/** Peripheral NETC__ENETC1_PSEUDO_MAC_PORT base pointer */
#define IP_NETC__ENETC1_PSEUDO_MAC_PORT          ((ENETC_PSEUDO_MAC_PORT_Type *)IP_NETC__ENETC1_PSEUDO_MAC_PORT_BASE)
/** Array initializer of ENETC_PSEUDO_MAC_PORT peripheral base addresses */
#define IP_ENETC_PSEUDO_MAC_PORT_BASE_ADDRS      { IP_NETC__ENETC0_PSEUDO_MAC_PORT_BASE, IP_NETC__ENETC1_PSEUDO_MAC_PORT_BASE }
/** Array initializer of ENETC_PSEUDO_MAC_PORT peripheral base pointers */
#define IP_ENETC_PSEUDO_MAC_PORT_BASE_PTRS       { IP_NETC__ENETC0_PSEUDO_MAC_PORT, IP_NETC__ENETC1_PSEUDO_MAC_PORT }

/* ----------------------------------------------------------------------------
   -- ENETC_PSEUDO_MAC_PORT Register Masks
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup ENETC_PSEUDO_MAC_PORT_Register_Masks ENETC_PSEUDO_MAC_PORT Register Masks
 * @{
 */

/*! @name PPMSR - Port pseudo MAC status register */
/*! @{ */

#define ENETC_PSEUDO_MAC_PORT_PPMSR_LSTATE_MASK  (0x1U)
#define ENETC_PSEUDO_MAC_PORT_PPMSR_LSTATE_SHIFT (0U)
#define ENETC_PSEUDO_MAC_PORT_PPMSR_LSTATE_WIDTH (1U)
#define ENETC_PSEUDO_MAC_PORT_PPMSR_LSTATE(x)    (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPMSR_LSTATE_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPMSR_LSTATE_MASK)

#define ENETC_PSEUDO_MAC_PORT_PPMSR_RSTATE_MASK  (0x100U)
#define ENETC_PSEUDO_MAC_PORT_PPMSR_RSTATE_SHIFT (8U)
#define ENETC_PSEUDO_MAC_PORT_PPMSR_RSTATE_WIDTH (1U)
#define ENETC_PSEUDO_MAC_PORT_PPMSR_RSTATE(x)    (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPMSR_RSTATE_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPMSR_RSTATE_MASK)
/*! @} */

/*! @name PPMCR - Port pseudo MAC configuration register */
/*! @{ */

#define ENETC_PSEUDO_MAC_PORT_PPMCR_TXPAD_MASK   (0x10000U)
#define ENETC_PSEUDO_MAC_PORT_PPMCR_TXPAD_SHIFT  (16U)
#define ENETC_PSEUDO_MAC_PORT_PPMCR_TXPAD_WIDTH  (1U)
#define ENETC_PSEUDO_MAC_PORT_PPMCR_TXPAD(x)     (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPMCR_TXPAD_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPMCR_TXPAD_MASK)
/*! @} */

/*! @name PPMROCR - Port pseudo MAC receive octets counter */
/*! @{ */

#define ENETC_PSEUDO_MAC_PORT_PPMROCR_ROCT_MASK  (0xFFFFFFFFU)
#define ENETC_PSEUDO_MAC_PORT_PPMROCR_ROCT_SHIFT (0U)
#define ENETC_PSEUDO_MAC_PORT_PPMROCR_ROCT_WIDTH (32U)
#define ENETC_PSEUDO_MAC_PORT_PPMROCR_ROCT(x)    (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPMROCR_ROCT_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPMROCR_ROCT_MASK)
/*! @} */

/*! @name PPMRUFCR - Port pseudo MAC receive unicast frame counter register */
/*! @{ */

#define ENETC_PSEUDO_MAC_PORT_PPMRUFCR_RUCA_MASK (0xFFFFFFFFU)
#define ENETC_PSEUDO_MAC_PORT_PPMRUFCR_RUCA_SHIFT (0U)
#define ENETC_PSEUDO_MAC_PORT_PPMRUFCR_RUCA_WIDTH (32U)
#define ENETC_PSEUDO_MAC_PORT_PPMRUFCR_RUCA(x)   (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPMRUFCR_RUCA_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPMRUFCR_RUCA_MASK)
/*! @} */

/*! @name PPMRMFCR - Port pseudo MAC receive multicast frame counter register */
/*! @{ */

#define ENETC_PSEUDO_MAC_PORT_PPMRMFCR_RMCA_MASK (0xFFFFFFFFU)
#define ENETC_PSEUDO_MAC_PORT_PPMRMFCR_RMCA_SHIFT (0U)
#define ENETC_PSEUDO_MAC_PORT_PPMRMFCR_RMCA_WIDTH (32U)
#define ENETC_PSEUDO_MAC_PORT_PPMRMFCR_RMCA(x)   (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPMRMFCR_RMCA_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPMRMFCR_RMCA_MASK)
/*! @} */

/*! @name PPMRBFCR - Port pseudo MAC receive broadcast frame counter register */
/*! @{ */

#define ENETC_PSEUDO_MAC_PORT_PPMRBFCR_RBCA_MASK (0xFFFFFFFFU)
#define ENETC_PSEUDO_MAC_PORT_PPMRBFCR_RBCA_SHIFT (0U)
#define ENETC_PSEUDO_MAC_PORT_PPMRBFCR_RBCA_WIDTH (32U)
#define ENETC_PSEUDO_MAC_PORT_PPMRBFCR_RBCA(x)   (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPMRBFCR_RBCA_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPMRBFCR_RBCA_MASK)
/*! @} */

/*! @name PPMTOCR - Port pseudo MAC transmit octets counter */
/*! @{ */

#define ENETC_PSEUDO_MAC_PORT_PPMTOCR_TOCT_MASK  (0xFFFFFFFFU)
#define ENETC_PSEUDO_MAC_PORT_PPMTOCR_TOCT_SHIFT (0U)
#define ENETC_PSEUDO_MAC_PORT_PPMTOCR_TOCT_WIDTH (32U)
#define ENETC_PSEUDO_MAC_PORT_PPMTOCR_TOCT(x)    (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPMTOCR_TOCT_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPMTOCR_TOCT_MASK)
/*! @} */

/*! @name PPMTUFCR - Port pseudo MAC transmit unicast frame counter register */
/*! @{ */

#define ENETC_PSEUDO_MAC_PORT_PPMTUFCR_TUCA_MASK (0xFFFFFFFFU)
#define ENETC_PSEUDO_MAC_PORT_PPMTUFCR_TUCA_SHIFT (0U)
#define ENETC_PSEUDO_MAC_PORT_PPMTUFCR_TUCA_WIDTH (32U)
#define ENETC_PSEUDO_MAC_PORT_PPMTUFCR_TUCA(x)   (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPMTUFCR_TUCA_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPMTUFCR_TUCA_MASK)
/*! @} */

/*! @name PPMTMFCR - Port pseudo MAC transmit multicast frame counter register */
/*! @{ */

#define ENETC_PSEUDO_MAC_PORT_PPMTMFCR_TMCA_MASK (0xFFFFFFFFU)
#define ENETC_PSEUDO_MAC_PORT_PPMTMFCR_TMCA_SHIFT (0U)
#define ENETC_PSEUDO_MAC_PORT_PPMTMFCR_TMCA_WIDTH (32U)
#define ENETC_PSEUDO_MAC_PORT_PPMTMFCR_TMCA(x)   (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPMTMFCR_TMCA_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPMTMFCR_TMCA_MASK)
/*! @} */

/*! @name PPMTBFCR - Port pseudo MAC transmit broadcast frame counter register */
/*! @{ */

#define ENETC_PSEUDO_MAC_PORT_PPMTBFCR_TBCA_MASK (0xFFFFFFFFU)
#define ENETC_PSEUDO_MAC_PORT_PPMTBFCR_TBCA_SHIFT (0U)
#define ENETC_PSEUDO_MAC_PORT_PPMTBFCR_TBCA_WIDTH (32U)
#define ENETC_PSEUDO_MAC_PORT_PPMTBFCR_TBCA(x)   (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPMTBFCR_TBCA_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPMTBFCR_TBCA_MASK)
/*! @} */

/*! @name PPM_IEVENT - Port pseudo MAC Interrupt Event register */
/*! @{ */

#define ENETC_PSEUDO_MAC_PORT_PPM_IEVENT_LINK_UP_MASK (0x1000000U)
#define ENETC_PSEUDO_MAC_PORT_PPM_IEVENT_LINK_UP_SHIFT (24U)
#define ENETC_PSEUDO_MAC_PORT_PPM_IEVENT_LINK_UP_WIDTH (1U)
#define ENETC_PSEUDO_MAC_PORT_PPM_IEVENT_LINK_UP(x) (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPM_IEVENT_LINK_UP_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPM_IEVENT_LINK_UP_MASK)

#define ENETC_PSEUDO_MAC_PORT_PPM_IEVENT_LINK_DOWN_MASK (0x2000000U)
#define ENETC_PSEUDO_MAC_PORT_PPM_IEVENT_LINK_DOWN_SHIFT (25U)
#define ENETC_PSEUDO_MAC_PORT_PPM_IEVENT_LINK_DOWN_WIDTH (1U)
#define ENETC_PSEUDO_MAC_PORT_PPM_IEVENT_LINK_DOWN(x) (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPM_IEVENT_LINK_DOWN_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPM_IEVENT_LINK_DOWN_MASK)
/*! @} */

/*! @name PPM_IMASK - Port pseudo MAC Interrupt Mask register */
/*! @{ */

#define ENETC_PSEUDO_MAC_PORT_PPM_IMASK_LINK_UP_MASK (0x1000000U)
#define ENETC_PSEUDO_MAC_PORT_PPM_IMASK_LINK_UP_SHIFT (24U)
#define ENETC_PSEUDO_MAC_PORT_PPM_IMASK_LINK_UP_WIDTH (1U)
#define ENETC_PSEUDO_MAC_PORT_PPM_IMASK_LINK_UP(x) (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPM_IMASK_LINK_UP_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPM_IMASK_LINK_UP_MASK)

#define ENETC_PSEUDO_MAC_PORT_PPM_IMASK_LINK_DOWN_MASK (0x2000000U)
#define ENETC_PSEUDO_MAC_PORT_PPM_IMASK_LINK_DOWN_SHIFT (25U)
#define ENETC_PSEUDO_MAC_PORT_PPM_IMASK_LINK_DOWN_WIDTH (1U)
#define ENETC_PSEUDO_MAC_PORT_PPM_IMASK_LINK_DOWN(x) (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPM_IMASK_LINK_DOWN_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPM_IMASK_LINK_DOWN_MASK)
/*! @} */

/*! @name PPMRERR - Port pseudo MAC receive frame error counter register */
/*! @{ */

#define ENETC_PSEUDO_MAC_PORT_PPMRERR_RERR_MASK  (0xFFU)
#define ENETC_PSEUDO_MAC_PORT_PPMRERR_RERR_SHIFT (0U)
#define ENETC_PSEUDO_MAC_PORT_PPMRERR_RERR_WIDTH (8U)
#define ENETC_PSEUDO_MAC_PORT_PPMRERR_RERR(x)    (((uint32_t)(((uint32_t)(x)) << ENETC_PSEUDO_MAC_PORT_PPMRERR_RERR_SHIFT)) & ENETC_PSEUDO_MAC_PORT_PPMRERR_RERR_MASK)
/*! @} */

/*!
 * @}
 */ /* end of group ENETC_PSEUDO_MAC_PORT_Register_Masks */

/*!
 * @}
 */ /* end of group ENETC_PSEUDO_MAC_PORT_Peripheral_Access_Layer */

#endif  /* #if !defined(S32K566_ENETC_PSEUDO_MAC_PORT_H_) */
