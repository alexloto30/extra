/*
** ###################################################################
**     Processor:           S32K566_M7
**     Compiler:            Keil ARM C/C++ Compiler
**     Reference manual:    S32K5 RM Rev 3
**     Version:             rev. 2.7, 2026-09-09
**     Build:               b260908
**
**     Abstract:
**         Peripheral Access Layer for S32K566_M7
**
**     Copyright 1997-2016 Freescale Semiconductor, Inc.
**     Copyright 2016-2026 NXP
**
**     NXP Confidential and Proprietary. This software is owned or controlled
**     by NXP and may only be used strictly in accordance with the applicable
**     license terms. By expressly accepting such terms or by downloading,
**     installing, activating and/or otherwise using the software, you are
**     agreeing that you have read, and that you agree to comply with and are
**     bound by, such license terms. If you do not agree to be bound by the
**     applicable license terms, then you may not retain, install, activate
**     or otherwise use the software.
**
**     http:                 www.nxp.com
**     mail:                 support@nxp.com
**
** ###################################################################
*/

/*!
 * @file S32K566_SIUL2.h
 * @version 2.7
 * @date 2026-09-09
 * @brief Peripheral Access Layer for S32K566_SIUL2
 *
 * This file contains register definitions and macros for easy access to their
 * bit fields.
 *
 * This file assumes LITTLE endian system.
 */

/**
* @page misra_violations MISRA-C:2012 violations
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.3, local typedef not referenced
* The SoC header defines typedef for all modules.
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.5, local macro not referenced
* The SoC header defines macros for all modules and registers.
*
* @section [global]
* Violates MISRA 2012 Advisory Directive 4.9, Function-like macro
* These are generated macros used for accessing the bit-fields from registers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.1, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.2, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.4, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.5, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 21.1, defined macro '__I' is reserved to the compiler
* This type qualifier is needed to ensure correct I/O access and addressing.
*/

/* Prevention from multiple including the same memory map */
#if !defined(S32K566_SIUL2_H_)  /* Check if memory map has not been already included */
#define S32K566_SIUL2_H_

#include "S32K566_COMMON.h"

/* ----------------------------------------------------------------------------
   -- SIUL2 Peripheral Access Layer
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup SIUL2_Peripheral_Access_Layer SIUL2 Peripheral Access Layer
 * @{
 */

/** SIUL2 - Size of Registers Arrays */
#define SIUL2_IFMCR_COUNT                         16u
#define SIUL2_MSCR_COUNT                          438u
#define SIUL2_IMCR_COUNT                          263u
#define SIUL2_MPGPDO_COUNT                        28u

/** SIUL2 - Register Layout Typedef */
typedef struct SIUL2_Struct {
  uint8_t RESERVED_0[4];
  __I  uint32_t MIDR1;                             /**< SIUL2 MCU ID Register #1, offset: 0x4 */
  __I  uint32_t MIDR2;                             /**< SIUL2 MCU ID Register #2, offset: 0x8 */
  uint8_t RESERVED_1[4];
  __IO uint32_t DISR0;                             /**< DMA or Interrupt Status Flag 0, offset: 0x10 */
  uint8_t RESERVED_2[4];
  __IO uint32_t DIRER0;                            /**< DMA or Interrupt Request Enable 0, offset: 0x18 */
  uint8_t RESERVED_3[4];
  __IO uint32_t DIRSR0;                            /**< DMA or Interrupt Request Select 0, offset: 0x20 */
  uint8_t RESERVED_4[4];
  __IO uint32_t IREER0;                            /**< Interrupt Rising-Edge Event Enable 0, offset: 0x28 */
  uint8_t RESERVED_5[4];
  __IO uint32_t IFEER0;                            /**< Interrupt Falling-Edge Event Enable 0, offset: 0x30 */
  uint8_t RESERVED_6[4];
  __IO uint32_t IFER0;                             /**< Interrupt Filter Enable 0, offset: 0x38 */
  uint8_t RESERVED_7[4];
  __IO uint32_t IFMCR[SIUL2_IFMCR_COUNT];          /**< Interrupt Filter Maximum Counter, array offset: 0x40, array step: 0x4 */
  uint8_t RESERVED_8[64];
  __IO uint32_t IFCPR;                             /**< Interrupt Filter Clock Prescaler, offset: 0xC0 */
  uint8_t RESERVED_9[60];
  __IO uint32_t UDR1;                              /**< User Defined, offset: 0x100 */
  __IO uint32_t UDR0;                              /**< User Defined, offset: 0x104 */
  __IO uint32_t UDR3;                              /**< User Defined, offset: 0x108 */
  __IO uint32_t UDR2;                              /**< User Defined, offset: 0x10C */
  __IO uint32_t UDR5;                              /**< User Defined, offset: 0x110 */
  __IO uint32_t UDR4;                              /**< User Defined, offset: 0x114 */
  uint8_t RESERVED_10[232];
  __I  uint32_t MIDR3;                             /**< SIUL2 MCU ID Register #3, offset: 0x200 */
  __I  uint32_t MIDR4;                             /**< SIUL2 MCU ID Register #4, offset: 0x204 */
  uint8_t RESERVED_11[56];
  __IO uint32_t MSCR[SIUL2_MSCR_COUNT];            /**< Multiplexed Signal Configuration, array offset: 0x240, array step: 0x4, irregular array, not all indices are valid */
  uint8_t RESERVED_12[296];
  __IO uint32_t IMCR[SIUL2_IMCR_COUNT];            /**< Input Multiplexed Signal Configuration, array offset: 0xA40, array step: 0x4, irregular array, not all indices are valid */
  uint8_t RESERVED_13[1188];
  __IO uint8_t GPDO3;                              /**< GPIO Pad Data Output, offset: 0x1300, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO2;                              /**< GPIO Pad Data Output, offset: 0x1301, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO1;                              /**< GPIO Pad Data Output, offset: 0x1302, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO0;                              /**< GPIO Pad Data Output, offset: 0x1303, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO7;                              /**< GPIO Pad Data Output, offset: 0x1304, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO6;                              /**< GPIO Pad Data Output, offset: 0x1305, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO5;                              /**< GPIO Pad Data Output, offset: 0x1306, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO4;                              /**< GPIO Pad Data Output, offset: 0x1307, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO11;                             /**< GPIO Pad Data Output, offset: 0x1308, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO10;                             /**< GPIO Pad Data Output, offset: 0x1309, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO9;                              /**< GPIO Pad Data Output, offset: 0x130A, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO8;                              /**< GPIO Pad Data Output, offset: 0x130B, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO15;                             /**< GPIO Pad Data Output, offset: 0x130C, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO14;                             /**< GPIO Pad Data Output, offset: 0x130D, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO13;                             /**< GPIO Pad Data Output, offset: 0x130E, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO12;                             /**< GPIO Pad Data Output, offset: 0x130F, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO19;                             /**< GPIO Pad Data Output, offset: 0x1310, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO18;                             /**< GPIO Pad Data Output, offset: 0x1311, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO17;                             /**< GPIO Pad Data Output, offset: 0x1312, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO16;                             /**< GPIO Pad Data Output, offset: 0x1313, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO23;                             /**< GPIO Pad Data Output, offset: 0x1314, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO22;                             /**< GPIO Pad Data Output, offset: 0x1315, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO21;                             /**< GPIO Pad Data Output, offset: 0x1316, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO20;                             /**< GPIO Pad Data Output, offset: 0x1317, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO27;                             /**< GPIO Pad Data Output, offset: 0x1318, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO26;                             /**< GPIO Pad Data Output, offset: 0x1319, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO25;                             /**< GPIO Pad Data Output, offset: 0x131A, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO24;                             /**< GPIO Pad Data Output, offset: 0x131B, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO31;                             /**< GPIO Pad Data Output, offset: 0x131C, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO30;                             /**< GPIO Pad Data Output, offset: 0x131D, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO29;                             /**< GPIO Pad Data Output, offset: 0x131E, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO28;                             /**< GPIO Pad Data Output, offset: 0x131F, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO35;                             /**< GPIO Pad Data Output, offset: 0x1320, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO34;                             /**< GPIO Pad Data Output, offset: 0x1321, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO33;                             /**< GPIO Pad Data Output, offset: 0x1322, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO32;                             /**< GPIO Pad Data Output, offset: 0x1323, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO39;                             /**< GPIO Pad Data Output, offset: 0x1324, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO38;                             /**< GPIO Pad Data Output, offset: 0x1325, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO37;                             /**< GPIO Pad Data Output, offset: 0x1326, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO36;                             /**< GPIO Pad Data Output, offset: 0x1327, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO43;                             /**< GPIO Pad Data Output, offset: 0x1328, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO42;                             /**< GPIO Pad Data Output, offset: 0x1329, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO41;                             /**< GPIO Pad Data Output, offset: 0x132A, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO40;                             /**< GPIO Pad Data Output, offset: 0x132B, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO47;                             /**< GPIO Pad Data Output, offset: 0x132C, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO46;                             /**< GPIO Pad Data Output, offset: 0x132D, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO45;                             /**< GPIO Pad Data Output, offset: 0x132E, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO44;                             /**< GPIO Pad Data Output, offset: 0x132F, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO51;                             /**< GPIO Pad Data Output, offset: 0x1330, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_14[1];
  __IO uint8_t GPDO49;                             /**< GPIO Pad Data Output, offset: 0x1332, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO48;                             /**< GPIO Pad Data Output, offset: 0x1333, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO55;                             /**< GPIO Pad Data Output, offset: 0x1334, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO54;                             /**< GPIO Pad Data Output, offset: 0x1335, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO53;                             /**< GPIO Pad Data Output, offset: 0x1336, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO52;                             /**< GPIO Pad Data Output, offset: 0x1337, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO59;                             /**< GPIO Pad Data Output, offset: 0x1338, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO58;                             /**< GPIO Pad Data Output, offset: 0x1339, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO57;                             /**< GPIO Pad Data Output, offset: 0x133A, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO56;                             /**< GPIO Pad Data Output, offset: 0x133B, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO63;                             /**< GPIO Pad Data Output, offset: 0x133C, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO62;                             /**< GPIO Pad Data Output, offset: 0x133D, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO61;                             /**< GPIO Pad Data Output, offset: 0x133E, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO60;                             /**< GPIO Pad Data Output, offset: 0x133F, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO67;                             /**< GPIO Pad Data Output, offset: 0x1340, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO66;                             /**< GPIO Pad Data Output, offset: 0x1341, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO65;                             /**< GPIO Pad Data Output, offset: 0x1342, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO64;                             /**< GPIO Pad Data Output, offset: 0x1343, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO71;                             /**< GPIO Pad Data Output, offset: 0x1344, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO70;                             /**< GPIO Pad Data Output, offset: 0x1345, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO69;                             /**< GPIO Pad Data Output, offset: 0x1346, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO68;                             /**< GPIO Pad Data Output, offset: 0x1347, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO75;                             /**< GPIO Pad Data Output, offset: 0x1348, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO74;                             /**< GPIO Pad Data Output, offset: 0x1349, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO73;                             /**< GPIO Pad Data Output, offset: 0x134A, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO72;                             /**< GPIO Pad Data Output, offset: 0x134B, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_15[1];
  __IO uint8_t GPDO78;                             /**< GPIO Pad Data Output, offset: 0x134D, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO77;                             /**< GPIO Pad Data Output, offset: 0x134E, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO76;                             /**< GPIO Pad Data Output, offset: 0x134F, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO83;                             /**< GPIO Pad Data Output, offset: 0x1350, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO82;                             /**< GPIO Pad Data Output, offset: 0x1351, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO81;                             /**< GPIO Pad Data Output, offset: 0x1352, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO80;                             /**< GPIO Pad Data Output, offset: 0x1353, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO87;                             /**< GPIO Pad Data Output, offset: 0x1354, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO86;                             /**< GPIO Pad Data Output, offset: 0x1355, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO85;                             /**< GPIO Pad Data Output, offset: 0x1356, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO84;                             /**< GPIO Pad Data Output, offset: 0x1357, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO91;                             /**< GPIO Pad Data Output, offset: 0x1358, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO90;                             /**< GPIO Pad Data Output, offset: 0x1359, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO89;                             /**< GPIO Pad Data Output, offset: 0x135A, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO88;                             /**< GPIO Pad Data Output, offset: 0x135B, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO95;                             /**< GPIO Pad Data Output, offset: 0x135C, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO94;                             /**< GPIO Pad Data Output, offset: 0x135D, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO93;                             /**< GPIO Pad Data Output, offset: 0x135E, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO92;                             /**< GPIO Pad Data Output, offset: 0x135F, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO99;                             /**< GPIO Pad Data Output, offset: 0x1360, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO98;                             /**< GPIO Pad Data Output, offset: 0x1361, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO97;                             /**< GPIO Pad Data Output, offset: 0x1362, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO96;                             /**< GPIO Pad Data Output, offset: 0x1363, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO103;                            /**< GPIO Pad Data Output, offset: 0x1364, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO102;                            /**< GPIO Pad Data Output, offset: 0x1365, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO101;                            /**< GPIO Pad Data Output, offset: 0x1366, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO100;                            /**< GPIO Pad Data Output, offset: 0x1367, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO107;                            /**< GPIO Pad Data Output, offset: 0x1368, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO106;                            /**< GPIO Pad Data Output, offset: 0x1369, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO105;                            /**< GPIO Pad Data Output, offset: 0x136A, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO104;                            /**< GPIO Pad Data Output, offset: 0x136B, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO111;                            /**< GPIO Pad Data Output, offset: 0x136C, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO110;                            /**< GPIO Pad Data Output, offset: 0x136D, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO109;                            /**< GPIO Pad Data Output, offset: 0x136E, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO108;                            /**< GPIO Pad Data Output, offset: 0x136F, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO115;                            /**< GPIO Pad Data Output, offset: 0x1370, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO114;                            /**< GPIO Pad Data Output, offset: 0x1371, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO113;                            /**< GPIO Pad Data Output, offset: 0x1372, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO112;                            /**< GPIO Pad Data Output, offset: 0x1373, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_16[3];
  __IO uint8_t GPDO116;                            /**< GPIO Pad Data Output, offset: 0x1377, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_17[4];
  __IO uint8_t GPDO127;                            /**< GPIO Pad Data Output, offset: 0x137C, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO126;                            /**< GPIO Pad Data Output, offset: 0x137D, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_18[2];
  __IO uint8_t GPDO131;                            /**< GPIO Pad Data Output, offset: 0x1380, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO130;                            /**< GPIO Pad Data Output, offset: 0x1381, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO129;                            /**< GPIO Pad Data Output, offset: 0x1382, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO128;                            /**< GPIO Pad Data Output, offset: 0x1383, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO135;                            /**< GPIO Pad Data Output, offset: 0x1384, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO134;                            /**< GPIO Pad Data Output, offset: 0x1385, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO133;                            /**< GPIO Pad Data Output, offset: 0x1386, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO132;                            /**< GPIO Pad Data Output, offset: 0x1387, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_19[1];
  __IO uint8_t GPDO138;                            /**< GPIO Pad Data Output, offset: 0x1389, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO137;                            /**< GPIO Pad Data Output, offset: 0x138A, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO136;                            /**< GPIO Pad Data Output, offset: 0x138B, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_20[11];
  __IO uint8_t GPDO148;                            /**< GPIO Pad Data Output, offset: 0x1397, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_21[4];
  __IO uint8_t GPDO159;                            /**< GPIO Pad Data Output, offset: 0x139C, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO158;                            /**< GPIO Pad Data Output, offset: 0x139D, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO157;                            /**< GPIO Pad Data Output, offset: 0x139E, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO156;                            /**< GPIO Pad Data Output, offset: 0x139F, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO163;                            /**< GPIO Pad Data Output, offset: 0x13A0, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO162;                            /**< GPIO Pad Data Output, offset: 0x13A1, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO161;                            /**< GPIO Pad Data Output, offset: 0x13A2, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO160;                            /**< GPIO Pad Data Output, offset: 0x13A3, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO167;                            /**< GPIO Pad Data Output, offset: 0x13A4, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO166;                            /**< GPIO Pad Data Output, offset: 0x13A5, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO165;                            /**< GPIO Pad Data Output, offset: 0x13A6, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO164;                            /**< GPIO Pad Data Output, offset: 0x13A7, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO171;                            /**< GPIO Pad Data Output, offset: 0x13A8, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO170;                            /**< GPIO Pad Data Output, offset: 0x13A9, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO169;                            /**< GPIO Pad Data Output, offset: 0x13AA, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO168;                            /**< GPIO Pad Data Output, offset: 0x13AB, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO175;                            /**< GPIO Pad Data Output, offset: 0x13AC, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO174;                            /**< GPIO Pad Data Output, offset: 0x13AD, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO173;                            /**< GPIO Pad Data Output, offset: 0x13AE, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO172;                            /**< GPIO Pad Data Output, offset: 0x13AF, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO179;                            /**< GPIO Pad Data Output, offset: 0x13B0, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO178;                            /**< GPIO Pad Data Output, offset: 0x13B1, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO177;                            /**< GPIO Pad Data Output, offset: 0x13B2, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO176;                            /**< GPIO Pad Data Output, offset: 0x13B3, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO183;                            /**< GPIO Pad Data Output, offset: 0x13B4, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO182;                            /**< GPIO Pad Data Output, offset: 0x13B5, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO181;                            /**< GPIO Pad Data Output, offset: 0x13B6, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO180;                            /**< GPIO Pad Data Output, offset: 0x13B7, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO187;                            /**< GPIO Pad Data Output, offset: 0x13B8, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO186;                            /**< GPIO Pad Data Output, offset: 0x13B9, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO185;                            /**< GPIO Pad Data Output, offset: 0x13BA, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO184;                            /**< GPIO Pad Data Output, offset: 0x13BB, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO191;                            /**< GPIO Pad Data Output, offset: 0x13BC, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO190;                            /**< GPIO Pad Data Output, offset: 0x13BD, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO189;                            /**< GPIO Pad Data Output, offset: 0x13BE, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO188;                            /**< GPIO Pad Data Output, offset: 0x13BF, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO195;                            /**< GPIO Pad Data Output, offset: 0x13C0, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO194;                            /**< GPIO Pad Data Output, offset: 0x13C1, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO193;                            /**< GPIO Pad Data Output, offset: 0x13C2, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO192;                            /**< GPIO Pad Data Output, offset: 0x13C3, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO199;                            /**< GPIO Pad Data Output, offset: 0x13C4, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO198;                            /**< GPIO Pad Data Output, offset: 0x13C5, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO197;                            /**< GPIO Pad Data Output, offset: 0x13C6, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO196;                            /**< GPIO Pad Data Output, offset: 0x13C7, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO203;                            /**< GPIO Pad Data Output, offset: 0x13C8, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO202;                            /**< GPIO Pad Data Output, offset: 0x13C9, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO201;                            /**< GPIO Pad Data Output, offset: 0x13CA, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO200;                            /**< GPIO Pad Data Output, offset: 0x13CB, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO207;                            /**< GPIO Pad Data Output, offset: 0x13CC, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO206;                            /**< GPIO Pad Data Output, offset: 0x13CD, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO205;                            /**< GPIO Pad Data Output, offset: 0x13CE, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO204;                            /**< GPIO Pad Data Output, offset: 0x13CF, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO211;                            /**< GPIO Pad Data Output, offset: 0x13D0, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO210;                            /**< GPIO Pad Data Output, offset: 0x13D1, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO209;                            /**< GPIO Pad Data Output, offset: 0x13D2, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO208;                            /**< GPIO Pad Data Output, offset: 0x13D3, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO215;                            /**< GPIO Pad Data Output, offset: 0x13D4, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO214;                            /**< GPIO Pad Data Output, offset: 0x13D5, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO213;                            /**< GPIO Pad Data Output, offset: 0x13D6, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO212;                            /**< GPIO Pad Data Output, offset: 0x13D7, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO219;                            /**< GPIO Pad Data Output, offset: 0x13D8, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO218;                            /**< GPIO Pad Data Output, offset: 0x13D9, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO217;                            /**< GPIO Pad Data Output, offset: 0x13DA, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO216;                            /**< GPIO Pad Data Output, offset: 0x13DB, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO223;                            /**< GPIO Pad Data Output, offset: 0x13DC, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO222;                            /**< GPIO Pad Data Output, offset: 0x13DD, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO221;                            /**< GPIO Pad Data Output, offset: 0x13DE, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO220;                            /**< GPIO Pad Data Output, offset: 0x13DF, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO227;                            /**< GPIO Pad Data Output, offset: 0x13E0, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO226;                            /**< GPIO Pad Data Output, offset: 0x13E1, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO225;                            /**< GPIO Pad Data Output, offset: 0x13E2, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO224;                            /**< GPIO Pad Data Output, offset: 0x13E3, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO231;                            /**< GPIO Pad Data Output, offset: 0x13E4, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  uint8_t RESERVED_22[1];
  __IO uint8_t GPDO229;                            /**< GPIO Pad Data Output, offset: 0x13E6, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO228;                            /**< GPIO Pad Data Output, offset: 0x13E7, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO235;                            /**< GPIO Pad Data Output, offset: 0x13E8, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO234;                            /**< GPIO Pad Data Output, offset: 0x13E9, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO233;                            /**< GPIO Pad Data Output, offset: 0x13EA, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO232;                            /**< GPIO Pad Data Output, offset: 0x13EB, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO239;                            /**< GPIO Pad Data Output, offset: 0x13EC, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO238;                            /**< GPIO Pad Data Output, offset: 0x13ED, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO237;                            /**< GPIO Pad Data Output, offset: 0x13EE, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO236;                            /**< GPIO Pad Data Output, offset: 0x13EF, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO243;                            /**< GPIO Pad Data Output, offset: 0x13F0, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO242;                            /**< GPIO Pad Data Output, offset: 0x13F1, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO241;                            /**< GPIO Pad Data Output, offset: 0x13F2, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO240;                            /**< GPIO Pad Data Output, offset: 0x13F3, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO247;                            /**< GPIO Pad Data Output, offset: 0x13F4, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO246;                            /**< GPIO Pad Data Output, offset: 0x13F5, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO245;                            /**< GPIO Pad Data Output, offset: 0x13F6, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO244;                            /**< GPIO Pad Data Output, offset: 0x13F7, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO251;                            /**< GPIO Pad Data Output, offset: 0x13F8, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO250;                            /**< GPIO Pad Data Output, offset: 0x13F9, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO249;                            /**< GPIO Pad Data Output, offset: 0x13FA, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO248;                            /**< GPIO Pad Data Output, offset: 0x13FB, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO255;                            /**< GPIO Pad Data Output, offset: 0x13FC, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO254;                            /**< GPIO Pad Data Output, offset: 0x13FD, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO253;                            /**< GPIO Pad Data Output, offset: 0x13FE, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO252;                            /**< GPIO Pad Data Output, offset: 0x13FF, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO259;                            /**< GPIO Pad Data Output, offset: 0x1400, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO258;                            /**< GPIO Pad Data Output, offset: 0x1401, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO257;                            /**< GPIO Pad Data Output, offset: 0x1402, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO256;                            /**< GPIO Pad Data Output, offset: 0x1403, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO263;                            /**< GPIO Pad Data Output, offset: 0x1404, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO262;                            /**< GPIO Pad Data Output, offset: 0x1405, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO261;                            /**< GPIO Pad Data Output, offset: 0x1406, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint8_t GPDO260;                            /**< GPIO Pad Data Output, offset: 0x1407, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  uint8_t RESERVED_23[3];
  __IO uint8_t GPDO264;                            /**< GPIO Pad Data Output, offset: 0x140B, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  uint8_t RESERVED_24[36];
  __IO uint8_t GPDO307;                            /**< GPIO Pad Data Output, offset: 0x1430, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO306;                            /**< GPIO Pad Data Output, offset: 0x1431, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO305;                            /**< GPIO Pad Data Output, offset: 0x1432, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO304;                            /**< GPIO Pad Data Output, offset: 0x1433, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO311;                            /**< GPIO Pad Data Output, offset: 0x1434, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO310;                            /**< GPIO Pad Data Output, offset: 0x1435, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO309;                            /**< GPIO Pad Data Output, offset: 0x1436, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO308;                            /**< GPIO Pad Data Output, offset: 0x1437, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO315;                            /**< GPIO Pad Data Output, offset: 0x1438, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO314;                            /**< GPIO Pad Data Output, offset: 0x1439, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO313;                            /**< GPIO Pad Data Output, offset: 0x143A, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO312;                            /**< GPIO Pad Data Output, offset: 0x143B, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO319;                            /**< GPIO Pad Data Output, offset: 0x143C, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO318;                            /**< GPIO Pad Data Output, offset: 0x143D, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO317;                            /**< GPIO Pad Data Output, offset: 0x143E, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO316;                            /**< GPIO Pad Data Output, offset: 0x143F, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO323;                            /**< GPIO Pad Data Output, offset: 0x1440, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO322;                            /**< GPIO Pad Data Output, offset: 0x1441, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO321;                            /**< GPIO Pad Data Output, offset: 0x1442, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO320;                            /**< GPIO Pad Data Output, offset: 0x1443, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO327;                            /**< GPIO Pad Data Output, offset: 0x1444, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO326;                            /**< GPIO Pad Data Output, offset: 0x1445, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO325;                            /**< GPIO Pad Data Output, offset: 0x1446, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO324;                            /**< GPIO Pad Data Output, offset: 0x1447, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO331;                            /**< GPIO Pad Data Output, offset: 0x1448, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO330;                            /**< GPIO Pad Data Output, offset: 0x1449, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO329;                            /**< GPIO Pad Data Output, offset: 0x144A, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO328;                            /**< GPIO Pad Data Output, offset: 0x144B, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO335;                            /**< GPIO Pad Data Output, offset: 0x144C, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO334;                            /**< GPIO Pad Data Output, offset: 0x144D, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO333;                            /**< GPIO Pad Data Output, offset: 0x144E, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO332;                            /**< GPIO Pad Data Output, offset: 0x144F, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO339;                            /**< GPIO Pad Data Output, offset: 0x1450, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO338;                            /**< GPIO Pad Data Output, offset: 0x1451, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO337;                            /**< GPIO Pad Data Output, offset: 0x1452, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO336;                            /**< GPIO Pad Data Output, offset: 0x1453, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO343;                            /**< GPIO Pad Data Output, offset: 0x1454, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO342;                            /**< GPIO Pad Data Output, offset: 0x1455, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO341;                            /**< GPIO Pad Data Output, offset: 0x1456, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO340;                            /**< GPIO Pad Data Output, offset: 0x1457, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO347;                            /**< GPIO Pad Data Output, offset: 0x1458, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO346;                            /**< GPIO Pad Data Output, offset: 0x1459, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO345;                            /**< GPIO Pad Data Output, offset: 0x145A, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO344;                            /**< GPIO Pad Data Output, offset: 0x145B, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO351;                            /**< GPIO Pad Data Output, offset: 0x145C, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO350;                            /**< GPIO Pad Data Output, offset: 0x145D, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO349;                            /**< GPIO Pad Data Output, offset: 0x145E, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO348;                            /**< GPIO Pad Data Output, offset: 0x145F, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO355;                            /**< GPIO Pad Data Output, offset: 0x1460, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO354;                            /**< GPIO Pad Data Output, offset: 0x1461, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO353;                            /**< GPIO Pad Data Output, offset: 0x1462, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO352;                            /**< GPIO Pad Data Output, offset: 0x1463, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO359;                            /**< GPIO Pad Data Output, offset: 0x1464, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO358;                            /**< GPIO Pad Data Output, offset: 0x1465, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO357;                            /**< GPIO Pad Data Output, offset: 0x1466, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO356;                            /**< GPIO Pad Data Output, offset: 0x1467, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO363;                            /**< GPIO Pad Data Output, offset: 0x1468, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO362;                            /**< GPIO Pad Data Output, offset: 0x1469, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO361;                            /**< GPIO Pad Data Output, offset: 0x146A, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO360;                            /**< GPIO Pad Data Output, offset: 0x146B, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO367;                            /**< GPIO Pad Data Output, offset: 0x146C, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO366;                            /**< GPIO Pad Data Output, offset: 0x146D, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO365;                            /**< GPIO Pad Data Output, offset: 0x146E, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO364;                            /**< GPIO Pad Data Output, offset: 0x146F, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO371;                            /**< GPIO Pad Data Output, offset: 0x1470, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO370;                            /**< GPIO Pad Data Output, offset: 0x1471, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO369;                            /**< GPIO Pad Data Output, offset: 0x1472, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint8_t GPDO368;                            /**< GPIO Pad Data Output, offset: 0x1473, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  uint8_t RESERVED_25[60];
  __IO uint8_t GPDO435;                            /**< GPIO Pad Data Output, offset: 0x14B0, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO434;                            /**< GPIO Pad Data Output, offset: 0x14B1, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO433;                            /**< GPIO Pad Data Output, offset: 0x14B2, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO432;                            /**< GPIO Pad Data Output, offset: 0x14B3, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_26[2];
  __IO uint8_t GPDO437;                            /**< GPIO Pad Data Output, offset: 0x14B6, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint8_t GPDO436;                            /**< GPIO Pad Data Output, offset: 0x14B7, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_27[72];
  __I  uint8_t GPDI3;                              /**< GPIO Pad Data Input, offset: 0x1500, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI2;                              /**< GPIO Pad Data Input, offset: 0x1501, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI1;                              /**< GPIO Pad Data Input, offset: 0x1502, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI0;                              /**< GPIO Pad Data Input, offset: 0x1503, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI7;                              /**< GPIO Pad Data Input, offset: 0x1504, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI6;                              /**< GPIO Pad Data Input, offset: 0x1505, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI5;                              /**< GPIO Pad Data Input, offset: 0x1506, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI4;                              /**< GPIO Pad Data Input, offset: 0x1507, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI11;                             /**< GPIO Pad Data Input, offset: 0x1508, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI10;                             /**< GPIO Pad Data Input, offset: 0x1509, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI9;                              /**< GPIO Pad Data Input, offset: 0x150A, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI8;                              /**< GPIO Pad Data Input, offset: 0x150B, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI15;                             /**< GPIO Pad Data Input, offset: 0x150C, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI14;                             /**< GPIO Pad Data Input, offset: 0x150D, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI13;                             /**< GPIO Pad Data Input, offset: 0x150E, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI12;                             /**< GPIO Pad Data Input, offset: 0x150F, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI19;                             /**< GPIO Pad Data Input, offset: 0x1510, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI18;                             /**< GPIO Pad Data Input, offset: 0x1511, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI17;                             /**< GPIO Pad Data Input, offset: 0x1512, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI16;                             /**< GPIO Pad Data Input, offset: 0x1513, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI23;                             /**< GPIO Pad Data Input, offset: 0x1514, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI22;                             /**< GPIO Pad Data Input, offset: 0x1515, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI21;                             /**< GPIO Pad Data Input, offset: 0x1516, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI20;                             /**< GPIO Pad Data Input, offset: 0x1517, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI27;                             /**< GPIO Pad Data Input, offset: 0x1518, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI26;                             /**< GPIO Pad Data Input, offset: 0x1519, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI25;                             /**< GPIO Pad Data Input, offset: 0x151A, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI24;                             /**< GPIO Pad Data Input, offset: 0x151B, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI31;                             /**< GPIO Pad Data Input, offset: 0x151C, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI30;                             /**< GPIO Pad Data Input, offset: 0x151D, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI29;                             /**< GPIO Pad Data Input, offset: 0x151E, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI28;                             /**< GPIO Pad Data Input, offset: 0x151F, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI35;                             /**< GPIO Pad Data Input, offset: 0x1520, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI34;                             /**< GPIO Pad Data Input, offset: 0x1521, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI33;                             /**< GPIO Pad Data Input, offset: 0x1522, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI32;                             /**< GPIO Pad Data Input, offset: 0x1523, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI39;                             /**< GPIO Pad Data Input, offset: 0x1524, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI38;                             /**< GPIO Pad Data Input, offset: 0x1525, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI37;                             /**< GPIO Pad Data Input, offset: 0x1526, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI36;                             /**< GPIO Pad Data Input, offset: 0x1527, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI43;                             /**< GPIO Pad Data Input, offset: 0x1528, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI42;                             /**< GPIO Pad Data Input, offset: 0x1529, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI41;                             /**< GPIO Pad Data Input, offset: 0x152A, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI40;                             /**< GPIO Pad Data Input, offset: 0x152B, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI47;                             /**< GPIO Pad Data Input, offset: 0x152C, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI46;                             /**< GPIO Pad Data Input, offset: 0x152D, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI45;                             /**< GPIO Pad Data Input, offset: 0x152E, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI44;                             /**< GPIO Pad Data Input, offset: 0x152F, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI51;                             /**< GPIO Pad Data Input, offset: 0x1530, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_28[1];
  __I  uint8_t GPDI49;                             /**< GPIO Pad Data Input, offset: 0x1532, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI48;                             /**< GPIO Pad Data Input, offset: 0x1533, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI55;                             /**< GPIO Pad Data Input, offset: 0x1534, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI54;                             /**< GPIO Pad Data Input, offset: 0x1535, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI53;                             /**< GPIO Pad Data Input, offset: 0x1536, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI52;                             /**< GPIO Pad Data Input, offset: 0x1537, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI59;                             /**< GPIO Pad Data Input, offset: 0x1538, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI58;                             /**< GPIO Pad Data Input, offset: 0x1539, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI57;                             /**< GPIO Pad Data Input, offset: 0x153A, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI56;                             /**< GPIO Pad Data Input, offset: 0x153B, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI63;                             /**< GPIO Pad Data Input, offset: 0x153C, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI62;                             /**< GPIO Pad Data Input, offset: 0x153D, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI61;                             /**< GPIO Pad Data Input, offset: 0x153E, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI60;                             /**< GPIO Pad Data Input, offset: 0x153F, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI67;                             /**< GPIO Pad Data Input, offset: 0x1540, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI66;                             /**< GPIO Pad Data Input, offset: 0x1541, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI65;                             /**< GPIO Pad Data Input, offset: 0x1542, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI64;                             /**< GPIO Pad Data Input, offset: 0x1543, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI71;                             /**< GPIO Pad Data Input, offset: 0x1544, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI70;                             /**< GPIO Pad Data Input, offset: 0x1545, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI69;                             /**< GPIO Pad Data Input, offset: 0x1546, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI68;                             /**< GPIO Pad Data Input, offset: 0x1547, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI75;                             /**< GPIO Pad Data Input, offset: 0x1548, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI74;                             /**< GPIO Pad Data Input, offset: 0x1549, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI73;                             /**< GPIO Pad Data Input, offset: 0x154A, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI72;                             /**< GPIO Pad Data Input, offset: 0x154B, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_29[1];
  __I  uint8_t GPDI78;                             /**< GPIO Pad Data Input, offset: 0x154D, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI77;                             /**< GPIO Pad Data Input, offset: 0x154E, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI76;                             /**< GPIO Pad Data Input, offset: 0x154F, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI83;                             /**< GPIO Pad Data Input, offset: 0x1550, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI82;                             /**< GPIO Pad Data Input, offset: 0x1551, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI81;                             /**< GPIO Pad Data Input, offset: 0x1552, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI80;                             /**< GPIO Pad Data Input, offset: 0x1553, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI87;                             /**< GPIO Pad Data Input, offset: 0x1554, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI86;                             /**< GPIO Pad Data Input, offset: 0x1555, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI85;                             /**< GPIO Pad Data Input, offset: 0x1556, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI84;                             /**< GPIO Pad Data Input, offset: 0x1557, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI91;                             /**< GPIO Pad Data Input, offset: 0x1558, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI90;                             /**< GPIO Pad Data Input, offset: 0x1559, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI89;                             /**< GPIO Pad Data Input, offset: 0x155A, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI88;                             /**< GPIO Pad Data Input, offset: 0x155B, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI95;                             /**< GPIO Pad Data Input, offset: 0x155C, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI94;                             /**< GPIO Pad Data Input, offset: 0x155D, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI93;                             /**< GPIO Pad Data Input, offset: 0x155E, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI92;                             /**< GPIO Pad Data Input, offset: 0x155F, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI99;                             /**< GPIO Pad Data Input, offset: 0x1560, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI98;                             /**< GPIO Pad Data Input, offset: 0x1561, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI97;                             /**< GPIO Pad Data Input, offset: 0x1562, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI96;                             /**< GPIO Pad Data Input, offset: 0x1563, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI103;                            /**< GPIO Pad Data Input, offset: 0x1564, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI102;                            /**< GPIO Pad Data Input, offset: 0x1565, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI101;                            /**< GPIO Pad Data Input, offset: 0x1566, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI100;                            /**< GPIO Pad Data Input, offset: 0x1567, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI107;                            /**< GPIO Pad Data Input, offset: 0x1568, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI106;                            /**< GPIO Pad Data Input, offset: 0x1569, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI105;                            /**< GPIO Pad Data Input, offset: 0x156A, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI104;                            /**< GPIO Pad Data Input, offset: 0x156B, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI111;                            /**< GPIO Pad Data Input, offset: 0x156C, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI110;                            /**< GPIO Pad Data Input, offset: 0x156D, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI109;                            /**< GPIO Pad Data Input, offset: 0x156E, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI108;                            /**< GPIO Pad Data Input, offset: 0x156F, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI115;                            /**< GPIO Pad Data Input, offset: 0x1570, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI114;                            /**< GPIO Pad Data Input, offset: 0x1571, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI113;                            /**< GPIO Pad Data Input, offset: 0x1572, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI112;                            /**< GPIO Pad Data Input, offset: 0x1573, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_30[3];
  __I  uint8_t GPDI116;                            /**< GPIO Pad Data Input, offset: 0x1577, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_31[4];
  __I  uint8_t GPDI127;                            /**< GPIO Pad Data Input, offset: 0x157C, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI126;                            /**< GPIO Pad Data Input, offset: 0x157D, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_32[2];
  __I  uint8_t GPDI131;                            /**< GPIO Pad Data Input, offset: 0x1580, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI130;                            /**< GPIO Pad Data Input, offset: 0x1581, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI129;                            /**< GPIO Pad Data Input, offset: 0x1582, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI128;                            /**< GPIO Pad Data Input, offset: 0x1583, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI135;                            /**< GPIO Pad Data Input, offset: 0x1584, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI134;                            /**< GPIO Pad Data Input, offset: 0x1585, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI133;                            /**< GPIO Pad Data Input, offset: 0x1586, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI132;                            /**< GPIO Pad Data Input, offset: 0x1587, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_33[1];
  __I  uint8_t GPDI138;                            /**< GPIO Pad Data Input, offset: 0x1589, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI137;                            /**< GPIO Pad Data Input, offset: 0x158A, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI136;                            /**< GPIO Pad Data Input, offset: 0x158B, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_34[11];
  __I  uint8_t GPDI148;                            /**< GPIO Pad Data Input, offset: 0x1597, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_35[4];
  __I  uint8_t GPDI159;                            /**< GPIO Pad Data Input, offset: 0x159C, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI158;                            /**< GPIO Pad Data Input, offset: 0x159D, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI157;                            /**< GPIO Pad Data Input, offset: 0x159E, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI156;                            /**< GPIO Pad Data Input, offset: 0x159F, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI163;                            /**< GPIO Pad Data Input, offset: 0x15A0, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI162;                            /**< GPIO Pad Data Input, offset: 0x15A1, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI161;                            /**< GPIO Pad Data Input, offset: 0x15A2, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI160;                            /**< GPIO Pad Data Input, offset: 0x15A3, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI167;                            /**< GPIO Pad Data Input, offset: 0x15A4, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI166;                            /**< GPIO Pad Data Input, offset: 0x15A5, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI165;                            /**< GPIO Pad Data Input, offset: 0x15A6, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI164;                            /**< GPIO Pad Data Input, offset: 0x15A7, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI171;                            /**< GPIO Pad Data Input, offset: 0x15A8, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI170;                            /**< GPIO Pad Data Input, offset: 0x15A9, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI169;                            /**< GPIO Pad Data Input, offset: 0x15AA, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI168;                            /**< GPIO Pad Data Input, offset: 0x15AB, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI175;                            /**< GPIO Pad Data Input, offset: 0x15AC, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI174;                            /**< GPIO Pad Data Input, offset: 0x15AD, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI173;                            /**< GPIO Pad Data Input, offset: 0x15AE, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI172;                            /**< GPIO Pad Data Input, offset: 0x15AF, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI179;                            /**< GPIO Pad Data Input, offset: 0x15B0, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI178;                            /**< GPIO Pad Data Input, offset: 0x15B1, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI177;                            /**< GPIO Pad Data Input, offset: 0x15B2, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI176;                            /**< GPIO Pad Data Input, offset: 0x15B3, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI183;                            /**< GPIO Pad Data Input, offset: 0x15B4, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI182;                            /**< GPIO Pad Data Input, offset: 0x15B5, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI181;                            /**< GPIO Pad Data Input, offset: 0x15B6, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI180;                            /**< GPIO Pad Data Input, offset: 0x15B7, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI187;                            /**< GPIO Pad Data Input, offset: 0x15B8, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI186;                            /**< GPIO Pad Data Input, offset: 0x15B9, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI185;                            /**< GPIO Pad Data Input, offset: 0x15BA, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI184;                            /**< GPIO Pad Data Input, offset: 0x15BB, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI191;                            /**< GPIO Pad Data Input, offset: 0x15BC, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI190;                            /**< GPIO Pad Data Input, offset: 0x15BD, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI189;                            /**< GPIO Pad Data Input, offset: 0x15BE, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI188;                            /**< GPIO Pad Data Input, offset: 0x15BF, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI195;                            /**< GPIO Pad Data Input, offset: 0x15C0, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI194;                            /**< GPIO Pad Data Input, offset: 0x15C1, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI193;                            /**< GPIO Pad Data Input, offset: 0x15C2, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI192;                            /**< GPIO Pad Data Input, offset: 0x15C3, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI199;                            /**< GPIO Pad Data Input, offset: 0x15C4, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI198;                            /**< GPIO Pad Data Input, offset: 0x15C5, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI197;                            /**< GPIO Pad Data Input, offset: 0x15C6, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI196;                            /**< GPIO Pad Data Input, offset: 0x15C7, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI203;                            /**< GPIO Pad Data Input, offset: 0x15C8, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI202;                            /**< GPIO Pad Data Input, offset: 0x15C9, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI201;                            /**< GPIO Pad Data Input, offset: 0x15CA, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI200;                            /**< GPIO Pad Data Input, offset: 0x15CB, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI207;                            /**< GPIO Pad Data Input, offset: 0x15CC, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI206;                            /**< GPIO Pad Data Input, offset: 0x15CD, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI205;                            /**< GPIO Pad Data Input, offset: 0x15CE, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI204;                            /**< GPIO Pad Data Input, offset: 0x15CF, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI211;                            /**< GPIO Pad Data Input, offset: 0x15D0, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI210;                            /**< GPIO Pad Data Input, offset: 0x15D1, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI209;                            /**< GPIO Pad Data Input, offset: 0x15D2, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI208;                            /**< GPIO Pad Data Input, offset: 0x15D3, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI215;                            /**< GPIO Pad Data Input, offset: 0x15D4, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI214;                            /**< GPIO Pad Data Input, offset: 0x15D5, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI213;                            /**< GPIO Pad Data Input, offset: 0x15D6, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI212;                            /**< GPIO Pad Data Input, offset: 0x15D7, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI219;                            /**< GPIO Pad Data Input, offset: 0x15D8, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI218;                            /**< GPIO Pad Data Input, offset: 0x15D9, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI217;                            /**< GPIO Pad Data Input, offset: 0x15DA, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI216;                            /**< GPIO Pad Data Input, offset: 0x15DB, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI223;                            /**< GPIO Pad Data Input, offset: 0x15DC, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI222;                            /**< GPIO Pad Data Input, offset: 0x15DD, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI221;                            /**< GPIO Pad Data Input, offset: 0x15DE, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI220;                            /**< GPIO Pad Data Input, offset: 0x15DF, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI227;                            /**< GPIO Pad Data Input, offset: 0x15E0, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI226;                            /**< GPIO Pad Data Input, offset: 0x15E1, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI225;                            /**< GPIO Pad Data Input, offset: 0x15E2, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI224;                            /**< GPIO Pad Data Input, offset: 0x15E3, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI231;                            /**< GPIO Pad Data Input, offset: 0x15E4, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  uint8_t RESERVED_36[1];
  __I  uint8_t GPDI229;                            /**< GPIO Pad Data Input, offset: 0x15E6, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI228;                            /**< GPIO Pad Data Input, offset: 0x15E7, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI235;                            /**< GPIO Pad Data Input, offset: 0x15E8, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI234;                            /**< GPIO Pad Data Input, offset: 0x15E9, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI233;                            /**< GPIO Pad Data Input, offset: 0x15EA, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI232;                            /**< GPIO Pad Data Input, offset: 0x15EB, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI239;                            /**< GPIO Pad Data Input, offset: 0x15EC, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI238;                            /**< GPIO Pad Data Input, offset: 0x15ED, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI237;                            /**< GPIO Pad Data Input, offset: 0x15EE, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI236;                            /**< GPIO Pad Data Input, offset: 0x15EF, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI243;                            /**< GPIO Pad Data Input, offset: 0x15F0, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI242;                            /**< GPIO Pad Data Input, offset: 0x15F1, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI241;                            /**< GPIO Pad Data Input, offset: 0x15F2, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI240;                            /**< GPIO Pad Data Input, offset: 0x15F3, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI247;                            /**< GPIO Pad Data Input, offset: 0x15F4, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI246;                            /**< GPIO Pad Data Input, offset: 0x15F5, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI245;                            /**< GPIO Pad Data Input, offset: 0x15F6, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI244;                            /**< GPIO Pad Data Input, offset: 0x15F7, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI251;                            /**< GPIO Pad Data Input, offset: 0x15F8, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI250;                            /**< GPIO Pad Data Input, offset: 0x15F9, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI249;                            /**< GPIO Pad Data Input, offset: 0x15FA, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI248;                            /**< GPIO Pad Data Input, offset: 0x15FB, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI255;                            /**< GPIO Pad Data Input, offset: 0x15FC, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI254;                            /**< GPIO Pad Data Input, offset: 0x15FD, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI253;                            /**< GPIO Pad Data Input, offset: 0x15FE, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI252;                            /**< GPIO Pad Data Input, offset: 0x15FF, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI259;                            /**< GPIO Pad Data Input, offset: 0x1600, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI258;                            /**< GPIO Pad Data Input, offset: 0x1601, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI257;                            /**< GPIO Pad Data Input, offset: 0x1602, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI256;                            /**< GPIO Pad Data Input, offset: 0x1603, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI263;                            /**< GPIO Pad Data Input, offset: 0x1604, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI262;                            /**< GPIO Pad Data Input, offset: 0x1605, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI261;                            /**< GPIO Pad Data Input, offset: 0x1606, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint8_t GPDI260;                            /**< GPIO Pad Data Input, offset: 0x1607, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  uint8_t RESERVED_37[3];
  __I  uint8_t GPDI264;                            /**< GPIO Pad Data Input, offset: 0x160B, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  uint8_t RESERVED_38[36];
  __I  uint8_t GPDI307;                            /**< GPIO Pad Data Input, offset: 0x1630, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI306;                            /**< GPIO Pad Data Input, offset: 0x1631, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI305;                            /**< GPIO Pad Data Input, offset: 0x1632, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI304;                            /**< GPIO Pad Data Input, offset: 0x1633, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI311;                            /**< GPIO Pad Data Input, offset: 0x1634, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI310;                            /**< GPIO Pad Data Input, offset: 0x1635, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI309;                            /**< GPIO Pad Data Input, offset: 0x1636, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI308;                            /**< GPIO Pad Data Input, offset: 0x1637, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI315;                            /**< GPIO Pad Data Input, offset: 0x1638, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI314;                            /**< GPIO Pad Data Input, offset: 0x1639, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI313;                            /**< GPIO Pad Data Input, offset: 0x163A, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI312;                            /**< GPIO Pad Data Input, offset: 0x163B, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI319;                            /**< GPIO Pad Data Input, offset: 0x163C, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI318;                            /**< GPIO Pad Data Input, offset: 0x163D, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI317;                            /**< GPIO Pad Data Input, offset: 0x163E, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI316;                            /**< GPIO Pad Data Input, offset: 0x163F, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI323;                            /**< GPIO Pad Data Input, offset: 0x1640, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI322;                            /**< GPIO Pad Data Input, offset: 0x1641, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI321;                            /**< GPIO Pad Data Input, offset: 0x1642, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI320;                            /**< GPIO Pad Data Input, offset: 0x1643, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI327;                            /**< GPIO Pad Data Input, offset: 0x1644, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI326;                            /**< GPIO Pad Data Input, offset: 0x1645, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI325;                            /**< GPIO Pad Data Input, offset: 0x1646, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI324;                            /**< GPIO Pad Data Input, offset: 0x1647, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI331;                            /**< GPIO Pad Data Input, offset: 0x1648, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI330;                            /**< GPIO Pad Data Input, offset: 0x1649, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI329;                            /**< GPIO Pad Data Input, offset: 0x164A, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI328;                            /**< GPIO Pad Data Input, offset: 0x164B, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI335;                            /**< GPIO Pad Data Input, offset: 0x164C, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI334;                            /**< GPIO Pad Data Input, offset: 0x164D, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI333;                            /**< GPIO Pad Data Input, offset: 0x164E, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI332;                            /**< GPIO Pad Data Input, offset: 0x164F, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI339;                            /**< GPIO Pad Data Input, offset: 0x1650, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI338;                            /**< GPIO Pad Data Input, offset: 0x1651, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI337;                            /**< GPIO Pad Data Input, offset: 0x1652, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI336;                            /**< GPIO Pad Data Input, offset: 0x1653, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI343;                            /**< GPIO Pad Data Input, offset: 0x1654, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI342;                            /**< GPIO Pad Data Input, offset: 0x1655, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI341;                            /**< GPIO Pad Data Input, offset: 0x1656, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI340;                            /**< GPIO Pad Data Input, offset: 0x1657, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI347;                            /**< GPIO Pad Data Input, offset: 0x1658, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI346;                            /**< GPIO Pad Data Input, offset: 0x1659, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI345;                            /**< GPIO Pad Data Input, offset: 0x165A, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI344;                            /**< GPIO Pad Data Input, offset: 0x165B, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI351;                            /**< GPIO Pad Data Input, offset: 0x165C, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI350;                            /**< GPIO Pad Data Input, offset: 0x165D, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI349;                            /**< GPIO Pad Data Input, offset: 0x165E, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI348;                            /**< GPIO Pad Data Input, offset: 0x165F, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI355;                            /**< GPIO Pad Data Input, offset: 0x1660, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI354;                            /**< GPIO Pad Data Input, offset: 0x1661, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI353;                            /**< GPIO Pad Data Input, offset: 0x1662, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI352;                            /**< GPIO Pad Data Input, offset: 0x1663, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI359;                            /**< GPIO Pad Data Input, offset: 0x1664, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI358;                            /**< GPIO Pad Data Input, offset: 0x1665, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI357;                            /**< GPIO Pad Data Input, offset: 0x1666, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI356;                            /**< GPIO Pad Data Input, offset: 0x1667, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI363;                            /**< GPIO Pad Data Input, offset: 0x1668, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI362;                            /**< GPIO Pad Data Input, offset: 0x1669, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI361;                            /**< GPIO Pad Data Input, offset: 0x166A, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI360;                            /**< GPIO Pad Data Input, offset: 0x166B, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI367;                            /**< GPIO Pad Data Input, offset: 0x166C, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI366;                            /**< GPIO Pad Data Input, offset: 0x166D, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI365;                            /**< GPIO Pad Data Input, offset: 0x166E, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI364;                            /**< GPIO Pad Data Input, offset: 0x166F, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI371;                            /**< GPIO Pad Data Input, offset: 0x1670, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI370;                            /**< GPIO Pad Data Input, offset: 0x1671, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI369;                            /**< GPIO Pad Data Input, offset: 0x1672, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint8_t GPDI368;                            /**< GPIO Pad Data Input, offset: 0x1673, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  uint8_t RESERVED_39[60];
  __I  uint8_t GPDI435;                            /**< GPIO Pad Data Input, offset: 0x16B0, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI434;                            /**< GPIO Pad Data Input, offset: 0x16B1, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI433;                            /**< GPIO Pad Data Input, offset: 0x16B2, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI432;                            /**< GPIO Pad Data Input, offset: 0x16B3, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_40[2];
  __I  uint8_t GPDI437;                            /**< GPIO Pad Data Input, offset: 0x16B6, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint8_t GPDI436;                            /**< GPIO Pad Data Input, offset: 0x16B7, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_41[72];
  __IO uint16_t PGPDO1;                            /**< Parallel GPIO Pad Data Output, offset: 0x1700, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint16_t PGPDO0;                            /**< Parallel GPIO Pad Data Output, offset: 0x1702, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint16_t PGPDO3;                            /**< Parallel GPIO Pad Data Output, offset: 0x1704, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint16_t PGPDO2;                            /**< Parallel GPIO Pad Data Output, offset: 0x1706, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint16_t PGPDO5;                            /**< Parallel GPIO Pad Data Output, offset: 0x1708, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint16_t PGPDO4;                            /**< Parallel GPIO Pad Data Output, offset: 0x170A, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint16_t PGPDO7;                            /**< Parallel GPIO Pad Data Output, offset: 0x170C, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint16_t PGPDO6;                            /**< Parallel GPIO Pad Data Output, offset: 0x170E, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint16_t PGPDO9;                            /**< Parallel GPIO Pad Data Output, offset: 0x1710, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint16_t PGPDO8;                            /**< Parallel GPIO Pad Data Output, offset: 0x1712, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __IO uint16_t PGPDO11;                           /**< Parallel GPIO Pad Data Output, offset: 0x1714, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint16_t PGPDO10;                           /**< Parallel GPIO Pad Data Output, offset: 0x1716, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint16_t PGPDO13;                           /**< Parallel GPIO Pad Data Output, offset: 0x1718, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint16_t PGPDO12;                           /**< Parallel GPIO Pad Data Output, offset: 0x171A, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __IO uint16_t PGPDO15;                           /**< Parallel GPIO Pad Data Output, offset: 0x171C, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint16_t PGPDO14;                           /**< Parallel GPIO Pad Data Output, offset: 0x171E, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  uint8_t RESERVED_42[2];
  __IO uint16_t PGPDO16;                           /**< Parallel GPIO Pad Data Output, offset: 0x1722, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __IO uint16_t PGPDO19;                           /**< Parallel GPIO Pad Data Output, offset: 0x1724, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  uint8_t RESERVED_43[2];
  __IO uint16_t PGPDO21;                           /**< Parallel GPIO Pad Data Output, offset: 0x1728, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint16_t PGPDO20;                           /**< Parallel GPIO Pad Data Output, offset: 0x172A, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint16_t PGPDO23;                           /**< Parallel GPIO Pad Data Output, offset: 0x172C, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __IO uint16_t PGPDO22;                           /**< Parallel GPIO Pad Data Output, offset: 0x172E, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  uint8_t RESERVED_44[4];
  __IO uint16_t PGPDO27;                           /**< Parallel GPIO Pad Data Output, offset: 0x1734, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_45[10];
  __I  uint16_t PGPDI1;                            /**< Parallel GPIO Pad Data Input, offset: 0x1740, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint16_t PGPDI0;                            /**< Parallel GPIO Pad Data Input, offset: 0x1742, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint16_t PGPDI3;                            /**< Parallel GPIO Pad Data Input, offset: 0x1744, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint16_t PGPDI2;                            /**< Parallel GPIO Pad Data Input, offset: 0x1746, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint16_t PGPDI5;                            /**< Parallel GPIO Pad Data Input, offset: 0x1748, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint16_t PGPDI4;                            /**< Parallel GPIO Pad Data Input, offset: 0x174A, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint16_t PGPDI7;                            /**< Parallel GPIO Pad Data Input, offset: 0x174C, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint16_t PGPDI6;                            /**< Parallel GPIO Pad Data Input, offset: 0x174E, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint16_t PGPDI9;                            /**< Parallel GPIO Pad Data Input, offset: 0x1750, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint16_t PGPDI8;                            /**< Parallel GPIO Pad Data Input, offset: 0x1752, available only on: SIUL2_1 (missing on LPE_SIUL2, SIUL2_0, SIUL2_3, SIUL2_4) */
  __I  uint16_t PGPDI11;                           /**< Parallel GPIO Pad Data Input, offset: 0x1754, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint16_t PGPDI10;                           /**< Parallel GPIO Pad Data Input, offset: 0x1756, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint16_t PGPDI13;                           /**< Parallel GPIO Pad Data Input, offset: 0x1758, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint16_t PGPDI12;                           /**< Parallel GPIO Pad Data Input, offset: 0x175A, available only on: LPE_SIUL2 (missing on SIUL2_0, SIUL2_1, SIUL2_3, SIUL2_4) */
  __I  uint16_t PGPDI15;                           /**< Parallel GPIO Pad Data Input, offset: 0x175C, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint16_t PGPDI14;                           /**< Parallel GPIO Pad Data Input, offset: 0x175E, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  uint8_t RESERVED_46[2];
  __I  uint16_t PGPDI16;                           /**< Parallel GPIO Pad Data Input, offset: 0x1762, available only on: SIUL2_3 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_4) */
  __I  uint16_t PGPDI19;                           /**< Parallel GPIO Pad Data Input, offset: 0x1764, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  uint8_t RESERVED_47[2];
  __I  uint16_t PGPDI21;                           /**< Parallel GPIO Pad Data Input, offset: 0x1768, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint16_t PGPDI20;                           /**< Parallel GPIO Pad Data Input, offset: 0x176A, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint16_t PGPDI23;                           /**< Parallel GPIO Pad Data Input, offset: 0x176C, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  __I  uint16_t PGPDI22;                           /**< Parallel GPIO Pad Data Input, offset: 0x176E, available only on: SIUL2_4 (missing on LPE_SIUL2, SIUL2_0, SIUL2_1, SIUL2_3) */
  uint8_t RESERVED_48[4];
  __I  uint16_t PGPDI27;                           /**< Parallel GPIO Pad Data Input, offset: 0x1774, available only on: SIUL2_0 (missing on LPE_SIUL2, SIUL2_1, SIUL2_3, SIUL2_4) */
  uint8_t RESERVED_49[10];
  __IO uint32_t MPGPDO[SIUL2_MPGPDO_COUNT];        /**< Masked Parallel GPIO Pad Data Output, array offset: 0x1780, array step: 0x4, irregular array, not all indices are valid */
} SIUL2_Type, *SIUL2_MemMapPtr;

/** Number of instances of the SIUL2 module. */
#define SIUL2_INSTANCE_COUNT                     (5u)

/* SIUL2 - Peripheral instance base addresses */
/** Peripheral LPE_SIUL2 base address */
#define IP_LPE_SIUL2_BASE                        (0x4208C000u)
/** Peripheral LPE_SIUL2 base pointer */
#define IP_LPE_SIUL2                             ((SIUL2_Type *)IP_LPE_SIUL2_BASE)
/** Peripheral SIUL2_0 base address */
#define IP_SIUL2_0_BASE                          (0x40014000u)
/** Peripheral SIUL2_0 base pointer */
#define IP_SIUL2_0                               ((SIUL2_Type *)IP_SIUL2_0_BASE)
/** Peripheral SIUL2_0 base address */
#define IP_SIUL2_0_Alias2_BASE                   (0x50014000u)
/** Peripheral SIUL2_0 base pointer */
#define IP_SIUL2_0_Alias2                        ((SIUL2_Type *)IP_SIUL2_0_Alias2_BASE)
/** Peripheral SIUL2_1 base address */
#define IP_SIUL2_1_BASE                          (0x40204000u)
/** Peripheral SIUL2_1 base pointer */
#define IP_SIUL2_1                               ((SIUL2_Type *)IP_SIUL2_1_BASE)
/** Peripheral SIUL2_3 base address */
#define IP_SIUL2_3_BASE                          (0x40610000u)
/** Peripheral SIUL2_3 base pointer */
#define IP_SIUL2_3                               ((SIUL2_Type *)IP_SIUL2_3_BASE)
/** Peripheral SIUL2_4 base address */
#define IP_SIUL2_4_BASE                          (0x40804000u)
/** Peripheral SIUL2_4 base pointer */
#define IP_SIUL2_4                               ((SIUL2_Type *)IP_SIUL2_4_BASE)
/** Array initializer of SIUL2 peripheral base addresses */
#define IP_SIUL2_BASE_ADDRS                      { IP_LPE_SIUL2_BASE, IP_SIUL2_0_BASE, IP_SIUL2_0_Alias2_BASE, IP_SIUL2_1_BASE, IP_SIUL2_3_BASE, IP_SIUL2_4_BASE }
/** Array initializer of SIUL2 peripheral base pointers */
#define IP_SIUL2_BASE_PTRS                       { IP_LPE_SIUL2, IP_SIUL2_0, IP_SIUL2_0_Alias2, IP_SIUL2_1, IP_SIUL2_3, IP_SIUL2_4 }

/* ----------------------------------------------------------------------------
   -- SIUL2 Register Masks
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup SIUL2_Register_Masks SIUL2 Register Masks
 * @{
 */

/*! @name MIDR1 - SIUL2 MCU ID Register #1 */
/*! @{ */

#define SIUL2_MIDR1_MINOR_MASK_MASK              (0xFU)
#define SIUL2_MIDR1_MINOR_MASK_SHIFT             (0U)
#define SIUL2_MIDR1_MINOR_MASK_WIDTH             (4U)
#define SIUL2_MIDR1_MINOR_MASK(x)                (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR1_MINOR_MASK_SHIFT)) & SIUL2_MIDR1_MINOR_MASK_MASK)

#define SIUL2_MIDR1_MAJOR_MASK_MASK              (0xF0U)
#define SIUL2_MIDR1_MAJOR_MASK_SHIFT             (4U)
#define SIUL2_MIDR1_MAJOR_MASK_WIDTH             (4U)
#define SIUL2_MIDR1_MAJOR_MASK(x)                (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR1_MAJOR_MASK_SHIFT)) & SIUL2_MIDR1_MAJOR_MASK_MASK)

#define SIUL2_MIDR1_PART_NO_MASK                 (0x3FF0000U)
#define SIUL2_MIDR1_PART_NO_SHIFT                (16U)
#define SIUL2_MIDR1_PART_NO_WIDTH                (10U)
#define SIUL2_MIDR1_PART_NO(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR1_PART_NO_SHIFT)) & SIUL2_MIDR1_PART_NO_MASK)

#define SIUL2_MIDR1_PRODUCT_LINE_LETTER_MASK     (0xFC000000U)
#define SIUL2_MIDR1_PRODUCT_LINE_LETTER_SHIFT    (26U)
#define SIUL2_MIDR1_PRODUCT_LINE_LETTER_WIDTH    (6U)
#define SIUL2_MIDR1_PRODUCT_LINE_LETTER(x)       (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR1_PRODUCT_LINE_LETTER_SHIFT)) & SIUL2_MIDR1_PRODUCT_LINE_LETTER_MASK)
/*! @} */

/*! @name MIDR2 - SIUL2 MCU ID Register #2 */
/*! @{ */

#define SIUL2_MIDR2_NVM_SIZE_CODE_MASK           (0xFFU)
#define SIUL2_MIDR2_NVM_SIZE_CODE_SHIFT          (0U)
#define SIUL2_MIDR2_NVM_SIZE_CODE_WIDTH          (8U)
#define SIUL2_MIDR2_NVM_SIZE_CODE(x)             (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR2_NVM_SIZE_CODE_SHIFT)) & SIUL2_MIDR2_NVM_SIZE_CODE_MASK)

#define SIUL2_MIDR2_NVM_SIZE_DATA_MASK           (0xF00U)
#define SIUL2_MIDR2_NVM_SIZE_DATA_SHIFT          (8U)
#define SIUL2_MIDR2_NVM_SIZE_DATA_WIDTH          (4U)
#define SIUL2_MIDR2_NVM_SIZE_DATA(x)             (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR2_NVM_SIZE_DATA_SHIFT)) & SIUL2_MIDR2_NVM_SIZE_DATA_MASK)

#define SIUL2_MIDR2_NVM_DATA_MASK                (0x3000U)
#define SIUL2_MIDR2_NVM_DATA_SHIFT               (12U)
#define SIUL2_MIDR2_NVM_DATA_WIDTH               (2U)
#define SIUL2_MIDR2_NVM_DATA(x)                  (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR2_NVM_DATA_SHIFT)) & SIUL2_MIDR2_NVM_DATA_MASK)

#define SIUL2_MIDR2_NVM_CODE_MASK                (0xC000U)
#define SIUL2_MIDR2_NVM_CODE_SHIFT               (14U)
#define SIUL2_MIDR2_NVM_CODE_WIDTH               (2U)
#define SIUL2_MIDR2_NVM_CODE(x)                  (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR2_NVM_CODE_SHIFT)) & SIUL2_MIDR2_NVM_CODE_MASK)

#define SIUL2_MIDR2_FREQUENCY_MASK               (0xF0000U)
#define SIUL2_MIDR2_FREQUENCY_SHIFT              (16U)
#define SIUL2_MIDR2_FREQUENCY_WIDTH              (4U)
#define SIUL2_MIDR2_FREQUENCY(x)                 (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR2_FREQUENCY_SHIFT)) & SIUL2_MIDR2_FREQUENCY_MASK)

#define SIUL2_MIDR2_PACKAGE_MASK                 (0x3F00000U)
#define SIUL2_MIDR2_PACKAGE_SHIFT                (20U)
#define SIUL2_MIDR2_PACKAGE_WIDTH                (6U)
#define SIUL2_MIDR2_PACKAGE(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR2_PACKAGE_SHIFT)) & SIUL2_MIDR2_PACKAGE_MASK)

#define SIUL2_MIDR2_TECHNOLOGY_MASK              (0xE0000000U)
#define SIUL2_MIDR2_TECHNOLOGY_SHIFT             (29U)
#define SIUL2_MIDR2_TECHNOLOGY_WIDTH             (3U)
#define SIUL2_MIDR2_TECHNOLOGY(x)                (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR2_TECHNOLOGY_SHIFT)) & SIUL2_MIDR2_TECHNOLOGY_MASK)
/*! @} */

/*! @name DISR0 - DMA or Interrupt Status Flag 0 */
/*! @{ */

#define SIUL2_DISR0_EIF0_MASK                    (0x1U)
#define SIUL2_DISR0_EIF0_SHIFT                   (0U)
#define SIUL2_DISR0_EIF0_WIDTH                   (1U)
#define SIUL2_DISR0_EIF0(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF0_SHIFT)) & SIUL2_DISR0_EIF0_MASK)

#define SIUL2_DISR0_EIF1_MASK                    (0x2U)
#define SIUL2_DISR0_EIF1_SHIFT                   (1U)
#define SIUL2_DISR0_EIF1_WIDTH                   (1U)
#define SIUL2_DISR0_EIF1(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF1_SHIFT)) & SIUL2_DISR0_EIF1_MASK)

#define SIUL2_DISR0_EIF2_MASK                    (0x4U)
#define SIUL2_DISR0_EIF2_SHIFT                   (2U)
#define SIUL2_DISR0_EIF2_WIDTH                   (1U)
#define SIUL2_DISR0_EIF2(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF2_SHIFT)) & SIUL2_DISR0_EIF2_MASK)

#define SIUL2_DISR0_EIF3_MASK                    (0x8U)
#define SIUL2_DISR0_EIF3_SHIFT                   (3U)
#define SIUL2_DISR0_EIF3_WIDTH                   (1U)
#define SIUL2_DISR0_EIF3(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF3_SHIFT)) & SIUL2_DISR0_EIF3_MASK)

#define SIUL2_DISR0_EIF4_MASK                    (0x10U)
#define SIUL2_DISR0_EIF4_SHIFT                   (4U)
#define SIUL2_DISR0_EIF4_WIDTH                   (1U)
#define SIUL2_DISR0_EIF4(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF4_SHIFT)) & SIUL2_DISR0_EIF4_MASK)

#define SIUL2_DISR0_EIF5_MASK                    (0x20U)
#define SIUL2_DISR0_EIF5_SHIFT                   (5U)
#define SIUL2_DISR0_EIF5_WIDTH                   (1U)
#define SIUL2_DISR0_EIF5(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF5_SHIFT)) & SIUL2_DISR0_EIF5_MASK)

#define SIUL2_DISR0_EIF6_MASK                    (0x40U)
#define SIUL2_DISR0_EIF6_SHIFT                   (6U)
#define SIUL2_DISR0_EIF6_WIDTH                   (1U)
#define SIUL2_DISR0_EIF6(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF6_SHIFT)) & SIUL2_DISR0_EIF6_MASK)

#define SIUL2_DISR0_EIF7_MASK                    (0x80U)
#define SIUL2_DISR0_EIF7_SHIFT                   (7U)
#define SIUL2_DISR0_EIF7_WIDTH                   (1U)
#define SIUL2_DISR0_EIF7(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF7_SHIFT)) & SIUL2_DISR0_EIF7_MASK)

#define SIUL2_DISR0_EIF8_MASK                    (0x100U)
#define SIUL2_DISR0_EIF8_SHIFT                   (8U)
#define SIUL2_DISR0_EIF8_WIDTH                   (1U)
#define SIUL2_DISR0_EIF8(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF8_SHIFT)) & SIUL2_DISR0_EIF8_MASK)

#define SIUL2_DISR0_EIF9_MASK                    (0x200U)
#define SIUL2_DISR0_EIF9_SHIFT                   (9U)
#define SIUL2_DISR0_EIF9_WIDTH                   (1U)
#define SIUL2_DISR0_EIF9(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF9_SHIFT)) & SIUL2_DISR0_EIF9_MASK)

#define SIUL2_DISR0_EIF10_MASK                   (0x400U)
#define SIUL2_DISR0_EIF10_SHIFT                  (10U)
#define SIUL2_DISR0_EIF10_WIDTH                  (1U)
#define SIUL2_DISR0_EIF10(x)                     (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF10_SHIFT)) & SIUL2_DISR0_EIF10_MASK)

#define SIUL2_DISR0_EIF11_MASK                   (0x800U)
#define SIUL2_DISR0_EIF11_SHIFT                  (11U)
#define SIUL2_DISR0_EIF11_WIDTH                  (1U)
#define SIUL2_DISR0_EIF11(x)                     (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF11_SHIFT)) & SIUL2_DISR0_EIF11_MASK)

#define SIUL2_DISR0_EIF12_MASK                   (0x1000U)
#define SIUL2_DISR0_EIF12_SHIFT                  (12U)
#define SIUL2_DISR0_EIF12_WIDTH                  (1U)
#define SIUL2_DISR0_EIF12(x)                     (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF12_SHIFT)) & SIUL2_DISR0_EIF12_MASK)

#define SIUL2_DISR0_EIF13_MASK                   (0x2000U)
#define SIUL2_DISR0_EIF13_SHIFT                  (13U)
#define SIUL2_DISR0_EIF13_WIDTH                  (1U)
#define SIUL2_DISR0_EIF13(x)                     (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF13_SHIFT)) & SIUL2_DISR0_EIF13_MASK)

#define SIUL2_DISR0_EIF14_MASK                   (0x4000U)
#define SIUL2_DISR0_EIF14_SHIFT                  (14U)
#define SIUL2_DISR0_EIF14_WIDTH                  (1U)
#define SIUL2_DISR0_EIF14(x)                     (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF14_SHIFT)) & SIUL2_DISR0_EIF14_MASK)

#define SIUL2_DISR0_EIF15_MASK                   (0x8000U)
#define SIUL2_DISR0_EIF15_SHIFT                  (15U)
#define SIUL2_DISR0_EIF15_WIDTH                  (1U)
#define SIUL2_DISR0_EIF15(x)                     (((uint32_t)(((uint32_t)(x)) << SIUL2_DISR0_EIF15_SHIFT)) & SIUL2_DISR0_EIF15_MASK)
/*! @} */

/*! @name DIRER0 - DMA or Interrupt Request Enable 0 */
/*! @{ */

#define SIUL2_DIRER0_EIRE0_MASK                  (0x1U)
#define SIUL2_DIRER0_EIRE0_SHIFT                 (0U)
#define SIUL2_DIRER0_EIRE0_WIDTH                 (1U)
#define SIUL2_DIRER0_EIRE0(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE0_SHIFT)) & SIUL2_DIRER0_EIRE0_MASK)

#define SIUL2_DIRER0_EIRE1_MASK                  (0x2U)
#define SIUL2_DIRER0_EIRE1_SHIFT                 (1U)
#define SIUL2_DIRER0_EIRE1_WIDTH                 (1U)
#define SIUL2_DIRER0_EIRE1(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE1_SHIFT)) & SIUL2_DIRER0_EIRE1_MASK)

#define SIUL2_DIRER0_EIRE2_MASK                  (0x4U)
#define SIUL2_DIRER0_EIRE2_SHIFT                 (2U)
#define SIUL2_DIRER0_EIRE2_WIDTH                 (1U)
#define SIUL2_DIRER0_EIRE2(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE2_SHIFT)) & SIUL2_DIRER0_EIRE2_MASK)

#define SIUL2_DIRER0_EIRE3_MASK                  (0x8U)
#define SIUL2_DIRER0_EIRE3_SHIFT                 (3U)
#define SIUL2_DIRER0_EIRE3_WIDTH                 (1U)
#define SIUL2_DIRER0_EIRE3(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE3_SHIFT)) & SIUL2_DIRER0_EIRE3_MASK)

#define SIUL2_DIRER0_EIRE4_MASK                  (0x10U)
#define SIUL2_DIRER0_EIRE4_SHIFT                 (4U)
#define SIUL2_DIRER0_EIRE4_WIDTH                 (1U)
#define SIUL2_DIRER0_EIRE4(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE4_SHIFT)) & SIUL2_DIRER0_EIRE4_MASK)

#define SIUL2_DIRER0_EIRE5_MASK                  (0x20U)
#define SIUL2_DIRER0_EIRE5_SHIFT                 (5U)
#define SIUL2_DIRER0_EIRE5_WIDTH                 (1U)
#define SIUL2_DIRER0_EIRE5(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE5_SHIFT)) & SIUL2_DIRER0_EIRE5_MASK)

#define SIUL2_DIRER0_EIRE6_MASK                  (0x40U)
#define SIUL2_DIRER0_EIRE6_SHIFT                 (6U)
#define SIUL2_DIRER0_EIRE6_WIDTH                 (1U)
#define SIUL2_DIRER0_EIRE6(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE6_SHIFT)) & SIUL2_DIRER0_EIRE6_MASK)

#define SIUL2_DIRER0_EIRE7_MASK                  (0x80U)
#define SIUL2_DIRER0_EIRE7_SHIFT                 (7U)
#define SIUL2_DIRER0_EIRE7_WIDTH                 (1U)
#define SIUL2_DIRER0_EIRE7(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE7_SHIFT)) & SIUL2_DIRER0_EIRE7_MASK)

#define SIUL2_DIRER0_EIRE8_MASK                  (0x100U)
#define SIUL2_DIRER0_EIRE8_SHIFT                 (8U)
#define SIUL2_DIRER0_EIRE8_WIDTH                 (1U)
#define SIUL2_DIRER0_EIRE8(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE8_SHIFT)) & SIUL2_DIRER0_EIRE8_MASK)

#define SIUL2_DIRER0_EIRE9_MASK                  (0x200U)
#define SIUL2_DIRER0_EIRE9_SHIFT                 (9U)
#define SIUL2_DIRER0_EIRE9_WIDTH                 (1U)
#define SIUL2_DIRER0_EIRE9(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE9_SHIFT)) & SIUL2_DIRER0_EIRE9_MASK)

#define SIUL2_DIRER0_EIRE10_MASK                 (0x400U)
#define SIUL2_DIRER0_EIRE10_SHIFT                (10U)
#define SIUL2_DIRER0_EIRE10_WIDTH                (1U)
#define SIUL2_DIRER0_EIRE10(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE10_SHIFT)) & SIUL2_DIRER0_EIRE10_MASK)

#define SIUL2_DIRER0_EIRE11_MASK                 (0x800U)
#define SIUL2_DIRER0_EIRE11_SHIFT                (11U)
#define SIUL2_DIRER0_EIRE11_WIDTH                (1U)
#define SIUL2_DIRER0_EIRE11(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE11_SHIFT)) & SIUL2_DIRER0_EIRE11_MASK)

#define SIUL2_DIRER0_EIRE12_MASK                 (0x1000U)
#define SIUL2_DIRER0_EIRE12_SHIFT                (12U)
#define SIUL2_DIRER0_EIRE12_WIDTH                (1U)
#define SIUL2_DIRER0_EIRE12(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE12_SHIFT)) & SIUL2_DIRER0_EIRE12_MASK)

#define SIUL2_DIRER0_EIRE13_MASK                 (0x2000U)
#define SIUL2_DIRER0_EIRE13_SHIFT                (13U)
#define SIUL2_DIRER0_EIRE13_WIDTH                (1U)
#define SIUL2_DIRER0_EIRE13(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE13_SHIFT)) & SIUL2_DIRER0_EIRE13_MASK)

#define SIUL2_DIRER0_EIRE14_MASK                 (0x4000U)
#define SIUL2_DIRER0_EIRE14_SHIFT                (14U)
#define SIUL2_DIRER0_EIRE14_WIDTH                (1U)
#define SIUL2_DIRER0_EIRE14(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE14_SHIFT)) & SIUL2_DIRER0_EIRE14_MASK)

#define SIUL2_DIRER0_EIRE15_MASK                 (0x8000U)
#define SIUL2_DIRER0_EIRE15_SHIFT                (15U)
#define SIUL2_DIRER0_EIRE15_WIDTH                (1U)
#define SIUL2_DIRER0_EIRE15(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRER0_EIRE15_SHIFT)) & SIUL2_DIRER0_EIRE15_MASK)
/*! @} */

/*! @name DIRSR0 - DMA or Interrupt Request Select 0 */
/*! @{ */

#define SIUL2_DIRSR0_DIRSR0_MASK                 (0x1U)
#define SIUL2_DIRSR0_DIRSR0_SHIFT                (0U)
#define SIUL2_DIRSR0_DIRSR0_WIDTH                (1U)
#define SIUL2_DIRSR0_DIRSR0(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR0_SHIFT)) & SIUL2_DIRSR0_DIRSR0_MASK)

#define SIUL2_DIRSR0_DIRSR1_MASK                 (0x2U)
#define SIUL2_DIRSR0_DIRSR1_SHIFT                (1U)
#define SIUL2_DIRSR0_DIRSR1_WIDTH                (1U)
#define SIUL2_DIRSR0_DIRSR1(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR1_SHIFT)) & SIUL2_DIRSR0_DIRSR1_MASK)

#define SIUL2_DIRSR0_DIRSR2_MASK                 (0x4U)
#define SIUL2_DIRSR0_DIRSR2_SHIFT                (2U)
#define SIUL2_DIRSR0_DIRSR2_WIDTH                (1U)
#define SIUL2_DIRSR0_DIRSR2(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR2_SHIFT)) & SIUL2_DIRSR0_DIRSR2_MASK)

#define SIUL2_DIRSR0_DIRSR3_MASK                 (0x8U)
#define SIUL2_DIRSR0_DIRSR3_SHIFT                (3U)
#define SIUL2_DIRSR0_DIRSR3_WIDTH                (1U)
#define SIUL2_DIRSR0_DIRSR3(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR3_SHIFT)) & SIUL2_DIRSR0_DIRSR3_MASK)

#define SIUL2_DIRSR0_DIRSR4_MASK                 (0x10U)
#define SIUL2_DIRSR0_DIRSR4_SHIFT                (4U)
#define SIUL2_DIRSR0_DIRSR4_WIDTH                (1U)
#define SIUL2_DIRSR0_DIRSR4(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR4_SHIFT)) & SIUL2_DIRSR0_DIRSR4_MASK)

#define SIUL2_DIRSR0_DIRSR5_MASK                 (0x20U)
#define SIUL2_DIRSR0_DIRSR5_SHIFT                (5U)
#define SIUL2_DIRSR0_DIRSR5_WIDTH                (1U)
#define SIUL2_DIRSR0_DIRSR5(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR5_SHIFT)) & SIUL2_DIRSR0_DIRSR5_MASK)

#define SIUL2_DIRSR0_DIRSR6_MASK                 (0x40U)
#define SIUL2_DIRSR0_DIRSR6_SHIFT                (6U)
#define SIUL2_DIRSR0_DIRSR6_WIDTH                (1U)
#define SIUL2_DIRSR0_DIRSR6(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR6_SHIFT)) & SIUL2_DIRSR0_DIRSR6_MASK)

#define SIUL2_DIRSR0_DIRSR7_MASK                 (0x80U)
#define SIUL2_DIRSR0_DIRSR7_SHIFT                (7U)
#define SIUL2_DIRSR0_DIRSR7_WIDTH                (1U)
#define SIUL2_DIRSR0_DIRSR7(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR7_SHIFT)) & SIUL2_DIRSR0_DIRSR7_MASK)

#define SIUL2_DIRSR0_DIRSR8_MASK                 (0x100U)
#define SIUL2_DIRSR0_DIRSR8_SHIFT                (8U)
#define SIUL2_DIRSR0_DIRSR8_WIDTH                (1U)
#define SIUL2_DIRSR0_DIRSR8(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR8_SHIFT)) & SIUL2_DIRSR0_DIRSR8_MASK)

#define SIUL2_DIRSR0_DIRSR9_MASK                 (0x200U)
#define SIUL2_DIRSR0_DIRSR9_SHIFT                (9U)
#define SIUL2_DIRSR0_DIRSR9_WIDTH                (1U)
#define SIUL2_DIRSR0_DIRSR9(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR9_SHIFT)) & SIUL2_DIRSR0_DIRSR9_MASK)

#define SIUL2_DIRSR0_DIRSR10_MASK                (0x400U)
#define SIUL2_DIRSR0_DIRSR10_SHIFT               (10U)
#define SIUL2_DIRSR0_DIRSR10_WIDTH               (1U)
#define SIUL2_DIRSR0_DIRSR10(x)                  (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR10_SHIFT)) & SIUL2_DIRSR0_DIRSR10_MASK)

#define SIUL2_DIRSR0_DIRSR11_MASK                (0x800U)
#define SIUL2_DIRSR0_DIRSR11_SHIFT               (11U)
#define SIUL2_DIRSR0_DIRSR11_WIDTH               (1U)
#define SIUL2_DIRSR0_DIRSR11(x)                  (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR11_SHIFT)) & SIUL2_DIRSR0_DIRSR11_MASK)

#define SIUL2_DIRSR0_DIRSR12_MASK                (0x1000U)
#define SIUL2_DIRSR0_DIRSR12_SHIFT               (12U)
#define SIUL2_DIRSR0_DIRSR12_WIDTH               (1U)
#define SIUL2_DIRSR0_DIRSR12(x)                  (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR12_SHIFT)) & SIUL2_DIRSR0_DIRSR12_MASK)

#define SIUL2_DIRSR0_DIRSR13_MASK                (0x2000U)
#define SIUL2_DIRSR0_DIRSR13_SHIFT               (13U)
#define SIUL2_DIRSR0_DIRSR13_WIDTH               (1U)
#define SIUL2_DIRSR0_DIRSR13(x)                  (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR13_SHIFT)) & SIUL2_DIRSR0_DIRSR13_MASK)

#define SIUL2_DIRSR0_DIRSR14_MASK                (0x4000U)
#define SIUL2_DIRSR0_DIRSR14_SHIFT               (14U)
#define SIUL2_DIRSR0_DIRSR14_WIDTH               (1U)
#define SIUL2_DIRSR0_DIRSR14(x)                  (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR14_SHIFT)) & SIUL2_DIRSR0_DIRSR14_MASK)

#define SIUL2_DIRSR0_DIRSR15_MASK                (0x8000U)
#define SIUL2_DIRSR0_DIRSR15_SHIFT               (15U)
#define SIUL2_DIRSR0_DIRSR15_WIDTH               (1U)
#define SIUL2_DIRSR0_DIRSR15(x)                  (((uint32_t)(((uint32_t)(x)) << SIUL2_DIRSR0_DIRSR15_SHIFT)) & SIUL2_DIRSR0_DIRSR15_MASK)
/*! @} */

/*! @name IREER0 - Interrupt Rising-Edge Event Enable 0 */
/*! @{ */

#define SIUL2_IREER0_IREE0_MASK                  (0x1U)
#define SIUL2_IREER0_IREE0_SHIFT                 (0U)
#define SIUL2_IREER0_IREE0_WIDTH                 (1U)
#define SIUL2_IREER0_IREE0(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE0_SHIFT)) & SIUL2_IREER0_IREE0_MASK)

#define SIUL2_IREER0_IREE1_MASK                  (0x2U)
#define SIUL2_IREER0_IREE1_SHIFT                 (1U)
#define SIUL2_IREER0_IREE1_WIDTH                 (1U)
#define SIUL2_IREER0_IREE1(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE1_SHIFT)) & SIUL2_IREER0_IREE1_MASK)

#define SIUL2_IREER0_IREE2_MASK                  (0x4U)
#define SIUL2_IREER0_IREE2_SHIFT                 (2U)
#define SIUL2_IREER0_IREE2_WIDTH                 (1U)
#define SIUL2_IREER0_IREE2(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE2_SHIFT)) & SIUL2_IREER0_IREE2_MASK)

#define SIUL2_IREER0_IREE3_MASK                  (0x8U)
#define SIUL2_IREER0_IREE3_SHIFT                 (3U)
#define SIUL2_IREER0_IREE3_WIDTH                 (1U)
#define SIUL2_IREER0_IREE3(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE3_SHIFT)) & SIUL2_IREER0_IREE3_MASK)

#define SIUL2_IREER0_IREE4_MASK                  (0x10U)
#define SIUL2_IREER0_IREE4_SHIFT                 (4U)
#define SIUL2_IREER0_IREE4_WIDTH                 (1U)
#define SIUL2_IREER0_IREE4(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE4_SHIFT)) & SIUL2_IREER0_IREE4_MASK)

#define SIUL2_IREER0_IREE5_MASK                  (0x20U)
#define SIUL2_IREER0_IREE5_SHIFT                 (5U)
#define SIUL2_IREER0_IREE5_WIDTH                 (1U)
#define SIUL2_IREER0_IREE5(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE5_SHIFT)) & SIUL2_IREER0_IREE5_MASK)

#define SIUL2_IREER0_IREE6_MASK                  (0x40U)
#define SIUL2_IREER0_IREE6_SHIFT                 (6U)
#define SIUL2_IREER0_IREE6_WIDTH                 (1U)
#define SIUL2_IREER0_IREE6(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE6_SHIFT)) & SIUL2_IREER0_IREE6_MASK)

#define SIUL2_IREER0_IREE7_MASK                  (0x80U)
#define SIUL2_IREER0_IREE7_SHIFT                 (7U)
#define SIUL2_IREER0_IREE7_WIDTH                 (1U)
#define SIUL2_IREER0_IREE7(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE7_SHIFT)) & SIUL2_IREER0_IREE7_MASK)

#define SIUL2_IREER0_IREE8_MASK                  (0x100U)
#define SIUL2_IREER0_IREE8_SHIFT                 (8U)
#define SIUL2_IREER0_IREE8_WIDTH                 (1U)
#define SIUL2_IREER0_IREE8(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE8_SHIFT)) & SIUL2_IREER0_IREE8_MASK)

#define SIUL2_IREER0_IREE9_MASK                  (0x200U)
#define SIUL2_IREER0_IREE9_SHIFT                 (9U)
#define SIUL2_IREER0_IREE9_WIDTH                 (1U)
#define SIUL2_IREER0_IREE9(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE9_SHIFT)) & SIUL2_IREER0_IREE9_MASK)

#define SIUL2_IREER0_IREE10_MASK                 (0x400U)
#define SIUL2_IREER0_IREE10_SHIFT                (10U)
#define SIUL2_IREER0_IREE10_WIDTH                (1U)
#define SIUL2_IREER0_IREE10(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE10_SHIFT)) & SIUL2_IREER0_IREE10_MASK)

#define SIUL2_IREER0_IREE11_MASK                 (0x800U)
#define SIUL2_IREER0_IREE11_SHIFT                (11U)
#define SIUL2_IREER0_IREE11_WIDTH                (1U)
#define SIUL2_IREER0_IREE11(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE11_SHIFT)) & SIUL2_IREER0_IREE11_MASK)

#define SIUL2_IREER0_IREE12_MASK                 (0x1000U)
#define SIUL2_IREER0_IREE12_SHIFT                (12U)
#define SIUL2_IREER0_IREE12_WIDTH                (1U)
#define SIUL2_IREER0_IREE12(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE12_SHIFT)) & SIUL2_IREER0_IREE12_MASK)

#define SIUL2_IREER0_IREE13_MASK                 (0x2000U)
#define SIUL2_IREER0_IREE13_SHIFT                (13U)
#define SIUL2_IREER0_IREE13_WIDTH                (1U)
#define SIUL2_IREER0_IREE13(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE13_SHIFT)) & SIUL2_IREER0_IREE13_MASK)

#define SIUL2_IREER0_IREE14_MASK                 (0x4000U)
#define SIUL2_IREER0_IREE14_SHIFT                (14U)
#define SIUL2_IREER0_IREE14_WIDTH                (1U)
#define SIUL2_IREER0_IREE14(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE14_SHIFT)) & SIUL2_IREER0_IREE14_MASK)

#define SIUL2_IREER0_IREE15_MASK                 (0x8000U)
#define SIUL2_IREER0_IREE15_SHIFT                (15U)
#define SIUL2_IREER0_IREE15_WIDTH                (1U)
#define SIUL2_IREER0_IREE15(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_IREER0_IREE15_SHIFT)) & SIUL2_IREER0_IREE15_MASK)
/*! @} */

/*! @name IFEER0 - Interrupt Falling-Edge Event Enable 0 */
/*! @{ */

#define SIUL2_IFEER0_IFEE0_MASK                  (0x1U)
#define SIUL2_IFEER0_IFEE0_SHIFT                 (0U)
#define SIUL2_IFEER0_IFEE0_WIDTH                 (1U)
#define SIUL2_IFEER0_IFEE0(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE0_SHIFT)) & SIUL2_IFEER0_IFEE0_MASK)

#define SIUL2_IFEER0_IFEE1_MASK                  (0x2U)
#define SIUL2_IFEER0_IFEE1_SHIFT                 (1U)
#define SIUL2_IFEER0_IFEE1_WIDTH                 (1U)
#define SIUL2_IFEER0_IFEE1(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE1_SHIFT)) & SIUL2_IFEER0_IFEE1_MASK)

#define SIUL2_IFEER0_IFEE2_MASK                  (0x4U)
#define SIUL2_IFEER0_IFEE2_SHIFT                 (2U)
#define SIUL2_IFEER0_IFEE2_WIDTH                 (1U)
#define SIUL2_IFEER0_IFEE2(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE2_SHIFT)) & SIUL2_IFEER0_IFEE2_MASK)

#define SIUL2_IFEER0_IFEE3_MASK                  (0x8U)
#define SIUL2_IFEER0_IFEE3_SHIFT                 (3U)
#define SIUL2_IFEER0_IFEE3_WIDTH                 (1U)
#define SIUL2_IFEER0_IFEE3(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE3_SHIFT)) & SIUL2_IFEER0_IFEE3_MASK)

#define SIUL2_IFEER0_IFEE4_MASK                  (0x10U)
#define SIUL2_IFEER0_IFEE4_SHIFT                 (4U)
#define SIUL2_IFEER0_IFEE4_WIDTH                 (1U)
#define SIUL2_IFEER0_IFEE4(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE4_SHIFT)) & SIUL2_IFEER0_IFEE4_MASK)

#define SIUL2_IFEER0_IFEE5_MASK                  (0x20U)
#define SIUL2_IFEER0_IFEE5_SHIFT                 (5U)
#define SIUL2_IFEER0_IFEE5_WIDTH                 (1U)
#define SIUL2_IFEER0_IFEE5(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE5_SHIFT)) & SIUL2_IFEER0_IFEE5_MASK)

#define SIUL2_IFEER0_IFEE6_MASK                  (0x40U)
#define SIUL2_IFEER0_IFEE6_SHIFT                 (6U)
#define SIUL2_IFEER0_IFEE6_WIDTH                 (1U)
#define SIUL2_IFEER0_IFEE6(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE6_SHIFT)) & SIUL2_IFEER0_IFEE6_MASK)

#define SIUL2_IFEER0_IFEE7_MASK                  (0x80U)
#define SIUL2_IFEER0_IFEE7_SHIFT                 (7U)
#define SIUL2_IFEER0_IFEE7_WIDTH                 (1U)
#define SIUL2_IFEER0_IFEE7(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE7_SHIFT)) & SIUL2_IFEER0_IFEE7_MASK)

#define SIUL2_IFEER0_IFEE8_MASK                  (0x100U)
#define SIUL2_IFEER0_IFEE8_SHIFT                 (8U)
#define SIUL2_IFEER0_IFEE8_WIDTH                 (1U)
#define SIUL2_IFEER0_IFEE8(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE8_SHIFT)) & SIUL2_IFEER0_IFEE8_MASK)

#define SIUL2_IFEER0_IFEE9_MASK                  (0x200U)
#define SIUL2_IFEER0_IFEE9_SHIFT                 (9U)
#define SIUL2_IFEER0_IFEE9_WIDTH                 (1U)
#define SIUL2_IFEER0_IFEE9(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE9_SHIFT)) & SIUL2_IFEER0_IFEE9_MASK)

#define SIUL2_IFEER0_IFEE10_MASK                 (0x400U)
#define SIUL2_IFEER0_IFEE10_SHIFT                (10U)
#define SIUL2_IFEER0_IFEE10_WIDTH                (1U)
#define SIUL2_IFEER0_IFEE10(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE10_SHIFT)) & SIUL2_IFEER0_IFEE10_MASK)

#define SIUL2_IFEER0_IFEE11_MASK                 (0x800U)
#define SIUL2_IFEER0_IFEE11_SHIFT                (11U)
#define SIUL2_IFEER0_IFEE11_WIDTH                (1U)
#define SIUL2_IFEER0_IFEE11(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE11_SHIFT)) & SIUL2_IFEER0_IFEE11_MASK)

#define SIUL2_IFEER0_IFEE12_MASK                 (0x1000U)
#define SIUL2_IFEER0_IFEE12_SHIFT                (12U)
#define SIUL2_IFEER0_IFEE12_WIDTH                (1U)
#define SIUL2_IFEER0_IFEE12(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE12_SHIFT)) & SIUL2_IFEER0_IFEE12_MASK)

#define SIUL2_IFEER0_IFEE13_MASK                 (0x2000U)
#define SIUL2_IFEER0_IFEE13_SHIFT                (13U)
#define SIUL2_IFEER0_IFEE13_WIDTH                (1U)
#define SIUL2_IFEER0_IFEE13(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE13_SHIFT)) & SIUL2_IFEER0_IFEE13_MASK)

#define SIUL2_IFEER0_IFEE14_MASK                 (0x4000U)
#define SIUL2_IFEER0_IFEE14_SHIFT                (14U)
#define SIUL2_IFEER0_IFEE14_WIDTH                (1U)
#define SIUL2_IFEER0_IFEE14(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE14_SHIFT)) & SIUL2_IFEER0_IFEE14_MASK)

#define SIUL2_IFEER0_IFEE15_MASK                 (0x8000U)
#define SIUL2_IFEER0_IFEE15_SHIFT                (15U)
#define SIUL2_IFEER0_IFEE15_WIDTH                (1U)
#define SIUL2_IFEER0_IFEE15(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_IFEER0_IFEE15_SHIFT)) & SIUL2_IFEER0_IFEE15_MASK)
/*! @} */

/*! @name IFER0 - Interrupt Filter Enable 0 */
/*! @{ */

#define SIUL2_IFER0_IFE0_MASK                    (0x1U)
#define SIUL2_IFER0_IFE0_SHIFT                   (0U)
#define SIUL2_IFER0_IFE0_WIDTH                   (1U)
#define SIUL2_IFER0_IFE0(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE0_SHIFT)) & SIUL2_IFER0_IFE0_MASK)

#define SIUL2_IFER0_IFE1_MASK                    (0x2U)
#define SIUL2_IFER0_IFE1_SHIFT                   (1U)
#define SIUL2_IFER0_IFE1_WIDTH                   (1U)
#define SIUL2_IFER0_IFE1(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE1_SHIFT)) & SIUL2_IFER0_IFE1_MASK)

#define SIUL2_IFER0_IFE2_MASK                    (0x4U)
#define SIUL2_IFER0_IFE2_SHIFT                   (2U)
#define SIUL2_IFER0_IFE2_WIDTH                   (1U)
#define SIUL2_IFER0_IFE2(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE2_SHIFT)) & SIUL2_IFER0_IFE2_MASK)

#define SIUL2_IFER0_IFE3_MASK                    (0x8U)
#define SIUL2_IFER0_IFE3_SHIFT                   (3U)
#define SIUL2_IFER0_IFE3_WIDTH                   (1U)
#define SIUL2_IFER0_IFE3(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE3_SHIFT)) & SIUL2_IFER0_IFE3_MASK)

#define SIUL2_IFER0_IFE4_MASK                    (0x10U)
#define SIUL2_IFER0_IFE4_SHIFT                   (4U)
#define SIUL2_IFER0_IFE4_WIDTH                   (1U)
#define SIUL2_IFER0_IFE4(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE4_SHIFT)) & SIUL2_IFER0_IFE4_MASK)

#define SIUL2_IFER0_IFE5_MASK                    (0x20U)
#define SIUL2_IFER0_IFE5_SHIFT                   (5U)
#define SIUL2_IFER0_IFE5_WIDTH                   (1U)
#define SIUL2_IFER0_IFE5(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE5_SHIFT)) & SIUL2_IFER0_IFE5_MASK)

#define SIUL2_IFER0_IFE6_MASK                    (0x40U)
#define SIUL2_IFER0_IFE6_SHIFT                   (6U)
#define SIUL2_IFER0_IFE6_WIDTH                   (1U)
#define SIUL2_IFER0_IFE6(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE6_SHIFT)) & SIUL2_IFER0_IFE6_MASK)

#define SIUL2_IFER0_IFE7_MASK                    (0x80U)
#define SIUL2_IFER0_IFE7_SHIFT                   (7U)
#define SIUL2_IFER0_IFE7_WIDTH                   (1U)
#define SIUL2_IFER0_IFE7(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE7_SHIFT)) & SIUL2_IFER0_IFE7_MASK)

#define SIUL2_IFER0_IFE8_MASK                    (0x100U)
#define SIUL2_IFER0_IFE8_SHIFT                   (8U)
#define SIUL2_IFER0_IFE8_WIDTH                   (1U)
#define SIUL2_IFER0_IFE8(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE8_SHIFT)) & SIUL2_IFER0_IFE8_MASK)

#define SIUL2_IFER0_IFE9_MASK                    (0x200U)
#define SIUL2_IFER0_IFE9_SHIFT                   (9U)
#define SIUL2_IFER0_IFE9_WIDTH                   (1U)
#define SIUL2_IFER0_IFE9(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE9_SHIFT)) & SIUL2_IFER0_IFE9_MASK)

#define SIUL2_IFER0_IFE10_MASK                   (0x400U)
#define SIUL2_IFER0_IFE10_SHIFT                  (10U)
#define SIUL2_IFER0_IFE10_WIDTH                  (1U)
#define SIUL2_IFER0_IFE10(x)                     (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE10_SHIFT)) & SIUL2_IFER0_IFE10_MASK)

#define SIUL2_IFER0_IFE11_MASK                   (0x800U)
#define SIUL2_IFER0_IFE11_SHIFT                  (11U)
#define SIUL2_IFER0_IFE11_WIDTH                  (1U)
#define SIUL2_IFER0_IFE11(x)                     (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE11_SHIFT)) & SIUL2_IFER0_IFE11_MASK)

#define SIUL2_IFER0_IFE12_MASK                   (0x1000U)
#define SIUL2_IFER0_IFE12_SHIFT                  (12U)
#define SIUL2_IFER0_IFE12_WIDTH                  (1U)
#define SIUL2_IFER0_IFE12(x)                     (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE12_SHIFT)) & SIUL2_IFER0_IFE12_MASK)

#define SIUL2_IFER0_IFE13_MASK                   (0x2000U)
#define SIUL2_IFER0_IFE13_SHIFT                  (13U)
#define SIUL2_IFER0_IFE13_WIDTH                  (1U)
#define SIUL2_IFER0_IFE13(x)                     (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE13_SHIFT)) & SIUL2_IFER0_IFE13_MASK)

#define SIUL2_IFER0_IFE14_MASK                   (0x4000U)
#define SIUL2_IFER0_IFE14_SHIFT                  (14U)
#define SIUL2_IFER0_IFE14_WIDTH                  (1U)
#define SIUL2_IFER0_IFE14(x)                     (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE14_SHIFT)) & SIUL2_IFER0_IFE14_MASK)

#define SIUL2_IFER0_IFE15_MASK                   (0x8000U)
#define SIUL2_IFER0_IFE15_SHIFT                  (15U)
#define SIUL2_IFER0_IFE15_WIDTH                  (1U)
#define SIUL2_IFER0_IFE15(x)                     (((uint32_t)(((uint32_t)(x)) << SIUL2_IFER0_IFE15_SHIFT)) & SIUL2_IFER0_IFE15_MASK)
/*! @} */

/*! @name IFMCR - Interrupt Filter Maximum Counter */
/*! @{ */

#define SIUL2_IFMCR_MAXCNT_MASK                  (0xFU)
#define SIUL2_IFMCR_MAXCNT_SHIFT                 (0U)
#define SIUL2_IFMCR_MAXCNT_WIDTH                 (4U)
#define SIUL2_IFMCR_MAXCNT(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_IFMCR_MAXCNT_SHIFT)) & SIUL2_IFMCR_MAXCNT_MASK)
/*! @} */

/*! @name IFCPR - Interrupt Filter Clock Prescaler */
/*! @{ */

#define SIUL2_IFCPR_IFCP_MASK                    (0xFU)
#define SIUL2_IFCPR_IFCP_SHIFT                   (0U)
#define SIUL2_IFCPR_IFCP_WIDTH                   (4U)
#define SIUL2_IFCPR_IFCP(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_IFCPR_IFCP_SHIFT)) & SIUL2_IFCPR_IFCP_MASK)
/*! @} */

/*! @name UDR1 - User Defined */
/*! @{ */

#define SIUL2_UDR1_UDR0_MASK                     (0x1U)
#define SIUL2_UDR1_UDR0_SHIFT                    (0U)
#define SIUL2_UDR1_UDR0_WIDTH                    (1U)
#define SIUL2_UDR1_UDR0(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR0_SHIFT)) & SIUL2_UDR1_UDR0_MASK)

#define SIUL2_UDR1_UDR1_MASK                     (0x2U)
#define SIUL2_UDR1_UDR1_SHIFT                    (1U)
#define SIUL2_UDR1_UDR1_WIDTH                    (1U)
#define SIUL2_UDR1_UDR1(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR1_SHIFT)) & SIUL2_UDR1_UDR1_MASK)

#define SIUL2_UDR1_UDR2_MASK                     (0x4U)
#define SIUL2_UDR1_UDR2_SHIFT                    (2U)
#define SIUL2_UDR1_UDR2_WIDTH                    (1U)
#define SIUL2_UDR1_UDR2(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR2_SHIFT)) & SIUL2_UDR1_UDR2_MASK)

#define SIUL2_UDR1_UDR3_MASK                     (0x8U)
#define SIUL2_UDR1_UDR3_SHIFT                    (3U)
#define SIUL2_UDR1_UDR3_WIDTH                    (1U)
#define SIUL2_UDR1_UDR3(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR3_SHIFT)) & SIUL2_UDR1_UDR3_MASK)

#define SIUL2_UDR1_UDR4_MASK                     (0x10U)
#define SIUL2_UDR1_UDR4_SHIFT                    (4U)
#define SIUL2_UDR1_UDR4_WIDTH                    (1U)
#define SIUL2_UDR1_UDR4(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR4_SHIFT)) & SIUL2_UDR1_UDR4_MASK)

#define SIUL2_UDR1_UDR5_MASK                     (0x20U)
#define SIUL2_UDR1_UDR5_SHIFT                    (5U)
#define SIUL2_UDR1_UDR5_WIDTH                    (1U)
#define SIUL2_UDR1_UDR5(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR5_SHIFT)) & SIUL2_UDR1_UDR5_MASK)

#define SIUL2_UDR1_UDR6_MASK                     (0x40U)
#define SIUL2_UDR1_UDR6_SHIFT                    (6U)
#define SIUL2_UDR1_UDR6_WIDTH                    (1U)
#define SIUL2_UDR1_UDR6(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR6_SHIFT)) & SIUL2_UDR1_UDR6_MASK)

#define SIUL2_UDR1_UDR7_MASK                     (0x80U)
#define SIUL2_UDR1_UDR7_SHIFT                    (7U)
#define SIUL2_UDR1_UDR7_WIDTH                    (1U)
#define SIUL2_UDR1_UDR7(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR7_SHIFT)) & SIUL2_UDR1_UDR7_MASK)

#define SIUL2_UDR1_UDR8_MASK                     (0x100U)
#define SIUL2_UDR1_UDR8_SHIFT                    (8U)
#define SIUL2_UDR1_UDR8_WIDTH                    (1U)
#define SIUL2_UDR1_UDR8(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR8_SHIFT)) & SIUL2_UDR1_UDR8_MASK)

#define SIUL2_UDR1_UDR9_MASK                     (0x200U)
#define SIUL2_UDR1_UDR9_SHIFT                    (9U)
#define SIUL2_UDR1_UDR9_WIDTH                    (1U)
#define SIUL2_UDR1_UDR9(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR9_SHIFT)) & SIUL2_UDR1_UDR9_MASK)

#define SIUL2_UDR1_UDR10_MASK                    (0x400U)
#define SIUL2_UDR1_UDR10_SHIFT                   (10U)
#define SIUL2_UDR1_UDR10_WIDTH                   (1U)
#define SIUL2_UDR1_UDR10(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR10_SHIFT)) & SIUL2_UDR1_UDR10_MASK)

#define SIUL2_UDR1_UDR11_MASK                    (0x800U)
#define SIUL2_UDR1_UDR11_SHIFT                   (11U)
#define SIUL2_UDR1_UDR11_WIDTH                   (1U)
#define SIUL2_UDR1_UDR11(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR11_SHIFT)) & SIUL2_UDR1_UDR11_MASK)

#define SIUL2_UDR1_UDR12_MASK                    (0x1000U)
#define SIUL2_UDR1_UDR12_SHIFT                   (12U)
#define SIUL2_UDR1_UDR12_WIDTH                   (1U)
#define SIUL2_UDR1_UDR12(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR12_SHIFT)) & SIUL2_UDR1_UDR12_MASK)

#define SIUL2_UDR1_UDR13_MASK                    (0x2000U)
#define SIUL2_UDR1_UDR13_SHIFT                   (13U)
#define SIUL2_UDR1_UDR13_WIDTH                   (1U)
#define SIUL2_UDR1_UDR13(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR13_SHIFT)) & SIUL2_UDR1_UDR13_MASK)

#define SIUL2_UDR1_UDR14_MASK                    (0x4000U)
#define SIUL2_UDR1_UDR14_SHIFT                   (14U)
#define SIUL2_UDR1_UDR14_WIDTH                   (1U)
#define SIUL2_UDR1_UDR14(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR14_SHIFT)) & SIUL2_UDR1_UDR14_MASK)

#define SIUL2_UDR1_UDR15_MASK                    (0x8000U)
#define SIUL2_UDR1_UDR15_SHIFT                   (15U)
#define SIUL2_UDR1_UDR15_WIDTH                   (1U)
#define SIUL2_UDR1_UDR15(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR15_SHIFT)) & SIUL2_UDR1_UDR15_MASK)

#define SIUL2_UDR1_UDR16_MASK                    (0x10000U)
#define SIUL2_UDR1_UDR16_SHIFT                   (16U)
#define SIUL2_UDR1_UDR16_WIDTH                   (1U)
#define SIUL2_UDR1_UDR16(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR16_SHIFT)) & SIUL2_UDR1_UDR16_MASK)

#define SIUL2_UDR1_UDR17_MASK                    (0x20000U)
#define SIUL2_UDR1_UDR17_SHIFT                   (17U)
#define SIUL2_UDR1_UDR17_WIDTH                   (1U)
#define SIUL2_UDR1_UDR17(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR17_SHIFT)) & SIUL2_UDR1_UDR17_MASK)

#define SIUL2_UDR1_UDR18_MASK                    (0x40000U)
#define SIUL2_UDR1_UDR18_SHIFT                   (18U)
#define SIUL2_UDR1_UDR18_WIDTH                   (1U)
#define SIUL2_UDR1_UDR18(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR18_SHIFT)) & SIUL2_UDR1_UDR18_MASK)

#define SIUL2_UDR1_UDR19_MASK                    (0x80000U)
#define SIUL2_UDR1_UDR19_SHIFT                   (19U)
#define SIUL2_UDR1_UDR19_WIDTH                   (1U)
#define SIUL2_UDR1_UDR19(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR19_SHIFT)) & SIUL2_UDR1_UDR19_MASK)

#define SIUL2_UDR1_UDR20_MASK                    (0x100000U)
#define SIUL2_UDR1_UDR20_SHIFT                   (20U)
#define SIUL2_UDR1_UDR20_WIDTH                   (1U)
#define SIUL2_UDR1_UDR20(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR20_SHIFT)) & SIUL2_UDR1_UDR20_MASK)

#define SIUL2_UDR1_UDR21_MASK                    (0x200000U)
#define SIUL2_UDR1_UDR21_SHIFT                   (21U)
#define SIUL2_UDR1_UDR21_WIDTH                   (1U)
#define SIUL2_UDR1_UDR21(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR21_SHIFT)) & SIUL2_UDR1_UDR21_MASK)

#define SIUL2_UDR1_UDR22_MASK                    (0x400000U)
#define SIUL2_UDR1_UDR22_SHIFT                   (22U)
#define SIUL2_UDR1_UDR22_WIDTH                   (1U)
#define SIUL2_UDR1_UDR22(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR22_SHIFT)) & SIUL2_UDR1_UDR22_MASK)

#define SIUL2_UDR1_UDR23_MASK                    (0x800000U)
#define SIUL2_UDR1_UDR23_SHIFT                   (23U)
#define SIUL2_UDR1_UDR23_WIDTH                   (1U)
#define SIUL2_UDR1_UDR23(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR23_SHIFT)) & SIUL2_UDR1_UDR23_MASK)

#define SIUL2_UDR1_UDR24_MASK                    (0x1000000U)
#define SIUL2_UDR1_UDR24_SHIFT                   (24U)
#define SIUL2_UDR1_UDR24_WIDTH                   (1U)
#define SIUL2_UDR1_UDR24(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR24_SHIFT)) & SIUL2_UDR1_UDR24_MASK)

#define SIUL2_UDR1_UDR25_MASK                    (0x2000000U)
#define SIUL2_UDR1_UDR25_SHIFT                   (25U)
#define SIUL2_UDR1_UDR25_WIDTH                   (1U)
#define SIUL2_UDR1_UDR25(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR25_SHIFT)) & SIUL2_UDR1_UDR25_MASK)

#define SIUL2_UDR1_UDR26_MASK                    (0x4000000U)
#define SIUL2_UDR1_UDR26_SHIFT                   (26U)
#define SIUL2_UDR1_UDR26_WIDTH                   (1U)
#define SIUL2_UDR1_UDR26(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR26_SHIFT)) & SIUL2_UDR1_UDR26_MASK)

#define SIUL2_UDR1_UDR27_MASK                    (0x8000000U)
#define SIUL2_UDR1_UDR27_SHIFT                   (27U)
#define SIUL2_UDR1_UDR27_WIDTH                   (1U)
#define SIUL2_UDR1_UDR27(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR27_SHIFT)) & SIUL2_UDR1_UDR27_MASK)

#define SIUL2_UDR1_UDR28_MASK                    (0x10000000U)
#define SIUL2_UDR1_UDR28_SHIFT                   (28U)
#define SIUL2_UDR1_UDR28_WIDTH                   (1U)
#define SIUL2_UDR1_UDR28(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR28_SHIFT)) & SIUL2_UDR1_UDR28_MASK)

#define SIUL2_UDR1_UDR29_MASK                    (0x20000000U)
#define SIUL2_UDR1_UDR29_SHIFT                   (29U)
#define SIUL2_UDR1_UDR29_WIDTH                   (1U)
#define SIUL2_UDR1_UDR29(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR29_SHIFT)) & SIUL2_UDR1_UDR29_MASK)

#define SIUL2_UDR1_UDR30_MASK                    (0x40000000U)
#define SIUL2_UDR1_UDR30_SHIFT                   (30U)
#define SIUL2_UDR1_UDR30_WIDTH                   (1U)
#define SIUL2_UDR1_UDR30(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR30_SHIFT)) & SIUL2_UDR1_UDR30_MASK)

#define SIUL2_UDR1_UDR31_MASK                    (0x80000000U)
#define SIUL2_UDR1_UDR31_SHIFT                   (31U)
#define SIUL2_UDR1_UDR31_WIDTH                   (1U)
#define SIUL2_UDR1_UDR31(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR1_UDR31_SHIFT)) & SIUL2_UDR1_UDR31_MASK)
/*! @} */

/*! @name UDR0 - User Defined */
/*! @{ */

#define SIUL2_UDR0_UDR0_MASK                     (0x1U)
#define SIUL2_UDR0_UDR0_SHIFT                    (0U)
#define SIUL2_UDR0_UDR0_WIDTH                    (1U)
#define SIUL2_UDR0_UDR0(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR0_SHIFT)) & SIUL2_UDR0_UDR0_MASK)

#define SIUL2_UDR0_UDR1_MASK                     (0x2U)
#define SIUL2_UDR0_UDR1_SHIFT                    (1U)
#define SIUL2_UDR0_UDR1_WIDTH                    (1U)
#define SIUL2_UDR0_UDR1(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR1_SHIFT)) & SIUL2_UDR0_UDR1_MASK)

#define SIUL2_UDR0_UDR2_MASK                     (0x4U)
#define SIUL2_UDR0_UDR2_SHIFT                    (2U)
#define SIUL2_UDR0_UDR2_WIDTH                    (1U)
#define SIUL2_UDR0_UDR2(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR2_SHIFT)) & SIUL2_UDR0_UDR2_MASK)

#define SIUL2_UDR0_UDR3_MASK                     (0x8U)
#define SIUL2_UDR0_UDR3_SHIFT                    (3U)
#define SIUL2_UDR0_UDR3_WIDTH                    (1U)
#define SIUL2_UDR0_UDR3(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR3_SHIFT)) & SIUL2_UDR0_UDR3_MASK)

#define SIUL2_UDR0_UDR4_MASK                     (0x10U)
#define SIUL2_UDR0_UDR4_SHIFT                    (4U)
#define SIUL2_UDR0_UDR4_WIDTH                    (1U)
#define SIUL2_UDR0_UDR4(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR4_SHIFT)) & SIUL2_UDR0_UDR4_MASK)

#define SIUL2_UDR0_UDR5_MASK                     (0x20U)
#define SIUL2_UDR0_UDR5_SHIFT                    (5U)
#define SIUL2_UDR0_UDR5_WIDTH                    (1U)
#define SIUL2_UDR0_UDR5(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR5_SHIFT)) & SIUL2_UDR0_UDR5_MASK)

#define SIUL2_UDR0_UDR6_MASK                     (0x40U)
#define SIUL2_UDR0_UDR6_SHIFT                    (6U)
#define SIUL2_UDR0_UDR6_WIDTH                    (1U)
#define SIUL2_UDR0_UDR6(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR6_SHIFT)) & SIUL2_UDR0_UDR6_MASK)

#define SIUL2_UDR0_UDR7_MASK                     (0x80U)
#define SIUL2_UDR0_UDR7_SHIFT                    (7U)
#define SIUL2_UDR0_UDR7_WIDTH                    (1U)
#define SIUL2_UDR0_UDR7(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR7_SHIFT)) & SIUL2_UDR0_UDR7_MASK)

#define SIUL2_UDR0_UDR8_MASK                     (0x100U)
#define SIUL2_UDR0_UDR8_SHIFT                    (8U)
#define SIUL2_UDR0_UDR8_WIDTH                    (1U)
#define SIUL2_UDR0_UDR8(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR8_SHIFT)) & SIUL2_UDR0_UDR8_MASK)

#define SIUL2_UDR0_UDR9_MASK                     (0x200U)
#define SIUL2_UDR0_UDR9_SHIFT                    (9U)
#define SIUL2_UDR0_UDR9_WIDTH                    (1U)
#define SIUL2_UDR0_UDR9(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR9_SHIFT)) & SIUL2_UDR0_UDR9_MASK)

#define SIUL2_UDR0_UDR10_MASK                    (0x400U)
#define SIUL2_UDR0_UDR10_SHIFT                   (10U)
#define SIUL2_UDR0_UDR10_WIDTH                   (1U)
#define SIUL2_UDR0_UDR10(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR10_SHIFT)) & SIUL2_UDR0_UDR10_MASK)

#define SIUL2_UDR0_UDR11_MASK                    (0x800U)
#define SIUL2_UDR0_UDR11_SHIFT                   (11U)
#define SIUL2_UDR0_UDR11_WIDTH                   (1U)
#define SIUL2_UDR0_UDR11(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR11_SHIFT)) & SIUL2_UDR0_UDR11_MASK)

#define SIUL2_UDR0_UDR12_MASK                    (0x1000U)
#define SIUL2_UDR0_UDR12_SHIFT                   (12U)
#define SIUL2_UDR0_UDR12_WIDTH                   (1U)
#define SIUL2_UDR0_UDR12(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR12_SHIFT)) & SIUL2_UDR0_UDR12_MASK)

#define SIUL2_UDR0_UDR13_MASK                    (0x2000U)
#define SIUL2_UDR0_UDR13_SHIFT                   (13U)
#define SIUL2_UDR0_UDR13_WIDTH                   (1U)
#define SIUL2_UDR0_UDR13(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR13_SHIFT)) & SIUL2_UDR0_UDR13_MASK)

#define SIUL2_UDR0_UDR14_MASK                    (0x4000U)
#define SIUL2_UDR0_UDR14_SHIFT                   (14U)
#define SIUL2_UDR0_UDR14_WIDTH                   (1U)
#define SIUL2_UDR0_UDR14(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR14_SHIFT)) & SIUL2_UDR0_UDR14_MASK)

#define SIUL2_UDR0_UDR15_MASK                    (0x8000U)
#define SIUL2_UDR0_UDR15_SHIFT                   (15U)
#define SIUL2_UDR0_UDR15_WIDTH                   (1U)
#define SIUL2_UDR0_UDR15(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR15_SHIFT)) & SIUL2_UDR0_UDR15_MASK)

#define SIUL2_UDR0_UDR16_MASK                    (0x10000U)
#define SIUL2_UDR0_UDR16_SHIFT                   (16U)
#define SIUL2_UDR0_UDR16_WIDTH                   (1U)
#define SIUL2_UDR0_UDR16(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR16_SHIFT)) & SIUL2_UDR0_UDR16_MASK)

#define SIUL2_UDR0_UDR17_MASK                    (0x20000U)
#define SIUL2_UDR0_UDR17_SHIFT                   (17U)
#define SIUL2_UDR0_UDR17_WIDTH                   (1U)
#define SIUL2_UDR0_UDR17(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR17_SHIFT)) & SIUL2_UDR0_UDR17_MASK)

#define SIUL2_UDR0_UDR18_MASK                    (0x40000U)
#define SIUL2_UDR0_UDR18_SHIFT                   (18U)
#define SIUL2_UDR0_UDR18_WIDTH                   (1U)
#define SIUL2_UDR0_UDR18(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR18_SHIFT)) & SIUL2_UDR0_UDR18_MASK)

#define SIUL2_UDR0_UDR19_MASK                    (0x80000U)
#define SIUL2_UDR0_UDR19_SHIFT                   (19U)
#define SIUL2_UDR0_UDR19_WIDTH                   (1U)
#define SIUL2_UDR0_UDR19(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR19_SHIFT)) & SIUL2_UDR0_UDR19_MASK)

#define SIUL2_UDR0_UDR20_MASK                    (0x100000U)
#define SIUL2_UDR0_UDR20_SHIFT                   (20U)
#define SIUL2_UDR0_UDR20_WIDTH                   (1U)
#define SIUL2_UDR0_UDR20(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR20_SHIFT)) & SIUL2_UDR0_UDR20_MASK)

#define SIUL2_UDR0_UDR21_MASK                    (0x200000U)
#define SIUL2_UDR0_UDR21_SHIFT                   (21U)
#define SIUL2_UDR0_UDR21_WIDTH                   (1U)
#define SIUL2_UDR0_UDR21(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR21_SHIFT)) & SIUL2_UDR0_UDR21_MASK)

#define SIUL2_UDR0_UDR22_MASK                    (0x400000U)
#define SIUL2_UDR0_UDR22_SHIFT                   (22U)
#define SIUL2_UDR0_UDR22_WIDTH                   (1U)
#define SIUL2_UDR0_UDR22(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR22_SHIFT)) & SIUL2_UDR0_UDR22_MASK)

#define SIUL2_UDR0_UDR23_MASK                    (0x800000U)
#define SIUL2_UDR0_UDR23_SHIFT                   (23U)
#define SIUL2_UDR0_UDR23_WIDTH                   (1U)
#define SIUL2_UDR0_UDR23(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR23_SHIFT)) & SIUL2_UDR0_UDR23_MASK)

#define SIUL2_UDR0_UDR24_MASK                    (0x1000000U)
#define SIUL2_UDR0_UDR24_SHIFT                   (24U)
#define SIUL2_UDR0_UDR24_WIDTH                   (1U)
#define SIUL2_UDR0_UDR24(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR24_SHIFT)) & SIUL2_UDR0_UDR24_MASK)

#define SIUL2_UDR0_UDR25_MASK                    (0x2000000U)
#define SIUL2_UDR0_UDR25_SHIFT                   (25U)
#define SIUL2_UDR0_UDR25_WIDTH                   (1U)
#define SIUL2_UDR0_UDR25(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR25_SHIFT)) & SIUL2_UDR0_UDR25_MASK)

#define SIUL2_UDR0_UDR26_MASK                    (0x4000000U)
#define SIUL2_UDR0_UDR26_SHIFT                   (26U)
#define SIUL2_UDR0_UDR26_WIDTH                   (1U)
#define SIUL2_UDR0_UDR26(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR26_SHIFT)) & SIUL2_UDR0_UDR26_MASK)

#define SIUL2_UDR0_UDR27_MASK                    (0x8000000U)
#define SIUL2_UDR0_UDR27_SHIFT                   (27U)
#define SIUL2_UDR0_UDR27_WIDTH                   (1U)
#define SIUL2_UDR0_UDR27(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR27_SHIFT)) & SIUL2_UDR0_UDR27_MASK)

#define SIUL2_UDR0_UDR28_MASK                    (0x10000000U)
#define SIUL2_UDR0_UDR28_SHIFT                   (28U)
#define SIUL2_UDR0_UDR28_WIDTH                   (1U)
#define SIUL2_UDR0_UDR28(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR28_SHIFT)) & SIUL2_UDR0_UDR28_MASK)

#define SIUL2_UDR0_UDR29_MASK                    (0x20000000U)
#define SIUL2_UDR0_UDR29_SHIFT                   (29U)
#define SIUL2_UDR0_UDR29_WIDTH                   (1U)
#define SIUL2_UDR0_UDR29(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR29_SHIFT)) & SIUL2_UDR0_UDR29_MASK)

#define SIUL2_UDR0_UDR30_MASK                    (0x40000000U)
#define SIUL2_UDR0_UDR30_SHIFT                   (30U)
#define SIUL2_UDR0_UDR30_WIDTH                   (1U)
#define SIUL2_UDR0_UDR30(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR30_SHIFT)) & SIUL2_UDR0_UDR30_MASK)

#define SIUL2_UDR0_UDR31_MASK                    (0x80000000U)
#define SIUL2_UDR0_UDR31_SHIFT                   (31U)
#define SIUL2_UDR0_UDR31_WIDTH                   (1U)
#define SIUL2_UDR0_UDR31(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR0_UDR31_SHIFT)) & SIUL2_UDR0_UDR31_MASK)
/*! @} */

/*! @name UDR3 - User Defined */
/*! @{ */

#define SIUL2_UDR3_UDR0_MASK                     (0x1U)
#define SIUL2_UDR3_UDR0_SHIFT                    (0U)
#define SIUL2_UDR3_UDR0_WIDTH                    (1U)
#define SIUL2_UDR3_UDR0(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR0_SHIFT)) & SIUL2_UDR3_UDR0_MASK)

#define SIUL2_UDR3_UDR1_MASK                     (0x2U)
#define SIUL2_UDR3_UDR1_SHIFT                    (1U)
#define SIUL2_UDR3_UDR1_WIDTH                    (1U)
#define SIUL2_UDR3_UDR1(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR1_SHIFT)) & SIUL2_UDR3_UDR1_MASK)

#define SIUL2_UDR3_UDR2_MASK                     (0x4U)
#define SIUL2_UDR3_UDR2_SHIFT                    (2U)
#define SIUL2_UDR3_UDR2_WIDTH                    (1U)
#define SIUL2_UDR3_UDR2(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR2_SHIFT)) & SIUL2_UDR3_UDR2_MASK)

#define SIUL2_UDR3_UDR3_MASK                     (0x8U)
#define SIUL2_UDR3_UDR3_SHIFT                    (3U)
#define SIUL2_UDR3_UDR3_WIDTH                    (1U)
#define SIUL2_UDR3_UDR3(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR3_SHIFT)) & SIUL2_UDR3_UDR3_MASK)

#define SIUL2_UDR3_UDR4_MASK                     (0x10U)
#define SIUL2_UDR3_UDR4_SHIFT                    (4U)
#define SIUL2_UDR3_UDR4_WIDTH                    (1U)
#define SIUL2_UDR3_UDR4(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR4_SHIFT)) & SIUL2_UDR3_UDR4_MASK)

#define SIUL2_UDR3_UDR5_MASK                     (0x20U)
#define SIUL2_UDR3_UDR5_SHIFT                    (5U)
#define SIUL2_UDR3_UDR5_WIDTH                    (1U)
#define SIUL2_UDR3_UDR5(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR5_SHIFT)) & SIUL2_UDR3_UDR5_MASK)

#define SIUL2_UDR3_UDR6_MASK                     (0x40U)
#define SIUL2_UDR3_UDR6_SHIFT                    (6U)
#define SIUL2_UDR3_UDR6_WIDTH                    (1U)
#define SIUL2_UDR3_UDR6(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR6_SHIFT)) & SIUL2_UDR3_UDR6_MASK)

#define SIUL2_UDR3_UDR7_MASK                     (0x80U)
#define SIUL2_UDR3_UDR7_SHIFT                    (7U)
#define SIUL2_UDR3_UDR7_WIDTH                    (1U)
#define SIUL2_UDR3_UDR7(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR7_SHIFT)) & SIUL2_UDR3_UDR7_MASK)

#define SIUL2_UDR3_UDR8_MASK                     (0x100U)
#define SIUL2_UDR3_UDR8_SHIFT                    (8U)
#define SIUL2_UDR3_UDR8_WIDTH                    (1U)
#define SIUL2_UDR3_UDR8(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR8_SHIFT)) & SIUL2_UDR3_UDR8_MASK)

#define SIUL2_UDR3_UDR9_MASK                     (0x200U)
#define SIUL2_UDR3_UDR9_SHIFT                    (9U)
#define SIUL2_UDR3_UDR9_WIDTH                    (1U)
#define SIUL2_UDR3_UDR9(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR9_SHIFT)) & SIUL2_UDR3_UDR9_MASK)

#define SIUL2_UDR3_UDR10_MASK                    (0x400U)
#define SIUL2_UDR3_UDR10_SHIFT                   (10U)
#define SIUL2_UDR3_UDR10_WIDTH                   (1U)
#define SIUL2_UDR3_UDR10(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR10_SHIFT)) & SIUL2_UDR3_UDR10_MASK)

#define SIUL2_UDR3_UDR11_MASK                    (0x800U)
#define SIUL2_UDR3_UDR11_SHIFT                   (11U)
#define SIUL2_UDR3_UDR11_WIDTH                   (1U)
#define SIUL2_UDR3_UDR11(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR11_SHIFT)) & SIUL2_UDR3_UDR11_MASK)

#define SIUL2_UDR3_UDR12_MASK                    (0x1000U)
#define SIUL2_UDR3_UDR12_SHIFT                   (12U)
#define SIUL2_UDR3_UDR12_WIDTH                   (1U)
#define SIUL2_UDR3_UDR12(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR12_SHIFT)) & SIUL2_UDR3_UDR12_MASK)

#define SIUL2_UDR3_UDR13_MASK                    (0x2000U)
#define SIUL2_UDR3_UDR13_SHIFT                   (13U)
#define SIUL2_UDR3_UDR13_WIDTH                   (1U)
#define SIUL2_UDR3_UDR13(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR13_SHIFT)) & SIUL2_UDR3_UDR13_MASK)

#define SIUL2_UDR3_UDR14_MASK                    (0x4000U)
#define SIUL2_UDR3_UDR14_SHIFT                   (14U)
#define SIUL2_UDR3_UDR14_WIDTH                   (1U)
#define SIUL2_UDR3_UDR14(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR14_SHIFT)) & SIUL2_UDR3_UDR14_MASK)

#define SIUL2_UDR3_UDR15_MASK                    (0x8000U)
#define SIUL2_UDR3_UDR15_SHIFT                   (15U)
#define SIUL2_UDR3_UDR15_WIDTH                   (1U)
#define SIUL2_UDR3_UDR15(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR15_SHIFT)) & SIUL2_UDR3_UDR15_MASK)

#define SIUL2_UDR3_UDR16_MASK                    (0x10000U)
#define SIUL2_UDR3_UDR16_SHIFT                   (16U)
#define SIUL2_UDR3_UDR16_WIDTH                   (1U)
#define SIUL2_UDR3_UDR16(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR16_SHIFT)) & SIUL2_UDR3_UDR16_MASK)

#define SIUL2_UDR3_UDR17_MASK                    (0x20000U)
#define SIUL2_UDR3_UDR17_SHIFT                   (17U)
#define SIUL2_UDR3_UDR17_WIDTH                   (1U)
#define SIUL2_UDR3_UDR17(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR17_SHIFT)) & SIUL2_UDR3_UDR17_MASK)

#define SIUL2_UDR3_UDR18_MASK                    (0x40000U)
#define SIUL2_UDR3_UDR18_SHIFT                   (18U)
#define SIUL2_UDR3_UDR18_WIDTH                   (1U)
#define SIUL2_UDR3_UDR18(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR18_SHIFT)) & SIUL2_UDR3_UDR18_MASK)

#define SIUL2_UDR3_UDR19_MASK                    (0x80000U)
#define SIUL2_UDR3_UDR19_SHIFT                   (19U)
#define SIUL2_UDR3_UDR19_WIDTH                   (1U)
#define SIUL2_UDR3_UDR19(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR19_SHIFT)) & SIUL2_UDR3_UDR19_MASK)

#define SIUL2_UDR3_UDR20_MASK                    (0x100000U)
#define SIUL2_UDR3_UDR20_SHIFT                   (20U)
#define SIUL2_UDR3_UDR20_WIDTH                   (1U)
#define SIUL2_UDR3_UDR20(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR20_SHIFT)) & SIUL2_UDR3_UDR20_MASK)

#define SIUL2_UDR3_UDR21_MASK                    (0x200000U)
#define SIUL2_UDR3_UDR21_SHIFT                   (21U)
#define SIUL2_UDR3_UDR21_WIDTH                   (1U)
#define SIUL2_UDR3_UDR21(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR21_SHIFT)) & SIUL2_UDR3_UDR21_MASK)

#define SIUL2_UDR3_UDR22_MASK                    (0x400000U)
#define SIUL2_UDR3_UDR22_SHIFT                   (22U)
#define SIUL2_UDR3_UDR22_WIDTH                   (1U)
#define SIUL2_UDR3_UDR22(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR22_SHIFT)) & SIUL2_UDR3_UDR22_MASK)

#define SIUL2_UDR3_UDR23_MASK                    (0x800000U)
#define SIUL2_UDR3_UDR23_SHIFT                   (23U)
#define SIUL2_UDR3_UDR23_WIDTH                   (1U)
#define SIUL2_UDR3_UDR23(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR23_SHIFT)) & SIUL2_UDR3_UDR23_MASK)

#define SIUL2_UDR3_UDR24_MASK                    (0x1000000U)
#define SIUL2_UDR3_UDR24_SHIFT                   (24U)
#define SIUL2_UDR3_UDR24_WIDTH                   (1U)
#define SIUL2_UDR3_UDR24(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR24_SHIFT)) & SIUL2_UDR3_UDR24_MASK)

#define SIUL2_UDR3_UDR25_MASK                    (0x2000000U)
#define SIUL2_UDR3_UDR25_SHIFT                   (25U)
#define SIUL2_UDR3_UDR25_WIDTH                   (1U)
#define SIUL2_UDR3_UDR25(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR25_SHIFT)) & SIUL2_UDR3_UDR25_MASK)

#define SIUL2_UDR3_UDR26_MASK                    (0x4000000U)
#define SIUL2_UDR3_UDR26_SHIFT                   (26U)
#define SIUL2_UDR3_UDR26_WIDTH                   (1U)
#define SIUL2_UDR3_UDR26(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR26_SHIFT)) & SIUL2_UDR3_UDR26_MASK)

#define SIUL2_UDR3_UDR27_MASK                    (0x8000000U)
#define SIUL2_UDR3_UDR27_SHIFT                   (27U)
#define SIUL2_UDR3_UDR27_WIDTH                   (1U)
#define SIUL2_UDR3_UDR27(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR27_SHIFT)) & SIUL2_UDR3_UDR27_MASK)

#define SIUL2_UDR3_UDR28_MASK                    (0x10000000U)
#define SIUL2_UDR3_UDR28_SHIFT                   (28U)
#define SIUL2_UDR3_UDR28_WIDTH                   (1U)
#define SIUL2_UDR3_UDR28(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR28_SHIFT)) & SIUL2_UDR3_UDR28_MASK)

#define SIUL2_UDR3_UDR29_MASK                    (0x20000000U)
#define SIUL2_UDR3_UDR29_SHIFT                   (29U)
#define SIUL2_UDR3_UDR29_WIDTH                   (1U)
#define SIUL2_UDR3_UDR29(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR29_SHIFT)) & SIUL2_UDR3_UDR29_MASK)

#define SIUL2_UDR3_UDR30_MASK                    (0x40000000U)
#define SIUL2_UDR3_UDR30_SHIFT                   (30U)
#define SIUL2_UDR3_UDR30_WIDTH                   (1U)
#define SIUL2_UDR3_UDR30(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR30_SHIFT)) & SIUL2_UDR3_UDR30_MASK)

#define SIUL2_UDR3_UDR31_MASK                    (0x80000000U)
#define SIUL2_UDR3_UDR31_SHIFT                   (31U)
#define SIUL2_UDR3_UDR31_WIDTH                   (1U)
#define SIUL2_UDR3_UDR31(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR3_UDR31_SHIFT)) & SIUL2_UDR3_UDR31_MASK)
/*! @} */

/*! @name UDR2 - User Defined */
/*! @{ */

#define SIUL2_UDR2_UDR0_MASK                     (0x1U)
#define SIUL2_UDR2_UDR0_SHIFT                    (0U)
#define SIUL2_UDR2_UDR0_WIDTH                    (1U)
#define SIUL2_UDR2_UDR0(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR0_SHIFT)) & SIUL2_UDR2_UDR0_MASK)

#define SIUL2_UDR2_UDR1_MASK                     (0x2U)
#define SIUL2_UDR2_UDR1_SHIFT                    (1U)
#define SIUL2_UDR2_UDR1_WIDTH                    (1U)
#define SIUL2_UDR2_UDR1(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR1_SHIFT)) & SIUL2_UDR2_UDR1_MASK)

#define SIUL2_UDR2_UDR2_MASK                     (0x4U)
#define SIUL2_UDR2_UDR2_SHIFT                    (2U)
#define SIUL2_UDR2_UDR2_WIDTH                    (1U)
#define SIUL2_UDR2_UDR2(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR2_SHIFT)) & SIUL2_UDR2_UDR2_MASK)

#define SIUL2_UDR2_UDR3_MASK                     (0x8U)
#define SIUL2_UDR2_UDR3_SHIFT                    (3U)
#define SIUL2_UDR2_UDR3_WIDTH                    (1U)
#define SIUL2_UDR2_UDR3(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR3_SHIFT)) & SIUL2_UDR2_UDR3_MASK)

#define SIUL2_UDR2_UDR4_MASK                     (0x10U)
#define SIUL2_UDR2_UDR4_SHIFT                    (4U)
#define SIUL2_UDR2_UDR4_WIDTH                    (1U)
#define SIUL2_UDR2_UDR4(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR4_SHIFT)) & SIUL2_UDR2_UDR4_MASK)

#define SIUL2_UDR2_UDR5_MASK                     (0x20U)
#define SIUL2_UDR2_UDR5_SHIFT                    (5U)
#define SIUL2_UDR2_UDR5_WIDTH                    (1U)
#define SIUL2_UDR2_UDR5(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR5_SHIFT)) & SIUL2_UDR2_UDR5_MASK)

#define SIUL2_UDR2_UDR6_MASK                     (0x40U)
#define SIUL2_UDR2_UDR6_SHIFT                    (6U)
#define SIUL2_UDR2_UDR6_WIDTH                    (1U)
#define SIUL2_UDR2_UDR6(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR6_SHIFT)) & SIUL2_UDR2_UDR6_MASK)

#define SIUL2_UDR2_UDR7_MASK                     (0x80U)
#define SIUL2_UDR2_UDR7_SHIFT                    (7U)
#define SIUL2_UDR2_UDR7_WIDTH                    (1U)
#define SIUL2_UDR2_UDR7(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR7_SHIFT)) & SIUL2_UDR2_UDR7_MASK)

#define SIUL2_UDR2_UDR8_MASK                     (0x100U)
#define SIUL2_UDR2_UDR8_SHIFT                    (8U)
#define SIUL2_UDR2_UDR8_WIDTH                    (1U)
#define SIUL2_UDR2_UDR8(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR8_SHIFT)) & SIUL2_UDR2_UDR8_MASK)

#define SIUL2_UDR2_UDR9_MASK                     (0x200U)
#define SIUL2_UDR2_UDR9_SHIFT                    (9U)
#define SIUL2_UDR2_UDR9_WIDTH                    (1U)
#define SIUL2_UDR2_UDR9(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR9_SHIFT)) & SIUL2_UDR2_UDR9_MASK)

#define SIUL2_UDR2_UDR10_MASK                    (0x400U)
#define SIUL2_UDR2_UDR10_SHIFT                   (10U)
#define SIUL2_UDR2_UDR10_WIDTH                   (1U)
#define SIUL2_UDR2_UDR10(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR10_SHIFT)) & SIUL2_UDR2_UDR10_MASK)

#define SIUL2_UDR2_UDR11_MASK                    (0x800U)
#define SIUL2_UDR2_UDR11_SHIFT                   (11U)
#define SIUL2_UDR2_UDR11_WIDTH                   (1U)
#define SIUL2_UDR2_UDR11(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR11_SHIFT)) & SIUL2_UDR2_UDR11_MASK)

#define SIUL2_UDR2_UDR12_MASK                    (0x1000U)
#define SIUL2_UDR2_UDR12_SHIFT                   (12U)
#define SIUL2_UDR2_UDR12_WIDTH                   (1U)
#define SIUL2_UDR2_UDR12(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR12_SHIFT)) & SIUL2_UDR2_UDR12_MASK)

#define SIUL2_UDR2_UDR13_MASK                    (0x2000U)
#define SIUL2_UDR2_UDR13_SHIFT                   (13U)
#define SIUL2_UDR2_UDR13_WIDTH                   (1U)
#define SIUL2_UDR2_UDR13(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR13_SHIFT)) & SIUL2_UDR2_UDR13_MASK)

#define SIUL2_UDR2_UDR14_MASK                    (0x4000U)
#define SIUL2_UDR2_UDR14_SHIFT                   (14U)
#define SIUL2_UDR2_UDR14_WIDTH                   (1U)
#define SIUL2_UDR2_UDR14(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR14_SHIFT)) & SIUL2_UDR2_UDR14_MASK)

#define SIUL2_UDR2_UDR15_MASK                    (0x8000U)
#define SIUL2_UDR2_UDR15_SHIFT                   (15U)
#define SIUL2_UDR2_UDR15_WIDTH                   (1U)
#define SIUL2_UDR2_UDR15(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR15_SHIFT)) & SIUL2_UDR2_UDR15_MASK)

#define SIUL2_UDR2_UDR16_MASK                    (0x10000U)
#define SIUL2_UDR2_UDR16_SHIFT                   (16U)
#define SIUL2_UDR2_UDR16_WIDTH                   (1U)
#define SIUL2_UDR2_UDR16(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR16_SHIFT)) & SIUL2_UDR2_UDR16_MASK)

#define SIUL2_UDR2_UDR17_MASK                    (0x20000U)
#define SIUL2_UDR2_UDR17_SHIFT                   (17U)
#define SIUL2_UDR2_UDR17_WIDTH                   (1U)
#define SIUL2_UDR2_UDR17(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR17_SHIFT)) & SIUL2_UDR2_UDR17_MASK)

#define SIUL2_UDR2_UDR18_MASK                    (0x40000U)
#define SIUL2_UDR2_UDR18_SHIFT                   (18U)
#define SIUL2_UDR2_UDR18_WIDTH                   (1U)
#define SIUL2_UDR2_UDR18(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR18_SHIFT)) & SIUL2_UDR2_UDR18_MASK)

#define SIUL2_UDR2_UDR19_MASK                    (0x80000U)
#define SIUL2_UDR2_UDR19_SHIFT                   (19U)
#define SIUL2_UDR2_UDR19_WIDTH                   (1U)
#define SIUL2_UDR2_UDR19(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR19_SHIFT)) & SIUL2_UDR2_UDR19_MASK)

#define SIUL2_UDR2_UDR20_MASK                    (0x100000U)
#define SIUL2_UDR2_UDR20_SHIFT                   (20U)
#define SIUL2_UDR2_UDR20_WIDTH                   (1U)
#define SIUL2_UDR2_UDR20(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR20_SHIFT)) & SIUL2_UDR2_UDR20_MASK)

#define SIUL2_UDR2_UDR21_MASK                    (0x200000U)
#define SIUL2_UDR2_UDR21_SHIFT                   (21U)
#define SIUL2_UDR2_UDR21_WIDTH                   (1U)
#define SIUL2_UDR2_UDR21(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR21_SHIFT)) & SIUL2_UDR2_UDR21_MASK)

#define SIUL2_UDR2_UDR22_MASK                    (0x400000U)
#define SIUL2_UDR2_UDR22_SHIFT                   (22U)
#define SIUL2_UDR2_UDR22_WIDTH                   (1U)
#define SIUL2_UDR2_UDR22(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR22_SHIFT)) & SIUL2_UDR2_UDR22_MASK)

#define SIUL2_UDR2_UDR23_MASK                    (0x800000U)
#define SIUL2_UDR2_UDR23_SHIFT                   (23U)
#define SIUL2_UDR2_UDR23_WIDTH                   (1U)
#define SIUL2_UDR2_UDR23(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR23_SHIFT)) & SIUL2_UDR2_UDR23_MASK)

#define SIUL2_UDR2_UDR24_MASK                    (0x1000000U)
#define SIUL2_UDR2_UDR24_SHIFT                   (24U)
#define SIUL2_UDR2_UDR24_WIDTH                   (1U)
#define SIUL2_UDR2_UDR24(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR24_SHIFT)) & SIUL2_UDR2_UDR24_MASK)

#define SIUL2_UDR2_UDR25_MASK                    (0x2000000U)
#define SIUL2_UDR2_UDR25_SHIFT                   (25U)
#define SIUL2_UDR2_UDR25_WIDTH                   (1U)
#define SIUL2_UDR2_UDR25(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR25_SHIFT)) & SIUL2_UDR2_UDR25_MASK)

#define SIUL2_UDR2_UDR26_MASK                    (0x4000000U)
#define SIUL2_UDR2_UDR26_SHIFT                   (26U)
#define SIUL2_UDR2_UDR26_WIDTH                   (1U)
#define SIUL2_UDR2_UDR26(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR26_SHIFT)) & SIUL2_UDR2_UDR26_MASK)

#define SIUL2_UDR2_UDR27_MASK                    (0x8000000U)
#define SIUL2_UDR2_UDR27_SHIFT                   (27U)
#define SIUL2_UDR2_UDR27_WIDTH                   (1U)
#define SIUL2_UDR2_UDR27(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR27_SHIFT)) & SIUL2_UDR2_UDR27_MASK)

#define SIUL2_UDR2_UDR28_MASK                    (0x10000000U)
#define SIUL2_UDR2_UDR28_SHIFT                   (28U)
#define SIUL2_UDR2_UDR28_WIDTH                   (1U)
#define SIUL2_UDR2_UDR28(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR28_SHIFT)) & SIUL2_UDR2_UDR28_MASK)

#define SIUL2_UDR2_UDR29_MASK                    (0x20000000U)
#define SIUL2_UDR2_UDR29_SHIFT                   (29U)
#define SIUL2_UDR2_UDR29_WIDTH                   (1U)
#define SIUL2_UDR2_UDR29(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR29_SHIFT)) & SIUL2_UDR2_UDR29_MASK)

#define SIUL2_UDR2_UDR30_MASK                    (0x40000000U)
#define SIUL2_UDR2_UDR30_SHIFT                   (30U)
#define SIUL2_UDR2_UDR30_WIDTH                   (1U)
#define SIUL2_UDR2_UDR30(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR30_SHIFT)) & SIUL2_UDR2_UDR30_MASK)

#define SIUL2_UDR2_UDR31_MASK                    (0x80000000U)
#define SIUL2_UDR2_UDR31_SHIFT                   (31U)
#define SIUL2_UDR2_UDR31_WIDTH                   (1U)
#define SIUL2_UDR2_UDR31(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR2_UDR31_SHIFT)) & SIUL2_UDR2_UDR31_MASK)
/*! @} */

/*! @name UDR5 - User Defined */
/*! @{ */

#define SIUL2_UDR5_UDR0_MASK                     (0x1U)
#define SIUL2_UDR5_UDR0_SHIFT                    (0U)
#define SIUL2_UDR5_UDR0_WIDTH                    (1U)
#define SIUL2_UDR5_UDR0(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR0_SHIFT)) & SIUL2_UDR5_UDR0_MASK)

#define SIUL2_UDR5_UDR1_MASK                     (0x2U)
#define SIUL2_UDR5_UDR1_SHIFT                    (1U)
#define SIUL2_UDR5_UDR1_WIDTH                    (1U)
#define SIUL2_UDR5_UDR1(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR1_SHIFT)) & SIUL2_UDR5_UDR1_MASK)

#define SIUL2_UDR5_UDR2_MASK                     (0x4U)
#define SIUL2_UDR5_UDR2_SHIFT                    (2U)
#define SIUL2_UDR5_UDR2_WIDTH                    (1U)
#define SIUL2_UDR5_UDR2(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR2_SHIFT)) & SIUL2_UDR5_UDR2_MASK)

#define SIUL2_UDR5_UDR3_MASK                     (0x8U)
#define SIUL2_UDR5_UDR3_SHIFT                    (3U)
#define SIUL2_UDR5_UDR3_WIDTH                    (1U)
#define SIUL2_UDR5_UDR3(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR3_SHIFT)) & SIUL2_UDR5_UDR3_MASK)

#define SIUL2_UDR5_UDR4_MASK                     (0x10U)
#define SIUL2_UDR5_UDR4_SHIFT                    (4U)
#define SIUL2_UDR5_UDR4_WIDTH                    (1U)
#define SIUL2_UDR5_UDR4(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR4_SHIFT)) & SIUL2_UDR5_UDR4_MASK)

#define SIUL2_UDR5_UDR5_MASK                     (0x20U)
#define SIUL2_UDR5_UDR5_SHIFT                    (5U)
#define SIUL2_UDR5_UDR5_WIDTH                    (1U)
#define SIUL2_UDR5_UDR5(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR5_SHIFT)) & SIUL2_UDR5_UDR5_MASK)

#define SIUL2_UDR5_UDR6_MASK                     (0x40U)
#define SIUL2_UDR5_UDR6_SHIFT                    (6U)
#define SIUL2_UDR5_UDR6_WIDTH                    (1U)
#define SIUL2_UDR5_UDR6(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR6_SHIFT)) & SIUL2_UDR5_UDR6_MASK)

#define SIUL2_UDR5_UDR7_MASK                     (0x80U)
#define SIUL2_UDR5_UDR7_SHIFT                    (7U)
#define SIUL2_UDR5_UDR7_WIDTH                    (1U)
#define SIUL2_UDR5_UDR7(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR7_SHIFT)) & SIUL2_UDR5_UDR7_MASK)

#define SIUL2_UDR5_UDR8_MASK                     (0x100U)
#define SIUL2_UDR5_UDR8_SHIFT                    (8U)
#define SIUL2_UDR5_UDR8_WIDTH                    (1U)
#define SIUL2_UDR5_UDR8(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR8_SHIFT)) & SIUL2_UDR5_UDR8_MASK)

#define SIUL2_UDR5_UDR9_MASK                     (0x200U)
#define SIUL2_UDR5_UDR9_SHIFT                    (9U)
#define SIUL2_UDR5_UDR9_WIDTH                    (1U)
#define SIUL2_UDR5_UDR9(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR9_SHIFT)) & SIUL2_UDR5_UDR9_MASK)

#define SIUL2_UDR5_UDR10_MASK                    (0x400U)
#define SIUL2_UDR5_UDR10_SHIFT                   (10U)
#define SIUL2_UDR5_UDR10_WIDTH                   (1U)
#define SIUL2_UDR5_UDR10(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR10_SHIFT)) & SIUL2_UDR5_UDR10_MASK)

#define SIUL2_UDR5_UDR11_MASK                    (0x800U)
#define SIUL2_UDR5_UDR11_SHIFT                   (11U)
#define SIUL2_UDR5_UDR11_WIDTH                   (1U)
#define SIUL2_UDR5_UDR11(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR11_SHIFT)) & SIUL2_UDR5_UDR11_MASK)

#define SIUL2_UDR5_UDR12_MASK                    (0x1000U)
#define SIUL2_UDR5_UDR12_SHIFT                   (12U)
#define SIUL2_UDR5_UDR12_WIDTH                   (1U)
#define SIUL2_UDR5_UDR12(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR12_SHIFT)) & SIUL2_UDR5_UDR12_MASK)

#define SIUL2_UDR5_UDR13_MASK                    (0x2000U)
#define SIUL2_UDR5_UDR13_SHIFT                   (13U)
#define SIUL2_UDR5_UDR13_WIDTH                   (1U)
#define SIUL2_UDR5_UDR13(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR13_SHIFT)) & SIUL2_UDR5_UDR13_MASK)

#define SIUL2_UDR5_UDR14_MASK                    (0x4000U)
#define SIUL2_UDR5_UDR14_SHIFT                   (14U)
#define SIUL2_UDR5_UDR14_WIDTH                   (1U)
#define SIUL2_UDR5_UDR14(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR14_SHIFT)) & SIUL2_UDR5_UDR14_MASK)

#define SIUL2_UDR5_UDR15_MASK                    (0x8000U)
#define SIUL2_UDR5_UDR15_SHIFT                   (15U)
#define SIUL2_UDR5_UDR15_WIDTH                   (1U)
#define SIUL2_UDR5_UDR15(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR15_SHIFT)) & SIUL2_UDR5_UDR15_MASK)

#define SIUL2_UDR5_UDR16_MASK                    (0x10000U)
#define SIUL2_UDR5_UDR16_SHIFT                   (16U)
#define SIUL2_UDR5_UDR16_WIDTH                   (1U)
#define SIUL2_UDR5_UDR16(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR16_SHIFT)) & SIUL2_UDR5_UDR16_MASK)

#define SIUL2_UDR5_UDR17_MASK                    (0x20000U)
#define SIUL2_UDR5_UDR17_SHIFT                   (17U)
#define SIUL2_UDR5_UDR17_WIDTH                   (1U)
#define SIUL2_UDR5_UDR17(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR17_SHIFT)) & SIUL2_UDR5_UDR17_MASK)

#define SIUL2_UDR5_UDR18_MASK                    (0x40000U)
#define SIUL2_UDR5_UDR18_SHIFT                   (18U)
#define SIUL2_UDR5_UDR18_WIDTH                   (1U)
#define SIUL2_UDR5_UDR18(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR18_SHIFT)) & SIUL2_UDR5_UDR18_MASK)

#define SIUL2_UDR5_UDR19_MASK                    (0x80000U)
#define SIUL2_UDR5_UDR19_SHIFT                   (19U)
#define SIUL2_UDR5_UDR19_WIDTH                   (1U)
#define SIUL2_UDR5_UDR19(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR19_SHIFT)) & SIUL2_UDR5_UDR19_MASK)

#define SIUL2_UDR5_UDR20_MASK                    (0x100000U)
#define SIUL2_UDR5_UDR20_SHIFT                   (20U)
#define SIUL2_UDR5_UDR20_WIDTH                   (1U)
#define SIUL2_UDR5_UDR20(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR20_SHIFT)) & SIUL2_UDR5_UDR20_MASK)

#define SIUL2_UDR5_UDR21_MASK                    (0x200000U)
#define SIUL2_UDR5_UDR21_SHIFT                   (21U)
#define SIUL2_UDR5_UDR21_WIDTH                   (1U)
#define SIUL2_UDR5_UDR21(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR21_SHIFT)) & SIUL2_UDR5_UDR21_MASK)

#define SIUL2_UDR5_UDR22_MASK                    (0x400000U)
#define SIUL2_UDR5_UDR22_SHIFT                   (22U)
#define SIUL2_UDR5_UDR22_WIDTH                   (1U)
#define SIUL2_UDR5_UDR22(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR22_SHIFT)) & SIUL2_UDR5_UDR22_MASK)

#define SIUL2_UDR5_UDR23_MASK                    (0x800000U)
#define SIUL2_UDR5_UDR23_SHIFT                   (23U)
#define SIUL2_UDR5_UDR23_WIDTH                   (1U)
#define SIUL2_UDR5_UDR23(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR23_SHIFT)) & SIUL2_UDR5_UDR23_MASK)

#define SIUL2_UDR5_UDR24_MASK                    (0x1000000U)
#define SIUL2_UDR5_UDR24_SHIFT                   (24U)
#define SIUL2_UDR5_UDR24_WIDTH                   (1U)
#define SIUL2_UDR5_UDR24(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR24_SHIFT)) & SIUL2_UDR5_UDR24_MASK)

#define SIUL2_UDR5_UDR25_MASK                    (0x2000000U)
#define SIUL2_UDR5_UDR25_SHIFT                   (25U)
#define SIUL2_UDR5_UDR25_WIDTH                   (1U)
#define SIUL2_UDR5_UDR25(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR25_SHIFT)) & SIUL2_UDR5_UDR25_MASK)

#define SIUL2_UDR5_UDR26_MASK                    (0x4000000U)
#define SIUL2_UDR5_UDR26_SHIFT                   (26U)
#define SIUL2_UDR5_UDR26_WIDTH                   (1U)
#define SIUL2_UDR5_UDR26(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR26_SHIFT)) & SIUL2_UDR5_UDR26_MASK)

#define SIUL2_UDR5_UDR27_MASK                    (0x8000000U)
#define SIUL2_UDR5_UDR27_SHIFT                   (27U)
#define SIUL2_UDR5_UDR27_WIDTH                   (1U)
#define SIUL2_UDR5_UDR27(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR27_SHIFT)) & SIUL2_UDR5_UDR27_MASK)

#define SIUL2_UDR5_UDR28_MASK                    (0x10000000U)
#define SIUL2_UDR5_UDR28_SHIFT                   (28U)
#define SIUL2_UDR5_UDR28_WIDTH                   (1U)
#define SIUL2_UDR5_UDR28(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR28_SHIFT)) & SIUL2_UDR5_UDR28_MASK)

#define SIUL2_UDR5_UDR29_MASK                    (0x20000000U)
#define SIUL2_UDR5_UDR29_SHIFT                   (29U)
#define SIUL2_UDR5_UDR29_WIDTH                   (1U)
#define SIUL2_UDR5_UDR29(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR29_SHIFT)) & SIUL2_UDR5_UDR29_MASK)

#define SIUL2_UDR5_UDR30_MASK                    (0x40000000U)
#define SIUL2_UDR5_UDR30_SHIFT                   (30U)
#define SIUL2_UDR5_UDR30_WIDTH                   (1U)
#define SIUL2_UDR5_UDR30(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR30_SHIFT)) & SIUL2_UDR5_UDR30_MASK)

#define SIUL2_UDR5_UDR31_MASK                    (0x80000000U)
#define SIUL2_UDR5_UDR31_SHIFT                   (31U)
#define SIUL2_UDR5_UDR31_WIDTH                   (1U)
#define SIUL2_UDR5_UDR31(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR5_UDR31_SHIFT)) & SIUL2_UDR5_UDR31_MASK)
/*! @} */

/*! @name UDR4 - User Defined */
/*! @{ */

#define SIUL2_UDR4_UDR0_MASK                     (0x1U)
#define SIUL2_UDR4_UDR0_SHIFT                    (0U)
#define SIUL2_UDR4_UDR0_WIDTH                    (1U)
#define SIUL2_UDR4_UDR0(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR0_SHIFT)) & SIUL2_UDR4_UDR0_MASK)

#define SIUL2_UDR4_UDR1_MASK                     (0x2U)
#define SIUL2_UDR4_UDR1_SHIFT                    (1U)
#define SIUL2_UDR4_UDR1_WIDTH                    (1U)
#define SIUL2_UDR4_UDR1(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR1_SHIFT)) & SIUL2_UDR4_UDR1_MASK)

#define SIUL2_UDR4_UDR2_MASK                     (0x4U)
#define SIUL2_UDR4_UDR2_SHIFT                    (2U)
#define SIUL2_UDR4_UDR2_WIDTH                    (1U)
#define SIUL2_UDR4_UDR2(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR2_SHIFT)) & SIUL2_UDR4_UDR2_MASK)

#define SIUL2_UDR4_UDR3_MASK                     (0x8U)
#define SIUL2_UDR4_UDR3_SHIFT                    (3U)
#define SIUL2_UDR4_UDR3_WIDTH                    (1U)
#define SIUL2_UDR4_UDR3(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR3_SHIFT)) & SIUL2_UDR4_UDR3_MASK)

#define SIUL2_UDR4_UDR4_MASK                     (0x10U)
#define SIUL2_UDR4_UDR4_SHIFT                    (4U)
#define SIUL2_UDR4_UDR4_WIDTH                    (1U)
#define SIUL2_UDR4_UDR4(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR4_SHIFT)) & SIUL2_UDR4_UDR4_MASK)

#define SIUL2_UDR4_UDR5_MASK                     (0x20U)
#define SIUL2_UDR4_UDR5_SHIFT                    (5U)
#define SIUL2_UDR4_UDR5_WIDTH                    (1U)
#define SIUL2_UDR4_UDR5(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR5_SHIFT)) & SIUL2_UDR4_UDR5_MASK)

#define SIUL2_UDR4_UDR6_MASK                     (0x40U)
#define SIUL2_UDR4_UDR6_SHIFT                    (6U)
#define SIUL2_UDR4_UDR6_WIDTH                    (1U)
#define SIUL2_UDR4_UDR6(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR6_SHIFT)) & SIUL2_UDR4_UDR6_MASK)

#define SIUL2_UDR4_UDR7_MASK                     (0x80U)
#define SIUL2_UDR4_UDR7_SHIFT                    (7U)
#define SIUL2_UDR4_UDR7_WIDTH                    (1U)
#define SIUL2_UDR4_UDR7(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR7_SHIFT)) & SIUL2_UDR4_UDR7_MASK)

#define SIUL2_UDR4_UDR8_MASK                     (0x100U)
#define SIUL2_UDR4_UDR8_SHIFT                    (8U)
#define SIUL2_UDR4_UDR8_WIDTH                    (1U)
#define SIUL2_UDR4_UDR8(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR8_SHIFT)) & SIUL2_UDR4_UDR8_MASK)

#define SIUL2_UDR4_UDR9_MASK                     (0x200U)
#define SIUL2_UDR4_UDR9_SHIFT                    (9U)
#define SIUL2_UDR4_UDR9_WIDTH                    (1U)
#define SIUL2_UDR4_UDR9(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR9_SHIFT)) & SIUL2_UDR4_UDR9_MASK)

#define SIUL2_UDR4_UDR10_MASK                    (0x400U)
#define SIUL2_UDR4_UDR10_SHIFT                   (10U)
#define SIUL2_UDR4_UDR10_WIDTH                   (1U)
#define SIUL2_UDR4_UDR10(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR10_SHIFT)) & SIUL2_UDR4_UDR10_MASK)

#define SIUL2_UDR4_UDR11_MASK                    (0x800U)
#define SIUL2_UDR4_UDR11_SHIFT                   (11U)
#define SIUL2_UDR4_UDR11_WIDTH                   (1U)
#define SIUL2_UDR4_UDR11(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR11_SHIFT)) & SIUL2_UDR4_UDR11_MASK)

#define SIUL2_UDR4_UDR12_MASK                    (0x1000U)
#define SIUL2_UDR4_UDR12_SHIFT                   (12U)
#define SIUL2_UDR4_UDR12_WIDTH                   (1U)
#define SIUL2_UDR4_UDR12(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR12_SHIFT)) & SIUL2_UDR4_UDR12_MASK)

#define SIUL2_UDR4_UDR13_MASK                    (0x2000U)
#define SIUL2_UDR4_UDR13_SHIFT                   (13U)
#define SIUL2_UDR4_UDR13_WIDTH                   (1U)
#define SIUL2_UDR4_UDR13(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR13_SHIFT)) & SIUL2_UDR4_UDR13_MASK)

#define SIUL2_UDR4_UDR14_MASK                    (0x4000U)
#define SIUL2_UDR4_UDR14_SHIFT                   (14U)
#define SIUL2_UDR4_UDR14_WIDTH                   (1U)
#define SIUL2_UDR4_UDR14(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR14_SHIFT)) & SIUL2_UDR4_UDR14_MASK)

#define SIUL2_UDR4_UDR15_MASK                    (0x8000U)
#define SIUL2_UDR4_UDR15_SHIFT                   (15U)
#define SIUL2_UDR4_UDR15_WIDTH                   (1U)
#define SIUL2_UDR4_UDR15(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR15_SHIFT)) & SIUL2_UDR4_UDR15_MASK)

#define SIUL2_UDR4_UDR16_MASK                    (0x10000U)
#define SIUL2_UDR4_UDR16_SHIFT                   (16U)
#define SIUL2_UDR4_UDR16_WIDTH                   (1U)
#define SIUL2_UDR4_UDR16(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR16_SHIFT)) & SIUL2_UDR4_UDR16_MASK)

#define SIUL2_UDR4_UDR17_MASK                    (0x20000U)
#define SIUL2_UDR4_UDR17_SHIFT                   (17U)
#define SIUL2_UDR4_UDR17_WIDTH                   (1U)
#define SIUL2_UDR4_UDR17(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR17_SHIFT)) & SIUL2_UDR4_UDR17_MASK)

#define SIUL2_UDR4_UDR18_MASK                    (0x40000U)
#define SIUL2_UDR4_UDR18_SHIFT                   (18U)
#define SIUL2_UDR4_UDR18_WIDTH                   (1U)
#define SIUL2_UDR4_UDR18(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR18_SHIFT)) & SIUL2_UDR4_UDR18_MASK)

#define SIUL2_UDR4_UDR19_MASK                    (0x80000U)
#define SIUL2_UDR4_UDR19_SHIFT                   (19U)
#define SIUL2_UDR4_UDR19_WIDTH                   (1U)
#define SIUL2_UDR4_UDR19(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR19_SHIFT)) & SIUL2_UDR4_UDR19_MASK)

#define SIUL2_UDR4_UDR20_MASK                    (0x100000U)
#define SIUL2_UDR4_UDR20_SHIFT                   (20U)
#define SIUL2_UDR4_UDR20_WIDTH                   (1U)
#define SIUL2_UDR4_UDR20(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR20_SHIFT)) & SIUL2_UDR4_UDR20_MASK)

#define SIUL2_UDR4_UDR21_MASK                    (0x200000U)
#define SIUL2_UDR4_UDR21_SHIFT                   (21U)
#define SIUL2_UDR4_UDR21_WIDTH                   (1U)
#define SIUL2_UDR4_UDR21(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR21_SHIFT)) & SIUL2_UDR4_UDR21_MASK)

#define SIUL2_UDR4_UDR22_MASK                    (0x400000U)
#define SIUL2_UDR4_UDR22_SHIFT                   (22U)
#define SIUL2_UDR4_UDR22_WIDTH                   (1U)
#define SIUL2_UDR4_UDR22(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR22_SHIFT)) & SIUL2_UDR4_UDR22_MASK)

#define SIUL2_UDR4_UDR23_MASK                    (0x800000U)
#define SIUL2_UDR4_UDR23_SHIFT                   (23U)
#define SIUL2_UDR4_UDR23_WIDTH                   (1U)
#define SIUL2_UDR4_UDR23(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR23_SHIFT)) & SIUL2_UDR4_UDR23_MASK)

#define SIUL2_UDR4_UDR24_MASK                    (0x1000000U)
#define SIUL2_UDR4_UDR24_SHIFT                   (24U)
#define SIUL2_UDR4_UDR24_WIDTH                   (1U)
#define SIUL2_UDR4_UDR24(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR24_SHIFT)) & SIUL2_UDR4_UDR24_MASK)

#define SIUL2_UDR4_UDR25_MASK                    (0x2000000U)
#define SIUL2_UDR4_UDR25_SHIFT                   (25U)
#define SIUL2_UDR4_UDR25_WIDTH                   (1U)
#define SIUL2_UDR4_UDR25(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR25_SHIFT)) & SIUL2_UDR4_UDR25_MASK)

#define SIUL2_UDR4_UDR26_MASK                    (0x4000000U)
#define SIUL2_UDR4_UDR26_SHIFT                   (26U)
#define SIUL2_UDR4_UDR26_WIDTH                   (1U)
#define SIUL2_UDR4_UDR26(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR26_SHIFT)) & SIUL2_UDR4_UDR26_MASK)

#define SIUL2_UDR4_UDR27_MASK                    (0x8000000U)
#define SIUL2_UDR4_UDR27_SHIFT                   (27U)
#define SIUL2_UDR4_UDR27_WIDTH                   (1U)
#define SIUL2_UDR4_UDR27(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR27_SHIFT)) & SIUL2_UDR4_UDR27_MASK)

#define SIUL2_UDR4_UDR28_MASK                    (0x10000000U)
#define SIUL2_UDR4_UDR28_SHIFT                   (28U)
#define SIUL2_UDR4_UDR28_WIDTH                   (1U)
#define SIUL2_UDR4_UDR28(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR28_SHIFT)) & SIUL2_UDR4_UDR28_MASK)

#define SIUL2_UDR4_UDR29_MASK                    (0x20000000U)
#define SIUL2_UDR4_UDR29_SHIFT                   (29U)
#define SIUL2_UDR4_UDR29_WIDTH                   (1U)
#define SIUL2_UDR4_UDR29(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR29_SHIFT)) & SIUL2_UDR4_UDR29_MASK)

#define SIUL2_UDR4_UDR30_MASK                    (0x40000000U)
#define SIUL2_UDR4_UDR30_SHIFT                   (30U)
#define SIUL2_UDR4_UDR30_WIDTH                   (1U)
#define SIUL2_UDR4_UDR30(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR30_SHIFT)) & SIUL2_UDR4_UDR30_MASK)

#define SIUL2_UDR4_UDR31_MASK                    (0x80000000U)
#define SIUL2_UDR4_UDR31_SHIFT                   (31U)
#define SIUL2_UDR4_UDR31_WIDTH                   (1U)
#define SIUL2_UDR4_UDR31(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_UDR4_UDR31_SHIFT)) & SIUL2_UDR4_UDR31_MASK)
/*! @} */

/*! @name MIDR3 - SIUL2 MCU ID Register #3 */
/*! @{ */

#define SIUL2_MIDR3_PLAT_RAM_SIZE_MASK           (0x1FU)
#define SIUL2_MIDR3_PLAT_RAM_SIZE_SHIFT          (0U)
#define SIUL2_MIDR3_PLAT_RAM_SIZE_WIDTH          (5U)
#define SIUL2_MIDR3_PLAT_RAM_SIZE(x)             (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR3_PLAT_RAM_SIZE_SHIFT)) & SIUL2_MIDR3_PLAT_RAM_SIZE_MASK)

#define SIUL2_MIDR3_STANDBY_RAM_SIZE_MASK        (0xE0U)
#define SIUL2_MIDR3_STANDBY_RAM_SIZE_SHIFT       (5U)
#define SIUL2_MIDR3_STANDBY_RAM_SIZE_WIDTH       (3U)
#define SIUL2_MIDR3_STANDBY_RAM_SIZE(x)          (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR3_STANDBY_RAM_SIZE_SHIFT)) & SIUL2_MIDR3_STANDBY_RAM_SIZE_MASK)

#define SIUL2_MIDR3_PART_NO_SUF_MASK             (0xFC00U)
#define SIUL2_MIDR3_PART_NO_SUF_SHIFT            (10U)
#define SIUL2_MIDR3_PART_NO_SUF_WIDTH            (6U)
#define SIUL2_MIDR3_PART_NO_SUF(x)               (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR3_PART_NO_SUF_SHIFT)) & SIUL2_MIDR3_PART_NO_SUF_MASK)

#define SIUL2_MIDR3_PROD_FAM_NO_MASK             (0x3FF0000U)
#define SIUL2_MIDR3_PROD_FAM_NO_SHIFT            (16U)
#define SIUL2_MIDR3_PROD_FAM_NO_WIDTH            (10U)
#define SIUL2_MIDR3_PROD_FAM_NO(x)               (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR3_PROD_FAM_NO_SHIFT)) & SIUL2_MIDR3_PROD_FAM_NO_MASK)

#define SIUL2_MIDR3_PROD_FAM_LET_MASK            (0xFC000000U)
#define SIUL2_MIDR3_PROD_FAM_LET_SHIFT           (26U)
#define SIUL2_MIDR3_PROD_FAM_LET_WIDTH           (6U)
#define SIUL2_MIDR3_PROD_FAM_LET(x)              (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR3_PROD_FAM_LET_SHIFT)) & SIUL2_MIDR3_PROD_FAM_LET_MASK)
/*! @} */

/*! @name MIDR4 - SIUL2 MCU ID Register #4 */
/*! @{ */

#define SIUL2_MIDR4_CORE_PLAT_FET_MASK           (0x1FU)
#define SIUL2_MIDR4_CORE_PLAT_FET_SHIFT          (0U)
#define SIUL2_MIDR4_CORE_PLAT_FET_WIDTH          (5U)
#define SIUL2_MIDR4_CORE_PLAT_FET(x)             (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR4_CORE_PLAT_FET_SHIFT)) & SIUL2_MIDR4_CORE_PLAT_FET_MASK)

#define SIUL2_MIDR4_ENET_MASK                    (0x20U)
#define SIUL2_MIDR4_ENET_SHIFT                   (5U)
#define SIUL2_MIDR4_ENET_WIDTH                   (1U)
#define SIUL2_MIDR4_ENET(x)                      (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR4_ENET_SHIFT)) & SIUL2_MIDR4_ENET_MASK)

#define SIUL2_MIDR4_DSP_MASK                     (0x40U)
#define SIUL2_MIDR4_DSP_SHIFT                    (6U)
#define SIUL2_MIDR4_DSP_WIDTH                    (1U)
#define SIUL2_MIDR4_DSP(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR4_DSP_SHIFT)) & SIUL2_MIDR4_DSP_MASK)

#define SIUL2_MIDR4_NEUTRON_MASK                 (0x80U)
#define SIUL2_MIDR4_NEUTRON_SHIFT                (7U)
#define SIUL2_MIDR4_NEUTRON_WIDTH                (1U)
#define SIUL2_MIDR4_NEUTRON(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR4_NEUTRON_SHIFT)) & SIUL2_MIDR4_NEUTRON_MASK)

#define SIUL2_MIDR4_CM7_CORE_TCM_MASK            (0x1C00U)
#define SIUL2_MIDR4_CM7_CORE_TCM_SHIFT           (10U)
#define SIUL2_MIDR4_CM7_CORE_TCM_WIDTH           (3U)
#define SIUL2_MIDR4_CM7_CORE_TCM(x)              (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR4_CM7_CORE_TCM_SHIFT)) & SIUL2_MIDR4_CM7_CORE_TCM_MASK)

#define SIUL2_MIDR4_CPE_CORE_TCM_MASK            (0xE000U)
#define SIUL2_MIDR4_CPE_CORE_TCM_SHIFT           (13U)
#define SIUL2_MIDR4_CPE_CORE_TCM_WIDTH           (3U)
#define SIUL2_MIDR4_CPE_CORE_TCM(x)              (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR4_CPE_CORE_TCM_SHIFT)) & SIUL2_MIDR4_CPE_CORE_TCM_MASK)

#define SIUL2_MIDR4_CPE_RAM_SZ_MASK              (0x7000000U)
#define SIUL2_MIDR4_CPE_RAM_SZ_SHIFT             (24U)
#define SIUL2_MIDR4_CPE_RAM_SZ_WIDTH             (3U)
#define SIUL2_MIDR4_CPE_RAM_SZ(x)                (((uint32_t)(((uint32_t)(x)) << SIUL2_MIDR4_CPE_RAM_SZ_SHIFT)) & SIUL2_MIDR4_CPE_RAM_SZ_MASK)
/*! @} */

/*! @name MSCR - Multiplexed Signal Configuration */
/*! @{ */

#define SIUL2_MSCR_SSS_MASK                      (0xFU)
#define SIUL2_MSCR_SSS_SHIFT                     (0U)
#define SIUL2_MSCR_SSS_WIDTH                     (4U)
#define SIUL2_MSCR_SSS(x)                        (((uint32_t)(((uint32_t)(x)) << SIUL2_MSCR_SSS_SHIFT)) & SIUL2_MSCR_SSS_MASK)

#define SIUL2_MSCR_SMC_MASK                      (0x20U)
#define SIUL2_MSCR_SMC_SHIFT                     (5U)
#define SIUL2_MSCR_SMC_WIDTH                     (1U)
#define SIUL2_MSCR_SMC(x)                        (((uint32_t)(((uint32_t)(x)) << SIUL2_MSCR_SMC_SHIFT)) & SIUL2_MSCR_SMC_MASK)

#define SIUL2_MSCR_IFE_MASK                      (0x40U)
#define SIUL2_MSCR_IFE_SHIFT                     (6U)
#define SIUL2_MSCR_IFE_WIDTH                     (1U)
#define SIUL2_MSCR_IFE(x)                        (((uint32_t)(((uint32_t)(x)) << SIUL2_MSCR_IFE_SHIFT)) & SIUL2_MSCR_IFE_MASK)

#define SIUL2_MSCR_DSE_MASK                      (0x100U)
#define SIUL2_MSCR_DSE_SHIFT                     (8U)
#define SIUL2_MSCR_DSE_WIDTH                     (1U)
#define SIUL2_MSCR_DSE(x)                        (((uint32_t)(((uint32_t)(x)) << SIUL2_MSCR_DSE_SHIFT)) & SIUL2_MSCR_DSE_MASK)

#define SIUL2_MSCR_PUE_MASK                      (0x400U)
#define SIUL2_MSCR_PUE_SHIFT                     (10U)
#define SIUL2_MSCR_PUE_WIDTH                     (1U)
#define SIUL2_MSCR_PUE(x)                        (((uint32_t)(((uint32_t)(x)) << SIUL2_MSCR_PUE_SHIFT)) & SIUL2_MSCR_PUE_MASK)

#define SIUL2_MSCR_PUS_MASK                      (0x800U)
#define SIUL2_MSCR_PUS_SHIFT                     (11U)
#define SIUL2_MSCR_PUS_WIDTH                     (1U)
#define SIUL2_MSCR_PUS(x)                        (((uint32_t)(((uint32_t)(x)) << SIUL2_MSCR_PUS_SHIFT)) & SIUL2_MSCR_PUS_MASK)

#define SIUL2_MSCR_SRC_MASK                      (0x7000U)
#define SIUL2_MSCR_SRC_SHIFT                     (12U)
#define SIUL2_MSCR_SRC_WIDTH                     (3U)
#define SIUL2_MSCR_SRC(x)                        (((uint32_t)(((uint32_t)(x)) << SIUL2_MSCR_SRC_SHIFT)) & SIUL2_MSCR_SRC_MASK)

#define SIUL2_MSCR_PKE_PD1_MASK                  (0x8000U)
#define SIUL2_MSCR_PKE_PD1_SHIFT                 (15U)
#define SIUL2_MSCR_PKE_PD1_WIDTH                 (1U)
#define SIUL2_MSCR_PKE_PD1(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_MSCR_PKE_PD1_SHIFT)) & SIUL2_MSCR_PKE_PD1_MASK)

#define SIUL2_MSCR_PKE_PD2_MASK                  (0x10000U)
#define SIUL2_MSCR_PKE_PD2_SHIFT                 (16U)
#define SIUL2_MSCR_PKE_PD2_WIDTH                 (1U)
#define SIUL2_MSCR_PKE_PD2(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_MSCR_PKE_PD2_SHIFT)) & SIUL2_MSCR_PKE_PD2_MASK)

#define SIUL2_MSCR_INV_MASK                      (0x20000U)
#define SIUL2_MSCR_INV_SHIFT                     (17U)
#define SIUL2_MSCR_INV_WIDTH                     (1U)
#define SIUL2_MSCR_INV(x)                        (((uint32_t)(((uint32_t)(x)) << SIUL2_MSCR_INV_SHIFT)) & SIUL2_MSCR_INV_MASK)

#define SIUL2_MSCR_IBE_MASK                      (0x80000U)
#define SIUL2_MSCR_IBE_SHIFT                     (19U)
#define SIUL2_MSCR_IBE_WIDTH                     (1U)
#define SIUL2_MSCR_IBE(x)                        (((uint32_t)(((uint32_t)(x)) << SIUL2_MSCR_IBE_SHIFT)) & SIUL2_MSCR_IBE_MASK)

#define SIUL2_MSCR_OBE_MASK                      (0x200000U)
#define SIUL2_MSCR_OBE_SHIFT                     (21U)
#define SIUL2_MSCR_OBE_WIDTH                     (1U)
#define SIUL2_MSCR_OBE(x)                        (((uint32_t)(((uint32_t)(x)) << SIUL2_MSCR_OBE_SHIFT)) & SIUL2_MSCR_OBE_MASK)

#define SIUL2_MSCR_ICE_MASK                      (0x400000U)
#define SIUL2_MSCR_ICE_SHIFT                     (22U)
#define SIUL2_MSCR_ICE_WIDTH                     (1U)
#define SIUL2_MSCR_ICE(x)                        (((uint32_t)(((uint32_t)(x)) << SIUL2_MSCR_ICE_SHIFT)) & SIUL2_MSCR_ICE_MASK)

#define SIUL2_MSCR_RCVR_MASK                     (0x2000000U)
#define SIUL2_MSCR_RCVR_SHIFT                    (25U)
#define SIUL2_MSCR_RCVR_WIDTH                    (1U)
#define SIUL2_MSCR_RCVR(x)                       (((uint32_t)(((uint32_t)(x)) << SIUL2_MSCR_RCVR_SHIFT)) & SIUL2_MSCR_RCVR_MASK)
/*! @} */

/*! @name IMCR - Input Multiplexed Signal Configuration */
/*! @{ */

#define SIUL2_IMCR_SSS_MASK                      (0xFU)
#define SIUL2_IMCR_SSS_SHIFT                     (0U)
#define SIUL2_IMCR_SSS_WIDTH                     (4U)
#define SIUL2_IMCR_SSS(x)                        (((uint32_t)(((uint32_t)(x)) << SIUL2_IMCR_SSS_SHIFT)) & SIUL2_IMCR_SSS_MASK)
/*! @} */

/*! @name GPDO3 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO3_PDO_n_MASK                   (0x1U)
#define SIUL2_GPDO3_PDO_n_SHIFT                  (0U)
#define SIUL2_GPDO3_PDO_n_WIDTH                  (1U)
#define SIUL2_GPDO3_PDO_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO3_PDO_n_SHIFT)) & SIUL2_GPDO3_PDO_n_MASK)
/*! @} */

/*! @name GPDO2 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO2_PDO_n_MASK                   (0x1U)
#define SIUL2_GPDO2_PDO_n_SHIFT                  (0U)
#define SIUL2_GPDO2_PDO_n_WIDTH                  (1U)
#define SIUL2_GPDO2_PDO_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO2_PDO_n_SHIFT)) & SIUL2_GPDO2_PDO_n_MASK)
/*! @} */

/*! @name GPDO1 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO1_PDO_n_MASK                   (0x1U)
#define SIUL2_GPDO1_PDO_n_SHIFT                  (0U)
#define SIUL2_GPDO1_PDO_n_WIDTH                  (1U)
#define SIUL2_GPDO1_PDO_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO1_PDO_n_SHIFT)) & SIUL2_GPDO1_PDO_n_MASK)
/*! @} */

/*! @name GPDO0 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO0_PDO_n_MASK                   (0x1U)
#define SIUL2_GPDO0_PDO_n_SHIFT                  (0U)
#define SIUL2_GPDO0_PDO_n_WIDTH                  (1U)
#define SIUL2_GPDO0_PDO_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO0_PDO_n_SHIFT)) & SIUL2_GPDO0_PDO_n_MASK)
/*! @} */

/*! @name GPDO7 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO7_PDO_n_MASK                   (0x1U)
#define SIUL2_GPDO7_PDO_n_SHIFT                  (0U)
#define SIUL2_GPDO7_PDO_n_WIDTH                  (1U)
#define SIUL2_GPDO7_PDO_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO7_PDO_n_SHIFT)) & SIUL2_GPDO7_PDO_n_MASK)
/*! @} */

/*! @name GPDO6 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO6_PDO_n_MASK                   (0x1U)
#define SIUL2_GPDO6_PDO_n_SHIFT                  (0U)
#define SIUL2_GPDO6_PDO_n_WIDTH                  (1U)
#define SIUL2_GPDO6_PDO_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO6_PDO_n_SHIFT)) & SIUL2_GPDO6_PDO_n_MASK)
/*! @} */

/*! @name GPDO5 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO5_PDO_n_MASK                   (0x1U)
#define SIUL2_GPDO5_PDO_n_SHIFT                  (0U)
#define SIUL2_GPDO5_PDO_n_WIDTH                  (1U)
#define SIUL2_GPDO5_PDO_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO5_PDO_n_SHIFT)) & SIUL2_GPDO5_PDO_n_MASK)
/*! @} */

/*! @name GPDO4 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO4_PDO_n_MASK                   (0x1U)
#define SIUL2_GPDO4_PDO_n_SHIFT                  (0U)
#define SIUL2_GPDO4_PDO_n_WIDTH                  (1U)
#define SIUL2_GPDO4_PDO_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO4_PDO_n_SHIFT)) & SIUL2_GPDO4_PDO_n_MASK)
/*! @} */

/*! @name GPDO11 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO11_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO11_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO11_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO11_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO11_PDO_n_SHIFT)) & SIUL2_GPDO11_PDO_n_MASK)
/*! @} */

/*! @name GPDO10 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO10_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO10_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO10_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO10_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO10_PDO_n_SHIFT)) & SIUL2_GPDO10_PDO_n_MASK)
/*! @} */

/*! @name GPDO9 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO9_PDO_n_MASK                   (0x1U)
#define SIUL2_GPDO9_PDO_n_SHIFT                  (0U)
#define SIUL2_GPDO9_PDO_n_WIDTH                  (1U)
#define SIUL2_GPDO9_PDO_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO9_PDO_n_SHIFT)) & SIUL2_GPDO9_PDO_n_MASK)
/*! @} */

/*! @name GPDO8 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO8_PDO_n_MASK                   (0x1U)
#define SIUL2_GPDO8_PDO_n_SHIFT                  (0U)
#define SIUL2_GPDO8_PDO_n_WIDTH                  (1U)
#define SIUL2_GPDO8_PDO_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO8_PDO_n_SHIFT)) & SIUL2_GPDO8_PDO_n_MASK)
/*! @} */

/*! @name GPDO15 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO15_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO15_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO15_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO15_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO15_PDO_n_SHIFT)) & SIUL2_GPDO15_PDO_n_MASK)
/*! @} */

/*! @name GPDO14 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO14_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO14_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO14_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO14_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO14_PDO_n_SHIFT)) & SIUL2_GPDO14_PDO_n_MASK)
/*! @} */

/*! @name GPDO13 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO13_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO13_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO13_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO13_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO13_PDO_n_SHIFT)) & SIUL2_GPDO13_PDO_n_MASK)
/*! @} */

/*! @name GPDO12 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO12_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO12_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO12_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO12_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO12_PDO_n_SHIFT)) & SIUL2_GPDO12_PDO_n_MASK)
/*! @} */

/*! @name GPDO19 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO19_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO19_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO19_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO19_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO19_PDO_n_SHIFT)) & SIUL2_GPDO19_PDO_n_MASK)
/*! @} */

/*! @name GPDO18 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO18_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO18_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO18_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO18_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO18_PDO_n_SHIFT)) & SIUL2_GPDO18_PDO_n_MASK)
/*! @} */

/*! @name GPDO17 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO17_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO17_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO17_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO17_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO17_PDO_n_SHIFT)) & SIUL2_GPDO17_PDO_n_MASK)
/*! @} */

/*! @name GPDO16 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO16_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO16_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO16_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO16_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO16_PDO_n_SHIFT)) & SIUL2_GPDO16_PDO_n_MASK)
/*! @} */

/*! @name GPDO23 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO23_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO23_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO23_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO23_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO23_PDO_n_SHIFT)) & SIUL2_GPDO23_PDO_n_MASK)
/*! @} */

/*! @name GPDO22 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO22_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO22_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO22_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO22_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO22_PDO_n_SHIFT)) & SIUL2_GPDO22_PDO_n_MASK)
/*! @} */

/*! @name GPDO21 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO21_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO21_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO21_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO21_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO21_PDO_n_SHIFT)) & SIUL2_GPDO21_PDO_n_MASK)
/*! @} */

/*! @name GPDO20 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO20_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO20_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO20_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO20_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO20_PDO_n_SHIFT)) & SIUL2_GPDO20_PDO_n_MASK)
/*! @} */

/*! @name GPDO27 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO27_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO27_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO27_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO27_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO27_PDO_n_SHIFT)) & SIUL2_GPDO27_PDO_n_MASK)
/*! @} */

/*! @name GPDO26 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO26_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO26_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO26_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO26_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO26_PDO_n_SHIFT)) & SIUL2_GPDO26_PDO_n_MASK)
/*! @} */

/*! @name GPDO25 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO25_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO25_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO25_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO25_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO25_PDO_n_SHIFT)) & SIUL2_GPDO25_PDO_n_MASK)
/*! @} */

/*! @name GPDO24 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO24_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO24_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO24_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO24_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO24_PDO_n_SHIFT)) & SIUL2_GPDO24_PDO_n_MASK)
/*! @} */

/*! @name GPDO31 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO31_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO31_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO31_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO31_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO31_PDO_n_SHIFT)) & SIUL2_GPDO31_PDO_n_MASK)
/*! @} */

/*! @name GPDO30 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO30_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO30_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO30_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO30_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO30_PDO_n_SHIFT)) & SIUL2_GPDO30_PDO_n_MASK)
/*! @} */

/*! @name GPDO29 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO29_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO29_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO29_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO29_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO29_PDO_n_SHIFT)) & SIUL2_GPDO29_PDO_n_MASK)
/*! @} */

/*! @name GPDO28 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO28_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO28_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO28_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO28_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO28_PDO_n_SHIFT)) & SIUL2_GPDO28_PDO_n_MASK)
/*! @} */

/*! @name GPDO35 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO35_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO35_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO35_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO35_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO35_PDO_n_SHIFT)) & SIUL2_GPDO35_PDO_n_MASK)
/*! @} */

/*! @name GPDO34 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO34_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO34_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO34_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO34_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO34_PDO_n_SHIFT)) & SIUL2_GPDO34_PDO_n_MASK)
/*! @} */

/*! @name GPDO33 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO33_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO33_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO33_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO33_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO33_PDO_n_SHIFT)) & SIUL2_GPDO33_PDO_n_MASK)
/*! @} */

/*! @name GPDO32 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO32_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO32_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO32_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO32_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO32_PDO_n_SHIFT)) & SIUL2_GPDO32_PDO_n_MASK)
/*! @} */

/*! @name GPDO39 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO39_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO39_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO39_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO39_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO39_PDO_n_SHIFT)) & SIUL2_GPDO39_PDO_n_MASK)
/*! @} */

/*! @name GPDO38 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO38_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO38_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO38_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO38_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO38_PDO_n_SHIFT)) & SIUL2_GPDO38_PDO_n_MASK)
/*! @} */

/*! @name GPDO37 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO37_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO37_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO37_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO37_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO37_PDO_n_SHIFT)) & SIUL2_GPDO37_PDO_n_MASK)
/*! @} */

/*! @name GPDO36 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO36_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO36_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO36_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO36_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO36_PDO_n_SHIFT)) & SIUL2_GPDO36_PDO_n_MASK)
/*! @} */

/*! @name GPDO43 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO43_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO43_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO43_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO43_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO43_PDO_n_SHIFT)) & SIUL2_GPDO43_PDO_n_MASK)
/*! @} */

/*! @name GPDO42 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO42_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO42_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO42_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO42_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO42_PDO_n_SHIFT)) & SIUL2_GPDO42_PDO_n_MASK)
/*! @} */

/*! @name GPDO41 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO41_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO41_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO41_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO41_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO41_PDO_n_SHIFT)) & SIUL2_GPDO41_PDO_n_MASK)
/*! @} */

/*! @name GPDO40 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO40_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO40_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO40_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO40_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO40_PDO_n_SHIFT)) & SIUL2_GPDO40_PDO_n_MASK)
/*! @} */

/*! @name GPDO47 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO47_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO47_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO47_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO47_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO47_PDO_n_SHIFT)) & SIUL2_GPDO47_PDO_n_MASK)
/*! @} */

/*! @name GPDO46 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO46_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO46_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO46_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO46_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO46_PDO_n_SHIFT)) & SIUL2_GPDO46_PDO_n_MASK)
/*! @} */

/*! @name GPDO45 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO45_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO45_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO45_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO45_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO45_PDO_n_SHIFT)) & SIUL2_GPDO45_PDO_n_MASK)
/*! @} */

/*! @name GPDO44 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO44_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO44_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO44_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO44_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO44_PDO_n_SHIFT)) & SIUL2_GPDO44_PDO_n_MASK)
/*! @} */

/*! @name GPDO51 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO51_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO51_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO51_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO51_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO51_PDO_n_SHIFT)) & SIUL2_GPDO51_PDO_n_MASK)
/*! @} */

/*! @name GPDO49 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO49_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO49_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO49_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO49_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO49_PDO_n_SHIFT)) & SIUL2_GPDO49_PDO_n_MASK)
/*! @} */

/*! @name GPDO48 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO48_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO48_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO48_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO48_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO48_PDO_n_SHIFT)) & SIUL2_GPDO48_PDO_n_MASK)
/*! @} */

/*! @name GPDO55 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO55_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO55_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO55_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO55_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO55_PDO_n_SHIFT)) & SIUL2_GPDO55_PDO_n_MASK)
/*! @} */

/*! @name GPDO54 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO54_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO54_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO54_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO54_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO54_PDO_n_SHIFT)) & SIUL2_GPDO54_PDO_n_MASK)
/*! @} */

/*! @name GPDO53 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO53_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO53_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO53_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO53_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO53_PDO_n_SHIFT)) & SIUL2_GPDO53_PDO_n_MASK)
/*! @} */

/*! @name GPDO52 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO52_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO52_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO52_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO52_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO52_PDO_n_SHIFT)) & SIUL2_GPDO52_PDO_n_MASK)
/*! @} */

/*! @name GPDO59 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO59_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO59_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO59_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO59_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO59_PDO_n_SHIFT)) & SIUL2_GPDO59_PDO_n_MASK)
/*! @} */

/*! @name GPDO58 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO58_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO58_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO58_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO58_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO58_PDO_n_SHIFT)) & SIUL2_GPDO58_PDO_n_MASK)
/*! @} */

/*! @name GPDO57 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO57_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO57_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO57_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO57_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO57_PDO_n_SHIFT)) & SIUL2_GPDO57_PDO_n_MASK)
/*! @} */

/*! @name GPDO56 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO56_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO56_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO56_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO56_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO56_PDO_n_SHIFT)) & SIUL2_GPDO56_PDO_n_MASK)
/*! @} */

/*! @name GPDO63 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO63_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO63_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO63_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO63_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO63_PDO_n_SHIFT)) & SIUL2_GPDO63_PDO_n_MASK)
/*! @} */

/*! @name GPDO62 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO62_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO62_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO62_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO62_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO62_PDO_n_SHIFT)) & SIUL2_GPDO62_PDO_n_MASK)
/*! @} */

/*! @name GPDO61 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO61_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO61_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO61_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO61_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO61_PDO_n_SHIFT)) & SIUL2_GPDO61_PDO_n_MASK)
/*! @} */

/*! @name GPDO60 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO60_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO60_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO60_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO60_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO60_PDO_n_SHIFT)) & SIUL2_GPDO60_PDO_n_MASK)
/*! @} */

/*! @name GPDO67 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO67_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO67_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO67_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO67_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO67_PDO_n_SHIFT)) & SIUL2_GPDO67_PDO_n_MASK)
/*! @} */

/*! @name GPDO66 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO66_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO66_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO66_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO66_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO66_PDO_n_SHIFT)) & SIUL2_GPDO66_PDO_n_MASK)
/*! @} */

/*! @name GPDO65 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO65_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO65_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO65_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO65_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO65_PDO_n_SHIFT)) & SIUL2_GPDO65_PDO_n_MASK)
/*! @} */

/*! @name GPDO64 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO64_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO64_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO64_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO64_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO64_PDO_n_SHIFT)) & SIUL2_GPDO64_PDO_n_MASK)
/*! @} */

/*! @name GPDO71 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO71_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO71_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO71_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO71_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO71_PDO_n_SHIFT)) & SIUL2_GPDO71_PDO_n_MASK)
/*! @} */

/*! @name GPDO70 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO70_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO70_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO70_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO70_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO70_PDO_n_SHIFT)) & SIUL2_GPDO70_PDO_n_MASK)
/*! @} */

/*! @name GPDO69 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO69_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO69_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO69_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO69_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO69_PDO_n_SHIFT)) & SIUL2_GPDO69_PDO_n_MASK)
/*! @} */

/*! @name GPDO68 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO68_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO68_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO68_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO68_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO68_PDO_n_SHIFT)) & SIUL2_GPDO68_PDO_n_MASK)
/*! @} */

/*! @name GPDO75 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO75_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO75_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO75_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO75_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO75_PDO_n_SHIFT)) & SIUL2_GPDO75_PDO_n_MASK)
/*! @} */

/*! @name GPDO74 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO74_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO74_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO74_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO74_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO74_PDO_n_SHIFT)) & SIUL2_GPDO74_PDO_n_MASK)
/*! @} */

/*! @name GPDO73 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO73_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO73_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO73_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO73_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO73_PDO_n_SHIFT)) & SIUL2_GPDO73_PDO_n_MASK)
/*! @} */

/*! @name GPDO72 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO72_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO72_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO72_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO72_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO72_PDO_n_SHIFT)) & SIUL2_GPDO72_PDO_n_MASK)
/*! @} */

/*! @name GPDO78 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO78_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO78_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO78_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO78_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO78_PDO_n_SHIFT)) & SIUL2_GPDO78_PDO_n_MASK)
/*! @} */

/*! @name GPDO77 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO77_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO77_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO77_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO77_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO77_PDO_n_SHIFT)) & SIUL2_GPDO77_PDO_n_MASK)
/*! @} */

/*! @name GPDO76 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO76_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO76_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO76_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO76_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO76_PDO_n_SHIFT)) & SIUL2_GPDO76_PDO_n_MASK)
/*! @} */

/*! @name GPDO83 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO83_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO83_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO83_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO83_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO83_PDO_n_SHIFT)) & SIUL2_GPDO83_PDO_n_MASK)
/*! @} */

/*! @name GPDO82 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO82_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO82_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO82_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO82_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO82_PDO_n_SHIFT)) & SIUL2_GPDO82_PDO_n_MASK)
/*! @} */

/*! @name GPDO81 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO81_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO81_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO81_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO81_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO81_PDO_n_SHIFT)) & SIUL2_GPDO81_PDO_n_MASK)
/*! @} */

/*! @name GPDO80 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO80_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO80_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO80_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO80_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO80_PDO_n_SHIFT)) & SIUL2_GPDO80_PDO_n_MASK)
/*! @} */

/*! @name GPDO87 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO87_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO87_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO87_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO87_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO87_PDO_n_SHIFT)) & SIUL2_GPDO87_PDO_n_MASK)
/*! @} */

/*! @name GPDO86 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO86_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO86_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO86_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO86_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO86_PDO_n_SHIFT)) & SIUL2_GPDO86_PDO_n_MASK)
/*! @} */

/*! @name GPDO85 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO85_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO85_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO85_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO85_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO85_PDO_n_SHIFT)) & SIUL2_GPDO85_PDO_n_MASK)
/*! @} */

/*! @name GPDO84 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO84_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO84_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO84_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO84_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO84_PDO_n_SHIFT)) & SIUL2_GPDO84_PDO_n_MASK)
/*! @} */

/*! @name GPDO91 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO91_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO91_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO91_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO91_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO91_PDO_n_SHIFT)) & SIUL2_GPDO91_PDO_n_MASK)
/*! @} */

/*! @name GPDO90 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO90_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO90_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO90_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO90_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO90_PDO_n_SHIFT)) & SIUL2_GPDO90_PDO_n_MASK)
/*! @} */

/*! @name GPDO89 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO89_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO89_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO89_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO89_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO89_PDO_n_SHIFT)) & SIUL2_GPDO89_PDO_n_MASK)
/*! @} */

/*! @name GPDO88 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO88_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO88_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO88_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO88_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO88_PDO_n_SHIFT)) & SIUL2_GPDO88_PDO_n_MASK)
/*! @} */

/*! @name GPDO95 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO95_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO95_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO95_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO95_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO95_PDO_n_SHIFT)) & SIUL2_GPDO95_PDO_n_MASK)
/*! @} */

/*! @name GPDO94 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO94_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO94_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO94_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO94_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO94_PDO_n_SHIFT)) & SIUL2_GPDO94_PDO_n_MASK)
/*! @} */

/*! @name GPDO93 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO93_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO93_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO93_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO93_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO93_PDO_n_SHIFT)) & SIUL2_GPDO93_PDO_n_MASK)
/*! @} */

/*! @name GPDO92 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO92_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO92_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO92_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO92_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO92_PDO_n_SHIFT)) & SIUL2_GPDO92_PDO_n_MASK)
/*! @} */

/*! @name GPDO99 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO99_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO99_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO99_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO99_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO99_PDO_n_SHIFT)) & SIUL2_GPDO99_PDO_n_MASK)
/*! @} */

/*! @name GPDO98 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO98_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO98_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO98_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO98_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO98_PDO_n_SHIFT)) & SIUL2_GPDO98_PDO_n_MASK)
/*! @} */

/*! @name GPDO97 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO97_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO97_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO97_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO97_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO97_PDO_n_SHIFT)) & SIUL2_GPDO97_PDO_n_MASK)
/*! @} */

/*! @name GPDO96 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO96_PDO_n_MASK                  (0x1U)
#define SIUL2_GPDO96_PDO_n_SHIFT                 (0U)
#define SIUL2_GPDO96_PDO_n_WIDTH                 (1U)
#define SIUL2_GPDO96_PDO_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO96_PDO_n_SHIFT)) & SIUL2_GPDO96_PDO_n_MASK)
/*! @} */

/*! @name GPDO103 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO103_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO103_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO103_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO103_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO103_PDO_n_SHIFT)) & SIUL2_GPDO103_PDO_n_MASK)
/*! @} */

/*! @name GPDO102 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO102_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO102_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO102_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO102_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO102_PDO_n_SHIFT)) & SIUL2_GPDO102_PDO_n_MASK)
/*! @} */

/*! @name GPDO101 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO101_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO101_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO101_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO101_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO101_PDO_n_SHIFT)) & SIUL2_GPDO101_PDO_n_MASK)
/*! @} */

/*! @name GPDO100 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO100_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO100_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO100_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO100_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO100_PDO_n_SHIFT)) & SIUL2_GPDO100_PDO_n_MASK)
/*! @} */

/*! @name GPDO107 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO107_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO107_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO107_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO107_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO107_PDO_n_SHIFT)) & SIUL2_GPDO107_PDO_n_MASK)
/*! @} */

/*! @name GPDO106 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO106_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO106_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO106_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO106_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO106_PDO_n_SHIFT)) & SIUL2_GPDO106_PDO_n_MASK)
/*! @} */

/*! @name GPDO105 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO105_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO105_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO105_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO105_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO105_PDO_n_SHIFT)) & SIUL2_GPDO105_PDO_n_MASK)
/*! @} */

/*! @name GPDO104 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO104_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO104_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO104_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO104_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO104_PDO_n_SHIFT)) & SIUL2_GPDO104_PDO_n_MASK)
/*! @} */

/*! @name GPDO111 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO111_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO111_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO111_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO111_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO111_PDO_n_SHIFT)) & SIUL2_GPDO111_PDO_n_MASK)
/*! @} */

/*! @name GPDO110 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO110_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO110_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO110_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO110_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO110_PDO_n_SHIFT)) & SIUL2_GPDO110_PDO_n_MASK)
/*! @} */

/*! @name GPDO109 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO109_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO109_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO109_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO109_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO109_PDO_n_SHIFT)) & SIUL2_GPDO109_PDO_n_MASK)
/*! @} */

/*! @name GPDO108 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO108_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO108_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO108_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO108_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO108_PDO_n_SHIFT)) & SIUL2_GPDO108_PDO_n_MASK)
/*! @} */

/*! @name GPDO115 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO115_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO115_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO115_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO115_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO115_PDO_n_SHIFT)) & SIUL2_GPDO115_PDO_n_MASK)
/*! @} */

/*! @name GPDO114 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO114_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO114_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO114_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO114_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO114_PDO_n_SHIFT)) & SIUL2_GPDO114_PDO_n_MASK)
/*! @} */

/*! @name GPDO113 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO113_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO113_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO113_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO113_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO113_PDO_n_SHIFT)) & SIUL2_GPDO113_PDO_n_MASK)
/*! @} */

/*! @name GPDO112 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO112_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO112_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO112_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO112_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO112_PDO_n_SHIFT)) & SIUL2_GPDO112_PDO_n_MASK)
/*! @} */

/*! @name GPDO116 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO116_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO116_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO116_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO116_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO116_PDO_n_SHIFT)) & SIUL2_GPDO116_PDO_n_MASK)
/*! @} */

/*! @name GPDO127 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO127_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO127_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO127_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO127_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO127_PDO_n_SHIFT)) & SIUL2_GPDO127_PDO_n_MASK)
/*! @} */

/*! @name GPDO126 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO126_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO126_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO126_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO126_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO126_PDO_n_SHIFT)) & SIUL2_GPDO126_PDO_n_MASK)
/*! @} */

/*! @name GPDO131 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO131_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO131_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO131_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO131_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO131_PDO_n_SHIFT)) & SIUL2_GPDO131_PDO_n_MASK)
/*! @} */

/*! @name GPDO130 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO130_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO130_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO130_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO130_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO130_PDO_n_SHIFT)) & SIUL2_GPDO130_PDO_n_MASK)
/*! @} */

/*! @name GPDO129 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO129_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO129_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO129_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO129_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO129_PDO_n_SHIFT)) & SIUL2_GPDO129_PDO_n_MASK)
/*! @} */

/*! @name GPDO128 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO128_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO128_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO128_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO128_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO128_PDO_n_SHIFT)) & SIUL2_GPDO128_PDO_n_MASK)
/*! @} */

/*! @name GPDO135 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO135_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO135_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO135_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO135_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO135_PDO_n_SHIFT)) & SIUL2_GPDO135_PDO_n_MASK)
/*! @} */

/*! @name GPDO134 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO134_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO134_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO134_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO134_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO134_PDO_n_SHIFT)) & SIUL2_GPDO134_PDO_n_MASK)
/*! @} */

/*! @name GPDO133 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO133_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO133_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO133_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO133_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO133_PDO_n_SHIFT)) & SIUL2_GPDO133_PDO_n_MASK)
/*! @} */

/*! @name GPDO132 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO132_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO132_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO132_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO132_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO132_PDO_n_SHIFT)) & SIUL2_GPDO132_PDO_n_MASK)
/*! @} */

/*! @name GPDO138 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO138_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO138_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO138_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO138_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO138_PDO_n_SHIFT)) & SIUL2_GPDO138_PDO_n_MASK)
/*! @} */

/*! @name GPDO137 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO137_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO137_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO137_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO137_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO137_PDO_n_SHIFT)) & SIUL2_GPDO137_PDO_n_MASK)
/*! @} */

/*! @name GPDO136 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO136_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO136_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO136_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO136_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO136_PDO_n_SHIFT)) & SIUL2_GPDO136_PDO_n_MASK)
/*! @} */

/*! @name GPDO148 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO148_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO148_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO148_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO148_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO148_PDO_n_SHIFT)) & SIUL2_GPDO148_PDO_n_MASK)
/*! @} */

/*! @name GPDO159 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO159_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO159_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO159_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO159_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO159_PDO_n_SHIFT)) & SIUL2_GPDO159_PDO_n_MASK)
/*! @} */

/*! @name GPDO158 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO158_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO158_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO158_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO158_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO158_PDO_n_SHIFT)) & SIUL2_GPDO158_PDO_n_MASK)
/*! @} */

/*! @name GPDO157 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO157_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO157_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO157_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO157_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO157_PDO_n_SHIFT)) & SIUL2_GPDO157_PDO_n_MASK)
/*! @} */

/*! @name GPDO156 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO156_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO156_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO156_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO156_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO156_PDO_n_SHIFT)) & SIUL2_GPDO156_PDO_n_MASK)
/*! @} */

/*! @name GPDO163 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO163_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO163_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO163_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO163_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO163_PDO_n_SHIFT)) & SIUL2_GPDO163_PDO_n_MASK)
/*! @} */

/*! @name GPDO162 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO162_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO162_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO162_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO162_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO162_PDO_n_SHIFT)) & SIUL2_GPDO162_PDO_n_MASK)
/*! @} */

/*! @name GPDO161 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO161_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO161_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO161_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO161_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO161_PDO_n_SHIFT)) & SIUL2_GPDO161_PDO_n_MASK)
/*! @} */

/*! @name GPDO160 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO160_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO160_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO160_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO160_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO160_PDO_n_SHIFT)) & SIUL2_GPDO160_PDO_n_MASK)
/*! @} */

/*! @name GPDO167 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO167_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO167_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO167_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO167_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO167_PDO_n_SHIFT)) & SIUL2_GPDO167_PDO_n_MASK)
/*! @} */

/*! @name GPDO166 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO166_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO166_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO166_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO166_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO166_PDO_n_SHIFT)) & SIUL2_GPDO166_PDO_n_MASK)
/*! @} */

/*! @name GPDO165 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO165_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO165_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO165_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO165_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO165_PDO_n_SHIFT)) & SIUL2_GPDO165_PDO_n_MASK)
/*! @} */

/*! @name GPDO164 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO164_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO164_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO164_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO164_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO164_PDO_n_SHIFT)) & SIUL2_GPDO164_PDO_n_MASK)
/*! @} */

/*! @name GPDO171 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO171_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO171_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO171_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO171_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO171_PDO_n_SHIFT)) & SIUL2_GPDO171_PDO_n_MASK)
/*! @} */

/*! @name GPDO170 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO170_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO170_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO170_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO170_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO170_PDO_n_SHIFT)) & SIUL2_GPDO170_PDO_n_MASK)
/*! @} */

/*! @name GPDO169 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO169_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO169_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO169_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO169_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO169_PDO_n_SHIFT)) & SIUL2_GPDO169_PDO_n_MASK)
/*! @} */

/*! @name GPDO168 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO168_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO168_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO168_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO168_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO168_PDO_n_SHIFT)) & SIUL2_GPDO168_PDO_n_MASK)
/*! @} */

/*! @name GPDO175 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO175_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO175_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO175_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO175_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO175_PDO_n_SHIFT)) & SIUL2_GPDO175_PDO_n_MASK)
/*! @} */

/*! @name GPDO174 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO174_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO174_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO174_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO174_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO174_PDO_n_SHIFT)) & SIUL2_GPDO174_PDO_n_MASK)
/*! @} */

/*! @name GPDO173 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO173_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO173_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO173_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO173_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO173_PDO_n_SHIFT)) & SIUL2_GPDO173_PDO_n_MASK)
/*! @} */

/*! @name GPDO172 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO172_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO172_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO172_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO172_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO172_PDO_n_SHIFT)) & SIUL2_GPDO172_PDO_n_MASK)
/*! @} */

/*! @name GPDO179 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO179_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO179_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO179_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO179_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO179_PDO_n_SHIFT)) & SIUL2_GPDO179_PDO_n_MASK)
/*! @} */

/*! @name GPDO178 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO178_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO178_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO178_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO178_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO178_PDO_n_SHIFT)) & SIUL2_GPDO178_PDO_n_MASK)
/*! @} */

/*! @name GPDO177 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO177_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO177_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO177_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO177_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO177_PDO_n_SHIFT)) & SIUL2_GPDO177_PDO_n_MASK)
/*! @} */

/*! @name GPDO176 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO176_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO176_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO176_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO176_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO176_PDO_n_SHIFT)) & SIUL2_GPDO176_PDO_n_MASK)
/*! @} */

/*! @name GPDO183 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO183_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO183_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO183_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO183_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO183_PDO_n_SHIFT)) & SIUL2_GPDO183_PDO_n_MASK)
/*! @} */

/*! @name GPDO182 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO182_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO182_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO182_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO182_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO182_PDO_n_SHIFT)) & SIUL2_GPDO182_PDO_n_MASK)
/*! @} */

/*! @name GPDO181 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO181_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO181_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO181_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO181_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO181_PDO_n_SHIFT)) & SIUL2_GPDO181_PDO_n_MASK)
/*! @} */

/*! @name GPDO180 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO180_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO180_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO180_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO180_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO180_PDO_n_SHIFT)) & SIUL2_GPDO180_PDO_n_MASK)
/*! @} */

/*! @name GPDO187 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO187_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO187_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO187_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO187_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO187_PDO_n_SHIFT)) & SIUL2_GPDO187_PDO_n_MASK)
/*! @} */

/*! @name GPDO186 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO186_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO186_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO186_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO186_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO186_PDO_n_SHIFT)) & SIUL2_GPDO186_PDO_n_MASK)
/*! @} */

/*! @name GPDO185 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO185_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO185_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO185_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO185_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO185_PDO_n_SHIFT)) & SIUL2_GPDO185_PDO_n_MASK)
/*! @} */

/*! @name GPDO184 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO184_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO184_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO184_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO184_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO184_PDO_n_SHIFT)) & SIUL2_GPDO184_PDO_n_MASK)
/*! @} */

/*! @name GPDO191 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO191_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO191_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO191_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO191_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO191_PDO_n_SHIFT)) & SIUL2_GPDO191_PDO_n_MASK)
/*! @} */

/*! @name GPDO190 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO190_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO190_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO190_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO190_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO190_PDO_n_SHIFT)) & SIUL2_GPDO190_PDO_n_MASK)
/*! @} */

/*! @name GPDO189 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO189_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO189_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO189_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO189_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO189_PDO_n_SHIFT)) & SIUL2_GPDO189_PDO_n_MASK)
/*! @} */

/*! @name GPDO188 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO188_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO188_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO188_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO188_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO188_PDO_n_SHIFT)) & SIUL2_GPDO188_PDO_n_MASK)
/*! @} */

/*! @name GPDO195 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO195_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO195_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO195_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO195_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO195_PDO_n_SHIFT)) & SIUL2_GPDO195_PDO_n_MASK)
/*! @} */

/*! @name GPDO194 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO194_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO194_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO194_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO194_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO194_PDO_n_SHIFT)) & SIUL2_GPDO194_PDO_n_MASK)
/*! @} */

/*! @name GPDO193 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO193_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO193_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO193_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO193_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO193_PDO_n_SHIFT)) & SIUL2_GPDO193_PDO_n_MASK)
/*! @} */

/*! @name GPDO192 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO192_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO192_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO192_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO192_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO192_PDO_n_SHIFT)) & SIUL2_GPDO192_PDO_n_MASK)
/*! @} */

/*! @name GPDO199 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO199_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO199_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO199_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO199_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO199_PDO_n_SHIFT)) & SIUL2_GPDO199_PDO_n_MASK)
/*! @} */

/*! @name GPDO198 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO198_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO198_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO198_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO198_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO198_PDO_n_SHIFT)) & SIUL2_GPDO198_PDO_n_MASK)
/*! @} */

/*! @name GPDO197 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO197_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO197_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO197_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO197_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO197_PDO_n_SHIFT)) & SIUL2_GPDO197_PDO_n_MASK)
/*! @} */

/*! @name GPDO196 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO196_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO196_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO196_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO196_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO196_PDO_n_SHIFT)) & SIUL2_GPDO196_PDO_n_MASK)
/*! @} */

/*! @name GPDO203 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO203_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO203_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO203_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO203_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO203_PDO_n_SHIFT)) & SIUL2_GPDO203_PDO_n_MASK)
/*! @} */

/*! @name GPDO202 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO202_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO202_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO202_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO202_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO202_PDO_n_SHIFT)) & SIUL2_GPDO202_PDO_n_MASK)
/*! @} */

/*! @name GPDO201 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO201_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO201_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO201_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO201_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO201_PDO_n_SHIFT)) & SIUL2_GPDO201_PDO_n_MASK)
/*! @} */

/*! @name GPDO200 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO200_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO200_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO200_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO200_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO200_PDO_n_SHIFT)) & SIUL2_GPDO200_PDO_n_MASK)
/*! @} */

/*! @name GPDO207 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO207_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO207_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO207_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO207_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO207_PDO_n_SHIFT)) & SIUL2_GPDO207_PDO_n_MASK)
/*! @} */

/*! @name GPDO206 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO206_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO206_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO206_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO206_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO206_PDO_n_SHIFT)) & SIUL2_GPDO206_PDO_n_MASK)
/*! @} */

/*! @name GPDO205 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO205_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO205_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO205_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO205_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO205_PDO_n_SHIFT)) & SIUL2_GPDO205_PDO_n_MASK)
/*! @} */

/*! @name GPDO204 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO204_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO204_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO204_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO204_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO204_PDO_n_SHIFT)) & SIUL2_GPDO204_PDO_n_MASK)
/*! @} */

/*! @name GPDO211 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO211_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO211_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO211_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO211_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO211_PDO_n_SHIFT)) & SIUL2_GPDO211_PDO_n_MASK)
/*! @} */

/*! @name GPDO210 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO210_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO210_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO210_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO210_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO210_PDO_n_SHIFT)) & SIUL2_GPDO210_PDO_n_MASK)
/*! @} */

/*! @name GPDO209 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO209_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO209_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO209_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO209_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO209_PDO_n_SHIFT)) & SIUL2_GPDO209_PDO_n_MASK)
/*! @} */

/*! @name GPDO208 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO208_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO208_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO208_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO208_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO208_PDO_n_SHIFT)) & SIUL2_GPDO208_PDO_n_MASK)
/*! @} */

/*! @name GPDO215 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO215_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO215_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO215_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO215_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO215_PDO_n_SHIFT)) & SIUL2_GPDO215_PDO_n_MASK)
/*! @} */

/*! @name GPDO214 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO214_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO214_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO214_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO214_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO214_PDO_n_SHIFT)) & SIUL2_GPDO214_PDO_n_MASK)
/*! @} */

/*! @name GPDO213 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO213_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO213_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO213_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO213_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO213_PDO_n_SHIFT)) & SIUL2_GPDO213_PDO_n_MASK)
/*! @} */

/*! @name GPDO212 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO212_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO212_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO212_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO212_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO212_PDO_n_SHIFT)) & SIUL2_GPDO212_PDO_n_MASK)
/*! @} */

/*! @name GPDO219 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO219_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO219_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO219_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO219_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO219_PDO_n_SHIFT)) & SIUL2_GPDO219_PDO_n_MASK)
/*! @} */

/*! @name GPDO218 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO218_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO218_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO218_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO218_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO218_PDO_n_SHIFT)) & SIUL2_GPDO218_PDO_n_MASK)
/*! @} */

/*! @name GPDO217 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO217_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO217_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO217_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO217_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO217_PDO_n_SHIFT)) & SIUL2_GPDO217_PDO_n_MASK)
/*! @} */

/*! @name GPDO216 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO216_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO216_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO216_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO216_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO216_PDO_n_SHIFT)) & SIUL2_GPDO216_PDO_n_MASK)
/*! @} */

/*! @name GPDO223 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO223_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO223_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO223_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO223_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO223_PDO_n_SHIFT)) & SIUL2_GPDO223_PDO_n_MASK)
/*! @} */

/*! @name GPDO222 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO222_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO222_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO222_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO222_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO222_PDO_n_SHIFT)) & SIUL2_GPDO222_PDO_n_MASK)
/*! @} */

/*! @name GPDO221 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO221_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO221_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO221_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO221_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO221_PDO_n_SHIFT)) & SIUL2_GPDO221_PDO_n_MASK)
/*! @} */

/*! @name GPDO220 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO220_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO220_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO220_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO220_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO220_PDO_n_SHIFT)) & SIUL2_GPDO220_PDO_n_MASK)
/*! @} */

/*! @name GPDO227 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO227_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO227_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO227_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO227_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO227_PDO_n_SHIFT)) & SIUL2_GPDO227_PDO_n_MASK)
/*! @} */

/*! @name GPDO226 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO226_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO226_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO226_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO226_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO226_PDO_n_SHIFT)) & SIUL2_GPDO226_PDO_n_MASK)
/*! @} */

/*! @name GPDO225 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO225_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO225_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO225_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO225_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO225_PDO_n_SHIFT)) & SIUL2_GPDO225_PDO_n_MASK)
/*! @} */

/*! @name GPDO224 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO224_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO224_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO224_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO224_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO224_PDO_n_SHIFT)) & SIUL2_GPDO224_PDO_n_MASK)
/*! @} */

/*! @name GPDO231 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO231_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO231_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO231_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO231_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO231_PDO_n_SHIFT)) & SIUL2_GPDO231_PDO_n_MASK)
/*! @} */

/*! @name GPDO229 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO229_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO229_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO229_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO229_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO229_PDO_n_SHIFT)) & SIUL2_GPDO229_PDO_n_MASK)
/*! @} */

/*! @name GPDO228 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO228_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO228_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO228_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO228_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO228_PDO_n_SHIFT)) & SIUL2_GPDO228_PDO_n_MASK)
/*! @} */

/*! @name GPDO235 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO235_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO235_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO235_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO235_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO235_PDO_n_SHIFT)) & SIUL2_GPDO235_PDO_n_MASK)
/*! @} */

/*! @name GPDO234 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO234_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO234_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO234_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO234_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO234_PDO_n_SHIFT)) & SIUL2_GPDO234_PDO_n_MASK)
/*! @} */

/*! @name GPDO233 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO233_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO233_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO233_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO233_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO233_PDO_n_SHIFT)) & SIUL2_GPDO233_PDO_n_MASK)
/*! @} */

/*! @name GPDO232 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO232_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO232_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO232_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO232_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO232_PDO_n_SHIFT)) & SIUL2_GPDO232_PDO_n_MASK)
/*! @} */

/*! @name GPDO239 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO239_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO239_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO239_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO239_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO239_PDO_n_SHIFT)) & SIUL2_GPDO239_PDO_n_MASK)
/*! @} */

/*! @name GPDO238 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO238_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO238_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO238_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO238_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO238_PDO_n_SHIFT)) & SIUL2_GPDO238_PDO_n_MASK)
/*! @} */

/*! @name GPDO237 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO237_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO237_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO237_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO237_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO237_PDO_n_SHIFT)) & SIUL2_GPDO237_PDO_n_MASK)
/*! @} */

/*! @name GPDO236 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO236_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO236_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO236_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO236_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO236_PDO_n_SHIFT)) & SIUL2_GPDO236_PDO_n_MASK)
/*! @} */

/*! @name GPDO243 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO243_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO243_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO243_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO243_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO243_PDO_n_SHIFT)) & SIUL2_GPDO243_PDO_n_MASK)
/*! @} */

/*! @name GPDO242 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO242_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO242_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO242_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO242_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO242_PDO_n_SHIFT)) & SIUL2_GPDO242_PDO_n_MASK)
/*! @} */

/*! @name GPDO241 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO241_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO241_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO241_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO241_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO241_PDO_n_SHIFT)) & SIUL2_GPDO241_PDO_n_MASK)
/*! @} */

/*! @name GPDO240 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO240_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO240_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO240_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO240_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO240_PDO_n_SHIFT)) & SIUL2_GPDO240_PDO_n_MASK)
/*! @} */

/*! @name GPDO247 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO247_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO247_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO247_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO247_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO247_PDO_n_SHIFT)) & SIUL2_GPDO247_PDO_n_MASK)
/*! @} */

/*! @name GPDO246 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO246_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO246_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO246_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO246_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO246_PDO_n_SHIFT)) & SIUL2_GPDO246_PDO_n_MASK)
/*! @} */

/*! @name GPDO245 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO245_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO245_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO245_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO245_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO245_PDO_n_SHIFT)) & SIUL2_GPDO245_PDO_n_MASK)
/*! @} */

/*! @name GPDO244 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO244_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO244_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO244_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO244_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO244_PDO_n_SHIFT)) & SIUL2_GPDO244_PDO_n_MASK)
/*! @} */

/*! @name GPDO251 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO251_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO251_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO251_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO251_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO251_PDO_n_SHIFT)) & SIUL2_GPDO251_PDO_n_MASK)
/*! @} */

/*! @name GPDO250 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO250_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO250_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO250_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO250_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO250_PDO_n_SHIFT)) & SIUL2_GPDO250_PDO_n_MASK)
/*! @} */

/*! @name GPDO249 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO249_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO249_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO249_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO249_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO249_PDO_n_SHIFT)) & SIUL2_GPDO249_PDO_n_MASK)
/*! @} */

/*! @name GPDO248 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO248_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO248_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO248_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO248_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO248_PDO_n_SHIFT)) & SIUL2_GPDO248_PDO_n_MASK)
/*! @} */

/*! @name GPDO255 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO255_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO255_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO255_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO255_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO255_PDO_n_SHIFT)) & SIUL2_GPDO255_PDO_n_MASK)
/*! @} */

/*! @name GPDO254 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO254_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO254_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO254_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO254_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO254_PDO_n_SHIFT)) & SIUL2_GPDO254_PDO_n_MASK)
/*! @} */

/*! @name GPDO253 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO253_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO253_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO253_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO253_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO253_PDO_n_SHIFT)) & SIUL2_GPDO253_PDO_n_MASK)
/*! @} */

/*! @name GPDO252 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO252_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO252_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO252_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO252_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO252_PDO_n_SHIFT)) & SIUL2_GPDO252_PDO_n_MASK)
/*! @} */

/*! @name GPDO259 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO259_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO259_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO259_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO259_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO259_PDO_n_SHIFT)) & SIUL2_GPDO259_PDO_n_MASK)
/*! @} */

/*! @name GPDO258 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO258_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO258_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO258_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO258_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO258_PDO_n_SHIFT)) & SIUL2_GPDO258_PDO_n_MASK)
/*! @} */

/*! @name GPDO257 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO257_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO257_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO257_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO257_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO257_PDO_n_SHIFT)) & SIUL2_GPDO257_PDO_n_MASK)
/*! @} */

/*! @name GPDO256 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO256_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO256_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO256_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO256_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO256_PDO_n_SHIFT)) & SIUL2_GPDO256_PDO_n_MASK)
/*! @} */

/*! @name GPDO263 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO263_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO263_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO263_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO263_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO263_PDO_n_SHIFT)) & SIUL2_GPDO263_PDO_n_MASK)
/*! @} */

/*! @name GPDO262 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO262_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO262_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO262_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO262_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO262_PDO_n_SHIFT)) & SIUL2_GPDO262_PDO_n_MASK)
/*! @} */

/*! @name GPDO261 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO261_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO261_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO261_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO261_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO261_PDO_n_SHIFT)) & SIUL2_GPDO261_PDO_n_MASK)
/*! @} */

/*! @name GPDO260 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO260_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO260_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO260_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO260_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO260_PDO_n_SHIFT)) & SIUL2_GPDO260_PDO_n_MASK)
/*! @} */

/*! @name GPDO264 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO264_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO264_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO264_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO264_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO264_PDO_n_SHIFT)) & SIUL2_GPDO264_PDO_n_MASK)
/*! @} */

/*! @name GPDO307 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO307_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO307_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO307_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO307_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO307_PDO_n_SHIFT)) & SIUL2_GPDO307_PDO_n_MASK)
/*! @} */

/*! @name GPDO306 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO306_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO306_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO306_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO306_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO306_PDO_n_SHIFT)) & SIUL2_GPDO306_PDO_n_MASK)
/*! @} */

/*! @name GPDO305 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO305_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO305_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO305_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO305_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO305_PDO_n_SHIFT)) & SIUL2_GPDO305_PDO_n_MASK)
/*! @} */

/*! @name GPDO304 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO304_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO304_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO304_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO304_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO304_PDO_n_SHIFT)) & SIUL2_GPDO304_PDO_n_MASK)
/*! @} */

/*! @name GPDO311 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO311_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO311_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO311_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO311_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO311_PDO_n_SHIFT)) & SIUL2_GPDO311_PDO_n_MASK)
/*! @} */

/*! @name GPDO310 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO310_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO310_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO310_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO310_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO310_PDO_n_SHIFT)) & SIUL2_GPDO310_PDO_n_MASK)
/*! @} */

/*! @name GPDO309 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO309_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO309_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO309_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO309_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO309_PDO_n_SHIFT)) & SIUL2_GPDO309_PDO_n_MASK)
/*! @} */

/*! @name GPDO308 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO308_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO308_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO308_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO308_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO308_PDO_n_SHIFT)) & SIUL2_GPDO308_PDO_n_MASK)
/*! @} */

/*! @name GPDO315 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO315_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO315_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO315_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO315_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO315_PDO_n_SHIFT)) & SIUL2_GPDO315_PDO_n_MASK)
/*! @} */

/*! @name GPDO314 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO314_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO314_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO314_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO314_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO314_PDO_n_SHIFT)) & SIUL2_GPDO314_PDO_n_MASK)
/*! @} */

/*! @name GPDO313 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO313_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO313_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO313_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO313_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO313_PDO_n_SHIFT)) & SIUL2_GPDO313_PDO_n_MASK)
/*! @} */

/*! @name GPDO312 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO312_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO312_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO312_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO312_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO312_PDO_n_SHIFT)) & SIUL2_GPDO312_PDO_n_MASK)
/*! @} */

/*! @name GPDO319 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO319_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO319_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO319_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO319_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO319_PDO_n_SHIFT)) & SIUL2_GPDO319_PDO_n_MASK)
/*! @} */

/*! @name GPDO318 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO318_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO318_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO318_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO318_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO318_PDO_n_SHIFT)) & SIUL2_GPDO318_PDO_n_MASK)
/*! @} */

/*! @name GPDO317 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO317_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO317_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO317_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO317_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO317_PDO_n_SHIFT)) & SIUL2_GPDO317_PDO_n_MASK)
/*! @} */

/*! @name GPDO316 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO316_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO316_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO316_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO316_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO316_PDO_n_SHIFT)) & SIUL2_GPDO316_PDO_n_MASK)
/*! @} */

/*! @name GPDO323 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO323_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO323_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO323_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO323_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO323_PDO_n_SHIFT)) & SIUL2_GPDO323_PDO_n_MASK)
/*! @} */

/*! @name GPDO322 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO322_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO322_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO322_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO322_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO322_PDO_n_SHIFT)) & SIUL2_GPDO322_PDO_n_MASK)
/*! @} */

/*! @name GPDO321 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO321_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO321_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO321_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO321_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO321_PDO_n_SHIFT)) & SIUL2_GPDO321_PDO_n_MASK)
/*! @} */

/*! @name GPDO320 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO320_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO320_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO320_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO320_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO320_PDO_n_SHIFT)) & SIUL2_GPDO320_PDO_n_MASK)
/*! @} */

/*! @name GPDO327 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO327_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO327_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO327_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO327_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO327_PDO_n_SHIFT)) & SIUL2_GPDO327_PDO_n_MASK)
/*! @} */

/*! @name GPDO326 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO326_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO326_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO326_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO326_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO326_PDO_n_SHIFT)) & SIUL2_GPDO326_PDO_n_MASK)
/*! @} */

/*! @name GPDO325 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO325_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO325_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO325_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO325_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO325_PDO_n_SHIFT)) & SIUL2_GPDO325_PDO_n_MASK)
/*! @} */

/*! @name GPDO324 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO324_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO324_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO324_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO324_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO324_PDO_n_SHIFT)) & SIUL2_GPDO324_PDO_n_MASK)
/*! @} */

/*! @name GPDO331 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO331_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO331_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO331_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO331_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO331_PDO_n_SHIFT)) & SIUL2_GPDO331_PDO_n_MASK)
/*! @} */

/*! @name GPDO330 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO330_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO330_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO330_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO330_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO330_PDO_n_SHIFT)) & SIUL2_GPDO330_PDO_n_MASK)
/*! @} */

/*! @name GPDO329 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO329_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO329_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO329_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO329_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO329_PDO_n_SHIFT)) & SIUL2_GPDO329_PDO_n_MASK)
/*! @} */

/*! @name GPDO328 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO328_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO328_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO328_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO328_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO328_PDO_n_SHIFT)) & SIUL2_GPDO328_PDO_n_MASK)
/*! @} */

/*! @name GPDO335 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO335_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO335_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO335_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO335_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO335_PDO_n_SHIFT)) & SIUL2_GPDO335_PDO_n_MASK)
/*! @} */

/*! @name GPDO334 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO334_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO334_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO334_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO334_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO334_PDO_n_SHIFT)) & SIUL2_GPDO334_PDO_n_MASK)
/*! @} */

/*! @name GPDO333 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO333_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO333_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO333_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO333_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO333_PDO_n_SHIFT)) & SIUL2_GPDO333_PDO_n_MASK)
/*! @} */

/*! @name GPDO332 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO332_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO332_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO332_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO332_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO332_PDO_n_SHIFT)) & SIUL2_GPDO332_PDO_n_MASK)
/*! @} */

/*! @name GPDO339 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO339_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO339_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO339_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO339_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO339_PDO_n_SHIFT)) & SIUL2_GPDO339_PDO_n_MASK)
/*! @} */

/*! @name GPDO338 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO338_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO338_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO338_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO338_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO338_PDO_n_SHIFT)) & SIUL2_GPDO338_PDO_n_MASK)
/*! @} */

/*! @name GPDO337 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO337_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO337_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO337_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO337_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO337_PDO_n_SHIFT)) & SIUL2_GPDO337_PDO_n_MASK)
/*! @} */

/*! @name GPDO336 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO336_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO336_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO336_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO336_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO336_PDO_n_SHIFT)) & SIUL2_GPDO336_PDO_n_MASK)
/*! @} */

/*! @name GPDO343 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO343_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO343_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO343_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO343_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO343_PDO_n_SHIFT)) & SIUL2_GPDO343_PDO_n_MASK)
/*! @} */

/*! @name GPDO342 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO342_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO342_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO342_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO342_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO342_PDO_n_SHIFT)) & SIUL2_GPDO342_PDO_n_MASK)
/*! @} */

/*! @name GPDO341 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO341_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO341_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO341_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO341_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO341_PDO_n_SHIFT)) & SIUL2_GPDO341_PDO_n_MASK)
/*! @} */

/*! @name GPDO340 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO340_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO340_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO340_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO340_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO340_PDO_n_SHIFT)) & SIUL2_GPDO340_PDO_n_MASK)
/*! @} */

/*! @name GPDO347 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO347_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO347_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO347_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO347_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO347_PDO_n_SHIFT)) & SIUL2_GPDO347_PDO_n_MASK)
/*! @} */

/*! @name GPDO346 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO346_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO346_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO346_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO346_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO346_PDO_n_SHIFT)) & SIUL2_GPDO346_PDO_n_MASK)
/*! @} */

/*! @name GPDO345 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO345_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO345_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO345_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO345_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO345_PDO_n_SHIFT)) & SIUL2_GPDO345_PDO_n_MASK)
/*! @} */

/*! @name GPDO344 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO344_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO344_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO344_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO344_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO344_PDO_n_SHIFT)) & SIUL2_GPDO344_PDO_n_MASK)
/*! @} */

/*! @name GPDO351 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO351_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO351_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO351_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO351_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO351_PDO_n_SHIFT)) & SIUL2_GPDO351_PDO_n_MASK)
/*! @} */

/*! @name GPDO350 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO350_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO350_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO350_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO350_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO350_PDO_n_SHIFT)) & SIUL2_GPDO350_PDO_n_MASK)
/*! @} */

/*! @name GPDO349 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO349_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO349_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO349_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO349_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO349_PDO_n_SHIFT)) & SIUL2_GPDO349_PDO_n_MASK)
/*! @} */

/*! @name GPDO348 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO348_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO348_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO348_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO348_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO348_PDO_n_SHIFT)) & SIUL2_GPDO348_PDO_n_MASK)
/*! @} */

/*! @name GPDO355 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO355_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO355_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO355_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO355_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO355_PDO_n_SHIFT)) & SIUL2_GPDO355_PDO_n_MASK)
/*! @} */

/*! @name GPDO354 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO354_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO354_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO354_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO354_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO354_PDO_n_SHIFT)) & SIUL2_GPDO354_PDO_n_MASK)
/*! @} */

/*! @name GPDO353 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO353_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO353_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO353_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO353_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO353_PDO_n_SHIFT)) & SIUL2_GPDO353_PDO_n_MASK)
/*! @} */

/*! @name GPDO352 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO352_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO352_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO352_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO352_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO352_PDO_n_SHIFT)) & SIUL2_GPDO352_PDO_n_MASK)
/*! @} */

/*! @name GPDO359 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO359_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO359_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO359_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO359_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO359_PDO_n_SHIFT)) & SIUL2_GPDO359_PDO_n_MASK)
/*! @} */

/*! @name GPDO358 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO358_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO358_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO358_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO358_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO358_PDO_n_SHIFT)) & SIUL2_GPDO358_PDO_n_MASK)
/*! @} */

/*! @name GPDO357 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO357_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO357_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO357_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO357_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO357_PDO_n_SHIFT)) & SIUL2_GPDO357_PDO_n_MASK)
/*! @} */

/*! @name GPDO356 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO356_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO356_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO356_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO356_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO356_PDO_n_SHIFT)) & SIUL2_GPDO356_PDO_n_MASK)
/*! @} */

/*! @name GPDO363 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO363_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO363_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO363_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO363_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO363_PDO_n_SHIFT)) & SIUL2_GPDO363_PDO_n_MASK)
/*! @} */

/*! @name GPDO362 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO362_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO362_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO362_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO362_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO362_PDO_n_SHIFT)) & SIUL2_GPDO362_PDO_n_MASK)
/*! @} */

/*! @name GPDO361 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO361_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO361_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO361_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO361_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO361_PDO_n_SHIFT)) & SIUL2_GPDO361_PDO_n_MASK)
/*! @} */

/*! @name GPDO360 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO360_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO360_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO360_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO360_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO360_PDO_n_SHIFT)) & SIUL2_GPDO360_PDO_n_MASK)
/*! @} */

/*! @name GPDO367 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO367_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO367_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO367_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO367_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO367_PDO_n_SHIFT)) & SIUL2_GPDO367_PDO_n_MASK)
/*! @} */

/*! @name GPDO366 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO366_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO366_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO366_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO366_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO366_PDO_n_SHIFT)) & SIUL2_GPDO366_PDO_n_MASK)
/*! @} */

/*! @name GPDO365 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO365_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO365_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO365_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO365_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO365_PDO_n_SHIFT)) & SIUL2_GPDO365_PDO_n_MASK)
/*! @} */

/*! @name GPDO364 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO364_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO364_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO364_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO364_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO364_PDO_n_SHIFT)) & SIUL2_GPDO364_PDO_n_MASK)
/*! @} */

/*! @name GPDO371 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO371_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO371_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO371_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO371_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO371_PDO_n_SHIFT)) & SIUL2_GPDO371_PDO_n_MASK)
/*! @} */

/*! @name GPDO370 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO370_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO370_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO370_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO370_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO370_PDO_n_SHIFT)) & SIUL2_GPDO370_PDO_n_MASK)
/*! @} */

/*! @name GPDO369 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO369_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO369_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO369_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO369_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO369_PDO_n_SHIFT)) & SIUL2_GPDO369_PDO_n_MASK)
/*! @} */

/*! @name GPDO368 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO368_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO368_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO368_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO368_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO368_PDO_n_SHIFT)) & SIUL2_GPDO368_PDO_n_MASK)
/*! @} */

/*! @name GPDO435 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO435_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO435_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO435_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO435_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO435_PDO_n_SHIFT)) & SIUL2_GPDO435_PDO_n_MASK)
/*! @} */

/*! @name GPDO434 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO434_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO434_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO434_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO434_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO434_PDO_n_SHIFT)) & SIUL2_GPDO434_PDO_n_MASK)
/*! @} */

/*! @name GPDO433 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO433_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO433_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO433_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO433_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO433_PDO_n_SHIFT)) & SIUL2_GPDO433_PDO_n_MASK)
/*! @} */

/*! @name GPDO432 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO432_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO432_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO432_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO432_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO432_PDO_n_SHIFT)) & SIUL2_GPDO432_PDO_n_MASK)
/*! @} */

/*! @name GPDO437 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO437_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO437_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO437_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO437_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO437_PDO_n_SHIFT)) & SIUL2_GPDO437_PDO_n_MASK)
/*! @} */

/*! @name GPDO436 - GPIO Pad Data Output */
/*! @{ */

#define SIUL2_GPDO436_PDO_n_MASK                 (0x1U)
#define SIUL2_GPDO436_PDO_n_SHIFT                (0U)
#define SIUL2_GPDO436_PDO_n_WIDTH                (1U)
#define SIUL2_GPDO436_PDO_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDO436_PDO_n_SHIFT)) & SIUL2_GPDO436_PDO_n_MASK)
/*! @} */

/*! @name GPDI3 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI3_PDI_n_MASK                   (0x1U)
#define SIUL2_GPDI3_PDI_n_SHIFT                  (0U)
#define SIUL2_GPDI3_PDI_n_WIDTH                  (1U)
#define SIUL2_GPDI3_PDI_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI3_PDI_n_SHIFT)) & SIUL2_GPDI3_PDI_n_MASK)
/*! @} */

/*! @name GPDI2 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI2_PDI_n_MASK                   (0x1U)
#define SIUL2_GPDI2_PDI_n_SHIFT                  (0U)
#define SIUL2_GPDI2_PDI_n_WIDTH                  (1U)
#define SIUL2_GPDI2_PDI_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI2_PDI_n_SHIFT)) & SIUL2_GPDI2_PDI_n_MASK)
/*! @} */

/*! @name GPDI1 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI1_PDI_n_MASK                   (0x1U)
#define SIUL2_GPDI1_PDI_n_SHIFT                  (0U)
#define SIUL2_GPDI1_PDI_n_WIDTH                  (1U)
#define SIUL2_GPDI1_PDI_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI1_PDI_n_SHIFT)) & SIUL2_GPDI1_PDI_n_MASK)
/*! @} */

/*! @name GPDI0 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI0_PDI_n_MASK                   (0x1U)
#define SIUL2_GPDI0_PDI_n_SHIFT                  (0U)
#define SIUL2_GPDI0_PDI_n_WIDTH                  (1U)
#define SIUL2_GPDI0_PDI_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI0_PDI_n_SHIFT)) & SIUL2_GPDI0_PDI_n_MASK)
/*! @} */

/*! @name GPDI7 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI7_PDI_n_MASK                   (0x1U)
#define SIUL2_GPDI7_PDI_n_SHIFT                  (0U)
#define SIUL2_GPDI7_PDI_n_WIDTH                  (1U)
#define SIUL2_GPDI7_PDI_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI7_PDI_n_SHIFT)) & SIUL2_GPDI7_PDI_n_MASK)
/*! @} */

/*! @name GPDI6 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI6_PDI_n_MASK                   (0x1U)
#define SIUL2_GPDI6_PDI_n_SHIFT                  (0U)
#define SIUL2_GPDI6_PDI_n_WIDTH                  (1U)
#define SIUL2_GPDI6_PDI_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI6_PDI_n_SHIFT)) & SIUL2_GPDI6_PDI_n_MASK)
/*! @} */

/*! @name GPDI5 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI5_PDI_n_MASK                   (0x1U)
#define SIUL2_GPDI5_PDI_n_SHIFT                  (0U)
#define SIUL2_GPDI5_PDI_n_WIDTH                  (1U)
#define SIUL2_GPDI5_PDI_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI5_PDI_n_SHIFT)) & SIUL2_GPDI5_PDI_n_MASK)
/*! @} */

/*! @name GPDI4 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI4_PDI_n_MASK                   (0x1U)
#define SIUL2_GPDI4_PDI_n_SHIFT                  (0U)
#define SIUL2_GPDI4_PDI_n_WIDTH                  (1U)
#define SIUL2_GPDI4_PDI_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI4_PDI_n_SHIFT)) & SIUL2_GPDI4_PDI_n_MASK)
/*! @} */

/*! @name GPDI11 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI11_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI11_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI11_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI11_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI11_PDI_n_SHIFT)) & SIUL2_GPDI11_PDI_n_MASK)
/*! @} */

/*! @name GPDI10 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI10_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI10_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI10_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI10_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI10_PDI_n_SHIFT)) & SIUL2_GPDI10_PDI_n_MASK)
/*! @} */

/*! @name GPDI9 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI9_PDI_n_MASK                   (0x1U)
#define SIUL2_GPDI9_PDI_n_SHIFT                  (0U)
#define SIUL2_GPDI9_PDI_n_WIDTH                  (1U)
#define SIUL2_GPDI9_PDI_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI9_PDI_n_SHIFT)) & SIUL2_GPDI9_PDI_n_MASK)
/*! @} */

/*! @name GPDI8 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI8_PDI_n_MASK                   (0x1U)
#define SIUL2_GPDI8_PDI_n_SHIFT                  (0U)
#define SIUL2_GPDI8_PDI_n_WIDTH                  (1U)
#define SIUL2_GPDI8_PDI_n(x)                     (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI8_PDI_n_SHIFT)) & SIUL2_GPDI8_PDI_n_MASK)
/*! @} */

/*! @name GPDI15 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI15_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI15_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI15_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI15_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI15_PDI_n_SHIFT)) & SIUL2_GPDI15_PDI_n_MASK)
/*! @} */

/*! @name GPDI14 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI14_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI14_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI14_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI14_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI14_PDI_n_SHIFT)) & SIUL2_GPDI14_PDI_n_MASK)
/*! @} */

/*! @name GPDI13 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI13_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI13_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI13_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI13_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI13_PDI_n_SHIFT)) & SIUL2_GPDI13_PDI_n_MASK)
/*! @} */

/*! @name GPDI12 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI12_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI12_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI12_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI12_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI12_PDI_n_SHIFT)) & SIUL2_GPDI12_PDI_n_MASK)
/*! @} */

/*! @name GPDI19 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI19_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI19_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI19_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI19_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI19_PDI_n_SHIFT)) & SIUL2_GPDI19_PDI_n_MASK)
/*! @} */

/*! @name GPDI18 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI18_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI18_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI18_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI18_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI18_PDI_n_SHIFT)) & SIUL2_GPDI18_PDI_n_MASK)
/*! @} */

/*! @name GPDI17 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI17_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI17_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI17_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI17_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI17_PDI_n_SHIFT)) & SIUL2_GPDI17_PDI_n_MASK)
/*! @} */

/*! @name GPDI16 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI16_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI16_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI16_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI16_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI16_PDI_n_SHIFT)) & SIUL2_GPDI16_PDI_n_MASK)
/*! @} */

/*! @name GPDI23 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI23_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI23_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI23_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI23_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI23_PDI_n_SHIFT)) & SIUL2_GPDI23_PDI_n_MASK)
/*! @} */

/*! @name GPDI22 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI22_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI22_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI22_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI22_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI22_PDI_n_SHIFT)) & SIUL2_GPDI22_PDI_n_MASK)
/*! @} */

/*! @name GPDI21 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI21_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI21_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI21_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI21_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI21_PDI_n_SHIFT)) & SIUL2_GPDI21_PDI_n_MASK)
/*! @} */

/*! @name GPDI20 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI20_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI20_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI20_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI20_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI20_PDI_n_SHIFT)) & SIUL2_GPDI20_PDI_n_MASK)
/*! @} */

/*! @name GPDI27 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI27_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI27_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI27_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI27_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI27_PDI_n_SHIFT)) & SIUL2_GPDI27_PDI_n_MASK)
/*! @} */

/*! @name GPDI26 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI26_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI26_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI26_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI26_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI26_PDI_n_SHIFT)) & SIUL2_GPDI26_PDI_n_MASK)
/*! @} */

/*! @name GPDI25 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI25_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI25_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI25_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI25_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI25_PDI_n_SHIFT)) & SIUL2_GPDI25_PDI_n_MASK)
/*! @} */

/*! @name GPDI24 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI24_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI24_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI24_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI24_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI24_PDI_n_SHIFT)) & SIUL2_GPDI24_PDI_n_MASK)
/*! @} */

/*! @name GPDI31 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI31_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI31_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI31_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI31_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI31_PDI_n_SHIFT)) & SIUL2_GPDI31_PDI_n_MASK)
/*! @} */

/*! @name GPDI30 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI30_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI30_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI30_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI30_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI30_PDI_n_SHIFT)) & SIUL2_GPDI30_PDI_n_MASK)
/*! @} */

/*! @name GPDI29 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI29_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI29_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI29_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI29_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI29_PDI_n_SHIFT)) & SIUL2_GPDI29_PDI_n_MASK)
/*! @} */

/*! @name GPDI28 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI28_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI28_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI28_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI28_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI28_PDI_n_SHIFT)) & SIUL2_GPDI28_PDI_n_MASK)
/*! @} */

/*! @name GPDI35 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI35_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI35_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI35_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI35_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI35_PDI_n_SHIFT)) & SIUL2_GPDI35_PDI_n_MASK)
/*! @} */

/*! @name GPDI34 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI34_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI34_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI34_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI34_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI34_PDI_n_SHIFT)) & SIUL2_GPDI34_PDI_n_MASK)
/*! @} */

/*! @name GPDI33 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI33_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI33_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI33_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI33_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI33_PDI_n_SHIFT)) & SIUL2_GPDI33_PDI_n_MASK)
/*! @} */

/*! @name GPDI32 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI32_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI32_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI32_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI32_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI32_PDI_n_SHIFT)) & SIUL2_GPDI32_PDI_n_MASK)
/*! @} */

/*! @name GPDI39 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI39_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI39_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI39_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI39_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI39_PDI_n_SHIFT)) & SIUL2_GPDI39_PDI_n_MASK)
/*! @} */

/*! @name GPDI38 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI38_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI38_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI38_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI38_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI38_PDI_n_SHIFT)) & SIUL2_GPDI38_PDI_n_MASK)
/*! @} */

/*! @name GPDI37 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI37_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI37_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI37_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI37_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI37_PDI_n_SHIFT)) & SIUL2_GPDI37_PDI_n_MASK)
/*! @} */

/*! @name GPDI36 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI36_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI36_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI36_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI36_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI36_PDI_n_SHIFT)) & SIUL2_GPDI36_PDI_n_MASK)
/*! @} */

/*! @name GPDI43 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI43_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI43_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI43_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI43_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI43_PDI_n_SHIFT)) & SIUL2_GPDI43_PDI_n_MASK)
/*! @} */

/*! @name GPDI42 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI42_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI42_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI42_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI42_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI42_PDI_n_SHIFT)) & SIUL2_GPDI42_PDI_n_MASK)
/*! @} */

/*! @name GPDI41 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI41_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI41_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI41_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI41_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI41_PDI_n_SHIFT)) & SIUL2_GPDI41_PDI_n_MASK)
/*! @} */

/*! @name GPDI40 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI40_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI40_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI40_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI40_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI40_PDI_n_SHIFT)) & SIUL2_GPDI40_PDI_n_MASK)
/*! @} */

/*! @name GPDI47 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI47_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI47_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI47_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI47_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI47_PDI_n_SHIFT)) & SIUL2_GPDI47_PDI_n_MASK)
/*! @} */

/*! @name GPDI46 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI46_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI46_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI46_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI46_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI46_PDI_n_SHIFT)) & SIUL2_GPDI46_PDI_n_MASK)
/*! @} */

/*! @name GPDI45 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI45_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI45_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI45_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI45_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI45_PDI_n_SHIFT)) & SIUL2_GPDI45_PDI_n_MASK)
/*! @} */

/*! @name GPDI44 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI44_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI44_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI44_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI44_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI44_PDI_n_SHIFT)) & SIUL2_GPDI44_PDI_n_MASK)
/*! @} */

/*! @name GPDI51 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI51_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI51_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI51_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI51_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI51_PDI_n_SHIFT)) & SIUL2_GPDI51_PDI_n_MASK)
/*! @} */

/*! @name GPDI49 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI49_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI49_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI49_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI49_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI49_PDI_n_SHIFT)) & SIUL2_GPDI49_PDI_n_MASK)
/*! @} */

/*! @name GPDI48 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI48_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI48_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI48_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI48_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI48_PDI_n_SHIFT)) & SIUL2_GPDI48_PDI_n_MASK)
/*! @} */

/*! @name GPDI55 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI55_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI55_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI55_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI55_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI55_PDI_n_SHIFT)) & SIUL2_GPDI55_PDI_n_MASK)
/*! @} */

/*! @name GPDI54 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI54_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI54_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI54_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI54_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI54_PDI_n_SHIFT)) & SIUL2_GPDI54_PDI_n_MASK)
/*! @} */

/*! @name GPDI53 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI53_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI53_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI53_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI53_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI53_PDI_n_SHIFT)) & SIUL2_GPDI53_PDI_n_MASK)
/*! @} */

/*! @name GPDI52 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI52_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI52_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI52_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI52_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI52_PDI_n_SHIFT)) & SIUL2_GPDI52_PDI_n_MASK)
/*! @} */

/*! @name GPDI59 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI59_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI59_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI59_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI59_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI59_PDI_n_SHIFT)) & SIUL2_GPDI59_PDI_n_MASK)
/*! @} */

/*! @name GPDI58 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI58_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI58_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI58_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI58_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI58_PDI_n_SHIFT)) & SIUL2_GPDI58_PDI_n_MASK)
/*! @} */

/*! @name GPDI57 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI57_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI57_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI57_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI57_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI57_PDI_n_SHIFT)) & SIUL2_GPDI57_PDI_n_MASK)
/*! @} */

/*! @name GPDI56 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI56_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI56_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI56_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI56_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI56_PDI_n_SHIFT)) & SIUL2_GPDI56_PDI_n_MASK)
/*! @} */

/*! @name GPDI63 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI63_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI63_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI63_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI63_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI63_PDI_n_SHIFT)) & SIUL2_GPDI63_PDI_n_MASK)
/*! @} */

/*! @name GPDI62 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI62_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI62_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI62_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI62_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI62_PDI_n_SHIFT)) & SIUL2_GPDI62_PDI_n_MASK)
/*! @} */

/*! @name GPDI61 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI61_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI61_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI61_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI61_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI61_PDI_n_SHIFT)) & SIUL2_GPDI61_PDI_n_MASK)
/*! @} */

/*! @name GPDI60 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI60_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI60_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI60_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI60_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI60_PDI_n_SHIFT)) & SIUL2_GPDI60_PDI_n_MASK)
/*! @} */

/*! @name GPDI67 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI67_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI67_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI67_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI67_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI67_PDI_n_SHIFT)) & SIUL2_GPDI67_PDI_n_MASK)
/*! @} */

/*! @name GPDI66 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI66_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI66_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI66_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI66_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI66_PDI_n_SHIFT)) & SIUL2_GPDI66_PDI_n_MASK)
/*! @} */

/*! @name GPDI65 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI65_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI65_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI65_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI65_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI65_PDI_n_SHIFT)) & SIUL2_GPDI65_PDI_n_MASK)
/*! @} */

/*! @name GPDI64 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI64_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI64_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI64_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI64_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI64_PDI_n_SHIFT)) & SIUL2_GPDI64_PDI_n_MASK)
/*! @} */

/*! @name GPDI71 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI71_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI71_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI71_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI71_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI71_PDI_n_SHIFT)) & SIUL2_GPDI71_PDI_n_MASK)
/*! @} */

/*! @name GPDI70 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI70_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI70_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI70_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI70_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI70_PDI_n_SHIFT)) & SIUL2_GPDI70_PDI_n_MASK)
/*! @} */

/*! @name GPDI69 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI69_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI69_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI69_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI69_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI69_PDI_n_SHIFT)) & SIUL2_GPDI69_PDI_n_MASK)
/*! @} */

/*! @name GPDI68 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI68_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI68_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI68_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI68_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI68_PDI_n_SHIFT)) & SIUL2_GPDI68_PDI_n_MASK)
/*! @} */

/*! @name GPDI75 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI75_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI75_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI75_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI75_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI75_PDI_n_SHIFT)) & SIUL2_GPDI75_PDI_n_MASK)
/*! @} */

/*! @name GPDI74 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI74_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI74_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI74_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI74_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI74_PDI_n_SHIFT)) & SIUL2_GPDI74_PDI_n_MASK)
/*! @} */

/*! @name GPDI73 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI73_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI73_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI73_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI73_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI73_PDI_n_SHIFT)) & SIUL2_GPDI73_PDI_n_MASK)
/*! @} */

/*! @name GPDI72 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI72_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI72_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI72_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI72_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI72_PDI_n_SHIFT)) & SIUL2_GPDI72_PDI_n_MASK)
/*! @} */

/*! @name GPDI78 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI78_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI78_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI78_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI78_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI78_PDI_n_SHIFT)) & SIUL2_GPDI78_PDI_n_MASK)
/*! @} */

/*! @name GPDI77 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI77_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI77_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI77_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI77_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI77_PDI_n_SHIFT)) & SIUL2_GPDI77_PDI_n_MASK)
/*! @} */

/*! @name GPDI76 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI76_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI76_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI76_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI76_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI76_PDI_n_SHIFT)) & SIUL2_GPDI76_PDI_n_MASK)
/*! @} */

/*! @name GPDI83 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI83_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI83_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI83_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI83_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI83_PDI_n_SHIFT)) & SIUL2_GPDI83_PDI_n_MASK)
/*! @} */

/*! @name GPDI82 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI82_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI82_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI82_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI82_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI82_PDI_n_SHIFT)) & SIUL2_GPDI82_PDI_n_MASK)
/*! @} */

/*! @name GPDI81 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI81_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI81_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI81_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI81_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI81_PDI_n_SHIFT)) & SIUL2_GPDI81_PDI_n_MASK)
/*! @} */

/*! @name GPDI80 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI80_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI80_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI80_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI80_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI80_PDI_n_SHIFT)) & SIUL2_GPDI80_PDI_n_MASK)
/*! @} */

/*! @name GPDI87 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI87_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI87_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI87_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI87_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI87_PDI_n_SHIFT)) & SIUL2_GPDI87_PDI_n_MASK)
/*! @} */

/*! @name GPDI86 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI86_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI86_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI86_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI86_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI86_PDI_n_SHIFT)) & SIUL2_GPDI86_PDI_n_MASK)
/*! @} */

/*! @name GPDI85 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI85_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI85_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI85_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI85_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI85_PDI_n_SHIFT)) & SIUL2_GPDI85_PDI_n_MASK)
/*! @} */

/*! @name GPDI84 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI84_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI84_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI84_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI84_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI84_PDI_n_SHIFT)) & SIUL2_GPDI84_PDI_n_MASK)
/*! @} */

/*! @name GPDI91 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI91_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI91_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI91_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI91_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI91_PDI_n_SHIFT)) & SIUL2_GPDI91_PDI_n_MASK)
/*! @} */

/*! @name GPDI90 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI90_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI90_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI90_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI90_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI90_PDI_n_SHIFT)) & SIUL2_GPDI90_PDI_n_MASK)
/*! @} */

/*! @name GPDI89 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI89_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI89_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI89_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI89_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI89_PDI_n_SHIFT)) & SIUL2_GPDI89_PDI_n_MASK)
/*! @} */

/*! @name GPDI88 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI88_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI88_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI88_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI88_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI88_PDI_n_SHIFT)) & SIUL2_GPDI88_PDI_n_MASK)
/*! @} */

/*! @name GPDI95 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI95_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI95_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI95_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI95_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI95_PDI_n_SHIFT)) & SIUL2_GPDI95_PDI_n_MASK)
/*! @} */

/*! @name GPDI94 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI94_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI94_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI94_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI94_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI94_PDI_n_SHIFT)) & SIUL2_GPDI94_PDI_n_MASK)
/*! @} */

/*! @name GPDI93 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI93_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI93_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI93_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI93_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI93_PDI_n_SHIFT)) & SIUL2_GPDI93_PDI_n_MASK)
/*! @} */

/*! @name GPDI92 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI92_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI92_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI92_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI92_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI92_PDI_n_SHIFT)) & SIUL2_GPDI92_PDI_n_MASK)
/*! @} */

/*! @name GPDI99 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI99_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI99_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI99_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI99_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI99_PDI_n_SHIFT)) & SIUL2_GPDI99_PDI_n_MASK)
/*! @} */

/*! @name GPDI98 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI98_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI98_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI98_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI98_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI98_PDI_n_SHIFT)) & SIUL2_GPDI98_PDI_n_MASK)
/*! @} */

/*! @name GPDI97 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI97_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI97_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI97_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI97_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI97_PDI_n_SHIFT)) & SIUL2_GPDI97_PDI_n_MASK)
/*! @} */

/*! @name GPDI96 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI96_PDI_n_MASK                  (0x1U)
#define SIUL2_GPDI96_PDI_n_SHIFT                 (0U)
#define SIUL2_GPDI96_PDI_n_WIDTH                 (1U)
#define SIUL2_GPDI96_PDI_n(x)                    (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI96_PDI_n_SHIFT)) & SIUL2_GPDI96_PDI_n_MASK)
/*! @} */

/*! @name GPDI103 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI103_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI103_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI103_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI103_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI103_PDI_n_SHIFT)) & SIUL2_GPDI103_PDI_n_MASK)
/*! @} */

/*! @name GPDI102 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI102_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI102_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI102_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI102_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI102_PDI_n_SHIFT)) & SIUL2_GPDI102_PDI_n_MASK)
/*! @} */

/*! @name GPDI101 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI101_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI101_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI101_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI101_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI101_PDI_n_SHIFT)) & SIUL2_GPDI101_PDI_n_MASK)
/*! @} */

/*! @name GPDI100 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI100_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI100_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI100_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI100_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI100_PDI_n_SHIFT)) & SIUL2_GPDI100_PDI_n_MASK)
/*! @} */

/*! @name GPDI107 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI107_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI107_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI107_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI107_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI107_PDI_n_SHIFT)) & SIUL2_GPDI107_PDI_n_MASK)
/*! @} */

/*! @name GPDI106 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI106_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI106_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI106_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI106_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI106_PDI_n_SHIFT)) & SIUL2_GPDI106_PDI_n_MASK)
/*! @} */

/*! @name GPDI105 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI105_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI105_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI105_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI105_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI105_PDI_n_SHIFT)) & SIUL2_GPDI105_PDI_n_MASK)
/*! @} */

/*! @name GPDI104 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI104_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI104_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI104_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI104_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI104_PDI_n_SHIFT)) & SIUL2_GPDI104_PDI_n_MASK)
/*! @} */

/*! @name GPDI111 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI111_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI111_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI111_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI111_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI111_PDI_n_SHIFT)) & SIUL2_GPDI111_PDI_n_MASK)
/*! @} */

/*! @name GPDI110 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI110_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI110_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI110_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI110_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI110_PDI_n_SHIFT)) & SIUL2_GPDI110_PDI_n_MASK)
/*! @} */

/*! @name GPDI109 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI109_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI109_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI109_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI109_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI109_PDI_n_SHIFT)) & SIUL2_GPDI109_PDI_n_MASK)
/*! @} */

/*! @name GPDI108 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI108_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI108_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI108_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI108_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI108_PDI_n_SHIFT)) & SIUL2_GPDI108_PDI_n_MASK)
/*! @} */

/*! @name GPDI115 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI115_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI115_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI115_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI115_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI115_PDI_n_SHIFT)) & SIUL2_GPDI115_PDI_n_MASK)
/*! @} */

/*! @name GPDI114 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI114_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI114_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI114_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI114_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI114_PDI_n_SHIFT)) & SIUL2_GPDI114_PDI_n_MASK)
/*! @} */

/*! @name GPDI113 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI113_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI113_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI113_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI113_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI113_PDI_n_SHIFT)) & SIUL2_GPDI113_PDI_n_MASK)
/*! @} */

/*! @name GPDI112 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI112_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI112_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI112_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI112_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI112_PDI_n_SHIFT)) & SIUL2_GPDI112_PDI_n_MASK)
/*! @} */

/*! @name GPDI116 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI116_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI116_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI116_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI116_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI116_PDI_n_SHIFT)) & SIUL2_GPDI116_PDI_n_MASK)
/*! @} */

/*! @name GPDI127 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI127_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI127_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI127_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI127_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI127_PDI_n_SHIFT)) & SIUL2_GPDI127_PDI_n_MASK)
/*! @} */

/*! @name GPDI126 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI126_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI126_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI126_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI126_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI126_PDI_n_SHIFT)) & SIUL2_GPDI126_PDI_n_MASK)
/*! @} */

/*! @name GPDI131 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI131_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI131_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI131_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI131_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI131_PDI_n_SHIFT)) & SIUL2_GPDI131_PDI_n_MASK)
/*! @} */

/*! @name GPDI130 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI130_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI130_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI130_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI130_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI130_PDI_n_SHIFT)) & SIUL2_GPDI130_PDI_n_MASK)
/*! @} */

/*! @name GPDI129 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI129_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI129_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI129_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI129_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI129_PDI_n_SHIFT)) & SIUL2_GPDI129_PDI_n_MASK)
/*! @} */

/*! @name GPDI128 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI128_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI128_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI128_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI128_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI128_PDI_n_SHIFT)) & SIUL2_GPDI128_PDI_n_MASK)
/*! @} */

/*! @name GPDI135 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI135_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI135_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI135_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI135_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI135_PDI_n_SHIFT)) & SIUL2_GPDI135_PDI_n_MASK)
/*! @} */

/*! @name GPDI134 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI134_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI134_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI134_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI134_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI134_PDI_n_SHIFT)) & SIUL2_GPDI134_PDI_n_MASK)
/*! @} */

/*! @name GPDI133 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI133_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI133_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI133_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI133_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI133_PDI_n_SHIFT)) & SIUL2_GPDI133_PDI_n_MASK)
/*! @} */

/*! @name GPDI132 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI132_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI132_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI132_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI132_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI132_PDI_n_SHIFT)) & SIUL2_GPDI132_PDI_n_MASK)
/*! @} */

/*! @name GPDI138 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI138_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI138_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI138_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI138_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI138_PDI_n_SHIFT)) & SIUL2_GPDI138_PDI_n_MASK)
/*! @} */

/*! @name GPDI137 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI137_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI137_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI137_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI137_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI137_PDI_n_SHIFT)) & SIUL2_GPDI137_PDI_n_MASK)
/*! @} */

/*! @name GPDI136 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI136_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI136_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI136_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI136_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI136_PDI_n_SHIFT)) & SIUL2_GPDI136_PDI_n_MASK)
/*! @} */

/*! @name GPDI148 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI148_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI148_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI148_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI148_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI148_PDI_n_SHIFT)) & SIUL2_GPDI148_PDI_n_MASK)
/*! @} */

/*! @name GPDI159 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI159_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI159_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI159_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI159_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI159_PDI_n_SHIFT)) & SIUL2_GPDI159_PDI_n_MASK)
/*! @} */

/*! @name GPDI158 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI158_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI158_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI158_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI158_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI158_PDI_n_SHIFT)) & SIUL2_GPDI158_PDI_n_MASK)
/*! @} */

/*! @name GPDI157 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI157_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI157_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI157_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI157_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI157_PDI_n_SHIFT)) & SIUL2_GPDI157_PDI_n_MASK)
/*! @} */

/*! @name GPDI156 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI156_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI156_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI156_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI156_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI156_PDI_n_SHIFT)) & SIUL2_GPDI156_PDI_n_MASK)
/*! @} */

/*! @name GPDI163 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI163_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI163_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI163_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI163_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI163_PDI_n_SHIFT)) & SIUL2_GPDI163_PDI_n_MASK)
/*! @} */

/*! @name GPDI162 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI162_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI162_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI162_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI162_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI162_PDI_n_SHIFT)) & SIUL2_GPDI162_PDI_n_MASK)
/*! @} */

/*! @name GPDI161 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI161_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI161_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI161_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI161_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI161_PDI_n_SHIFT)) & SIUL2_GPDI161_PDI_n_MASK)
/*! @} */

/*! @name GPDI160 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI160_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI160_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI160_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI160_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI160_PDI_n_SHIFT)) & SIUL2_GPDI160_PDI_n_MASK)
/*! @} */

/*! @name GPDI167 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI167_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI167_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI167_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI167_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI167_PDI_n_SHIFT)) & SIUL2_GPDI167_PDI_n_MASK)
/*! @} */

/*! @name GPDI166 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI166_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI166_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI166_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI166_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI166_PDI_n_SHIFT)) & SIUL2_GPDI166_PDI_n_MASK)
/*! @} */

/*! @name GPDI165 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI165_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI165_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI165_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI165_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI165_PDI_n_SHIFT)) & SIUL2_GPDI165_PDI_n_MASK)
/*! @} */

/*! @name GPDI164 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI164_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI164_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI164_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI164_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI164_PDI_n_SHIFT)) & SIUL2_GPDI164_PDI_n_MASK)
/*! @} */

/*! @name GPDI171 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI171_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI171_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI171_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI171_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI171_PDI_n_SHIFT)) & SIUL2_GPDI171_PDI_n_MASK)
/*! @} */

/*! @name GPDI170 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI170_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI170_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI170_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI170_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI170_PDI_n_SHIFT)) & SIUL2_GPDI170_PDI_n_MASK)
/*! @} */

/*! @name GPDI169 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI169_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI169_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI169_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI169_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI169_PDI_n_SHIFT)) & SIUL2_GPDI169_PDI_n_MASK)
/*! @} */

/*! @name GPDI168 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI168_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI168_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI168_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI168_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI168_PDI_n_SHIFT)) & SIUL2_GPDI168_PDI_n_MASK)
/*! @} */

/*! @name GPDI175 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI175_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI175_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI175_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI175_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI175_PDI_n_SHIFT)) & SIUL2_GPDI175_PDI_n_MASK)
/*! @} */

/*! @name GPDI174 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI174_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI174_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI174_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI174_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI174_PDI_n_SHIFT)) & SIUL2_GPDI174_PDI_n_MASK)
/*! @} */

/*! @name GPDI173 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI173_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI173_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI173_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI173_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI173_PDI_n_SHIFT)) & SIUL2_GPDI173_PDI_n_MASK)
/*! @} */

/*! @name GPDI172 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI172_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI172_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI172_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI172_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI172_PDI_n_SHIFT)) & SIUL2_GPDI172_PDI_n_MASK)
/*! @} */

/*! @name GPDI179 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI179_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI179_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI179_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI179_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI179_PDI_n_SHIFT)) & SIUL2_GPDI179_PDI_n_MASK)
/*! @} */

/*! @name GPDI178 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI178_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI178_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI178_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI178_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI178_PDI_n_SHIFT)) & SIUL2_GPDI178_PDI_n_MASK)
/*! @} */

/*! @name GPDI177 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI177_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI177_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI177_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI177_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI177_PDI_n_SHIFT)) & SIUL2_GPDI177_PDI_n_MASK)
/*! @} */

/*! @name GPDI176 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI176_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI176_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI176_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI176_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI176_PDI_n_SHIFT)) & SIUL2_GPDI176_PDI_n_MASK)
/*! @} */

/*! @name GPDI183 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI183_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI183_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI183_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI183_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI183_PDI_n_SHIFT)) & SIUL2_GPDI183_PDI_n_MASK)
/*! @} */

/*! @name GPDI182 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI182_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI182_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI182_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI182_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI182_PDI_n_SHIFT)) & SIUL2_GPDI182_PDI_n_MASK)
/*! @} */

/*! @name GPDI181 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI181_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI181_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI181_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI181_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI181_PDI_n_SHIFT)) & SIUL2_GPDI181_PDI_n_MASK)
/*! @} */

/*! @name GPDI180 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI180_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI180_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI180_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI180_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI180_PDI_n_SHIFT)) & SIUL2_GPDI180_PDI_n_MASK)
/*! @} */

/*! @name GPDI187 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI187_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI187_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI187_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI187_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI187_PDI_n_SHIFT)) & SIUL2_GPDI187_PDI_n_MASK)
/*! @} */

/*! @name GPDI186 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI186_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI186_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI186_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI186_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI186_PDI_n_SHIFT)) & SIUL2_GPDI186_PDI_n_MASK)
/*! @} */

/*! @name GPDI185 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI185_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI185_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI185_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI185_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI185_PDI_n_SHIFT)) & SIUL2_GPDI185_PDI_n_MASK)
/*! @} */

/*! @name GPDI184 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI184_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI184_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI184_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI184_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI184_PDI_n_SHIFT)) & SIUL2_GPDI184_PDI_n_MASK)
/*! @} */

/*! @name GPDI191 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI191_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI191_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI191_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI191_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI191_PDI_n_SHIFT)) & SIUL2_GPDI191_PDI_n_MASK)
/*! @} */

/*! @name GPDI190 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI190_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI190_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI190_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI190_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI190_PDI_n_SHIFT)) & SIUL2_GPDI190_PDI_n_MASK)
/*! @} */

/*! @name GPDI189 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI189_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI189_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI189_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI189_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI189_PDI_n_SHIFT)) & SIUL2_GPDI189_PDI_n_MASK)
/*! @} */

/*! @name GPDI188 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI188_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI188_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI188_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI188_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI188_PDI_n_SHIFT)) & SIUL2_GPDI188_PDI_n_MASK)
/*! @} */

/*! @name GPDI195 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI195_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI195_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI195_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI195_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI195_PDI_n_SHIFT)) & SIUL2_GPDI195_PDI_n_MASK)
/*! @} */

/*! @name GPDI194 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI194_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI194_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI194_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI194_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI194_PDI_n_SHIFT)) & SIUL2_GPDI194_PDI_n_MASK)
/*! @} */

/*! @name GPDI193 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI193_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI193_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI193_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI193_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI193_PDI_n_SHIFT)) & SIUL2_GPDI193_PDI_n_MASK)
/*! @} */

/*! @name GPDI192 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI192_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI192_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI192_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI192_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI192_PDI_n_SHIFT)) & SIUL2_GPDI192_PDI_n_MASK)
/*! @} */

/*! @name GPDI199 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI199_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI199_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI199_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI199_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI199_PDI_n_SHIFT)) & SIUL2_GPDI199_PDI_n_MASK)
/*! @} */

/*! @name GPDI198 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI198_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI198_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI198_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI198_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI198_PDI_n_SHIFT)) & SIUL2_GPDI198_PDI_n_MASK)
/*! @} */

/*! @name GPDI197 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI197_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI197_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI197_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI197_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI197_PDI_n_SHIFT)) & SIUL2_GPDI197_PDI_n_MASK)
/*! @} */

/*! @name GPDI196 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI196_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI196_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI196_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI196_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI196_PDI_n_SHIFT)) & SIUL2_GPDI196_PDI_n_MASK)
/*! @} */

/*! @name GPDI203 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI203_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI203_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI203_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI203_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI203_PDI_n_SHIFT)) & SIUL2_GPDI203_PDI_n_MASK)
/*! @} */

/*! @name GPDI202 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI202_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI202_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI202_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI202_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI202_PDI_n_SHIFT)) & SIUL2_GPDI202_PDI_n_MASK)
/*! @} */

/*! @name GPDI201 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI201_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI201_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI201_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI201_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI201_PDI_n_SHIFT)) & SIUL2_GPDI201_PDI_n_MASK)
/*! @} */

/*! @name GPDI200 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI200_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI200_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI200_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI200_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI200_PDI_n_SHIFT)) & SIUL2_GPDI200_PDI_n_MASK)
/*! @} */

/*! @name GPDI207 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI207_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI207_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI207_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI207_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI207_PDI_n_SHIFT)) & SIUL2_GPDI207_PDI_n_MASK)
/*! @} */

/*! @name GPDI206 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI206_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI206_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI206_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI206_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI206_PDI_n_SHIFT)) & SIUL2_GPDI206_PDI_n_MASK)
/*! @} */

/*! @name GPDI205 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI205_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI205_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI205_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI205_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI205_PDI_n_SHIFT)) & SIUL2_GPDI205_PDI_n_MASK)
/*! @} */

/*! @name GPDI204 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI204_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI204_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI204_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI204_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI204_PDI_n_SHIFT)) & SIUL2_GPDI204_PDI_n_MASK)
/*! @} */

/*! @name GPDI211 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI211_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI211_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI211_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI211_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI211_PDI_n_SHIFT)) & SIUL2_GPDI211_PDI_n_MASK)
/*! @} */

/*! @name GPDI210 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI210_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI210_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI210_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI210_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI210_PDI_n_SHIFT)) & SIUL2_GPDI210_PDI_n_MASK)
/*! @} */

/*! @name GPDI209 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI209_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI209_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI209_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI209_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI209_PDI_n_SHIFT)) & SIUL2_GPDI209_PDI_n_MASK)
/*! @} */

/*! @name GPDI208 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI208_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI208_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI208_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI208_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI208_PDI_n_SHIFT)) & SIUL2_GPDI208_PDI_n_MASK)
/*! @} */

/*! @name GPDI215 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI215_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI215_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI215_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI215_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI215_PDI_n_SHIFT)) & SIUL2_GPDI215_PDI_n_MASK)
/*! @} */

/*! @name GPDI214 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI214_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI214_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI214_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI214_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI214_PDI_n_SHIFT)) & SIUL2_GPDI214_PDI_n_MASK)
/*! @} */

/*! @name GPDI213 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI213_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI213_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI213_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI213_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI213_PDI_n_SHIFT)) & SIUL2_GPDI213_PDI_n_MASK)
/*! @} */

/*! @name GPDI212 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI212_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI212_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI212_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI212_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI212_PDI_n_SHIFT)) & SIUL2_GPDI212_PDI_n_MASK)
/*! @} */

/*! @name GPDI219 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI219_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI219_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI219_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI219_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI219_PDI_n_SHIFT)) & SIUL2_GPDI219_PDI_n_MASK)
/*! @} */

/*! @name GPDI218 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI218_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI218_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI218_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI218_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI218_PDI_n_SHIFT)) & SIUL2_GPDI218_PDI_n_MASK)
/*! @} */

/*! @name GPDI217 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI217_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI217_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI217_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI217_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI217_PDI_n_SHIFT)) & SIUL2_GPDI217_PDI_n_MASK)
/*! @} */

/*! @name GPDI216 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI216_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI216_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI216_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI216_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI216_PDI_n_SHIFT)) & SIUL2_GPDI216_PDI_n_MASK)
/*! @} */

/*! @name GPDI223 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI223_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI223_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI223_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI223_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI223_PDI_n_SHIFT)) & SIUL2_GPDI223_PDI_n_MASK)
/*! @} */

/*! @name GPDI222 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI222_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI222_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI222_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI222_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI222_PDI_n_SHIFT)) & SIUL2_GPDI222_PDI_n_MASK)
/*! @} */

/*! @name GPDI221 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI221_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI221_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI221_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI221_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI221_PDI_n_SHIFT)) & SIUL2_GPDI221_PDI_n_MASK)
/*! @} */

/*! @name GPDI220 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI220_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI220_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI220_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI220_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI220_PDI_n_SHIFT)) & SIUL2_GPDI220_PDI_n_MASK)
/*! @} */

/*! @name GPDI227 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI227_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI227_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI227_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI227_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI227_PDI_n_SHIFT)) & SIUL2_GPDI227_PDI_n_MASK)
/*! @} */

/*! @name GPDI226 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI226_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI226_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI226_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI226_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI226_PDI_n_SHIFT)) & SIUL2_GPDI226_PDI_n_MASK)
/*! @} */

/*! @name GPDI225 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI225_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI225_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI225_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI225_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI225_PDI_n_SHIFT)) & SIUL2_GPDI225_PDI_n_MASK)
/*! @} */

/*! @name GPDI224 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI224_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI224_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI224_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI224_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI224_PDI_n_SHIFT)) & SIUL2_GPDI224_PDI_n_MASK)
/*! @} */

/*! @name GPDI231 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI231_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI231_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI231_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI231_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI231_PDI_n_SHIFT)) & SIUL2_GPDI231_PDI_n_MASK)
/*! @} */

/*! @name GPDI229 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI229_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI229_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI229_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI229_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI229_PDI_n_SHIFT)) & SIUL2_GPDI229_PDI_n_MASK)
/*! @} */

/*! @name GPDI228 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI228_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI228_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI228_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI228_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI228_PDI_n_SHIFT)) & SIUL2_GPDI228_PDI_n_MASK)
/*! @} */

/*! @name GPDI235 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI235_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI235_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI235_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI235_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI235_PDI_n_SHIFT)) & SIUL2_GPDI235_PDI_n_MASK)
/*! @} */

/*! @name GPDI234 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI234_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI234_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI234_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI234_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI234_PDI_n_SHIFT)) & SIUL2_GPDI234_PDI_n_MASK)
/*! @} */

/*! @name GPDI233 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI233_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI233_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI233_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI233_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI233_PDI_n_SHIFT)) & SIUL2_GPDI233_PDI_n_MASK)
/*! @} */

/*! @name GPDI232 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI232_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI232_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI232_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI232_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI232_PDI_n_SHIFT)) & SIUL2_GPDI232_PDI_n_MASK)
/*! @} */

/*! @name GPDI239 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI239_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI239_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI239_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI239_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI239_PDI_n_SHIFT)) & SIUL2_GPDI239_PDI_n_MASK)
/*! @} */

/*! @name GPDI238 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI238_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI238_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI238_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI238_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI238_PDI_n_SHIFT)) & SIUL2_GPDI238_PDI_n_MASK)
/*! @} */

/*! @name GPDI237 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI237_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI237_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI237_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI237_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI237_PDI_n_SHIFT)) & SIUL2_GPDI237_PDI_n_MASK)
/*! @} */

/*! @name GPDI236 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI236_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI236_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI236_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI236_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI236_PDI_n_SHIFT)) & SIUL2_GPDI236_PDI_n_MASK)
/*! @} */

/*! @name GPDI243 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI243_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI243_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI243_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI243_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI243_PDI_n_SHIFT)) & SIUL2_GPDI243_PDI_n_MASK)
/*! @} */

/*! @name GPDI242 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI242_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI242_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI242_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI242_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI242_PDI_n_SHIFT)) & SIUL2_GPDI242_PDI_n_MASK)
/*! @} */

/*! @name GPDI241 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI241_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI241_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI241_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI241_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI241_PDI_n_SHIFT)) & SIUL2_GPDI241_PDI_n_MASK)
/*! @} */

/*! @name GPDI240 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI240_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI240_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI240_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI240_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI240_PDI_n_SHIFT)) & SIUL2_GPDI240_PDI_n_MASK)
/*! @} */

/*! @name GPDI247 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI247_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI247_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI247_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI247_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI247_PDI_n_SHIFT)) & SIUL2_GPDI247_PDI_n_MASK)
/*! @} */

/*! @name GPDI246 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI246_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI246_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI246_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI246_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI246_PDI_n_SHIFT)) & SIUL2_GPDI246_PDI_n_MASK)
/*! @} */

/*! @name GPDI245 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI245_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI245_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI245_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI245_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI245_PDI_n_SHIFT)) & SIUL2_GPDI245_PDI_n_MASK)
/*! @} */

/*! @name GPDI244 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI244_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI244_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI244_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI244_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI244_PDI_n_SHIFT)) & SIUL2_GPDI244_PDI_n_MASK)
/*! @} */

/*! @name GPDI251 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI251_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI251_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI251_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI251_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI251_PDI_n_SHIFT)) & SIUL2_GPDI251_PDI_n_MASK)
/*! @} */

/*! @name GPDI250 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI250_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI250_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI250_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI250_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI250_PDI_n_SHIFT)) & SIUL2_GPDI250_PDI_n_MASK)
/*! @} */

/*! @name GPDI249 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI249_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI249_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI249_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI249_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI249_PDI_n_SHIFT)) & SIUL2_GPDI249_PDI_n_MASK)
/*! @} */

/*! @name GPDI248 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI248_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI248_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI248_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI248_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI248_PDI_n_SHIFT)) & SIUL2_GPDI248_PDI_n_MASK)
/*! @} */

/*! @name GPDI255 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI255_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI255_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI255_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI255_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI255_PDI_n_SHIFT)) & SIUL2_GPDI255_PDI_n_MASK)
/*! @} */

/*! @name GPDI254 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI254_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI254_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI254_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI254_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI254_PDI_n_SHIFT)) & SIUL2_GPDI254_PDI_n_MASK)
/*! @} */

/*! @name GPDI253 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI253_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI253_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI253_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI253_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI253_PDI_n_SHIFT)) & SIUL2_GPDI253_PDI_n_MASK)
/*! @} */

/*! @name GPDI252 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI252_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI252_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI252_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI252_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI252_PDI_n_SHIFT)) & SIUL2_GPDI252_PDI_n_MASK)
/*! @} */

/*! @name GPDI259 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI259_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI259_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI259_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI259_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI259_PDI_n_SHIFT)) & SIUL2_GPDI259_PDI_n_MASK)
/*! @} */

/*! @name GPDI258 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI258_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI258_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI258_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI258_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI258_PDI_n_SHIFT)) & SIUL2_GPDI258_PDI_n_MASK)
/*! @} */

/*! @name GPDI257 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI257_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI257_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI257_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI257_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI257_PDI_n_SHIFT)) & SIUL2_GPDI257_PDI_n_MASK)
/*! @} */

/*! @name GPDI256 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI256_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI256_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI256_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI256_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI256_PDI_n_SHIFT)) & SIUL2_GPDI256_PDI_n_MASK)
/*! @} */

/*! @name GPDI263 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI263_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI263_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI263_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI263_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI263_PDI_n_SHIFT)) & SIUL2_GPDI263_PDI_n_MASK)
/*! @} */

/*! @name GPDI262 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI262_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI262_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI262_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI262_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI262_PDI_n_SHIFT)) & SIUL2_GPDI262_PDI_n_MASK)
/*! @} */

/*! @name GPDI261 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI261_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI261_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI261_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI261_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI261_PDI_n_SHIFT)) & SIUL2_GPDI261_PDI_n_MASK)
/*! @} */

/*! @name GPDI260 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI260_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI260_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI260_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI260_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI260_PDI_n_SHIFT)) & SIUL2_GPDI260_PDI_n_MASK)
/*! @} */

/*! @name GPDI264 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI264_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI264_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI264_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI264_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI264_PDI_n_SHIFT)) & SIUL2_GPDI264_PDI_n_MASK)
/*! @} */

/*! @name GPDI307 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI307_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI307_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI307_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI307_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI307_PDI_n_SHIFT)) & SIUL2_GPDI307_PDI_n_MASK)
/*! @} */

/*! @name GPDI306 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI306_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI306_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI306_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI306_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI306_PDI_n_SHIFT)) & SIUL2_GPDI306_PDI_n_MASK)
/*! @} */

/*! @name GPDI305 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI305_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI305_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI305_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI305_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI305_PDI_n_SHIFT)) & SIUL2_GPDI305_PDI_n_MASK)
/*! @} */

/*! @name GPDI304 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI304_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI304_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI304_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI304_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI304_PDI_n_SHIFT)) & SIUL2_GPDI304_PDI_n_MASK)
/*! @} */

/*! @name GPDI311 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI311_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI311_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI311_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI311_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI311_PDI_n_SHIFT)) & SIUL2_GPDI311_PDI_n_MASK)
/*! @} */

/*! @name GPDI310 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI310_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI310_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI310_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI310_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI310_PDI_n_SHIFT)) & SIUL2_GPDI310_PDI_n_MASK)
/*! @} */

/*! @name GPDI309 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI309_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI309_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI309_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI309_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI309_PDI_n_SHIFT)) & SIUL2_GPDI309_PDI_n_MASK)
/*! @} */

/*! @name GPDI308 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI308_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI308_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI308_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI308_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI308_PDI_n_SHIFT)) & SIUL2_GPDI308_PDI_n_MASK)
/*! @} */

/*! @name GPDI315 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI315_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI315_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI315_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI315_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI315_PDI_n_SHIFT)) & SIUL2_GPDI315_PDI_n_MASK)
/*! @} */

/*! @name GPDI314 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI314_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI314_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI314_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI314_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI314_PDI_n_SHIFT)) & SIUL2_GPDI314_PDI_n_MASK)
/*! @} */

/*! @name GPDI313 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI313_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI313_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI313_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI313_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI313_PDI_n_SHIFT)) & SIUL2_GPDI313_PDI_n_MASK)
/*! @} */

/*! @name GPDI312 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI312_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI312_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI312_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI312_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI312_PDI_n_SHIFT)) & SIUL2_GPDI312_PDI_n_MASK)
/*! @} */

/*! @name GPDI319 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI319_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI319_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI319_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI319_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI319_PDI_n_SHIFT)) & SIUL2_GPDI319_PDI_n_MASK)
/*! @} */

/*! @name GPDI318 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI318_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI318_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI318_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI318_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI318_PDI_n_SHIFT)) & SIUL2_GPDI318_PDI_n_MASK)
/*! @} */

/*! @name GPDI317 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI317_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI317_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI317_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI317_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI317_PDI_n_SHIFT)) & SIUL2_GPDI317_PDI_n_MASK)
/*! @} */

/*! @name GPDI316 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI316_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI316_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI316_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI316_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI316_PDI_n_SHIFT)) & SIUL2_GPDI316_PDI_n_MASK)
/*! @} */

/*! @name GPDI323 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI323_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI323_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI323_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI323_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI323_PDI_n_SHIFT)) & SIUL2_GPDI323_PDI_n_MASK)
/*! @} */

/*! @name GPDI322 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI322_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI322_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI322_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI322_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI322_PDI_n_SHIFT)) & SIUL2_GPDI322_PDI_n_MASK)
/*! @} */

/*! @name GPDI321 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI321_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI321_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI321_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI321_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI321_PDI_n_SHIFT)) & SIUL2_GPDI321_PDI_n_MASK)
/*! @} */

/*! @name GPDI320 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI320_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI320_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI320_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI320_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI320_PDI_n_SHIFT)) & SIUL2_GPDI320_PDI_n_MASK)
/*! @} */

/*! @name GPDI327 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI327_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI327_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI327_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI327_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI327_PDI_n_SHIFT)) & SIUL2_GPDI327_PDI_n_MASK)
/*! @} */

/*! @name GPDI326 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI326_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI326_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI326_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI326_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI326_PDI_n_SHIFT)) & SIUL2_GPDI326_PDI_n_MASK)
/*! @} */

/*! @name GPDI325 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI325_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI325_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI325_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI325_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI325_PDI_n_SHIFT)) & SIUL2_GPDI325_PDI_n_MASK)
/*! @} */

/*! @name GPDI324 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI324_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI324_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI324_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI324_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI324_PDI_n_SHIFT)) & SIUL2_GPDI324_PDI_n_MASK)
/*! @} */

/*! @name GPDI331 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI331_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI331_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI331_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI331_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI331_PDI_n_SHIFT)) & SIUL2_GPDI331_PDI_n_MASK)
/*! @} */

/*! @name GPDI330 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI330_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI330_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI330_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI330_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI330_PDI_n_SHIFT)) & SIUL2_GPDI330_PDI_n_MASK)
/*! @} */

/*! @name GPDI329 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI329_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI329_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI329_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI329_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI329_PDI_n_SHIFT)) & SIUL2_GPDI329_PDI_n_MASK)
/*! @} */

/*! @name GPDI328 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI328_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI328_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI328_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI328_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI328_PDI_n_SHIFT)) & SIUL2_GPDI328_PDI_n_MASK)
/*! @} */

/*! @name GPDI335 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI335_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI335_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI335_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI335_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI335_PDI_n_SHIFT)) & SIUL2_GPDI335_PDI_n_MASK)
/*! @} */

/*! @name GPDI334 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI334_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI334_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI334_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI334_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI334_PDI_n_SHIFT)) & SIUL2_GPDI334_PDI_n_MASK)
/*! @} */

/*! @name GPDI333 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI333_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI333_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI333_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI333_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI333_PDI_n_SHIFT)) & SIUL2_GPDI333_PDI_n_MASK)
/*! @} */

/*! @name GPDI332 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI332_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI332_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI332_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI332_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI332_PDI_n_SHIFT)) & SIUL2_GPDI332_PDI_n_MASK)
/*! @} */

/*! @name GPDI339 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI339_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI339_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI339_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI339_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI339_PDI_n_SHIFT)) & SIUL2_GPDI339_PDI_n_MASK)
/*! @} */

/*! @name GPDI338 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI338_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI338_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI338_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI338_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI338_PDI_n_SHIFT)) & SIUL2_GPDI338_PDI_n_MASK)
/*! @} */

/*! @name GPDI337 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI337_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI337_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI337_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI337_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI337_PDI_n_SHIFT)) & SIUL2_GPDI337_PDI_n_MASK)
/*! @} */

/*! @name GPDI336 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI336_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI336_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI336_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI336_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI336_PDI_n_SHIFT)) & SIUL2_GPDI336_PDI_n_MASK)
/*! @} */

/*! @name GPDI343 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI343_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI343_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI343_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI343_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI343_PDI_n_SHIFT)) & SIUL2_GPDI343_PDI_n_MASK)
/*! @} */

/*! @name GPDI342 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI342_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI342_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI342_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI342_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI342_PDI_n_SHIFT)) & SIUL2_GPDI342_PDI_n_MASK)
/*! @} */

/*! @name GPDI341 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI341_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI341_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI341_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI341_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI341_PDI_n_SHIFT)) & SIUL2_GPDI341_PDI_n_MASK)
/*! @} */

/*! @name GPDI340 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI340_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI340_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI340_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI340_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI340_PDI_n_SHIFT)) & SIUL2_GPDI340_PDI_n_MASK)
/*! @} */

/*! @name GPDI347 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI347_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI347_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI347_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI347_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI347_PDI_n_SHIFT)) & SIUL2_GPDI347_PDI_n_MASK)
/*! @} */

/*! @name GPDI346 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI346_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI346_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI346_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI346_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI346_PDI_n_SHIFT)) & SIUL2_GPDI346_PDI_n_MASK)
/*! @} */

/*! @name GPDI345 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI345_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI345_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI345_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI345_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI345_PDI_n_SHIFT)) & SIUL2_GPDI345_PDI_n_MASK)
/*! @} */

/*! @name GPDI344 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI344_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI344_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI344_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI344_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI344_PDI_n_SHIFT)) & SIUL2_GPDI344_PDI_n_MASK)
/*! @} */

/*! @name GPDI351 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI351_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI351_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI351_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI351_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI351_PDI_n_SHIFT)) & SIUL2_GPDI351_PDI_n_MASK)
/*! @} */

/*! @name GPDI350 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI350_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI350_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI350_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI350_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI350_PDI_n_SHIFT)) & SIUL2_GPDI350_PDI_n_MASK)
/*! @} */

/*! @name GPDI349 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI349_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI349_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI349_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI349_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI349_PDI_n_SHIFT)) & SIUL2_GPDI349_PDI_n_MASK)
/*! @} */

/*! @name GPDI348 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI348_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI348_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI348_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI348_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI348_PDI_n_SHIFT)) & SIUL2_GPDI348_PDI_n_MASK)
/*! @} */

/*! @name GPDI355 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI355_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI355_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI355_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI355_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI355_PDI_n_SHIFT)) & SIUL2_GPDI355_PDI_n_MASK)
/*! @} */

/*! @name GPDI354 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI354_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI354_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI354_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI354_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI354_PDI_n_SHIFT)) & SIUL2_GPDI354_PDI_n_MASK)
/*! @} */

/*! @name GPDI353 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI353_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI353_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI353_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI353_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI353_PDI_n_SHIFT)) & SIUL2_GPDI353_PDI_n_MASK)
/*! @} */

/*! @name GPDI352 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI352_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI352_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI352_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI352_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI352_PDI_n_SHIFT)) & SIUL2_GPDI352_PDI_n_MASK)
/*! @} */

/*! @name GPDI359 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI359_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI359_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI359_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI359_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI359_PDI_n_SHIFT)) & SIUL2_GPDI359_PDI_n_MASK)
/*! @} */

/*! @name GPDI358 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI358_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI358_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI358_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI358_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI358_PDI_n_SHIFT)) & SIUL2_GPDI358_PDI_n_MASK)
/*! @} */

/*! @name GPDI357 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI357_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI357_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI357_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI357_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI357_PDI_n_SHIFT)) & SIUL2_GPDI357_PDI_n_MASK)
/*! @} */

/*! @name GPDI356 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI356_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI356_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI356_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI356_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI356_PDI_n_SHIFT)) & SIUL2_GPDI356_PDI_n_MASK)
/*! @} */

/*! @name GPDI363 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI363_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI363_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI363_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI363_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI363_PDI_n_SHIFT)) & SIUL2_GPDI363_PDI_n_MASK)
/*! @} */

/*! @name GPDI362 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI362_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI362_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI362_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI362_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI362_PDI_n_SHIFT)) & SIUL2_GPDI362_PDI_n_MASK)
/*! @} */

/*! @name GPDI361 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI361_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI361_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI361_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI361_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI361_PDI_n_SHIFT)) & SIUL2_GPDI361_PDI_n_MASK)
/*! @} */

/*! @name GPDI360 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI360_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI360_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI360_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI360_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI360_PDI_n_SHIFT)) & SIUL2_GPDI360_PDI_n_MASK)
/*! @} */

/*! @name GPDI367 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI367_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI367_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI367_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI367_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI367_PDI_n_SHIFT)) & SIUL2_GPDI367_PDI_n_MASK)
/*! @} */

/*! @name GPDI366 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI366_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI366_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI366_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI366_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI366_PDI_n_SHIFT)) & SIUL2_GPDI366_PDI_n_MASK)
/*! @} */

/*! @name GPDI365 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI365_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI365_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI365_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI365_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI365_PDI_n_SHIFT)) & SIUL2_GPDI365_PDI_n_MASK)
/*! @} */

/*! @name GPDI364 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI364_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI364_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI364_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI364_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI364_PDI_n_SHIFT)) & SIUL2_GPDI364_PDI_n_MASK)
/*! @} */

/*! @name GPDI371 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI371_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI371_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI371_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI371_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI371_PDI_n_SHIFT)) & SIUL2_GPDI371_PDI_n_MASK)
/*! @} */

/*! @name GPDI370 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI370_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI370_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI370_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI370_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI370_PDI_n_SHIFT)) & SIUL2_GPDI370_PDI_n_MASK)
/*! @} */

/*! @name GPDI369 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI369_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI369_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI369_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI369_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI369_PDI_n_SHIFT)) & SIUL2_GPDI369_PDI_n_MASK)
/*! @} */

/*! @name GPDI368 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI368_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI368_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI368_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI368_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI368_PDI_n_SHIFT)) & SIUL2_GPDI368_PDI_n_MASK)
/*! @} */

/*! @name GPDI435 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI435_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI435_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI435_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI435_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI435_PDI_n_SHIFT)) & SIUL2_GPDI435_PDI_n_MASK)
/*! @} */

/*! @name GPDI434 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI434_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI434_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI434_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI434_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI434_PDI_n_SHIFT)) & SIUL2_GPDI434_PDI_n_MASK)
/*! @} */

/*! @name GPDI433 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI433_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI433_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI433_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI433_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI433_PDI_n_SHIFT)) & SIUL2_GPDI433_PDI_n_MASK)
/*! @} */

/*! @name GPDI432 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI432_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI432_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI432_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI432_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI432_PDI_n_SHIFT)) & SIUL2_GPDI432_PDI_n_MASK)
/*! @} */

/*! @name GPDI437 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI437_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI437_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI437_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI437_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI437_PDI_n_SHIFT)) & SIUL2_GPDI437_PDI_n_MASK)
/*! @} */

/*! @name GPDI436 - GPIO Pad Data Input */
/*! @{ */

#define SIUL2_GPDI436_PDI_n_MASK                 (0x1U)
#define SIUL2_GPDI436_PDI_n_SHIFT                (0U)
#define SIUL2_GPDI436_PDI_n_WIDTH                (1U)
#define SIUL2_GPDI436_PDI_n(x)                   (((uint8_t)(((uint8_t)(x)) << SIUL2_GPDI436_PDI_n_SHIFT)) & SIUL2_GPDI436_PDI_n_MASK)
/*! @} */

/*! @name PGPDO1 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO1_PPDO0_MASK                  (0x1U)
#define SIUL2_PGPDO1_PPDO0_SHIFT                 (0U)
#define SIUL2_PGPDO1_PPDO0_WIDTH                 (1U)
#define SIUL2_PGPDO1_PPDO0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO0_SHIFT)) & SIUL2_PGPDO1_PPDO0_MASK)

#define SIUL2_PGPDO1_PPDO1_MASK                  (0x2U)
#define SIUL2_PGPDO1_PPDO1_SHIFT                 (1U)
#define SIUL2_PGPDO1_PPDO1_WIDTH                 (1U)
#define SIUL2_PGPDO1_PPDO1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO1_SHIFT)) & SIUL2_PGPDO1_PPDO1_MASK)

#define SIUL2_PGPDO1_PPDO2_MASK                  (0x4U)
#define SIUL2_PGPDO1_PPDO2_SHIFT                 (2U)
#define SIUL2_PGPDO1_PPDO2_WIDTH                 (1U)
#define SIUL2_PGPDO1_PPDO2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO2_SHIFT)) & SIUL2_PGPDO1_PPDO2_MASK)

#define SIUL2_PGPDO1_PPDO3_MASK                  (0x8U)
#define SIUL2_PGPDO1_PPDO3_SHIFT                 (3U)
#define SIUL2_PGPDO1_PPDO3_WIDTH                 (1U)
#define SIUL2_PGPDO1_PPDO3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO3_SHIFT)) & SIUL2_PGPDO1_PPDO3_MASK)

#define SIUL2_PGPDO1_PPDO4_MASK                  (0x10U)
#define SIUL2_PGPDO1_PPDO4_SHIFT                 (4U)
#define SIUL2_PGPDO1_PPDO4_WIDTH                 (1U)
#define SIUL2_PGPDO1_PPDO4(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO4_SHIFT)) & SIUL2_PGPDO1_PPDO4_MASK)

#define SIUL2_PGPDO1_PPDO5_MASK                  (0x20U)
#define SIUL2_PGPDO1_PPDO5_SHIFT                 (5U)
#define SIUL2_PGPDO1_PPDO5_WIDTH                 (1U)
#define SIUL2_PGPDO1_PPDO5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO5_SHIFT)) & SIUL2_PGPDO1_PPDO5_MASK)

#define SIUL2_PGPDO1_PPDO6_MASK                  (0x40U)
#define SIUL2_PGPDO1_PPDO6_SHIFT                 (6U)
#define SIUL2_PGPDO1_PPDO6_WIDTH                 (1U)
#define SIUL2_PGPDO1_PPDO6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO6_SHIFT)) & SIUL2_PGPDO1_PPDO6_MASK)

#define SIUL2_PGPDO1_PPDO7_MASK                  (0x80U)
#define SIUL2_PGPDO1_PPDO7_SHIFT                 (7U)
#define SIUL2_PGPDO1_PPDO7_WIDTH                 (1U)
#define SIUL2_PGPDO1_PPDO7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO7_SHIFT)) & SIUL2_PGPDO1_PPDO7_MASK)

#define SIUL2_PGPDO1_PPDO8_MASK                  (0x100U)
#define SIUL2_PGPDO1_PPDO8_SHIFT                 (8U)
#define SIUL2_PGPDO1_PPDO8_WIDTH                 (1U)
#define SIUL2_PGPDO1_PPDO8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO8_SHIFT)) & SIUL2_PGPDO1_PPDO8_MASK)

#define SIUL2_PGPDO1_PPDO9_MASK                  (0x200U)
#define SIUL2_PGPDO1_PPDO9_SHIFT                 (9U)
#define SIUL2_PGPDO1_PPDO9_WIDTH                 (1U)
#define SIUL2_PGPDO1_PPDO9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO9_SHIFT)) & SIUL2_PGPDO1_PPDO9_MASK)

#define SIUL2_PGPDO1_PPDO10_MASK                 (0x400U)
#define SIUL2_PGPDO1_PPDO10_SHIFT                (10U)
#define SIUL2_PGPDO1_PPDO10_WIDTH                (1U)
#define SIUL2_PGPDO1_PPDO10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO10_SHIFT)) & SIUL2_PGPDO1_PPDO10_MASK)

#define SIUL2_PGPDO1_PPDO11_MASK                 (0x800U)
#define SIUL2_PGPDO1_PPDO11_SHIFT                (11U)
#define SIUL2_PGPDO1_PPDO11_WIDTH                (1U)
#define SIUL2_PGPDO1_PPDO11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO11_SHIFT)) & SIUL2_PGPDO1_PPDO11_MASK)

#define SIUL2_PGPDO1_PPDO12_MASK                 (0x1000U)
#define SIUL2_PGPDO1_PPDO12_SHIFT                (12U)
#define SIUL2_PGPDO1_PPDO12_WIDTH                (1U)
#define SIUL2_PGPDO1_PPDO12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO12_SHIFT)) & SIUL2_PGPDO1_PPDO12_MASK)

#define SIUL2_PGPDO1_PPDO13_MASK                 (0x2000U)
#define SIUL2_PGPDO1_PPDO13_SHIFT                (13U)
#define SIUL2_PGPDO1_PPDO13_WIDTH                (1U)
#define SIUL2_PGPDO1_PPDO13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO13_SHIFT)) & SIUL2_PGPDO1_PPDO13_MASK)

#define SIUL2_PGPDO1_PPDO14_MASK                 (0x4000U)
#define SIUL2_PGPDO1_PPDO14_SHIFT                (14U)
#define SIUL2_PGPDO1_PPDO14_WIDTH                (1U)
#define SIUL2_PGPDO1_PPDO14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO14_SHIFT)) & SIUL2_PGPDO1_PPDO14_MASK)

#define SIUL2_PGPDO1_PPDO15_MASK                 (0x8000U)
#define SIUL2_PGPDO1_PPDO15_SHIFT                (15U)
#define SIUL2_PGPDO1_PPDO15_WIDTH                (1U)
#define SIUL2_PGPDO1_PPDO15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO1_PPDO15_SHIFT)) & SIUL2_PGPDO1_PPDO15_MASK)
/*! @} */

/*! @name PGPDO0 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO0_PPDO0_MASK                  (0x1U)
#define SIUL2_PGPDO0_PPDO0_SHIFT                 (0U)
#define SIUL2_PGPDO0_PPDO0_WIDTH                 (1U)
#define SIUL2_PGPDO0_PPDO0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO0_SHIFT)) & SIUL2_PGPDO0_PPDO0_MASK)

#define SIUL2_PGPDO0_PPDO1_MASK                  (0x2U)
#define SIUL2_PGPDO0_PPDO1_SHIFT                 (1U)
#define SIUL2_PGPDO0_PPDO1_WIDTH                 (1U)
#define SIUL2_PGPDO0_PPDO1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO1_SHIFT)) & SIUL2_PGPDO0_PPDO1_MASK)

#define SIUL2_PGPDO0_PPDO2_MASK                  (0x4U)
#define SIUL2_PGPDO0_PPDO2_SHIFT                 (2U)
#define SIUL2_PGPDO0_PPDO2_WIDTH                 (1U)
#define SIUL2_PGPDO0_PPDO2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO2_SHIFT)) & SIUL2_PGPDO0_PPDO2_MASK)

#define SIUL2_PGPDO0_PPDO3_MASK                  (0x8U)
#define SIUL2_PGPDO0_PPDO3_SHIFT                 (3U)
#define SIUL2_PGPDO0_PPDO3_WIDTH                 (1U)
#define SIUL2_PGPDO0_PPDO3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO3_SHIFT)) & SIUL2_PGPDO0_PPDO3_MASK)

#define SIUL2_PGPDO0_PPDO4_MASK                  (0x10U)
#define SIUL2_PGPDO0_PPDO4_SHIFT                 (4U)
#define SIUL2_PGPDO0_PPDO4_WIDTH                 (1U)
#define SIUL2_PGPDO0_PPDO4(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO4_SHIFT)) & SIUL2_PGPDO0_PPDO4_MASK)

#define SIUL2_PGPDO0_PPDO5_MASK                  (0x20U)
#define SIUL2_PGPDO0_PPDO5_SHIFT                 (5U)
#define SIUL2_PGPDO0_PPDO5_WIDTH                 (1U)
#define SIUL2_PGPDO0_PPDO5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO5_SHIFT)) & SIUL2_PGPDO0_PPDO5_MASK)

#define SIUL2_PGPDO0_PPDO6_MASK                  (0x40U)
#define SIUL2_PGPDO0_PPDO6_SHIFT                 (6U)
#define SIUL2_PGPDO0_PPDO6_WIDTH                 (1U)
#define SIUL2_PGPDO0_PPDO6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO6_SHIFT)) & SIUL2_PGPDO0_PPDO6_MASK)

#define SIUL2_PGPDO0_PPDO7_MASK                  (0x80U)
#define SIUL2_PGPDO0_PPDO7_SHIFT                 (7U)
#define SIUL2_PGPDO0_PPDO7_WIDTH                 (1U)
#define SIUL2_PGPDO0_PPDO7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO7_SHIFT)) & SIUL2_PGPDO0_PPDO7_MASK)

#define SIUL2_PGPDO0_PPDO8_MASK                  (0x100U)
#define SIUL2_PGPDO0_PPDO8_SHIFT                 (8U)
#define SIUL2_PGPDO0_PPDO8_WIDTH                 (1U)
#define SIUL2_PGPDO0_PPDO8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO8_SHIFT)) & SIUL2_PGPDO0_PPDO8_MASK)

#define SIUL2_PGPDO0_PPDO9_MASK                  (0x200U)
#define SIUL2_PGPDO0_PPDO9_SHIFT                 (9U)
#define SIUL2_PGPDO0_PPDO9_WIDTH                 (1U)
#define SIUL2_PGPDO0_PPDO9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO9_SHIFT)) & SIUL2_PGPDO0_PPDO9_MASK)

#define SIUL2_PGPDO0_PPDO10_MASK                 (0x400U)
#define SIUL2_PGPDO0_PPDO10_SHIFT                (10U)
#define SIUL2_PGPDO0_PPDO10_WIDTH                (1U)
#define SIUL2_PGPDO0_PPDO10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO10_SHIFT)) & SIUL2_PGPDO0_PPDO10_MASK)

#define SIUL2_PGPDO0_PPDO11_MASK                 (0x800U)
#define SIUL2_PGPDO0_PPDO11_SHIFT                (11U)
#define SIUL2_PGPDO0_PPDO11_WIDTH                (1U)
#define SIUL2_PGPDO0_PPDO11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO11_SHIFT)) & SIUL2_PGPDO0_PPDO11_MASK)

#define SIUL2_PGPDO0_PPDO12_MASK                 (0x1000U)
#define SIUL2_PGPDO0_PPDO12_SHIFT                (12U)
#define SIUL2_PGPDO0_PPDO12_WIDTH                (1U)
#define SIUL2_PGPDO0_PPDO12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO12_SHIFT)) & SIUL2_PGPDO0_PPDO12_MASK)

#define SIUL2_PGPDO0_PPDO13_MASK                 (0x2000U)
#define SIUL2_PGPDO0_PPDO13_SHIFT                (13U)
#define SIUL2_PGPDO0_PPDO13_WIDTH                (1U)
#define SIUL2_PGPDO0_PPDO13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO13_SHIFT)) & SIUL2_PGPDO0_PPDO13_MASK)

#define SIUL2_PGPDO0_PPDO14_MASK                 (0x4000U)
#define SIUL2_PGPDO0_PPDO14_SHIFT                (14U)
#define SIUL2_PGPDO0_PPDO14_WIDTH                (1U)
#define SIUL2_PGPDO0_PPDO14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO14_SHIFT)) & SIUL2_PGPDO0_PPDO14_MASK)

#define SIUL2_PGPDO0_PPDO15_MASK                 (0x8000U)
#define SIUL2_PGPDO0_PPDO15_SHIFT                (15U)
#define SIUL2_PGPDO0_PPDO15_WIDTH                (1U)
#define SIUL2_PGPDO0_PPDO15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO0_PPDO15_SHIFT)) & SIUL2_PGPDO0_PPDO15_MASK)
/*! @} */

/*! @name PGPDO3 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO3_PPDO0_MASK                  (0x1U)
#define SIUL2_PGPDO3_PPDO0_SHIFT                 (0U)
#define SIUL2_PGPDO3_PPDO0_WIDTH                 (1U)
#define SIUL2_PGPDO3_PPDO0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO0_SHIFT)) & SIUL2_PGPDO3_PPDO0_MASK)

#define SIUL2_PGPDO3_PPDO1_MASK                  (0x2U)
#define SIUL2_PGPDO3_PPDO1_SHIFT                 (1U)
#define SIUL2_PGPDO3_PPDO1_WIDTH                 (1U)
#define SIUL2_PGPDO3_PPDO1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO1_SHIFT)) & SIUL2_PGPDO3_PPDO1_MASK)

#define SIUL2_PGPDO3_PPDO2_MASK                  (0x4U)
#define SIUL2_PGPDO3_PPDO2_SHIFT                 (2U)
#define SIUL2_PGPDO3_PPDO2_WIDTH                 (1U)
#define SIUL2_PGPDO3_PPDO2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO2_SHIFT)) & SIUL2_PGPDO3_PPDO2_MASK)

#define SIUL2_PGPDO3_PPDO3_MASK                  (0x8U)
#define SIUL2_PGPDO3_PPDO3_SHIFT                 (3U)
#define SIUL2_PGPDO3_PPDO3_WIDTH                 (1U)
#define SIUL2_PGPDO3_PPDO3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO3_SHIFT)) & SIUL2_PGPDO3_PPDO3_MASK)

#define SIUL2_PGPDO3_PPDO4_MASK                  (0x10U)
#define SIUL2_PGPDO3_PPDO4_SHIFT                 (4U)
#define SIUL2_PGPDO3_PPDO4_WIDTH                 (1U)
#define SIUL2_PGPDO3_PPDO4(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO4_SHIFT)) & SIUL2_PGPDO3_PPDO4_MASK)

#define SIUL2_PGPDO3_PPDO5_MASK                  (0x20U)
#define SIUL2_PGPDO3_PPDO5_SHIFT                 (5U)
#define SIUL2_PGPDO3_PPDO5_WIDTH                 (1U)
#define SIUL2_PGPDO3_PPDO5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO5_SHIFT)) & SIUL2_PGPDO3_PPDO5_MASK)

#define SIUL2_PGPDO3_PPDO6_MASK                  (0x40U)
#define SIUL2_PGPDO3_PPDO6_SHIFT                 (6U)
#define SIUL2_PGPDO3_PPDO6_WIDTH                 (1U)
#define SIUL2_PGPDO3_PPDO6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO6_SHIFT)) & SIUL2_PGPDO3_PPDO6_MASK)

#define SIUL2_PGPDO3_PPDO7_MASK                  (0x80U)
#define SIUL2_PGPDO3_PPDO7_SHIFT                 (7U)
#define SIUL2_PGPDO3_PPDO7_WIDTH                 (1U)
#define SIUL2_PGPDO3_PPDO7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO7_SHIFT)) & SIUL2_PGPDO3_PPDO7_MASK)

#define SIUL2_PGPDO3_PPDO8_MASK                  (0x100U)
#define SIUL2_PGPDO3_PPDO8_SHIFT                 (8U)
#define SIUL2_PGPDO3_PPDO8_WIDTH                 (1U)
#define SIUL2_PGPDO3_PPDO8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO8_SHIFT)) & SIUL2_PGPDO3_PPDO8_MASK)

#define SIUL2_PGPDO3_PPDO9_MASK                  (0x200U)
#define SIUL2_PGPDO3_PPDO9_SHIFT                 (9U)
#define SIUL2_PGPDO3_PPDO9_WIDTH                 (1U)
#define SIUL2_PGPDO3_PPDO9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO9_SHIFT)) & SIUL2_PGPDO3_PPDO9_MASK)

#define SIUL2_PGPDO3_PPDO10_MASK                 (0x400U)
#define SIUL2_PGPDO3_PPDO10_SHIFT                (10U)
#define SIUL2_PGPDO3_PPDO10_WIDTH                (1U)
#define SIUL2_PGPDO3_PPDO10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO10_SHIFT)) & SIUL2_PGPDO3_PPDO10_MASK)

#define SIUL2_PGPDO3_PPDO11_MASK                 (0x800U)
#define SIUL2_PGPDO3_PPDO11_SHIFT                (11U)
#define SIUL2_PGPDO3_PPDO11_WIDTH                (1U)
#define SIUL2_PGPDO3_PPDO11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO11_SHIFT)) & SIUL2_PGPDO3_PPDO11_MASK)

#define SIUL2_PGPDO3_PPDO12_MASK                 (0x1000U)
#define SIUL2_PGPDO3_PPDO12_SHIFT                (12U)
#define SIUL2_PGPDO3_PPDO12_WIDTH                (1U)
#define SIUL2_PGPDO3_PPDO12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO12_SHIFT)) & SIUL2_PGPDO3_PPDO12_MASK)

#define SIUL2_PGPDO3_PPDO14_MASK                 (0x4000U)
#define SIUL2_PGPDO3_PPDO14_SHIFT                (14U)
#define SIUL2_PGPDO3_PPDO14_WIDTH                (1U)
#define SIUL2_PGPDO3_PPDO14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO14_SHIFT)) & SIUL2_PGPDO3_PPDO14_MASK)

#define SIUL2_PGPDO3_PPDO15_MASK                 (0x8000U)
#define SIUL2_PGPDO3_PPDO15_SHIFT                (15U)
#define SIUL2_PGPDO3_PPDO15_WIDTH                (1U)
#define SIUL2_PGPDO3_PPDO15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO3_PPDO15_SHIFT)) & SIUL2_PGPDO3_PPDO15_MASK)
/*! @} */

/*! @name PGPDO2 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO2_PPDO0_MASK                  (0x1U)
#define SIUL2_PGPDO2_PPDO0_SHIFT                 (0U)
#define SIUL2_PGPDO2_PPDO0_WIDTH                 (1U)
#define SIUL2_PGPDO2_PPDO0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO0_SHIFT)) & SIUL2_PGPDO2_PPDO0_MASK)

#define SIUL2_PGPDO2_PPDO1_MASK                  (0x2U)
#define SIUL2_PGPDO2_PPDO1_SHIFT                 (1U)
#define SIUL2_PGPDO2_PPDO1_WIDTH                 (1U)
#define SIUL2_PGPDO2_PPDO1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO1_SHIFT)) & SIUL2_PGPDO2_PPDO1_MASK)

#define SIUL2_PGPDO2_PPDO2_MASK                  (0x4U)
#define SIUL2_PGPDO2_PPDO2_SHIFT                 (2U)
#define SIUL2_PGPDO2_PPDO2_WIDTH                 (1U)
#define SIUL2_PGPDO2_PPDO2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO2_SHIFT)) & SIUL2_PGPDO2_PPDO2_MASK)

#define SIUL2_PGPDO2_PPDO3_MASK                  (0x8U)
#define SIUL2_PGPDO2_PPDO3_SHIFT                 (3U)
#define SIUL2_PGPDO2_PPDO3_WIDTH                 (1U)
#define SIUL2_PGPDO2_PPDO3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO3_SHIFT)) & SIUL2_PGPDO2_PPDO3_MASK)

#define SIUL2_PGPDO2_PPDO4_MASK                  (0x10U)
#define SIUL2_PGPDO2_PPDO4_SHIFT                 (4U)
#define SIUL2_PGPDO2_PPDO4_WIDTH                 (1U)
#define SIUL2_PGPDO2_PPDO4(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO4_SHIFT)) & SIUL2_PGPDO2_PPDO4_MASK)

#define SIUL2_PGPDO2_PPDO5_MASK                  (0x20U)
#define SIUL2_PGPDO2_PPDO5_SHIFT                 (5U)
#define SIUL2_PGPDO2_PPDO5_WIDTH                 (1U)
#define SIUL2_PGPDO2_PPDO5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO5_SHIFT)) & SIUL2_PGPDO2_PPDO5_MASK)

#define SIUL2_PGPDO2_PPDO6_MASK                  (0x40U)
#define SIUL2_PGPDO2_PPDO6_SHIFT                 (6U)
#define SIUL2_PGPDO2_PPDO6_WIDTH                 (1U)
#define SIUL2_PGPDO2_PPDO6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO6_SHIFT)) & SIUL2_PGPDO2_PPDO6_MASK)

#define SIUL2_PGPDO2_PPDO7_MASK                  (0x80U)
#define SIUL2_PGPDO2_PPDO7_SHIFT                 (7U)
#define SIUL2_PGPDO2_PPDO7_WIDTH                 (1U)
#define SIUL2_PGPDO2_PPDO7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO7_SHIFT)) & SIUL2_PGPDO2_PPDO7_MASK)

#define SIUL2_PGPDO2_PPDO8_MASK                  (0x100U)
#define SIUL2_PGPDO2_PPDO8_SHIFT                 (8U)
#define SIUL2_PGPDO2_PPDO8_WIDTH                 (1U)
#define SIUL2_PGPDO2_PPDO8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO8_SHIFT)) & SIUL2_PGPDO2_PPDO8_MASK)

#define SIUL2_PGPDO2_PPDO9_MASK                  (0x200U)
#define SIUL2_PGPDO2_PPDO9_SHIFT                 (9U)
#define SIUL2_PGPDO2_PPDO9_WIDTH                 (1U)
#define SIUL2_PGPDO2_PPDO9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO9_SHIFT)) & SIUL2_PGPDO2_PPDO9_MASK)

#define SIUL2_PGPDO2_PPDO10_MASK                 (0x400U)
#define SIUL2_PGPDO2_PPDO10_SHIFT                (10U)
#define SIUL2_PGPDO2_PPDO10_WIDTH                (1U)
#define SIUL2_PGPDO2_PPDO10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO10_SHIFT)) & SIUL2_PGPDO2_PPDO10_MASK)

#define SIUL2_PGPDO2_PPDO11_MASK                 (0x800U)
#define SIUL2_PGPDO2_PPDO11_SHIFT                (11U)
#define SIUL2_PGPDO2_PPDO11_WIDTH                (1U)
#define SIUL2_PGPDO2_PPDO11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO11_SHIFT)) & SIUL2_PGPDO2_PPDO11_MASK)

#define SIUL2_PGPDO2_PPDO12_MASK                 (0x1000U)
#define SIUL2_PGPDO2_PPDO12_SHIFT                (12U)
#define SIUL2_PGPDO2_PPDO12_WIDTH                (1U)
#define SIUL2_PGPDO2_PPDO12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO12_SHIFT)) & SIUL2_PGPDO2_PPDO12_MASK)

#define SIUL2_PGPDO2_PPDO13_MASK                 (0x2000U)
#define SIUL2_PGPDO2_PPDO13_SHIFT                (13U)
#define SIUL2_PGPDO2_PPDO13_WIDTH                (1U)
#define SIUL2_PGPDO2_PPDO13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO13_SHIFT)) & SIUL2_PGPDO2_PPDO13_MASK)

#define SIUL2_PGPDO2_PPDO14_MASK                 (0x4000U)
#define SIUL2_PGPDO2_PPDO14_SHIFT                (14U)
#define SIUL2_PGPDO2_PPDO14_WIDTH                (1U)
#define SIUL2_PGPDO2_PPDO14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO14_SHIFT)) & SIUL2_PGPDO2_PPDO14_MASK)

#define SIUL2_PGPDO2_PPDO15_MASK                 (0x8000U)
#define SIUL2_PGPDO2_PPDO15_SHIFT                (15U)
#define SIUL2_PGPDO2_PPDO15_WIDTH                (1U)
#define SIUL2_PGPDO2_PPDO15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO2_PPDO15_SHIFT)) & SIUL2_PGPDO2_PPDO15_MASK)
/*! @} */

/*! @name PGPDO5 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO5_PPDO0_MASK                  (0x1U)
#define SIUL2_PGPDO5_PPDO0_SHIFT                 (0U)
#define SIUL2_PGPDO5_PPDO0_WIDTH                 (1U)
#define SIUL2_PGPDO5_PPDO0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO0_SHIFT)) & SIUL2_PGPDO5_PPDO0_MASK)

#define SIUL2_PGPDO5_PPDO1_MASK                  (0x2U)
#define SIUL2_PGPDO5_PPDO1_SHIFT                 (1U)
#define SIUL2_PGPDO5_PPDO1_WIDTH                 (1U)
#define SIUL2_PGPDO5_PPDO1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO1_SHIFT)) & SIUL2_PGPDO5_PPDO1_MASK)

#define SIUL2_PGPDO5_PPDO2_MASK                  (0x4U)
#define SIUL2_PGPDO5_PPDO2_SHIFT                 (2U)
#define SIUL2_PGPDO5_PPDO2_WIDTH                 (1U)
#define SIUL2_PGPDO5_PPDO2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO2_SHIFT)) & SIUL2_PGPDO5_PPDO2_MASK)

#define SIUL2_PGPDO5_PPDO3_MASK                  (0x8U)
#define SIUL2_PGPDO5_PPDO3_SHIFT                 (3U)
#define SIUL2_PGPDO5_PPDO3_WIDTH                 (1U)
#define SIUL2_PGPDO5_PPDO3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO3_SHIFT)) & SIUL2_PGPDO5_PPDO3_MASK)

#define SIUL2_PGPDO5_PPDO4_MASK                  (0x10U)
#define SIUL2_PGPDO5_PPDO4_SHIFT                 (4U)
#define SIUL2_PGPDO5_PPDO4_WIDTH                 (1U)
#define SIUL2_PGPDO5_PPDO4(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO4_SHIFT)) & SIUL2_PGPDO5_PPDO4_MASK)

#define SIUL2_PGPDO5_PPDO5_MASK                  (0x20U)
#define SIUL2_PGPDO5_PPDO5_SHIFT                 (5U)
#define SIUL2_PGPDO5_PPDO5_WIDTH                 (1U)
#define SIUL2_PGPDO5_PPDO5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO5_SHIFT)) & SIUL2_PGPDO5_PPDO5_MASK)

#define SIUL2_PGPDO5_PPDO6_MASK                  (0x40U)
#define SIUL2_PGPDO5_PPDO6_SHIFT                 (6U)
#define SIUL2_PGPDO5_PPDO6_WIDTH                 (1U)
#define SIUL2_PGPDO5_PPDO6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO6_SHIFT)) & SIUL2_PGPDO5_PPDO6_MASK)

#define SIUL2_PGPDO5_PPDO7_MASK                  (0x80U)
#define SIUL2_PGPDO5_PPDO7_SHIFT                 (7U)
#define SIUL2_PGPDO5_PPDO7_WIDTH                 (1U)
#define SIUL2_PGPDO5_PPDO7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO7_SHIFT)) & SIUL2_PGPDO5_PPDO7_MASK)

#define SIUL2_PGPDO5_PPDO8_MASK                  (0x100U)
#define SIUL2_PGPDO5_PPDO8_SHIFT                 (8U)
#define SIUL2_PGPDO5_PPDO8_WIDTH                 (1U)
#define SIUL2_PGPDO5_PPDO8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO8_SHIFT)) & SIUL2_PGPDO5_PPDO8_MASK)

#define SIUL2_PGPDO5_PPDO9_MASK                  (0x200U)
#define SIUL2_PGPDO5_PPDO9_SHIFT                 (9U)
#define SIUL2_PGPDO5_PPDO9_WIDTH                 (1U)
#define SIUL2_PGPDO5_PPDO9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO9_SHIFT)) & SIUL2_PGPDO5_PPDO9_MASK)

#define SIUL2_PGPDO5_PPDO10_MASK                 (0x400U)
#define SIUL2_PGPDO5_PPDO10_SHIFT                (10U)
#define SIUL2_PGPDO5_PPDO10_WIDTH                (1U)
#define SIUL2_PGPDO5_PPDO10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO10_SHIFT)) & SIUL2_PGPDO5_PPDO10_MASK)

#define SIUL2_PGPDO5_PPDO11_MASK                 (0x800U)
#define SIUL2_PGPDO5_PPDO11_SHIFT                (11U)
#define SIUL2_PGPDO5_PPDO11_WIDTH                (1U)
#define SIUL2_PGPDO5_PPDO11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO11_SHIFT)) & SIUL2_PGPDO5_PPDO11_MASK)

#define SIUL2_PGPDO5_PPDO12_MASK                 (0x1000U)
#define SIUL2_PGPDO5_PPDO12_SHIFT                (12U)
#define SIUL2_PGPDO5_PPDO12_WIDTH                (1U)
#define SIUL2_PGPDO5_PPDO12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO12_SHIFT)) & SIUL2_PGPDO5_PPDO12_MASK)

#define SIUL2_PGPDO5_PPDO13_MASK                 (0x2000U)
#define SIUL2_PGPDO5_PPDO13_SHIFT                (13U)
#define SIUL2_PGPDO5_PPDO13_WIDTH                (1U)
#define SIUL2_PGPDO5_PPDO13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO13_SHIFT)) & SIUL2_PGPDO5_PPDO13_MASK)

#define SIUL2_PGPDO5_PPDO14_MASK                 (0x4000U)
#define SIUL2_PGPDO5_PPDO14_SHIFT                (14U)
#define SIUL2_PGPDO5_PPDO14_WIDTH                (1U)
#define SIUL2_PGPDO5_PPDO14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO14_SHIFT)) & SIUL2_PGPDO5_PPDO14_MASK)

#define SIUL2_PGPDO5_PPDO15_MASK                 (0x8000U)
#define SIUL2_PGPDO5_PPDO15_SHIFT                (15U)
#define SIUL2_PGPDO5_PPDO15_WIDTH                (1U)
#define SIUL2_PGPDO5_PPDO15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO5_PPDO15_SHIFT)) & SIUL2_PGPDO5_PPDO15_MASK)
/*! @} */

/*! @name PGPDO4 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO4_PPDO1_MASK                  (0x2U)
#define SIUL2_PGPDO4_PPDO1_SHIFT                 (1U)
#define SIUL2_PGPDO4_PPDO1_WIDTH                 (1U)
#define SIUL2_PGPDO4_PPDO1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO1_SHIFT)) & SIUL2_PGPDO4_PPDO1_MASK)

#define SIUL2_PGPDO4_PPDO2_MASK                  (0x4U)
#define SIUL2_PGPDO4_PPDO2_SHIFT                 (2U)
#define SIUL2_PGPDO4_PPDO2_WIDTH                 (1U)
#define SIUL2_PGPDO4_PPDO2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO2_SHIFT)) & SIUL2_PGPDO4_PPDO2_MASK)

#define SIUL2_PGPDO4_PPDO3_MASK                  (0x8U)
#define SIUL2_PGPDO4_PPDO3_SHIFT                 (3U)
#define SIUL2_PGPDO4_PPDO3_WIDTH                 (1U)
#define SIUL2_PGPDO4_PPDO3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO3_SHIFT)) & SIUL2_PGPDO4_PPDO3_MASK)

#define SIUL2_PGPDO4_PPDO4_MASK                  (0x10U)
#define SIUL2_PGPDO4_PPDO4_SHIFT                 (4U)
#define SIUL2_PGPDO4_PPDO4_WIDTH                 (1U)
#define SIUL2_PGPDO4_PPDO4(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO4_SHIFT)) & SIUL2_PGPDO4_PPDO4_MASK)

#define SIUL2_PGPDO4_PPDO5_MASK                  (0x20U)
#define SIUL2_PGPDO4_PPDO5_SHIFT                 (5U)
#define SIUL2_PGPDO4_PPDO5_WIDTH                 (1U)
#define SIUL2_PGPDO4_PPDO5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO5_SHIFT)) & SIUL2_PGPDO4_PPDO5_MASK)

#define SIUL2_PGPDO4_PPDO6_MASK                  (0x40U)
#define SIUL2_PGPDO4_PPDO6_SHIFT                 (6U)
#define SIUL2_PGPDO4_PPDO6_WIDTH                 (1U)
#define SIUL2_PGPDO4_PPDO6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO6_SHIFT)) & SIUL2_PGPDO4_PPDO6_MASK)

#define SIUL2_PGPDO4_PPDO7_MASK                  (0x80U)
#define SIUL2_PGPDO4_PPDO7_SHIFT                 (7U)
#define SIUL2_PGPDO4_PPDO7_WIDTH                 (1U)
#define SIUL2_PGPDO4_PPDO7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO7_SHIFT)) & SIUL2_PGPDO4_PPDO7_MASK)

#define SIUL2_PGPDO4_PPDO8_MASK                  (0x100U)
#define SIUL2_PGPDO4_PPDO8_SHIFT                 (8U)
#define SIUL2_PGPDO4_PPDO8_WIDTH                 (1U)
#define SIUL2_PGPDO4_PPDO8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO8_SHIFT)) & SIUL2_PGPDO4_PPDO8_MASK)

#define SIUL2_PGPDO4_PPDO9_MASK                  (0x200U)
#define SIUL2_PGPDO4_PPDO9_SHIFT                 (9U)
#define SIUL2_PGPDO4_PPDO9_WIDTH                 (1U)
#define SIUL2_PGPDO4_PPDO9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO9_SHIFT)) & SIUL2_PGPDO4_PPDO9_MASK)

#define SIUL2_PGPDO4_PPDO10_MASK                 (0x400U)
#define SIUL2_PGPDO4_PPDO10_SHIFT                (10U)
#define SIUL2_PGPDO4_PPDO10_WIDTH                (1U)
#define SIUL2_PGPDO4_PPDO10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO10_SHIFT)) & SIUL2_PGPDO4_PPDO10_MASK)

#define SIUL2_PGPDO4_PPDO11_MASK                 (0x800U)
#define SIUL2_PGPDO4_PPDO11_SHIFT                (11U)
#define SIUL2_PGPDO4_PPDO11_WIDTH                (1U)
#define SIUL2_PGPDO4_PPDO11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO11_SHIFT)) & SIUL2_PGPDO4_PPDO11_MASK)

#define SIUL2_PGPDO4_PPDO12_MASK                 (0x1000U)
#define SIUL2_PGPDO4_PPDO12_SHIFT                (12U)
#define SIUL2_PGPDO4_PPDO12_WIDTH                (1U)
#define SIUL2_PGPDO4_PPDO12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO12_SHIFT)) & SIUL2_PGPDO4_PPDO12_MASK)

#define SIUL2_PGPDO4_PPDO13_MASK                 (0x2000U)
#define SIUL2_PGPDO4_PPDO13_SHIFT                (13U)
#define SIUL2_PGPDO4_PPDO13_WIDTH                (1U)
#define SIUL2_PGPDO4_PPDO13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO13_SHIFT)) & SIUL2_PGPDO4_PPDO13_MASK)

#define SIUL2_PGPDO4_PPDO14_MASK                 (0x4000U)
#define SIUL2_PGPDO4_PPDO14_SHIFT                (14U)
#define SIUL2_PGPDO4_PPDO14_WIDTH                (1U)
#define SIUL2_PGPDO4_PPDO14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO14_SHIFT)) & SIUL2_PGPDO4_PPDO14_MASK)

#define SIUL2_PGPDO4_PPDO15_MASK                 (0x8000U)
#define SIUL2_PGPDO4_PPDO15_SHIFT                (15U)
#define SIUL2_PGPDO4_PPDO15_WIDTH                (1U)
#define SIUL2_PGPDO4_PPDO15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO4_PPDO15_SHIFT)) & SIUL2_PGPDO4_PPDO15_MASK)
/*! @} */

/*! @name PGPDO7 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO7_PPDO0_MASK                  (0x1U)
#define SIUL2_PGPDO7_PPDO0_SHIFT                 (0U)
#define SIUL2_PGPDO7_PPDO0_WIDTH                 (1U)
#define SIUL2_PGPDO7_PPDO0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO7_PPDO0_SHIFT)) & SIUL2_PGPDO7_PPDO0_MASK)

#define SIUL2_PGPDO7_PPDO1_MASK                  (0x2U)
#define SIUL2_PGPDO7_PPDO1_SHIFT                 (1U)
#define SIUL2_PGPDO7_PPDO1_WIDTH                 (1U)
#define SIUL2_PGPDO7_PPDO1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO7_PPDO1_SHIFT)) & SIUL2_PGPDO7_PPDO1_MASK)

#define SIUL2_PGPDO7_PPDO11_MASK                 (0x800U)
#define SIUL2_PGPDO7_PPDO11_SHIFT                (11U)
#define SIUL2_PGPDO7_PPDO11_WIDTH                (1U)
#define SIUL2_PGPDO7_PPDO11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO7_PPDO11_SHIFT)) & SIUL2_PGPDO7_PPDO11_MASK)

#define SIUL2_PGPDO7_PPDO12_MASK                 (0x1000U)
#define SIUL2_PGPDO7_PPDO12_SHIFT                (12U)
#define SIUL2_PGPDO7_PPDO12_WIDTH                (1U)
#define SIUL2_PGPDO7_PPDO12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO7_PPDO12_SHIFT)) & SIUL2_PGPDO7_PPDO12_MASK)

#define SIUL2_PGPDO7_PPDO13_MASK                 (0x2000U)
#define SIUL2_PGPDO7_PPDO13_SHIFT                (13U)
#define SIUL2_PGPDO7_PPDO13_WIDTH                (1U)
#define SIUL2_PGPDO7_PPDO13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO7_PPDO13_SHIFT)) & SIUL2_PGPDO7_PPDO13_MASK)

#define SIUL2_PGPDO7_PPDO14_MASK                 (0x4000U)
#define SIUL2_PGPDO7_PPDO14_SHIFT                (14U)
#define SIUL2_PGPDO7_PPDO14_WIDTH                (1U)
#define SIUL2_PGPDO7_PPDO14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO7_PPDO14_SHIFT)) & SIUL2_PGPDO7_PPDO14_MASK)

#define SIUL2_PGPDO7_PPDO15_MASK                 (0x8000U)
#define SIUL2_PGPDO7_PPDO15_SHIFT                (15U)
#define SIUL2_PGPDO7_PPDO15_WIDTH                (1U)
#define SIUL2_PGPDO7_PPDO15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO7_PPDO15_SHIFT)) & SIUL2_PGPDO7_PPDO15_MASK)
/*! @} */

/*! @name PGPDO6 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO6_PPDO0_MASK                  (0x1U)
#define SIUL2_PGPDO6_PPDO0_SHIFT                 (0U)
#define SIUL2_PGPDO6_PPDO0_WIDTH                 (1U)
#define SIUL2_PGPDO6_PPDO0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO0_SHIFT)) & SIUL2_PGPDO6_PPDO0_MASK)

#define SIUL2_PGPDO6_PPDO1_MASK                  (0x2U)
#define SIUL2_PGPDO6_PPDO1_SHIFT                 (1U)
#define SIUL2_PGPDO6_PPDO1_WIDTH                 (1U)
#define SIUL2_PGPDO6_PPDO1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO1_SHIFT)) & SIUL2_PGPDO6_PPDO1_MASK)

#define SIUL2_PGPDO6_PPDO2_MASK                  (0x4U)
#define SIUL2_PGPDO6_PPDO2_SHIFT                 (2U)
#define SIUL2_PGPDO6_PPDO2_WIDTH                 (1U)
#define SIUL2_PGPDO6_PPDO2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO2_SHIFT)) & SIUL2_PGPDO6_PPDO2_MASK)

#define SIUL2_PGPDO6_PPDO3_MASK                  (0x8U)
#define SIUL2_PGPDO6_PPDO3_SHIFT                 (3U)
#define SIUL2_PGPDO6_PPDO3_WIDTH                 (1U)
#define SIUL2_PGPDO6_PPDO3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO3_SHIFT)) & SIUL2_PGPDO6_PPDO3_MASK)

#define SIUL2_PGPDO6_PPDO4_MASK                  (0x10U)
#define SIUL2_PGPDO6_PPDO4_SHIFT                 (4U)
#define SIUL2_PGPDO6_PPDO4_WIDTH                 (1U)
#define SIUL2_PGPDO6_PPDO4(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO4_SHIFT)) & SIUL2_PGPDO6_PPDO4_MASK)

#define SIUL2_PGPDO6_PPDO5_MASK                  (0x20U)
#define SIUL2_PGPDO6_PPDO5_SHIFT                 (5U)
#define SIUL2_PGPDO6_PPDO5_WIDTH                 (1U)
#define SIUL2_PGPDO6_PPDO5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO5_SHIFT)) & SIUL2_PGPDO6_PPDO5_MASK)

#define SIUL2_PGPDO6_PPDO6_MASK                  (0x40U)
#define SIUL2_PGPDO6_PPDO6_SHIFT                 (6U)
#define SIUL2_PGPDO6_PPDO6_WIDTH                 (1U)
#define SIUL2_PGPDO6_PPDO6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO6_SHIFT)) & SIUL2_PGPDO6_PPDO6_MASK)

#define SIUL2_PGPDO6_PPDO7_MASK                  (0x80U)
#define SIUL2_PGPDO6_PPDO7_SHIFT                 (7U)
#define SIUL2_PGPDO6_PPDO7_WIDTH                 (1U)
#define SIUL2_PGPDO6_PPDO7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO7_SHIFT)) & SIUL2_PGPDO6_PPDO7_MASK)

#define SIUL2_PGPDO6_PPDO8_MASK                  (0x100U)
#define SIUL2_PGPDO6_PPDO8_SHIFT                 (8U)
#define SIUL2_PGPDO6_PPDO8_WIDTH                 (1U)
#define SIUL2_PGPDO6_PPDO8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO8_SHIFT)) & SIUL2_PGPDO6_PPDO8_MASK)

#define SIUL2_PGPDO6_PPDO9_MASK                  (0x200U)
#define SIUL2_PGPDO6_PPDO9_SHIFT                 (9U)
#define SIUL2_PGPDO6_PPDO9_WIDTH                 (1U)
#define SIUL2_PGPDO6_PPDO9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO9_SHIFT)) & SIUL2_PGPDO6_PPDO9_MASK)

#define SIUL2_PGPDO6_PPDO10_MASK                 (0x400U)
#define SIUL2_PGPDO6_PPDO10_SHIFT                (10U)
#define SIUL2_PGPDO6_PPDO10_WIDTH                (1U)
#define SIUL2_PGPDO6_PPDO10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO10_SHIFT)) & SIUL2_PGPDO6_PPDO10_MASK)

#define SIUL2_PGPDO6_PPDO11_MASK                 (0x800U)
#define SIUL2_PGPDO6_PPDO11_SHIFT                (11U)
#define SIUL2_PGPDO6_PPDO11_WIDTH                (1U)
#define SIUL2_PGPDO6_PPDO11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO11_SHIFT)) & SIUL2_PGPDO6_PPDO11_MASK)

#define SIUL2_PGPDO6_PPDO12_MASK                 (0x1000U)
#define SIUL2_PGPDO6_PPDO12_SHIFT                (12U)
#define SIUL2_PGPDO6_PPDO12_WIDTH                (1U)
#define SIUL2_PGPDO6_PPDO12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO12_SHIFT)) & SIUL2_PGPDO6_PPDO12_MASK)

#define SIUL2_PGPDO6_PPDO13_MASK                 (0x2000U)
#define SIUL2_PGPDO6_PPDO13_SHIFT                (13U)
#define SIUL2_PGPDO6_PPDO13_WIDTH                (1U)
#define SIUL2_PGPDO6_PPDO13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO13_SHIFT)) & SIUL2_PGPDO6_PPDO13_MASK)

#define SIUL2_PGPDO6_PPDO14_MASK                 (0x4000U)
#define SIUL2_PGPDO6_PPDO14_SHIFT                (14U)
#define SIUL2_PGPDO6_PPDO14_WIDTH                (1U)
#define SIUL2_PGPDO6_PPDO14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO14_SHIFT)) & SIUL2_PGPDO6_PPDO14_MASK)

#define SIUL2_PGPDO6_PPDO15_MASK                 (0x8000U)
#define SIUL2_PGPDO6_PPDO15_SHIFT                (15U)
#define SIUL2_PGPDO6_PPDO15_WIDTH                (1U)
#define SIUL2_PGPDO6_PPDO15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO6_PPDO15_SHIFT)) & SIUL2_PGPDO6_PPDO15_MASK)
/*! @} */

/*! @name PGPDO9 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO9_PPDO0_MASK                  (0x1U)
#define SIUL2_PGPDO9_PPDO0_SHIFT                 (0U)
#define SIUL2_PGPDO9_PPDO0_WIDTH                 (1U)
#define SIUL2_PGPDO9_PPDO0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO9_PPDO0_SHIFT)) & SIUL2_PGPDO9_PPDO0_MASK)

#define SIUL2_PGPDO9_PPDO1_MASK                  (0x2U)
#define SIUL2_PGPDO9_PPDO1_SHIFT                 (1U)
#define SIUL2_PGPDO9_PPDO1_WIDTH                 (1U)
#define SIUL2_PGPDO9_PPDO1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO9_PPDO1_SHIFT)) & SIUL2_PGPDO9_PPDO1_MASK)

#define SIUL2_PGPDO9_PPDO2_MASK                  (0x4U)
#define SIUL2_PGPDO9_PPDO2_SHIFT                 (2U)
#define SIUL2_PGPDO9_PPDO2_WIDTH                 (1U)
#define SIUL2_PGPDO9_PPDO2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO9_PPDO2_SHIFT)) & SIUL2_PGPDO9_PPDO2_MASK)

#define SIUL2_PGPDO9_PPDO3_MASK                  (0x8U)
#define SIUL2_PGPDO9_PPDO3_SHIFT                 (3U)
#define SIUL2_PGPDO9_PPDO3_WIDTH                 (1U)
#define SIUL2_PGPDO9_PPDO3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO9_PPDO3_SHIFT)) & SIUL2_PGPDO9_PPDO3_MASK)

#define SIUL2_PGPDO9_PPDO11_MASK                 (0x800U)
#define SIUL2_PGPDO9_PPDO11_SHIFT                (11U)
#define SIUL2_PGPDO9_PPDO11_WIDTH                (1U)
#define SIUL2_PGPDO9_PPDO11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO9_PPDO11_SHIFT)) & SIUL2_PGPDO9_PPDO11_MASK)
/*! @} */

/*! @name PGPDO8 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO8_PPDO5_MASK                  (0x20U)
#define SIUL2_PGPDO8_PPDO5_SHIFT                 (5U)
#define SIUL2_PGPDO8_PPDO5_WIDTH                 (1U)
#define SIUL2_PGPDO8_PPDO5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO8_PPDO5_SHIFT)) & SIUL2_PGPDO8_PPDO5_MASK)

#define SIUL2_PGPDO8_PPDO6_MASK                  (0x40U)
#define SIUL2_PGPDO8_PPDO6_SHIFT                 (6U)
#define SIUL2_PGPDO8_PPDO6_WIDTH                 (1U)
#define SIUL2_PGPDO8_PPDO6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO8_PPDO6_SHIFT)) & SIUL2_PGPDO8_PPDO6_MASK)

#define SIUL2_PGPDO8_PPDO7_MASK                  (0x80U)
#define SIUL2_PGPDO8_PPDO7_SHIFT                 (7U)
#define SIUL2_PGPDO8_PPDO7_WIDTH                 (1U)
#define SIUL2_PGPDO8_PPDO7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO8_PPDO7_SHIFT)) & SIUL2_PGPDO8_PPDO7_MASK)

#define SIUL2_PGPDO8_PPDO8_MASK                  (0x100U)
#define SIUL2_PGPDO8_PPDO8_SHIFT                 (8U)
#define SIUL2_PGPDO8_PPDO8_WIDTH                 (1U)
#define SIUL2_PGPDO8_PPDO8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO8_PPDO8_SHIFT)) & SIUL2_PGPDO8_PPDO8_MASK)

#define SIUL2_PGPDO8_PPDO9_MASK                  (0x200U)
#define SIUL2_PGPDO8_PPDO9_SHIFT                 (9U)
#define SIUL2_PGPDO8_PPDO9_WIDTH                 (1U)
#define SIUL2_PGPDO8_PPDO9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO8_PPDO9_SHIFT)) & SIUL2_PGPDO8_PPDO9_MASK)

#define SIUL2_PGPDO8_PPDO10_MASK                 (0x400U)
#define SIUL2_PGPDO8_PPDO10_SHIFT                (10U)
#define SIUL2_PGPDO8_PPDO10_WIDTH                (1U)
#define SIUL2_PGPDO8_PPDO10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO8_PPDO10_SHIFT)) & SIUL2_PGPDO8_PPDO10_MASK)

#define SIUL2_PGPDO8_PPDO11_MASK                 (0x800U)
#define SIUL2_PGPDO8_PPDO11_SHIFT                (11U)
#define SIUL2_PGPDO8_PPDO11_WIDTH                (1U)
#define SIUL2_PGPDO8_PPDO11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO8_PPDO11_SHIFT)) & SIUL2_PGPDO8_PPDO11_MASK)

#define SIUL2_PGPDO8_PPDO12_MASK                 (0x1000U)
#define SIUL2_PGPDO8_PPDO12_SHIFT                (12U)
#define SIUL2_PGPDO8_PPDO12_WIDTH                (1U)
#define SIUL2_PGPDO8_PPDO12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO8_PPDO12_SHIFT)) & SIUL2_PGPDO8_PPDO12_MASK)

#define SIUL2_PGPDO8_PPDO13_MASK                 (0x2000U)
#define SIUL2_PGPDO8_PPDO13_SHIFT                (13U)
#define SIUL2_PGPDO8_PPDO13_WIDTH                (1U)
#define SIUL2_PGPDO8_PPDO13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO8_PPDO13_SHIFT)) & SIUL2_PGPDO8_PPDO13_MASK)

#define SIUL2_PGPDO8_PPDO14_MASK                 (0x4000U)
#define SIUL2_PGPDO8_PPDO14_SHIFT                (14U)
#define SIUL2_PGPDO8_PPDO14_WIDTH                (1U)
#define SIUL2_PGPDO8_PPDO14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO8_PPDO14_SHIFT)) & SIUL2_PGPDO8_PPDO14_MASK)

#define SIUL2_PGPDO8_PPDO15_MASK                 (0x8000U)
#define SIUL2_PGPDO8_PPDO15_SHIFT                (15U)
#define SIUL2_PGPDO8_PPDO15_WIDTH                (1U)
#define SIUL2_PGPDO8_PPDO15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO8_PPDO15_SHIFT)) & SIUL2_PGPDO8_PPDO15_MASK)
/*! @} */

/*! @name PGPDO11 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO11_PPDO0_MASK                 (0x1U)
#define SIUL2_PGPDO11_PPDO0_SHIFT                (0U)
#define SIUL2_PGPDO11_PPDO0_WIDTH                (1U)
#define SIUL2_PGPDO11_PPDO0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO0_SHIFT)) & SIUL2_PGPDO11_PPDO0_MASK)

#define SIUL2_PGPDO11_PPDO1_MASK                 (0x2U)
#define SIUL2_PGPDO11_PPDO1_SHIFT                (1U)
#define SIUL2_PGPDO11_PPDO1_WIDTH                (1U)
#define SIUL2_PGPDO11_PPDO1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO1_SHIFT)) & SIUL2_PGPDO11_PPDO1_MASK)

#define SIUL2_PGPDO11_PPDO2_MASK                 (0x4U)
#define SIUL2_PGPDO11_PPDO2_SHIFT                (2U)
#define SIUL2_PGPDO11_PPDO2_WIDTH                (1U)
#define SIUL2_PGPDO11_PPDO2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO2_SHIFT)) & SIUL2_PGPDO11_PPDO2_MASK)

#define SIUL2_PGPDO11_PPDO3_MASK                 (0x8U)
#define SIUL2_PGPDO11_PPDO3_SHIFT                (3U)
#define SIUL2_PGPDO11_PPDO3_WIDTH                (1U)
#define SIUL2_PGPDO11_PPDO3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO3_SHIFT)) & SIUL2_PGPDO11_PPDO3_MASK)

#define SIUL2_PGPDO11_PPDO4_MASK                 (0x10U)
#define SIUL2_PGPDO11_PPDO4_SHIFT                (4U)
#define SIUL2_PGPDO11_PPDO4_WIDTH                (1U)
#define SIUL2_PGPDO11_PPDO4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO4_SHIFT)) & SIUL2_PGPDO11_PPDO4_MASK)

#define SIUL2_PGPDO11_PPDO5_MASK                 (0x20U)
#define SIUL2_PGPDO11_PPDO5_SHIFT                (5U)
#define SIUL2_PGPDO11_PPDO5_WIDTH                (1U)
#define SIUL2_PGPDO11_PPDO5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO5_SHIFT)) & SIUL2_PGPDO11_PPDO5_MASK)

#define SIUL2_PGPDO11_PPDO6_MASK                 (0x40U)
#define SIUL2_PGPDO11_PPDO6_SHIFT                (6U)
#define SIUL2_PGPDO11_PPDO6_WIDTH                (1U)
#define SIUL2_PGPDO11_PPDO6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO6_SHIFT)) & SIUL2_PGPDO11_PPDO6_MASK)

#define SIUL2_PGPDO11_PPDO7_MASK                 (0x80U)
#define SIUL2_PGPDO11_PPDO7_SHIFT                (7U)
#define SIUL2_PGPDO11_PPDO7_WIDTH                (1U)
#define SIUL2_PGPDO11_PPDO7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO7_SHIFT)) & SIUL2_PGPDO11_PPDO7_MASK)

#define SIUL2_PGPDO11_PPDO8_MASK                 (0x100U)
#define SIUL2_PGPDO11_PPDO8_SHIFT                (8U)
#define SIUL2_PGPDO11_PPDO8_WIDTH                (1U)
#define SIUL2_PGPDO11_PPDO8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO8_SHIFT)) & SIUL2_PGPDO11_PPDO8_MASK)

#define SIUL2_PGPDO11_PPDO9_MASK                 (0x200U)
#define SIUL2_PGPDO11_PPDO9_SHIFT                (9U)
#define SIUL2_PGPDO11_PPDO9_WIDTH                (1U)
#define SIUL2_PGPDO11_PPDO9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO9_SHIFT)) & SIUL2_PGPDO11_PPDO9_MASK)

#define SIUL2_PGPDO11_PPDO10_MASK                (0x400U)
#define SIUL2_PGPDO11_PPDO10_SHIFT               (10U)
#define SIUL2_PGPDO11_PPDO10_WIDTH               (1U)
#define SIUL2_PGPDO11_PPDO10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO10_SHIFT)) & SIUL2_PGPDO11_PPDO10_MASK)

#define SIUL2_PGPDO11_PPDO11_MASK                (0x800U)
#define SIUL2_PGPDO11_PPDO11_SHIFT               (11U)
#define SIUL2_PGPDO11_PPDO11_WIDTH               (1U)
#define SIUL2_PGPDO11_PPDO11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO11_SHIFT)) & SIUL2_PGPDO11_PPDO11_MASK)

#define SIUL2_PGPDO11_PPDO12_MASK                (0x1000U)
#define SIUL2_PGPDO11_PPDO12_SHIFT               (12U)
#define SIUL2_PGPDO11_PPDO12_WIDTH               (1U)
#define SIUL2_PGPDO11_PPDO12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO12_SHIFT)) & SIUL2_PGPDO11_PPDO12_MASK)

#define SIUL2_PGPDO11_PPDO13_MASK                (0x2000U)
#define SIUL2_PGPDO11_PPDO13_SHIFT               (13U)
#define SIUL2_PGPDO11_PPDO13_WIDTH               (1U)
#define SIUL2_PGPDO11_PPDO13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO13_SHIFT)) & SIUL2_PGPDO11_PPDO13_MASK)

#define SIUL2_PGPDO11_PPDO14_MASK                (0x4000U)
#define SIUL2_PGPDO11_PPDO14_SHIFT               (14U)
#define SIUL2_PGPDO11_PPDO14_WIDTH               (1U)
#define SIUL2_PGPDO11_PPDO14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO14_SHIFT)) & SIUL2_PGPDO11_PPDO14_MASK)

#define SIUL2_PGPDO11_PPDO15_MASK                (0x8000U)
#define SIUL2_PGPDO11_PPDO15_SHIFT               (15U)
#define SIUL2_PGPDO11_PPDO15_WIDTH               (1U)
#define SIUL2_PGPDO11_PPDO15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO11_PPDO15_SHIFT)) & SIUL2_PGPDO11_PPDO15_MASK)
/*! @} */

/*! @name PGPDO10 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO10_PPDO0_MASK                 (0x1U)
#define SIUL2_PGPDO10_PPDO0_SHIFT                (0U)
#define SIUL2_PGPDO10_PPDO0_WIDTH                (1U)
#define SIUL2_PGPDO10_PPDO0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO0_SHIFT)) & SIUL2_PGPDO10_PPDO0_MASK)

#define SIUL2_PGPDO10_PPDO1_MASK                 (0x2U)
#define SIUL2_PGPDO10_PPDO1_SHIFT                (1U)
#define SIUL2_PGPDO10_PPDO1_WIDTH                (1U)
#define SIUL2_PGPDO10_PPDO1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO1_SHIFT)) & SIUL2_PGPDO10_PPDO1_MASK)

#define SIUL2_PGPDO10_PPDO2_MASK                 (0x4U)
#define SIUL2_PGPDO10_PPDO2_SHIFT                (2U)
#define SIUL2_PGPDO10_PPDO2_WIDTH                (1U)
#define SIUL2_PGPDO10_PPDO2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO2_SHIFT)) & SIUL2_PGPDO10_PPDO2_MASK)

#define SIUL2_PGPDO10_PPDO3_MASK                 (0x8U)
#define SIUL2_PGPDO10_PPDO3_SHIFT                (3U)
#define SIUL2_PGPDO10_PPDO3_WIDTH                (1U)
#define SIUL2_PGPDO10_PPDO3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO3_SHIFT)) & SIUL2_PGPDO10_PPDO3_MASK)

#define SIUL2_PGPDO10_PPDO4_MASK                 (0x10U)
#define SIUL2_PGPDO10_PPDO4_SHIFT                (4U)
#define SIUL2_PGPDO10_PPDO4_WIDTH                (1U)
#define SIUL2_PGPDO10_PPDO4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO4_SHIFT)) & SIUL2_PGPDO10_PPDO4_MASK)

#define SIUL2_PGPDO10_PPDO5_MASK                 (0x20U)
#define SIUL2_PGPDO10_PPDO5_SHIFT                (5U)
#define SIUL2_PGPDO10_PPDO5_WIDTH                (1U)
#define SIUL2_PGPDO10_PPDO5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO5_SHIFT)) & SIUL2_PGPDO10_PPDO5_MASK)

#define SIUL2_PGPDO10_PPDO6_MASK                 (0x40U)
#define SIUL2_PGPDO10_PPDO6_SHIFT                (6U)
#define SIUL2_PGPDO10_PPDO6_WIDTH                (1U)
#define SIUL2_PGPDO10_PPDO6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO6_SHIFT)) & SIUL2_PGPDO10_PPDO6_MASK)

#define SIUL2_PGPDO10_PPDO7_MASK                 (0x80U)
#define SIUL2_PGPDO10_PPDO7_SHIFT                (7U)
#define SIUL2_PGPDO10_PPDO7_WIDTH                (1U)
#define SIUL2_PGPDO10_PPDO7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO7_SHIFT)) & SIUL2_PGPDO10_PPDO7_MASK)

#define SIUL2_PGPDO10_PPDO8_MASK                 (0x100U)
#define SIUL2_PGPDO10_PPDO8_SHIFT                (8U)
#define SIUL2_PGPDO10_PPDO8_WIDTH                (1U)
#define SIUL2_PGPDO10_PPDO8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO8_SHIFT)) & SIUL2_PGPDO10_PPDO8_MASK)

#define SIUL2_PGPDO10_PPDO9_MASK                 (0x200U)
#define SIUL2_PGPDO10_PPDO9_SHIFT                (9U)
#define SIUL2_PGPDO10_PPDO9_WIDTH                (1U)
#define SIUL2_PGPDO10_PPDO9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO9_SHIFT)) & SIUL2_PGPDO10_PPDO9_MASK)

#define SIUL2_PGPDO10_PPDO10_MASK                (0x400U)
#define SIUL2_PGPDO10_PPDO10_SHIFT               (10U)
#define SIUL2_PGPDO10_PPDO10_WIDTH               (1U)
#define SIUL2_PGPDO10_PPDO10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO10_SHIFT)) & SIUL2_PGPDO10_PPDO10_MASK)

#define SIUL2_PGPDO10_PPDO11_MASK                (0x800U)
#define SIUL2_PGPDO10_PPDO11_SHIFT               (11U)
#define SIUL2_PGPDO10_PPDO11_WIDTH               (1U)
#define SIUL2_PGPDO10_PPDO11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO11_SHIFT)) & SIUL2_PGPDO10_PPDO11_MASK)

#define SIUL2_PGPDO10_PPDO12_MASK                (0x1000U)
#define SIUL2_PGPDO10_PPDO12_SHIFT               (12U)
#define SIUL2_PGPDO10_PPDO12_WIDTH               (1U)
#define SIUL2_PGPDO10_PPDO12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO12_SHIFT)) & SIUL2_PGPDO10_PPDO12_MASK)

#define SIUL2_PGPDO10_PPDO13_MASK                (0x2000U)
#define SIUL2_PGPDO10_PPDO13_SHIFT               (13U)
#define SIUL2_PGPDO10_PPDO13_WIDTH               (1U)
#define SIUL2_PGPDO10_PPDO13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO13_SHIFT)) & SIUL2_PGPDO10_PPDO13_MASK)

#define SIUL2_PGPDO10_PPDO14_MASK                (0x4000U)
#define SIUL2_PGPDO10_PPDO14_SHIFT               (14U)
#define SIUL2_PGPDO10_PPDO14_WIDTH               (1U)
#define SIUL2_PGPDO10_PPDO14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO14_SHIFT)) & SIUL2_PGPDO10_PPDO14_MASK)

#define SIUL2_PGPDO10_PPDO15_MASK                (0x8000U)
#define SIUL2_PGPDO10_PPDO15_SHIFT               (15U)
#define SIUL2_PGPDO10_PPDO15_WIDTH               (1U)
#define SIUL2_PGPDO10_PPDO15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO10_PPDO15_SHIFT)) & SIUL2_PGPDO10_PPDO15_MASK)
/*! @} */

/*! @name PGPDO13 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO13_PPDO0_MASK                 (0x1U)
#define SIUL2_PGPDO13_PPDO0_SHIFT                (0U)
#define SIUL2_PGPDO13_PPDO0_WIDTH                (1U)
#define SIUL2_PGPDO13_PPDO0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO0_SHIFT)) & SIUL2_PGPDO13_PPDO0_MASK)

#define SIUL2_PGPDO13_PPDO1_MASK                 (0x2U)
#define SIUL2_PGPDO13_PPDO1_SHIFT                (1U)
#define SIUL2_PGPDO13_PPDO1_WIDTH                (1U)
#define SIUL2_PGPDO13_PPDO1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO1_SHIFT)) & SIUL2_PGPDO13_PPDO1_MASK)

#define SIUL2_PGPDO13_PPDO2_MASK                 (0x4U)
#define SIUL2_PGPDO13_PPDO2_SHIFT                (2U)
#define SIUL2_PGPDO13_PPDO2_WIDTH                (1U)
#define SIUL2_PGPDO13_PPDO2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO2_SHIFT)) & SIUL2_PGPDO13_PPDO2_MASK)

#define SIUL2_PGPDO13_PPDO3_MASK                 (0x8U)
#define SIUL2_PGPDO13_PPDO3_SHIFT                (3U)
#define SIUL2_PGPDO13_PPDO3_WIDTH                (1U)
#define SIUL2_PGPDO13_PPDO3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO3_SHIFT)) & SIUL2_PGPDO13_PPDO3_MASK)

#define SIUL2_PGPDO13_PPDO4_MASK                 (0x10U)
#define SIUL2_PGPDO13_PPDO4_SHIFT                (4U)
#define SIUL2_PGPDO13_PPDO4_WIDTH                (1U)
#define SIUL2_PGPDO13_PPDO4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO4_SHIFT)) & SIUL2_PGPDO13_PPDO4_MASK)

#define SIUL2_PGPDO13_PPDO5_MASK                 (0x20U)
#define SIUL2_PGPDO13_PPDO5_SHIFT                (5U)
#define SIUL2_PGPDO13_PPDO5_WIDTH                (1U)
#define SIUL2_PGPDO13_PPDO5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO5_SHIFT)) & SIUL2_PGPDO13_PPDO5_MASK)

#define SIUL2_PGPDO13_PPDO6_MASK                 (0x40U)
#define SIUL2_PGPDO13_PPDO6_SHIFT                (6U)
#define SIUL2_PGPDO13_PPDO6_WIDTH                (1U)
#define SIUL2_PGPDO13_PPDO6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO6_SHIFT)) & SIUL2_PGPDO13_PPDO6_MASK)

#define SIUL2_PGPDO13_PPDO7_MASK                 (0x80U)
#define SIUL2_PGPDO13_PPDO7_SHIFT                (7U)
#define SIUL2_PGPDO13_PPDO7_WIDTH                (1U)
#define SIUL2_PGPDO13_PPDO7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO7_SHIFT)) & SIUL2_PGPDO13_PPDO7_MASK)

#define SIUL2_PGPDO13_PPDO8_MASK                 (0x100U)
#define SIUL2_PGPDO13_PPDO8_SHIFT                (8U)
#define SIUL2_PGPDO13_PPDO8_WIDTH                (1U)
#define SIUL2_PGPDO13_PPDO8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO8_SHIFT)) & SIUL2_PGPDO13_PPDO8_MASK)

#define SIUL2_PGPDO13_PPDO9_MASK                 (0x200U)
#define SIUL2_PGPDO13_PPDO9_SHIFT                (9U)
#define SIUL2_PGPDO13_PPDO9_WIDTH                (1U)
#define SIUL2_PGPDO13_PPDO9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO9_SHIFT)) & SIUL2_PGPDO13_PPDO9_MASK)

#define SIUL2_PGPDO13_PPDO10_MASK                (0x400U)
#define SIUL2_PGPDO13_PPDO10_SHIFT               (10U)
#define SIUL2_PGPDO13_PPDO10_WIDTH               (1U)
#define SIUL2_PGPDO13_PPDO10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO10_SHIFT)) & SIUL2_PGPDO13_PPDO10_MASK)

#define SIUL2_PGPDO13_PPDO11_MASK                (0x800U)
#define SIUL2_PGPDO13_PPDO11_SHIFT               (11U)
#define SIUL2_PGPDO13_PPDO11_WIDTH               (1U)
#define SIUL2_PGPDO13_PPDO11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO11_SHIFT)) & SIUL2_PGPDO13_PPDO11_MASK)

#define SIUL2_PGPDO13_PPDO12_MASK                (0x1000U)
#define SIUL2_PGPDO13_PPDO12_SHIFT               (12U)
#define SIUL2_PGPDO13_PPDO12_WIDTH               (1U)
#define SIUL2_PGPDO13_PPDO12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO12_SHIFT)) & SIUL2_PGPDO13_PPDO12_MASK)

#define SIUL2_PGPDO13_PPDO13_MASK                (0x2000U)
#define SIUL2_PGPDO13_PPDO13_SHIFT               (13U)
#define SIUL2_PGPDO13_PPDO13_WIDTH               (1U)
#define SIUL2_PGPDO13_PPDO13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO13_SHIFT)) & SIUL2_PGPDO13_PPDO13_MASK)

#define SIUL2_PGPDO13_PPDO14_MASK                (0x4000U)
#define SIUL2_PGPDO13_PPDO14_SHIFT               (14U)
#define SIUL2_PGPDO13_PPDO14_WIDTH               (1U)
#define SIUL2_PGPDO13_PPDO14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO14_SHIFT)) & SIUL2_PGPDO13_PPDO14_MASK)

#define SIUL2_PGPDO13_PPDO15_MASK                (0x8000U)
#define SIUL2_PGPDO13_PPDO15_SHIFT               (15U)
#define SIUL2_PGPDO13_PPDO15_WIDTH               (1U)
#define SIUL2_PGPDO13_PPDO15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO13_PPDO15_SHIFT)) & SIUL2_PGPDO13_PPDO15_MASK)
/*! @} */

/*! @name PGPDO12 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO12_PPDO0_MASK                 (0x1U)
#define SIUL2_PGPDO12_PPDO0_SHIFT                (0U)
#define SIUL2_PGPDO12_PPDO0_WIDTH                (1U)
#define SIUL2_PGPDO12_PPDO0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO0_SHIFT)) & SIUL2_PGPDO12_PPDO0_MASK)

#define SIUL2_PGPDO12_PPDO1_MASK                 (0x2U)
#define SIUL2_PGPDO12_PPDO1_SHIFT                (1U)
#define SIUL2_PGPDO12_PPDO1_WIDTH                (1U)
#define SIUL2_PGPDO12_PPDO1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO1_SHIFT)) & SIUL2_PGPDO12_PPDO1_MASK)

#define SIUL2_PGPDO12_PPDO2_MASK                 (0x4U)
#define SIUL2_PGPDO12_PPDO2_SHIFT                (2U)
#define SIUL2_PGPDO12_PPDO2_WIDTH                (1U)
#define SIUL2_PGPDO12_PPDO2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO2_SHIFT)) & SIUL2_PGPDO12_PPDO2_MASK)

#define SIUL2_PGPDO12_PPDO3_MASK                 (0x8U)
#define SIUL2_PGPDO12_PPDO3_SHIFT                (3U)
#define SIUL2_PGPDO12_PPDO3_WIDTH                (1U)
#define SIUL2_PGPDO12_PPDO3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO3_SHIFT)) & SIUL2_PGPDO12_PPDO3_MASK)

#define SIUL2_PGPDO12_PPDO4_MASK                 (0x10U)
#define SIUL2_PGPDO12_PPDO4_SHIFT                (4U)
#define SIUL2_PGPDO12_PPDO4_WIDTH                (1U)
#define SIUL2_PGPDO12_PPDO4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO4_SHIFT)) & SIUL2_PGPDO12_PPDO4_MASK)

#define SIUL2_PGPDO12_PPDO5_MASK                 (0x20U)
#define SIUL2_PGPDO12_PPDO5_SHIFT                (5U)
#define SIUL2_PGPDO12_PPDO5_WIDTH                (1U)
#define SIUL2_PGPDO12_PPDO5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO5_SHIFT)) & SIUL2_PGPDO12_PPDO5_MASK)

#define SIUL2_PGPDO12_PPDO6_MASK                 (0x40U)
#define SIUL2_PGPDO12_PPDO6_SHIFT                (6U)
#define SIUL2_PGPDO12_PPDO6_WIDTH                (1U)
#define SIUL2_PGPDO12_PPDO6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO6_SHIFT)) & SIUL2_PGPDO12_PPDO6_MASK)

#define SIUL2_PGPDO12_PPDO7_MASK                 (0x80U)
#define SIUL2_PGPDO12_PPDO7_SHIFT                (7U)
#define SIUL2_PGPDO12_PPDO7_WIDTH                (1U)
#define SIUL2_PGPDO12_PPDO7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO7_SHIFT)) & SIUL2_PGPDO12_PPDO7_MASK)

#define SIUL2_PGPDO12_PPDO8_MASK                 (0x100U)
#define SIUL2_PGPDO12_PPDO8_SHIFT                (8U)
#define SIUL2_PGPDO12_PPDO8_WIDTH                (1U)
#define SIUL2_PGPDO12_PPDO8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO8_SHIFT)) & SIUL2_PGPDO12_PPDO8_MASK)

#define SIUL2_PGPDO12_PPDO9_MASK                 (0x200U)
#define SIUL2_PGPDO12_PPDO9_SHIFT                (9U)
#define SIUL2_PGPDO12_PPDO9_WIDTH                (1U)
#define SIUL2_PGPDO12_PPDO9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO9_SHIFT)) & SIUL2_PGPDO12_PPDO9_MASK)

#define SIUL2_PGPDO12_PPDO10_MASK                (0x400U)
#define SIUL2_PGPDO12_PPDO10_SHIFT               (10U)
#define SIUL2_PGPDO12_PPDO10_WIDTH               (1U)
#define SIUL2_PGPDO12_PPDO10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO10_SHIFT)) & SIUL2_PGPDO12_PPDO10_MASK)

#define SIUL2_PGPDO12_PPDO11_MASK                (0x800U)
#define SIUL2_PGPDO12_PPDO11_SHIFT               (11U)
#define SIUL2_PGPDO12_PPDO11_WIDTH               (1U)
#define SIUL2_PGPDO12_PPDO11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO11_SHIFT)) & SIUL2_PGPDO12_PPDO11_MASK)

#define SIUL2_PGPDO12_PPDO12_MASK                (0x1000U)
#define SIUL2_PGPDO12_PPDO12_SHIFT               (12U)
#define SIUL2_PGPDO12_PPDO12_WIDTH               (1U)
#define SIUL2_PGPDO12_PPDO12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO12_SHIFT)) & SIUL2_PGPDO12_PPDO12_MASK)

#define SIUL2_PGPDO12_PPDO13_MASK                (0x2000U)
#define SIUL2_PGPDO12_PPDO13_SHIFT               (13U)
#define SIUL2_PGPDO12_PPDO13_WIDTH               (1U)
#define SIUL2_PGPDO12_PPDO13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO13_SHIFT)) & SIUL2_PGPDO12_PPDO13_MASK)

#define SIUL2_PGPDO12_PPDO14_MASK                (0x4000U)
#define SIUL2_PGPDO12_PPDO14_SHIFT               (14U)
#define SIUL2_PGPDO12_PPDO14_WIDTH               (1U)
#define SIUL2_PGPDO12_PPDO14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO14_SHIFT)) & SIUL2_PGPDO12_PPDO14_MASK)

#define SIUL2_PGPDO12_PPDO15_MASK                (0x8000U)
#define SIUL2_PGPDO12_PPDO15_SHIFT               (15U)
#define SIUL2_PGPDO12_PPDO15_WIDTH               (1U)
#define SIUL2_PGPDO12_PPDO15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO12_PPDO15_SHIFT)) & SIUL2_PGPDO12_PPDO15_MASK)
/*! @} */

/*! @name PGPDO15 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO15_PPDO0_MASK                 (0x1U)
#define SIUL2_PGPDO15_PPDO0_SHIFT                (0U)
#define SIUL2_PGPDO15_PPDO0_WIDTH                (1U)
#define SIUL2_PGPDO15_PPDO0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO0_SHIFT)) & SIUL2_PGPDO15_PPDO0_MASK)

#define SIUL2_PGPDO15_PPDO1_MASK                 (0x2U)
#define SIUL2_PGPDO15_PPDO1_SHIFT                (1U)
#define SIUL2_PGPDO15_PPDO1_WIDTH                (1U)
#define SIUL2_PGPDO15_PPDO1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO1_SHIFT)) & SIUL2_PGPDO15_PPDO1_MASK)

#define SIUL2_PGPDO15_PPDO2_MASK                 (0x4U)
#define SIUL2_PGPDO15_PPDO2_SHIFT                (2U)
#define SIUL2_PGPDO15_PPDO2_WIDTH                (1U)
#define SIUL2_PGPDO15_PPDO2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO2_SHIFT)) & SIUL2_PGPDO15_PPDO2_MASK)

#define SIUL2_PGPDO15_PPDO3_MASK                 (0x8U)
#define SIUL2_PGPDO15_PPDO3_SHIFT                (3U)
#define SIUL2_PGPDO15_PPDO3_WIDTH                (1U)
#define SIUL2_PGPDO15_PPDO3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO3_SHIFT)) & SIUL2_PGPDO15_PPDO3_MASK)

#define SIUL2_PGPDO15_PPDO4_MASK                 (0x10U)
#define SIUL2_PGPDO15_PPDO4_SHIFT                (4U)
#define SIUL2_PGPDO15_PPDO4_WIDTH                (1U)
#define SIUL2_PGPDO15_PPDO4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO4_SHIFT)) & SIUL2_PGPDO15_PPDO4_MASK)

#define SIUL2_PGPDO15_PPDO5_MASK                 (0x20U)
#define SIUL2_PGPDO15_PPDO5_SHIFT                (5U)
#define SIUL2_PGPDO15_PPDO5_WIDTH                (1U)
#define SIUL2_PGPDO15_PPDO5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO5_SHIFT)) & SIUL2_PGPDO15_PPDO5_MASK)

#define SIUL2_PGPDO15_PPDO6_MASK                 (0x40U)
#define SIUL2_PGPDO15_PPDO6_SHIFT                (6U)
#define SIUL2_PGPDO15_PPDO6_WIDTH                (1U)
#define SIUL2_PGPDO15_PPDO6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO6_SHIFT)) & SIUL2_PGPDO15_PPDO6_MASK)

#define SIUL2_PGPDO15_PPDO7_MASK                 (0x80U)
#define SIUL2_PGPDO15_PPDO7_SHIFT                (7U)
#define SIUL2_PGPDO15_PPDO7_WIDTH                (1U)
#define SIUL2_PGPDO15_PPDO7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO7_SHIFT)) & SIUL2_PGPDO15_PPDO7_MASK)

#define SIUL2_PGPDO15_PPDO8_MASK                 (0x100U)
#define SIUL2_PGPDO15_PPDO8_SHIFT                (8U)
#define SIUL2_PGPDO15_PPDO8_WIDTH                (1U)
#define SIUL2_PGPDO15_PPDO8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO8_SHIFT)) & SIUL2_PGPDO15_PPDO8_MASK)

#define SIUL2_PGPDO15_PPDO9_MASK                 (0x200U)
#define SIUL2_PGPDO15_PPDO9_SHIFT                (9U)
#define SIUL2_PGPDO15_PPDO9_WIDTH                (1U)
#define SIUL2_PGPDO15_PPDO9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO9_SHIFT)) & SIUL2_PGPDO15_PPDO9_MASK)

#define SIUL2_PGPDO15_PPDO10_MASK                (0x400U)
#define SIUL2_PGPDO15_PPDO10_SHIFT               (10U)
#define SIUL2_PGPDO15_PPDO10_WIDTH               (1U)
#define SIUL2_PGPDO15_PPDO10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO10_SHIFT)) & SIUL2_PGPDO15_PPDO10_MASK)

#define SIUL2_PGPDO15_PPDO11_MASK                (0x800U)
#define SIUL2_PGPDO15_PPDO11_SHIFT               (11U)
#define SIUL2_PGPDO15_PPDO11_WIDTH               (1U)
#define SIUL2_PGPDO15_PPDO11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO11_SHIFT)) & SIUL2_PGPDO15_PPDO11_MASK)

#define SIUL2_PGPDO15_PPDO12_MASK                (0x1000U)
#define SIUL2_PGPDO15_PPDO12_SHIFT               (12U)
#define SIUL2_PGPDO15_PPDO12_WIDTH               (1U)
#define SIUL2_PGPDO15_PPDO12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO12_SHIFT)) & SIUL2_PGPDO15_PPDO12_MASK)

#define SIUL2_PGPDO15_PPDO13_MASK                (0x2000U)
#define SIUL2_PGPDO15_PPDO13_SHIFT               (13U)
#define SIUL2_PGPDO15_PPDO13_WIDTH               (1U)
#define SIUL2_PGPDO15_PPDO13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO13_SHIFT)) & SIUL2_PGPDO15_PPDO13_MASK)

#define SIUL2_PGPDO15_PPDO14_MASK                (0x4000U)
#define SIUL2_PGPDO15_PPDO14_SHIFT               (14U)
#define SIUL2_PGPDO15_PPDO14_WIDTH               (1U)
#define SIUL2_PGPDO15_PPDO14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO14_SHIFT)) & SIUL2_PGPDO15_PPDO14_MASK)

#define SIUL2_PGPDO15_PPDO15_MASK                (0x8000U)
#define SIUL2_PGPDO15_PPDO15_SHIFT               (15U)
#define SIUL2_PGPDO15_PPDO15_WIDTH               (1U)
#define SIUL2_PGPDO15_PPDO15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO15_PPDO15_SHIFT)) & SIUL2_PGPDO15_PPDO15_MASK)
/*! @} */

/*! @name PGPDO14 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO14_PPDO0_MASK                 (0x1U)
#define SIUL2_PGPDO14_PPDO0_SHIFT                (0U)
#define SIUL2_PGPDO14_PPDO0_WIDTH                (1U)
#define SIUL2_PGPDO14_PPDO0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO0_SHIFT)) & SIUL2_PGPDO14_PPDO0_MASK)

#define SIUL2_PGPDO14_PPDO1_MASK                 (0x2U)
#define SIUL2_PGPDO14_PPDO1_SHIFT                (1U)
#define SIUL2_PGPDO14_PPDO1_WIDTH                (1U)
#define SIUL2_PGPDO14_PPDO1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO1_SHIFT)) & SIUL2_PGPDO14_PPDO1_MASK)

#define SIUL2_PGPDO14_PPDO2_MASK                 (0x4U)
#define SIUL2_PGPDO14_PPDO2_SHIFT                (2U)
#define SIUL2_PGPDO14_PPDO2_WIDTH                (1U)
#define SIUL2_PGPDO14_PPDO2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO2_SHIFT)) & SIUL2_PGPDO14_PPDO2_MASK)

#define SIUL2_PGPDO14_PPDO3_MASK                 (0x8U)
#define SIUL2_PGPDO14_PPDO3_SHIFT                (3U)
#define SIUL2_PGPDO14_PPDO3_WIDTH                (1U)
#define SIUL2_PGPDO14_PPDO3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO3_SHIFT)) & SIUL2_PGPDO14_PPDO3_MASK)

#define SIUL2_PGPDO14_PPDO4_MASK                 (0x10U)
#define SIUL2_PGPDO14_PPDO4_SHIFT                (4U)
#define SIUL2_PGPDO14_PPDO4_WIDTH                (1U)
#define SIUL2_PGPDO14_PPDO4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO4_SHIFT)) & SIUL2_PGPDO14_PPDO4_MASK)

#define SIUL2_PGPDO14_PPDO5_MASK                 (0x20U)
#define SIUL2_PGPDO14_PPDO5_SHIFT                (5U)
#define SIUL2_PGPDO14_PPDO5_WIDTH                (1U)
#define SIUL2_PGPDO14_PPDO5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO5_SHIFT)) & SIUL2_PGPDO14_PPDO5_MASK)

#define SIUL2_PGPDO14_PPDO6_MASK                 (0x40U)
#define SIUL2_PGPDO14_PPDO6_SHIFT                (6U)
#define SIUL2_PGPDO14_PPDO6_WIDTH                (1U)
#define SIUL2_PGPDO14_PPDO6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO6_SHIFT)) & SIUL2_PGPDO14_PPDO6_MASK)

#define SIUL2_PGPDO14_PPDO7_MASK                 (0x80U)
#define SIUL2_PGPDO14_PPDO7_SHIFT                (7U)
#define SIUL2_PGPDO14_PPDO7_WIDTH                (1U)
#define SIUL2_PGPDO14_PPDO7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO7_SHIFT)) & SIUL2_PGPDO14_PPDO7_MASK)

#define SIUL2_PGPDO14_PPDO8_MASK                 (0x100U)
#define SIUL2_PGPDO14_PPDO8_SHIFT                (8U)
#define SIUL2_PGPDO14_PPDO8_WIDTH                (1U)
#define SIUL2_PGPDO14_PPDO8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO8_SHIFT)) & SIUL2_PGPDO14_PPDO8_MASK)

#define SIUL2_PGPDO14_PPDO10_MASK                (0x400U)
#define SIUL2_PGPDO14_PPDO10_SHIFT               (10U)
#define SIUL2_PGPDO14_PPDO10_WIDTH               (1U)
#define SIUL2_PGPDO14_PPDO10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO10_SHIFT)) & SIUL2_PGPDO14_PPDO10_MASK)

#define SIUL2_PGPDO14_PPDO11_MASK                (0x800U)
#define SIUL2_PGPDO14_PPDO11_SHIFT               (11U)
#define SIUL2_PGPDO14_PPDO11_WIDTH               (1U)
#define SIUL2_PGPDO14_PPDO11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO11_SHIFT)) & SIUL2_PGPDO14_PPDO11_MASK)

#define SIUL2_PGPDO14_PPDO12_MASK                (0x1000U)
#define SIUL2_PGPDO14_PPDO12_SHIFT               (12U)
#define SIUL2_PGPDO14_PPDO12_WIDTH               (1U)
#define SIUL2_PGPDO14_PPDO12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO12_SHIFT)) & SIUL2_PGPDO14_PPDO12_MASK)

#define SIUL2_PGPDO14_PPDO13_MASK                (0x2000U)
#define SIUL2_PGPDO14_PPDO13_SHIFT               (13U)
#define SIUL2_PGPDO14_PPDO13_WIDTH               (1U)
#define SIUL2_PGPDO14_PPDO13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO13_SHIFT)) & SIUL2_PGPDO14_PPDO13_MASK)

#define SIUL2_PGPDO14_PPDO14_MASK                (0x4000U)
#define SIUL2_PGPDO14_PPDO14_SHIFT               (14U)
#define SIUL2_PGPDO14_PPDO14_WIDTH               (1U)
#define SIUL2_PGPDO14_PPDO14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO14_SHIFT)) & SIUL2_PGPDO14_PPDO14_MASK)

#define SIUL2_PGPDO14_PPDO15_MASK                (0x8000U)
#define SIUL2_PGPDO14_PPDO15_SHIFT               (15U)
#define SIUL2_PGPDO14_PPDO15_WIDTH               (1U)
#define SIUL2_PGPDO14_PPDO15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO14_PPDO15_SHIFT)) & SIUL2_PGPDO14_PPDO15_MASK)
/*! @} */

/*! @name PGPDO16 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO16_PPDO7_MASK                 (0x80U)
#define SIUL2_PGPDO16_PPDO7_SHIFT                (7U)
#define SIUL2_PGPDO16_PPDO7_WIDTH                (1U)
#define SIUL2_PGPDO16_PPDO7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO16_PPDO7_SHIFT)) & SIUL2_PGPDO16_PPDO7_MASK)

#define SIUL2_PGPDO16_PPDO8_MASK                 (0x100U)
#define SIUL2_PGPDO16_PPDO8_SHIFT                (8U)
#define SIUL2_PGPDO16_PPDO8_WIDTH                (1U)
#define SIUL2_PGPDO16_PPDO8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO16_PPDO8_SHIFT)) & SIUL2_PGPDO16_PPDO8_MASK)

#define SIUL2_PGPDO16_PPDO9_MASK                 (0x200U)
#define SIUL2_PGPDO16_PPDO9_SHIFT                (9U)
#define SIUL2_PGPDO16_PPDO9_WIDTH                (1U)
#define SIUL2_PGPDO16_PPDO9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO16_PPDO9_SHIFT)) & SIUL2_PGPDO16_PPDO9_MASK)

#define SIUL2_PGPDO16_PPDO10_MASK                (0x400U)
#define SIUL2_PGPDO16_PPDO10_SHIFT               (10U)
#define SIUL2_PGPDO16_PPDO10_WIDTH               (1U)
#define SIUL2_PGPDO16_PPDO10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO16_PPDO10_SHIFT)) & SIUL2_PGPDO16_PPDO10_MASK)

#define SIUL2_PGPDO16_PPDO11_MASK                (0x800U)
#define SIUL2_PGPDO16_PPDO11_SHIFT               (11U)
#define SIUL2_PGPDO16_PPDO11_WIDTH               (1U)
#define SIUL2_PGPDO16_PPDO11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO16_PPDO11_SHIFT)) & SIUL2_PGPDO16_PPDO11_MASK)

#define SIUL2_PGPDO16_PPDO12_MASK                (0x1000U)
#define SIUL2_PGPDO16_PPDO12_SHIFT               (12U)
#define SIUL2_PGPDO16_PPDO12_WIDTH               (1U)
#define SIUL2_PGPDO16_PPDO12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO16_PPDO12_SHIFT)) & SIUL2_PGPDO16_PPDO12_MASK)

#define SIUL2_PGPDO16_PPDO13_MASK                (0x2000U)
#define SIUL2_PGPDO16_PPDO13_SHIFT               (13U)
#define SIUL2_PGPDO16_PPDO13_WIDTH               (1U)
#define SIUL2_PGPDO16_PPDO13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO16_PPDO13_SHIFT)) & SIUL2_PGPDO16_PPDO13_MASK)

#define SIUL2_PGPDO16_PPDO14_MASK                (0x4000U)
#define SIUL2_PGPDO16_PPDO14_SHIFT               (14U)
#define SIUL2_PGPDO16_PPDO14_WIDTH               (1U)
#define SIUL2_PGPDO16_PPDO14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO16_PPDO14_SHIFT)) & SIUL2_PGPDO16_PPDO14_MASK)

#define SIUL2_PGPDO16_PPDO15_MASK                (0x8000U)
#define SIUL2_PGPDO16_PPDO15_SHIFT               (15U)
#define SIUL2_PGPDO16_PPDO15_WIDTH               (1U)
#define SIUL2_PGPDO16_PPDO15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO16_PPDO15_SHIFT)) & SIUL2_PGPDO16_PPDO15_MASK)
/*! @} */

/*! @name PGPDO19 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO19_PPDO0_MASK                 (0x1U)
#define SIUL2_PGPDO19_PPDO0_SHIFT                (0U)
#define SIUL2_PGPDO19_PPDO0_WIDTH                (1U)
#define SIUL2_PGPDO19_PPDO0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO0_SHIFT)) & SIUL2_PGPDO19_PPDO0_MASK)

#define SIUL2_PGPDO19_PPDO1_MASK                 (0x2U)
#define SIUL2_PGPDO19_PPDO1_SHIFT                (1U)
#define SIUL2_PGPDO19_PPDO1_WIDTH                (1U)
#define SIUL2_PGPDO19_PPDO1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO1_SHIFT)) & SIUL2_PGPDO19_PPDO1_MASK)

#define SIUL2_PGPDO19_PPDO2_MASK                 (0x4U)
#define SIUL2_PGPDO19_PPDO2_SHIFT                (2U)
#define SIUL2_PGPDO19_PPDO2_WIDTH                (1U)
#define SIUL2_PGPDO19_PPDO2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO2_SHIFT)) & SIUL2_PGPDO19_PPDO2_MASK)

#define SIUL2_PGPDO19_PPDO3_MASK                 (0x8U)
#define SIUL2_PGPDO19_PPDO3_SHIFT                (3U)
#define SIUL2_PGPDO19_PPDO3_WIDTH                (1U)
#define SIUL2_PGPDO19_PPDO3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO3_SHIFT)) & SIUL2_PGPDO19_PPDO3_MASK)

#define SIUL2_PGPDO19_PPDO4_MASK                 (0x10U)
#define SIUL2_PGPDO19_PPDO4_SHIFT                (4U)
#define SIUL2_PGPDO19_PPDO4_WIDTH                (1U)
#define SIUL2_PGPDO19_PPDO4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO4_SHIFT)) & SIUL2_PGPDO19_PPDO4_MASK)

#define SIUL2_PGPDO19_PPDO5_MASK                 (0x20U)
#define SIUL2_PGPDO19_PPDO5_SHIFT                (5U)
#define SIUL2_PGPDO19_PPDO5_WIDTH                (1U)
#define SIUL2_PGPDO19_PPDO5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO5_SHIFT)) & SIUL2_PGPDO19_PPDO5_MASK)

#define SIUL2_PGPDO19_PPDO6_MASK                 (0x40U)
#define SIUL2_PGPDO19_PPDO6_SHIFT                (6U)
#define SIUL2_PGPDO19_PPDO6_WIDTH                (1U)
#define SIUL2_PGPDO19_PPDO6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO6_SHIFT)) & SIUL2_PGPDO19_PPDO6_MASK)

#define SIUL2_PGPDO19_PPDO7_MASK                 (0x80U)
#define SIUL2_PGPDO19_PPDO7_SHIFT                (7U)
#define SIUL2_PGPDO19_PPDO7_WIDTH                (1U)
#define SIUL2_PGPDO19_PPDO7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO7_SHIFT)) & SIUL2_PGPDO19_PPDO7_MASK)

#define SIUL2_PGPDO19_PPDO8_MASK                 (0x100U)
#define SIUL2_PGPDO19_PPDO8_SHIFT                (8U)
#define SIUL2_PGPDO19_PPDO8_WIDTH                (1U)
#define SIUL2_PGPDO19_PPDO8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO8_SHIFT)) & SIUL2_PGPDO19_PPDO8_MASK)

#define SIUL2_PGPDO19_PPDO9_MASK                 (0x200U)
#define SIUL2_PGPDO19_PPDO9_SHIFT                (9U)
#define SIUL2_PGPDO19_PPDO9_WIDTH                (1U)
#define SIUL2_PGPDO19_PPDO9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO9_SHIFT)) & SIUL2_PGPDO19_PPDO9_MASK)

#define SIUL2_PGPDO19_PPDO10_MASK                (0x400U)
#define SIUL2_PGPDO19_PPDO10_SHIFT               (10U)
#define SIUL2_PGPDO19_PPDO10_WIDTH               (1U)
#define SIUL2_PGPDO19_PPDO10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO10_SHIFT)) & SIUL2_PGPDO19_PPDO10_MASK)

#define SIUL2_PGPDO19_PPDO11_MASK                (0x800U)
#define SIUL2_PGPDO19_PPDO11_SHIFT               (11U)
#define SIUL2_PGPDO19_PPDO11_WIDTH               (1U)
#define SIUL2_PGPDO19_PPDO11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO11_SHIFT)) & SIUL2_PGPDO19_PPDO11_MASK)

#define SIUL2_PGPDO19_PPDO12_MASK                (0x1000U)
#define SIUL2_PGPDO19_PPDO12_SHIFT               (12U)
#define SIUL2_PGPDO19_PPDO12_WIDTH               (1U)
#define SIUL2_PGPDO19_PPDO12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO12_SHIFT)) & SIUL2_PGPDO19_PPDO12_MASK)

#define SIUL2_PGPDO19_PPDO13_MASK                (0x2000U)
#define SIUL2_PGPDO19_PPDO13_SHIFT               (13U)
#define SIUL2_PGPDO19_PPDO13_WIDTH               (1U)
#define SIUL2_PGPDO19_PPDO13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO13_SHIFT)) & SIUL2_PGPDO19_PPDO13_MASK)

#define SIUL2_PGPDO19_PPDO14_MASK                (0x4000U)
#define SIUL2_PGPDO19_PPDO14_SHIFT               (14U)
#define SIUL2_PGPDO19_PPDO14_WIDTH               (1U)
#define SIUL2_PGPDO19_PPDO14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO14_SHIFT)) & SIUL2_PGPDO19_PPDO14_MASK)

#define SIUL2_PGPDO19_PPDO15_MASK                (0x8000U)
#define SIUL2_PGPDO19_PPDO15_SHIFT               (15U)
#define SIUL2_PGPDO19_PPDO15_WIDTH               (1U)
#define SIUL2_PGPDO19_PPDO15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO19_PPDO15_SHIFT)) & SIUL2_PGPDO19_PPDO15_MASK)
/*! @} */

/*! @name PGPDO21 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO21_PPDO0_MASK                 (0x1U)
#define SIUL2_PGPDO21_PPDO0_SHIFT                (0U)
#define SIUL2_PGPDO21_PPDO0_WIDTH                (1U)
#define SIUL2_PGPDO21_PPDO0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO0_SHIFT)) & SIUL2_PGPDO21_PPDO0_MASK)

#define SIUL2_PGPDO21_PPDO1_MASK                 (0x2U)
#define SIUL2_PGPDO21_PPDO1_SHIFT                (1U)
#define SIUL2_PGPDO21_PPDO1_WIDTH                (1U)
#define SIUL2_PGPDO21_PPDO1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO1_SHIFT)) & SIUL2_PGPDO21_PPDO1_MASK)

#define SIUL2_PGPDO21_PPDO2_MASK                 (0x4U)
#define SIUL2_PGPDO21_PPDO2_SHIFT                (2U)
#define SIUL2_PGPDO21_PPDO2_WIDTH                (1U)
#define SIUL2_PGPDO21_PPDO2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO2_SHIFT)) & SIUL2_PGPDO21_PPDO2_MASK)

#define SIUL2_PGPDO21_PPDO3_MASK                 (0x8U)
#define SIUL2_PGPDO21_PPDO3_SHIFT                (3U)
#define SIUL2_PGPDO21_PPDO3_WIDTH                (1U)
#define SIUL2_PGPDO21_PPDO3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO3_SHIFT)) & SIUL2_PGPDO21_PPDO3_MASK)

#define SIUL2_PGPDO21_PPDO4_MASK                 (0x10U)
#define SIUL2_PGPDO21_PPDO4_SHIFT                (4U)
#define SIUL2_PGPDO21_PPDO4_WIDTH                (1U)
#define SIUL2_PGPDO21_PPDO4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO4_SHIFT)) & SIUL2_PGPDO21_PPDO4_MASK)

#define SIUL2_PGPDO21_PPDO5_MASK                 (0x20U)
#define SIUL2_PGPDO21_PPDO5_SHIFT                (5U)
#define SIUL2_PGPDO21_PPDO5_WIDTH                (1U)
#define SIUL2_PGPDO21_PPDO5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO5_SHIFT)) & SIUL2_PGPDO21_PPDO5_MASK)

#define SIUL2_PGPDO21_PPDO6_MASK                 (0x40U)
#define SIUL2_PGPDO21_PPDO6_SHIFT                (6U)
#define SIUL2_PGPDO21_PPDO6_WIDTH                (1U)
#define SIUL2_PGPDO21_PPDO6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO6_SHIFT)) & SIUL2_PGPDO21_PPDO6_MASK)

#define SIUL2_PGPDO21_PPDO7_MASK                 (0x80U)
#define SIUL2_PGPDO21_PPDO7_SHIFT                (7U)
#define SIUL2_PGPDO21_PPDO7_WIDTH                (1U)
#define SIUL2_PGPDO21_PPDO7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO7_SHIFT)) & SIUL2_PGPDO21_PPDO7_MASK)

#define SIUL2_PGPDO21_PPDO8_MASK                 (0x100U)
#define SIUL2_PGPDO21_PPDO8_SHIFT                (8U)
#define SIUL2_PGPDO21_PPDO8_WIDTH                (1U)
#define SIUL2_PGPDO21_PPDO8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO8_SHIFT)) & SIUL2_PGPDO21_PPDO8_MASK)

#define SIUL2_PGPDO21_PPDO9_MASK                 (0x200U)
#define SIUL2_PGPDO21_PPDO9_SHIFT                (9U)
#define SIUL2_PGPDO21_PPDO9_WIDTH                (1U)
#define SIUL2_PGPDO21_PPDO9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO9_SHIFT)) & SIUL2_PGPDO21_PPDO9_MASK)

#define SIUL2_PGPDO21_PPDO10_MASK                (0x400U)
#define SIUL2_PGPDO21_PPDO10_SHIFT               (10U)
#define SIUL2_PGPDO21_PPDO10_WIDTH               (1U)
#define SIUL2_PGPDO21_PPDO10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO10_SHIFT)) & SIUL2_PGPDO21_PPDO10_MASK)

#define SIUL2_PGPDO21_PPDO11_MASK                (0x800U)
#define SIUL2_PGPDO21_PPDO11_SHIFT               (11U)
#define SIUL2_PGPDO21_PPDO11_WIDTH               (1U)
#define SIUL2_PGPDO21_PPDO11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO11_SHIFT)) & SIUL2_PGPDO21_PPDO11_MASK)

#define SIUL2_PGPDO21_PPDO12_MASK                (0x1000U)
#define SIUL2_PGPDO21_PPDO12_SHIFT               (12U)
#define SIUL2_PGPDO21_PPDO12_WIDTH               (1U)
#define SIUL2_PGPDO21_PPDO12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO12_SHIFT)) & SIUL2_PGPDO21_PPDO12_MASK)

#define SIUL2_PGPDO21_PPDO13_MASK                (0x2000U)
#define SIUL2_PGPDO21_PPDO13_SHIFT               (13U)
#define SIUL2_PGPDO21_PPDO13_WIDTH               (1U)
#define SIUL2_PGPDO21_PPDO13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO13_SHIFT)) & SIUL2_PGPDO21_PPDO13_MASK)

#define SIUL2_PGPDO21_PPDO14_MASK                (0x4000U)
#define SIUL2_PGPDO21_PPDO14_SHIFT               (14U)
#define SIUL2_PGPDO21_PPDO14_WIDTH               (1U)
#define SIUL2_PGPDO21_PPDO14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO14_SHIFT)) & SIUL2_PGPDO21_PPDO14_MASK)

#define SIUL2_PGPDO21_PPDO15_MASK                (0x8000U)
#define SIUL2_PGPDO21_PPDO15_SHIFT               (15U)
#define SIUL2_PGPDO21_PPDO15_WIDTH               (1U)
#define SIUL2_PGPDO21_PPDO15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO21_PPDO15_SHIFT)) & SIUL2_PGPDO21_PPDO15_MASK)
/*! @} */

/*! @name PGPDO20 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO20_PPDO0_MASK                 (0x1U)
#define SIUL2_PGPDO20_PPDO0_SHIFT                (0U)
#define SIUL2_PGPDO20_PPDO0_WIDTH                (1U)
#define SIUL2_PGPDO20_PPDO0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO0_SHIFT)) & SIUL2_PGPDO20_PPDO0_MASK)

#define SIUL2_PGPDO20_PPDO1_MASK                 (0x2U)
#define SIUL2_PGPDO20_PPDO1_SHIFT                (1U)
#define SIUL2_PGPDO20_PPDO1_WIDTH                (1U)
#define SIUL2_PGPDO20_PPDO1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO1_SHIFT)) & SIUL2_PGPDO20_PPDO1_MASK)

#define SIUL2_PGPDO20_PPDO2_MASK                 (0x4U)
#define SIUL2_PGPDO20_PPDO2_SHIFT                (2U)
#define SIUL2_PGPDO20_PPDO2_WIDTH                (1U)
#define SIUL2_PGPDO20_PPDO2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO2_SHIFT)) & SIUL2_PGPDO20_PPDO2_MASK)

#define SIUL2_PGPDO20_PPDO3_MASK                 (0x8U)
#define SIUL2_PGPDO20_PPDO3_SHIFT                (3U)
#define SIUL2_PGPDO20_PPDO3_WIDTH                (1U)
#define SIUL2_PGPDO20_PPDO3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO3_SHIFT)) & SIUL2_PGPDO20_PPDO3_MASK)

#define SIUL2_PGPDO20_PPDO4_MASK                 (0x10U)
#define SIUL2_PGPDO20_PPDO4_SHIFT                (4U)
#define SIUL2_PGPDO20_PPDO4_WIDTH                (1U)
#define SIUL2_PGPDO20_PPDO4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO4_SHIFT)) & SIUL2_PGPDO20_PPDO4_MASK)

#define SIUL2_PGPDO20_PPDO5_MASK                 (0x20U)
#define SIUL2_PGPDO20_PPDO5_SHIFT                (5U)
#define SIUL2_PGPDO20_PPDO5_WIDTH                (1U)
#define SIUL2_PGPDO20_PPDO5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO5_SHIFT)) & SIUL2_PGPDO20_PPDO5_MASK)

#define SIUL2_PGPDO20_PPDO6_MASK                 (0x40U)
#define SIUL2_PGPDO20_PPDO6_SHIFT                (6U)
#define SIUL2_PGPDO20_PPDO6_WIDTH                (1U)
#define SIUL2_PGPDO20_PPDO6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO6_SHIFT)) & SIUL2_PGPDO20_PPDO6_MASK)

#define SIUL2_PGPDO20_PPDO7_MASK                 (0x80U)
#define SIUL2_PGPDO20_PPDO7_SHIFT                (7U)
#define SIUL2_PGPDO20_PPDO7_WIDTH                (1U)
#define SIUL2_PGPDO20_PPDO7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO7_SHIFT)) & SIUL2_PGPDO20_PPDO7_MASK)

#define SIUL2_PGPDO20_PPDO8_MASK                 (0x100U)
#define SIUL2_PGPDO20_PPDO8_SHIFT                (8U)
#define SIUL2_PGPDO20_PPDO8_WIDTH                (1U)
#define SIUL2_PGPDO20_PPDO8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO8_SHIFT)) & SIUL2_PGPDO20_PPDO8_MASK)

#define SIUL2_PGPDO20_PPDO9_MASK                 (0x200U)
#define SIUL2_PGPDO20_PPDO9_SHIFT                (9U)
#define SIUL2_PGPDO20_PPDO9_WIDTH                (1U)
#define SIUL2_PGPDO20_PPDO9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO9_SHIFT)) & SIUL2_PGPDO20_PPDO9_MASK)

#define SIUL2_PGPDO20_PPDO10_MASK                (0x400U)
#define SIUL2_PGPDO20_PPDO10_SHIFT               (10U)
#define SIUL2_PGPDO20_PPDO10_WIDTH               (1U)
#define SIUL2_PGPDO20_PPDO10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO10_SHIFT)) & SIUL2_PGPDO20_PPDO10_MASK)

#define SIUL2_PGPDO20_PPDO11_MASK                (0x800U)
#define SIUL2_PGPDO20_PPDO11_SHIFT               (11U)
#define SIUL2_PGPDO20_PPDO11_WIDTH               (1U)
#define SIUL2_PGPDO20_PPDO11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO11_SHIFT)) & SIUL2_PGPDO20_PPDO11_MASK)

#define SIUL2_PGPDO20_PPDO12_MASK                (0x1000U)
#define SIUL2_PGPDO20_PPDO12_SHIFT               (12U)
#define SIUL2_PGPDO20_PPDO12_WIDTH               (1U)
#define SIUL2_PGPDO20_PPDO12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO12_SHIFT)) & SIUL2_PGPDO20_PPDO12_MASK)

#define SIUL2_PGPDO20_PPDO13_MASK                (0x2000U)
#define SIUL2_PGPDO20_PPDO13_SHIFT               (13U)
#define SIUL2_PGPDO20_PPDO13_WIDTH               (1U)
#define SIUL2_PGPDO20_PPDO13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO13_SHIFT)) & SIUL2_PGPDO20_PPDO13_MASK)

#define SIUL2_PGPDO20_PPDO14_MASK                (0x4000U)
#define SIUL2_PGPDO20_PPDO14_SHIFT               (14U)
#define SIUL2_PGPDO20_PPDO14_WIDTH               (1U)
#define SIUL2_PGPDO20_PPDO14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO14_SHIFT)) & SIUL2_PGPDO20_PPDO14_MASK)

#define SIUL2_PGPDO20_PPDO15_MASK                (0x8000U)
#define SIUL2_PGPDO20_PPDO15_SHIFT               (15U)
#define SIUL2_PGPDO20_PPDO15_WIDTH               (1U)
#define SIUL2_PGPDO20_PPDO15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO20_PPDO15_SHIFT)) & SIUL2_PGPDO20_PPDO15_MASK)
/*! @} */

/*! @name PGPDO23 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO23_PPDO12_MASK                (0x1000U)
#define SIUL2_PGPDO23_PPDO12_SHIFT               (12U)
#define SIUL2_PGPDO23_PPDO12_WIDTH               (1U)
#define SIUL2_PGPDO23_PPDO12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO23_PPDO12_SHIFT)) & SIUL2_PGPDO23_PPDO12_MASK)

#define SIUL2_PGPDO23_PPDO13_MASK                (0x2000U)
#define SIUL2_PGPDO23_PPDO13_SHIFT               (13U)
#define SIUL2_PGPDO23_PPDO13_WIDTH               (1U)
#define SIUL2_PGPDO23_PPDO13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO23_PPDO13_SHIFT)) & SIUL2_PGPDO23_PPDO13_MASK)

#define SIUL2_PGPDO23_PPDO14_MASK                (0x4000U)
#define SIUL2_PGPDO23_PPDO14_SHIFT               (14U)
#define SIUL2_PGPDO23_PPDO14_WIDTH               (1U)
#define SIUL2_PGPDO23_PPDO14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO23_PPDO14_SHIFT)) & SIUL2_PGPDO23_PPDO14_MASK)

#define SIUL2_PGPDO23_PPDO15_MASK                (0x8000U)
#define SIUL2_PGPDO23_PPDO15_SHIFT               (15U)
#define SIUL2_PGPDO23_PPDO15_WIDTH               (1U)
#define SIUL2_PGPDO23_PPDO15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO23_PPDO15_SHIFT)) & SIUL2_PGPDO23_PPDO15_MASK)
/*! @} */

/*! @name PGPDO22 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO22_PPDO0_MASK                 (0x1U)
#define SIUL2_PGPDO22_PPDO0_SHIFT                (0U)
#define SIUL2_PGPDO22_PPDO0_WIDTH                (1U)
#define SIUL2_PGPDO22_PPDO0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO0_SHIFT)) & SIUL2_PGPDO22_PPDO0_MASK)

#define SIUL2_PGPDO22_PPDO1_MASK                 (0x2U)
#define SIUL2_PGPDO22_PPDO1_SHIFT                (1U)
#define SIUL2_PGPDO22_PPDO1_WIDTH                (1U)
#define SIUL2_PGPDO22_PPDO1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO1_SHIFT)) & SIUL2_PGPDO22_PPDO1_MASK)

#define SIUL2_PGPDO22_PPDO2_MASK                 (0x4U)
#define SIUL2_PGPDO22_PPDO2_SHIFT                (2U)
#define SIUL2_PGPDO22_PPDO2_WIDTH                (1U)
#define SIUL2_PGPDO22_PPDO2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO2_SHIFT)) & SIUL2_PGPDO22_PPDO2_MASK)

#define SIUL2_PGPDO22_PPDO3_MASK                 (0x8U)
#define SIUL2_PGPDO22_PPDO3_SHIFT                (3U)
#define SIUL2_PGPDO22_PPDO3_WIDTH                (1U)
#define SIUL2_PGPDO22_PPDO3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO3_SHIFT)) & SIUL2_PGPDO22_PPDO3_MASK)

#define SIUL2_PGPDO22_PPDO4_MASK                 (0x10U)
#define SIUL2_PGPDO22_PPDO4_SHIFT                (4U)
#define SIUL2_PGPDO22_PPDO4_WIDTH                (1U)
#define SIUL2_PGPDO22_PPDO4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO4_SHIFT)) & SIUL2_PGPDO22_PPDO4_MASK)

#define SIUL2_PGPDO22_PPDO5_MASK                 (0x20U)
#define SIUL2_PGPDO22_PPDO5_SHIFT                (5U)
#define SIUL2_PGPDO22_PPDO5_WIDTH                (1U)
#define SIUL2_PGPDO22_PPDO5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO5_SHIFT)) & SIUL2_PGPDO22_PPDO5_MASK)

#define SIUL2_PGPDO22_PPDO6_MASK                 (0x40U)
#define SIUL2_PGPDO22_PPDO6_SHIFT                (6U)
#define SIUL2_PGPDO22_PPDO6_WIDTH                (1U)
#define SIUL2_PGPDO22_PPDO6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO6_SHIFT)) & SIUL2_PGPDO22_PPDO6_MASK)

#define SIUL2_PGPDO22_PPDO7_MASK                 (0x80U)
#define SIUL2_PGPDO22_PPDO7_SHIFT                (7U)
#define SIUL2_PGPDO22_PPDO7_WIDTH                (1U)
#define SIUL2_PGPDO22_PPDO7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO7_SHIFT)) & SIUL2_PGPDO22_PPDO7_MASK)

#define SIUL2_PGPDO22_PPDO8_MASK                 (0x100U)
#define SIUL2_PGPDO22_PPDO8_SHIFT                (8U)
#define SIUL2_PGPDO22_PPDO8_WIDTH                (1U)
#define SIUL2_PGPDO22_PPDO8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO8_SHIFT)) & SIUL2_PGPDO22_PPDO8_MASK)

#define SIUL2_PGPDO22_PPDO9_MASK                 (0x200U)
#define SIUL2_PGPDO22_PPDO9_SHIFT                (9U)
#define SIUL2_PGPDO22_PPDO9_WIDTH                (1U)
#define SIUL2_PGPDO22_PPDO9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO9_SHIFT)) & SIUL2_PGPDO22_PPDO9_MASK)

#define SIUL2_PGPDO22_PPDO10_MASK                (0x400U)
#define SIUL2_PGPDO22_PPDO10_SHIFT               (10U)
#define SIUL2_PGPDO22_PPDO10_WIDTH               (1U)
#define SIUL2_PGPDO22_PPDO10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO10_SHIFT)) & SIUL2_PGPDO22_PPDO10_MASK)

#define SIUL2_PGPDO22_PPDO11_MASK                (0x800U)
#define SIUL2_PGPDO22_PPDO11_SHIFT               (11U)
#define SIUL2_PGPDO22_PPDO11_WIDTH               (1U)
#define SIUL2_PGPDO22_PPDO11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO11_SHIFT)) & SIUL2_PGPDO22_PPDO11_MASK)

#define SIUL2_PGPDO22_PPDO12_MASK                (0x1000U)
#define SIUL2_PGPDO22_PPDO12_SHIFT               (12U)
#define SIUL2_PGPDO22_PPDO12_WIDTH               (1U)
#define SIUL2_PGPDO22_PPDO12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO12_SHIFT)) & SIUL2_PGPDO22_PPDO12_MASK)

#define SIUL2_PGPDO22_PPDO13_MASK                (0x2000U)
#define SIUL2_PGPDO22_PPDO13_SHIFT               (13U)
#define SIUL2_PGPDO22_PPDO13_WIDTH               (1U)
#define SIUL2_PGPDO22_PPDO13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO13_SHIFT)) & SIUL2_PGPDO22_PPDO13_MASK)

#define SIUL2_PGPDO22_PPDO14_MASK                (0x4000U)
#define SIUL2_PGPDO22_PPDO14_SHIFT               (14U)
#define SIUL2_PGPDO22_PPDO14_WIDTH               (1U)
#define SIUL2_PGPDO22_PPDO14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO14_SHIFT)) & SIUL2_PGPDO22_PPDO14_MASK)

#define SIUL2_PGPDO22_PPDO15_MASK                (0x8000U)
#define SIUL2_PGPDO22_PPDO15_SHIFT               (15U)
#define SIUL2_PGPDO22_PPDO15_WIDTH               (1U)
#define SIUL2_PGPDO22_PPDO15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO22_PPDO15_SHIFT)) & SIUL2_PGPDO22_PPDO15_MASK)
/*! @} */

/*! @name PGPDO27 - Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_PGPDO27_PPDO10_MASK                (0x400U)
#define SIUL2_PGPDO27_PPDO10_SHIFT               (10U)
#define SIUL2_PGPDO27_PPDO10_WIDTH               (1U)
#define SIUL2_PGPDO27_PPDO10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO27_PPDO10_SHIFT)) & SIUL2_PGPDO27_PPDO10_MASK)

#define SIUL2_PGPDO27_PPDO11_MASK                (0x800U)
#define SIUL2_PGPDO27_PPDO11_SHIFT               (11U)
#define SIUL2_PGPDO27_PPDO11_WIDTH               (1U)
#define SIUL2_PGPDO27_PPDO11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO27_PPDO11_SHIFT)) & SIUL2_PGPDO27_PPDO11_MASK)

#define SIUL2_PGPDO27_PPDO12_MASK                (0x1000U)
#define SIUL2_PGPDO27_PPDO12_SHIFT               (12U)
#define SIUL2_PGPDO27_PPDO12_WIDTH               (1U)
#define SIUL2_PGPDO27_PPDO12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO27_PPDO12_SHIFT)) & SIUL2_PGPDO27_PPDO12_MASK)

#define SIUL2_PGPDO27_PPDO13_MASK                (0x2000U)
#define SIUL2_PGPDO27_PPDO13_SHIFT               (13U)
#define SIUL2_PGPDO27_PPDO13_WIDTH               (1U)
#define SIUL2_PGPDO27_PPDO13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO27_PPDO13_SHIFT)) & SIUL2_PGPDO27_PPDO13_MASK)

#define SIUL2_PGPDO27_PPDO14_MASK                (0x4000U)
#define SIUL2_PGPDO27_PPDO14_SHIFT               (14U)
#define SIUL2_PGPDO27_PPDO14_WIDTH               (1U)
#define SIUL2_PGPDO27_PPDO14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO27_PPDO14_SHIFT)) & SIUL2_PGPDO27_PPDO14_MASK)

#define SIUL2_PGPDO27_PPDO15_MASK                (0x8000U)
#define SIUL2_PGPDO27_PPDO15_SHIFT               (15U)
#define SIUL2_PGPDO27_PPDO15_WIDTH               (1U)
#define SIUL2_PGPDO27_PPDO15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDO27_PPDO15_SHIFT)) & SIUL2_PGPDO27_PPDO15_MASK)
/*! @} */

/*! @name PGPDI1 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI1_PPDI0_MASK                  (0x1U)
#define SIUL2_PGPDI1_PPDI0_SHIFT                 (0U)
#define SIUL2_PGPDI1_PPDI0_WIDTH                 (1U)
#define SIUL2_PGPDI1_PPDI0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI0_SHIFT)) & SIUL2_PGPDI1_PPDI0_MASK)

#define SIUL2_PGPDI1_PPDI1_MASK                  (0x2U)
#define SIUL2_PGPDI1_PPDI1_SHIFT                 (1U)
#define SIUL2_PGPDI1_PPDI1_WIDTH                 (1U)
#define SIUL2_PGPDI1_PPDI1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI1_SHIFT)) & SIUL2_PGPDI1_PPDI1_MASK)

#define SIUL2_PGPDI1_PPDI2_MASK                  (0x4U)
#define SIUL2_PGPDI1_PPDI2_SHIFT                 (2U)
#define SIUL2_PGPDI1_PPDI2_WIDTH                 (1U)
#define SIUL2_PGPDI1_PPDI2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI2_SHIFT)) & SIUL2_PGPDI1_PPDI2_MASK)

#define SIUL2_PGPDI1_PPDI3_MASK                  (0x8U)
#define SIUL2_PGPDI1_PPDI3_SHIFT                 (3U)
#define SIUL2_PGPDI1_PPDI3_WIDTH                 (1U)
#define SIUL2_PGPDI1_PPDI3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI3_SHIFT)) & SIUL2_PGPDI1_PPDI3_MASK)

#define SIUL2_PGPDI1_PPDI4_MASK                  (0x10U)
#define SIUL2_PGPDI1_PPDI4_SHIFT                 (4U)
#define SIUL2_PGPDI1_PPDI4_WIDTH                 (1U)
#define SIUL2_PGPDI1_PPDI4(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI4_SHIFT)) & SIUL2_PGPDI1_PPDI4_MASK)

#define SIUL2_PGPDI1_PPDI5_MASK                  (0x20U)
#define SIUL2_PGPDI1_PPDI5_SHIFT                 (5U)
#define SIUL2_PGPDI1_PPDI5_WIDTH                 (1U)
#define SIUL2_PGPDI1_PPDI5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI5_SHIFT)) & SIUL2_PGPDI1_PPDI5_MASK)

#define SIUL2_PGPDI1_PPDI6_MASK                  (0x40U)
#define SIUL2_PGPDI1_PPDI6_SHIFT                 (6U)
#define SIUL2_PGPDI1_PPDI6_WIDTH                 (1U)
#define SIUL2_PGPDI1_PPDI6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI6_SHIFT)) & SIUL2_PGPDI1_PPDI6_MASK)

#define SIUL2_PGPDI1_PPDI7_MASK                  (0x80U)
#define SIUL2_PGPDI1_PPDI7_SHIFT                 (7U)
#define SIUL2_PGPDI1_PPDI7_WIDTH                 (1U)
#define SIUL2_PGPDI1_PPDI7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI7_SHIFT)) & SIUL2_PGPDI1_PPDI7_MASK)

#define SIUL2_PGPDI1_PPDI8_MASK                  (0x100U)
#define SIUL2_PGPDI1_PPDI8_SHIFT                 (8U)
#define SIUL2_PGPDI1_PPDI8_WIDTH                 (1U)
#define SIUL2_PGPDI1_PPDI8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI8_SHIFT)) & SIUL2_PGPDI1_PPDI8_MASK)

#define SIUL2_PGPDI1_PPDI9_MASK                  (0x200U)
#define SIUL2_PGPDI1_PPDI9_SHIFT                 (9U)
#define SIUL2_PGPDI1_PPDI9_WIDTH                 (1U)
#define SIUL2_PGPDI1_PPDI9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI9_SHIFT)) & SIUL2_PGPDI1_PPDI9_MASK)

#define SIUL2_PGPDI1_PPDI10_MASK                 (0x400U)
#define SIUL2_PGPDI1_PPDI10_SHIFT                (10U)
#define SIUL2_PGPDI1_PPDI10_WIDTH                (1U)
#define SIUL2_PGPDI1_PPDI10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI10_SHIFT)) & SIUL2_PGPDI1_PPDI10_MASK)

#define SIUL2_PGPDI1_PPDI11_MASK                 (0x800U)
#define SIUL2_PGPDI1_PPDI11_SHIFT                (11U)
#define SIUL2_PGPDI1_PPDI11_WIDTH                (1U)
#define SIUL2_PGPDI1_PPDI11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI11_SHIFT)) & SIUL2_PGPDI1_PPDI11_MASK)

#define SIUL2_PGPDI1_PPDI12_MASK                 (0x1000U)
#define SIUL2_PGPDI1_PPDI12_SHIFT                (12U)
#define SIUL2_PGPDI1_PPDI12_WIDTH                (1U)
#define SIUL2_PGPDI1_PPDI12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI12_SHIFT)) & SIUL2_PGPDI1_PPDI12_MASK)

#define SIUL2_PGPDI1_PPDI13_MASK                 (0x2000U)
#define SIUL2_PGPDI1_PPDI13_SHIFT                (13U)
#define SIUL2_PGPDI1_PPDI13_WIDTH                (1U)
#define SIUL2_PGPDI1_PPDI13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI13_SHIFT)) & SIUL2_PGPDI1_PPDI13_MASK)

#define SIUL2_PGPDI1_PPDI14_MASK                 (0x4000U)
#define SIUL2_PGPDI1_PPDI14_SHIFT                (14U)
#define SIUL2_PGPDI1_PPDI14_WIDTH                (1U)
#define SIUL2_PGPDI1_PPDI14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI14_SHIFT)) & SIUL2_PGPDI1_PPDI14_MASK)

#define SIUL2_PGPDI1_PPDI15_MASK                 (0x8000U)
#define SIUL2_PGPDI1_PPDI15_SHIFT                (15U)
#define SIUL2_PGPDI1_PPDI15_WIDTH                (1U)
#define SIUL2_PGPDI1_PPDI15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI1_PPDI15_SHIFT)) & SIUL2_PGPDI1_PPDI15_MASK)
/*! @} */

/*! @name PGPDI0 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI0_PPDI0_MASK                  (0x1U)
#define SIUL2_PGPDI0_PPDI0_SHIFT                 (0U)
#define SIUL2_PGPDI0_PPDI0_WIDTH                 (1U)
#define SIUL2_PGPDI0_PPDI0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI0_SHIFT)) & SIUL2_PGPDI0_PPDI0_MASK)

#define SIUL2_PGPDI0_PPDI1_MASK                  (0x2U)
#define SIUL2_PGPDI0_PPDI1_SHIFT                 (1U)
#define SIUL2_PGPDI0_PPDI1_WIDTH                 (1U)
#define SIUL2_PGPDI0_PPDI1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI1_SHIFT)) & SIUL2_PGPDI0_PPDI1_MASK)

#define SIUL2_PGPDI0_PPDI2_MASK                  (0x4U)
#define SIUL2_PGPDI0_PPDI2_SHIFT                 (2U)
#define SIUL2_PGPDI0_PPDI2_WIDTH                 (1U)
#define SIUL2_PGPDI0_PPDI2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI2_SHIFT)) & SIUL2_PGPDI0_PPDI2_MASK)

#define SIUL2_PGPDI0_PPDI3_MASK                  (0x8U)
#define SIUL2_PGPDI0_PPDI3_SHIFT                 (3U)
#define SIUL2_PGPDI0_PPDI3_WIDTH                 (1U)
#define SIUL2_PGPDI0_PPDI3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI3_SHIFT)) & SIUL2_PGPDI0_PPDI3_MASK)

#define SIUL2_PGPDI0_PPDI4_MASK                  (0x10U)
#define SIUL2_PGPDI0_PPDI4_SHIFT                 (4U)
#define SIUL2_PGPDI0_PPDI4_WIDTH                 (1U)
#define SIUL2_PGPDI0_PPDI4(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI4_SHIFT)) & SIUL2_PGPDI0_PPDI4_MASK)

#define SIUL2_PGPDI0_PPDI5_MASK                  (0x20U)
#define SIUL2_PGPDI0_PPDI5_SHIFT                 (5U)
#define SIUL2_PGPDI0_PPDI5_WIDTH                 (1U)
#define SIUL2_PGPDI0_PPDI5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI5_SHIFT)) & SIUL2_PGPDI0_PPDI5_MASK)

#define SIUL2_PGPDI0_PPDI6_MASK                  (0x40U)
#define SIUL2_PGPDI0_PPDI6_SHIFT                 (6U)
#define SIUL2_PGPDI0_PPDI6_WIDTH                 (1U)
#define SIUL2_PGPDI0_PPDI6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI6_SHIFT)) & SIUL2_PGPDI0_PPDI6_MASK)

#define SIUL2_PGPDI0_PPDI7_MASK                  (0x80U)
#define SIUL2_PGPDI0_PPDI7_SHIFT                 (7U)
#define SIUL2_PGPDI0_PPDI7_WIDTH                 (1U)
#define SIUL2_PGPDI0_PPDI7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI7_SHIFT)) & SIUL2_PGPDI0_PPDI7_MASK)

#define SIUL2_PGPDI0_PPDI8_MASK                  (0x100U)
#define SIUL2_PGPDI0_PPDI8_SHIFT                 (8U)
#define SIUL2_PGPDI0_PPDI8_WIDTH                 (1U)
#define SIUL2_PGPDI0_PPDI8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI8_SHIFT)) & SIUL2_PGPDI0_PPDI8_MASK)

#define SIUL2_PGPDI0_PPDI9_MASK                  (0x200U)
#define SIUL2_PGPDI0_PPDI9_SHIFT                 (9U)
#define SIUL2_PGPDI0_PPDI9_WIDTH                 (1U)
#define SIUL2_PGPDI0_PPDI9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI9_SHIFT)) & SIUL2_PGPDI0_PPDI9_MASK)

#define SIUL2_PGPDI0_PPDI10_MASK                 (0x400U)
#define SIUL2_PGPDI0_PPDI10_SHIFT                (10U)
#define SIUL2_PGPDI0_PPDI10_WIDTH                (1U)
#define SIUL2_PGPDI0_PPDI10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI10_SHIFT)) & SIUL2_PGPDI0_PPDI10_MASK)

#define SIUL2_PGPDI0_PPDI11_MASK                 (0x800U)
#define SIUL2_PGPDI0_PPDI11_SHIFT                (11U)
#define SIUL2_PGPDI0_PPDI11_WIDTH                (1U)
#define SIUL2_PGPDI0_PPDI11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI11_SHIFT)) & SIUL2_PGPDI0_PPDI11_MASK)

#define SIUL2_PGPDI0_PPDI12_MASK                 (0x1000U)
#define SIUL2_PGPDI0_PPDI12_SHIFT                (12U)
#define SIUL2_PGPDI0_PPDI12_WIDTH                (1U)
#define SIUL2_PGPDI0_PPDI12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI12_SHIFT)) & SIUL2_PGPDI0_PPDI12_MASK)

#define SIUL2_PGPDI0_PPDI13_MASK                 (0x2000U)
#define SIUL2_PGPDI0_PPDI13_SHIFT                (13U)
#define SIUL2_PGPDI0_PPDI13_WIDTH                (1U)
#define SIUL2_PGPDI0_PPDI13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI13_SHIFT)) & SIUL2_PGPDI0_PPDI13_MASK)

#define SIUL2_PGPDI0_PPDI14_MASK                 (0x4000U)
#define SIUL2_PGPDI0_PPDI14_SHIFT                (14U)
#define SIUL2_PGPDI0_PPDI14_WIDTH                (1U)
#define SIUL2_PGPDI0_PPDI14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI14_SHIFT)) & SIUL2_PGPDI0_PPDI14_MASK)

#define SIUL2_PGPDI0_PPDI15_MASK                 (0x8000U)
#define SIUL2_PGPDI0_PPDI15_SHIFT                (15U)
#define SIUL2_PGPDI0_PPDI15_WIDTH                (1U)
#define SIUL2_PGPDI0_PPDI15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI0_PPDI15_SHIFT)) & SIUL2_PGPDI0_PPDI15_MASK)
/*! @} */

/*! @name PGPDI3 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI3_PPDI0_MASK                  (0x1U)
#define SIUL2_PGPDI3_PPDI0_SHIFT                 (0U)
#define SIUL2_PGPDI3_PPDI0_WIDTH                 (1U)
#define SIUL2_PGPDI3_PPDI0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI0_SHIFT)) & SIUL2_PGPDI3_PPDI0_MASK)

#define SIUL2_PGPDI3_PPDI1_MASK                  (0x2U)
#define SIUL2_PGPDI3_PPDI1_SHIFT                 (1U)
#define SIUL2_PGPDI3_PPDI1_WIDTH                 (1U)
#define SIUL2_PGPDI3_PPDI1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI1_SHIFT)) & SIUL2_PGPDI3_PPDI1_MASK)

#define SIUL2_PGPDI3_PPDI2_MASK                  (0x4U)
#define SIUL2_PGPDI3_PPDI2_SHIFT                 (2U)
#define SIUL2_PGPDI3_PPDI2_WIDTH                 (1U)
#define SIUL2_PGPDI3_PPDI2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI2_SHIFT)) & SIUL2_PGPDI3_PPDI2_MASK)

#define SIUL2_PGPDI3_PPDI3_MASK                  (0x8U)
#define SIUL2_PGPDI3_PPDI3_SHIFT                 (3U)
#define SIUL2_PGPDI3_PPDI3_WIDTH                 (1U)
#define SIUL2_PGPDI3_PPDI3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI3_SHIFT)) & SIUL2_PGPDI3_PPDI3_MASK)

#define SIUL2_PGPDI3_PPDI4_MASK                  (0x10U)
#define SIUL2_PGPDI3_PPDI4_SHIFT                 (4U)
#define SIUL2_PGPDI3_PPDI4_WIDTH                 (1U)
#define SIUL2_PGPDI3_PPDI4(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI4_SHIFT)) & SIUL2_PGPDI3_PPDI4_MASK)

#define SIUL2_PGPDI3_PPDI5_MASK                  (0x20U)
#define SIUL2_PGPDI3_PPDI5_SHIFT                 (5U)
#define SIUL2_PGPDI3_PPDI5_WIDTH                 (1U)
#define SIUL2_PGPDI3_PPDI5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI5_SHIFT)) & SIUL2_PGPDI3_PPDI5_MASK)

#define SIUL2_PGPDI3_PPDI6_MASK                  (0x40U)
#define SIUL2_PGPDI3_PPDI6_SHIFT                 (6U)
#define SIUL2_PGPDI3_PPDI6_WIDTH                 (1U)
#define SIUL2_PGPDI3_PPDI6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI6_SHIFT)) & SIUL2_PGPDI3_PPDI6_MASK)

#define SIUL2_PGPDI3_PPDI7_MASK                  (0x80U)
#define SIUL2_PGPDI3_PPDI7_SHIFT                 (7U)
#define SIUL2_PGPDI3_PPDI7_WIDTH                 (1U)
#define SIUL2_PGPDI3_PPDI7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI7_SHIFT)) & SIUL2_PGPDI3_PPDI7_MASK)

#define SIUL2_PGPDI3_PPDI8_MASK                  (0x100U)
#define SIUL2_PGPDI3_PPDI8_SHIFT                 (8U)
#define SIUL2_PGPDI3_PPDI8_WIDTH                 (1U)
#define SIUL2_PGPDI3_PPDI8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI8_SHIFT)) & SIUL2_PGPDI3_PPDI8_MASK)

#define SIUL2_PGPDI3_PPDI9_MASK                  (0x200U)
#define SIUL2_PGPDI3_PPDI9_SHIFT                 (9U)
#define SIUL2_PGPDI3_PPDI9_WIDTH                 (1U)
#define SIUL2_PGPDI3_PPDI9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI9_SHIFT)) & SIUL2_PGPDI3_PPDI9_MASK)

#define SIUL2_PGPDI3_PPDI10_MASK                 (0x400U)
#define SIUL2_PGPDI3_PPDI10_SHIFT                (10U)
#define SIUL2_PGPDI3_PPDI10_WIDTH                (1U)
#define SIUL2_PGPDI3_PPDI10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI10_SHIFT)) & SIUL2_PGPDI3_PPDI10_MASK)

#define SIUL2_PGPDI3_PPDI11_MASK                 (0x800U)
#define SIUL2_PGPDI3_PPDI11_SHIFT                (11U)
#define SIUL2_PGPDI3_PPDI11_WIDTH                (1U)
#define SIUL2_PGPDI3_PPDI11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI11_SHIFT)) & SIUL2_PGPDI3_PPDI11_MASK)

#define SIUL2_PGPDI3_PPDI12_MASK                 (0x1000U)
#define SIUL2_PGPDI3_PPDI12_SHIFT                (12U)
#define SIUL2_PGPDI3_PPDI12_WIDTH                (1U)
#define SIUL2_PGPDI3_PPDI12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI12_SHIFT)) & SIUL2_PGPDI3_PPDI12_MASK)

#define SIUL2_PGPDI3_PPDI14_MASK                 (0x4000U)
#define SIUL2_PGPDI3_PPDI14_SHIFT                (14U)
#define SIUL2_PGPDI3_PPDI14_WIDTH                (1U)
#define SIUL2_PGPDI3_PPDI14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI14_SHIFT)) & SIUL2_PGPDI3_PPDI14_MASK)

#define SIUL2_PGPDI3_PPDI15_MASK                 (0x8000U)
#define SIUL2_PGPDI3_PPDI15_SHIFT                (15U)
#define SIUL2_PGPDI3_PPDI15_WIDTH                (1U)
#define SIUL2_PGPDI3_PPDI15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI3_PPDI15_SHIFT)) & SIUL2_PGPDI3_PPDI15_MASK)
/*! @} */

/*! @name PGPDI2 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI2_PPDI0_MASK                  (0x1U)
#define SIUL2_PGPDI2_PPDI0_SHIFT                 (0U)
#define SIUL2_PGPDI2_PPDI0_WIDTH                 (1U)
#define SIUL2_PGPDI2_PPDI0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI0_SHIFT)) & SIUL2_PGPDI2_PPDI0_MASK)

#define SIUL2_PGPDI2_PPDI1_MASK                  (0x2U)
#define SIUL2_PGPDI2_PPDI1_SHIFT                 (1U)
#define SIUL2_PGPDI2_PPDI1_WIDTH                 (1U)
#define SIUL2_PGPDI2_PPDI1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI1_SHIFT)) & SIUL2_PGPDI2_PPDI1_MASK)

#define SIUL2_PGPDI2_PPDI2_MASK                  (0x4U)
#define SIUL2_PGPDI2_PPDI2_SHIFT                 (2U)
#define SIUL2_PGPDI2_PPDI2_WIDTH                 (1U)
#define SIUL2_PGPDI2_PPDI2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI2_SHIFT)) & SIUL2_PGPDI2_PPDI2_MASK)

#define SIUL2_PGPDI2_PPDI3_MASK                  (0x8U)
#define SIUL2_PGPDI2_PPDI3_SHIFT                 (3U)
#define SIUL2_PGPDI2_PPDI3_WIDTH                 (1U)
#define SIUL2_PGPDI2_PPDI3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI3_SHIFT)) & SIUL2_PGPDI2_PPDI3_MASK)

#define SIUL2_PGPDI2_PPDI4_MASK                  (0x10U)
#define SIUL2_PGPDI2_PPDI4_SHIFT                 (4U)
#define SIUL2_PGPDI2_PPDI4_WIDTH                 (1U)
#define SIUL2_PGPDI2_PPDI4(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI4_SHIFT)) & SIUL2_PGPDI2_PPDI4_MASK)

#define SIUL2_PGPDI2_PPDI5_MASK                  (0x20U)
#define SIUL2_PGPDI2_PPDI5_SHIFT                 (5U)
#define SIUL2_PGPDI2_PPDI5_WIDTH                 (1U)
#define SIUL2_PGPDI2_PPDI5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI5_SHIFT)) & SIUL2_PGPDI2_PPDI5_MASK)

#define SIUL2_PGPDI2_PPDI6_MASK                  (0x40U)
#define SIUL2_PGPDI2_PPDI6_SHIFT                 (6U)
#define SIUL2_PGPDI2_PPDI6_WIDTH                 (1U)
#define SIUL2_PGPDI2_PPDI6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI6_SHIFT)) & SIUL2_PGPDI2_PPDI6_MASK)

#define SIUL2_PGPDI2_PPDI7_MASK                  (0x80U)
#define SIUL2_PGPDI2_PPDI7_SHIFT                 (7U)
#define SIUL2_PGPDI2_PPDI7_WIDTH                 (1U)
#define SIUL2_PGPDI2_PPDI7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI7_SHIFT)) & SIUL2_PGPDI2_PPDI7_MASK)

#define SIUL2_PGPDI2_PPDI8_MASK                  (0x100U)
#define SIUL2_PGPDI2_PPDI8_SHIFT                 (8U)
#define SIUL2_PGPDI2_PPDI8_WIDTH                 (1U)
#define SIUL2_PGPDI2_PPDI8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI8_SHIFT)) & SIUL2_PGPDI2_PPDI8_MASK)

#define SIUL2_PGPDI2_PPDI9_MASK                  (0x200U)
#define SIUL2_PGPDI2_PPDI9_SHIFT                 (9U)
#define SIUL2_PGPDI2_PPDI9_WIDTH                 (1U)
#define SIUL2_PGPDI2_PPDI9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI9_SHIFT)) & SIUL2_PGPDI2_PPDI9_MASK)

#define SIUL2_PGPDI2_PPDI10_MASK                 (0x400U)
#define SIUL2_PGPDI2_PPDI10_SHIFT                (10U)
#define SIUL2_PGPDI2_PPDI10_WIDTH                (1U)
#define SIUL2_PGPDI2_PPDI10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI10_SHIFT)) & SIUL2_PGPDI2_PPDI10_MASK)

#define SIUL2_PGPDI2_PPDI11_MASK                 (0x800U)
#define SIUL2_PGPDI2_PPDI11_SHIFT                (11U)
#define SIUL2_PGPDI2_PPDI11_WIDTH                (1U)
#define SIUL2_PGPDI2_PPDI11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI11_SHIFT)) & SIUL2_PGPDI2_PPDI11_MASK)

#define SIUL2_PGPDI2_PPDI12_MASK                 (0x1000U)
#define SIUL2_PGPDI2_PPDI12_SHIFT                (12U)
#define SIUL2_PGPDI2_PPDI12_WIDTH                (1U)
#define SIUL2_PGPDI2_PPDI12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI12_SHIFT)) & SIUL2_PGPDI2_PPDI12_MASK)

#define SIUL2_PGPDI2_PPDI13_MASK                 (0x2000U)
#define SIUL2_PGPDI2_PPDI13_SHIFT                (13U)
#define SIUL2_PGPDI2_PPDI13_WIDTH                (1U)
#define SIUL2_PGPDI2_PPDI13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI13_SHIFT)) & SIUL2_PGPDI2_PPDI13_MASK)

#define SIUL2_PGPDI2_PPDI14_MASK                 (0x4000U)
#define SIUL2_PGPDI2_PPDI14_SHIFT                (14U)
#define SIUL2_PGPDI2_PPDI14_WIDTH                (1U)
#define SIUL2_PGPDI2_PPDI14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI14_SHIFT)) & SIUL2_PGPDI2_PPDI14_MASK)

#define SIUL2_PGPDI2_PPDI15_MASK                 (0x8000U)
#define SIUL2_PGPDI2_PPDI15_SHIFT                (15U)
#define SIUL2_PGPDI2_PPDI15_WIDTH                (1U)
#define SIUL2_PGPDI2_PPDI15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI2_PPDI15_SHIFT)) & SIUL2_PGPDI2_PPDI15_MASK)
/*! @} */

/*! @name PGPDI5 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI5_PPDI0_MASK                  (0x1U)
#define SIUL2_PGPDI5_PPDI0_SHIFT                 (0U)
#define SIUL2_PGPDI5_PPDI0_WIDTH                 (1U)
#define SIUL2_PGPDI5_PPDI0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI0_SHIFT)) & SIUL2_PGPDI5_PPDI0_MASK)

#define SIUL2_PGPDI5_PPDI1_MASK                  (0x2U)
#define SIUL2_PGPDI5_PPDI1_SHIFT                 (1U)
#define SIUL2_PGPDI5_PPDI1_WIDTH                 (1U)
#define SIUL2_PGPDI5_PPDI1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI1_SHIFT)) & SIUL2_PGPDI5_PPDI1_MASK)

#define SIUL2_PGPDI5_PPDI2_MASK                  (0x4U)
#define SIUL2_PGPDI5_PPDI2_SHIFT                 (2U)
#define SIUL2_PGPDI5_PPDI2_WIDTH                 (1U)
#define SIUL2_PGPDI5_PPDI2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI2_SHIFT)) & SIUL2_PGPDI5_PPDI2_MASK)

#define SIUL2_PGPDI5_PPDI3_MASK                  (0x8U)
#define SIUL2_PGPDI5_PPDI3_SHIFT                 (3U)
#define SIUL2_PGPDI5_PPDI3_WIDTH                 (1U)
#define SIUL2_PGPDI5_PPDI3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI3_SHIFT)) & SIUL2_PGPDI5_PPDI3_MASK)

#define SIUL2_PGPDI5_PPDI4_MASK                  (0x10U)
#define SIUL2_PGPDI5_PPDI4_SHIFT                 (4U)
#define SIUL2_PGPDI5_PPDI4_WIDTH                 (1U)
#define SIUL2_PGPDI5_PPDI4(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI4_SHIFT)) & SIUL2_PGPDI5_PPDI4_MASK)

#define SIUL2_PGPDI5_PPDI5_MASK                  (0x20U)
#define SIUL2_PGPDI5_PPDI5_SHIFT                 (5U)
#define SIUL2_PGPDI5_PPDI5_WIDTH                 (1U)
#define SIUL2_PGPDI5_PPDI5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI5_SHIFT)) & SIUL2_PGPDI5_PPDI5_MASK)

#define SIUL2_PGPDI5_PPDI6_MASK                  (0x40U)
#define SIUL2_PGPDI5_PPDI6_SHIFT                 (6U)
#define SIUL2_PGPDI5_PPDI6_WIDTH                 (1U)
#define SIUL2_PGPDI5_PPDI6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI6_SHIFT)) & SIUL2_PGPDI5_PPDI6_MASK)

#define SIUL2_PGPDI5_PPDI7_MASK                  (0x80U)
#define SIUL2_PGPDI5_PPDI7_SHIFT                 (7U)
#define SIUL2_PGPDI5_PPDI7_WIDTH                 (1U)
#define SIUL2_PGPDI5_PPDI7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI7_SHIFT)) & SIUL2_PGPDI5_PPDI7_MASK)

#define SIUL2_PGPDI5_PPDI8_MASK                  (0x100U)
#define SIUL2_PGPDI5_PPDI8_SHIFT                 (8U)
#define SIUL2_PGPDI5_PPDI8_WIDTH                 (1U)
#define SIUL2_PGPDI5_PPDI8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI8_SHIFT)) & SIUL2_PGPDI5_PPDI8_MASK)

#define SIUL2_PGPDI5_PPDI9_MASK                  (0x200U)
#define SIUL2_PGPDI5_PPDI9_SHIFT                 (9U)
#define SIUL2_PGPDI5_PPDI9_WIDTH                 (1U)
#define SIUL2_PGPDI5_PPDI9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI9_SHIFT)) & SIUL2_PGPDI5_PPDI9_MASK)

#define SIUL2_PGPDI5_PPDI10_MASK                 (0x400U)
#define SIUL2_PGPDI5_PPDI10_SHIFT                (10U)
#define SIUL2_PGPDI5_PPDI10_WIDTH                (1U)
#define SIUL2_PGPDI5_PPDI10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI10_SHIFT)) & SIUL2_PGPDI5_PPDI10_MASK)

#define SIUL2_PGPDI5_PPDI11_MASK                 (0x800U)
#define SIUL2_PGPDI5_PPDI11_SHIFT                (11U)
#define SIUL2_PGPDI5_PPDI11_WIDTH                (1U)
#define SIUL2_PGPDI5_PPDI11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI11_SHIFT)) & SIUL2_PGPDI5_PPDI11_MASK)

#define SIUL2_PGPDI5_PPDI12_MASK                 (0x1000U)
#define SIUL2_PGPDI5_PPDI12_SHIFT                (12U)
#define SIUL2_PGPDI5_PPDI12_WIDTH                (1U)
#define SIUL2_PGPDI5_PPDI12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI12_SHIFT)) & SIUL2_PGPDI5_PPDI12_MASK)

#define SIUL2_PGPDI5_PPDI13_MASK                 (0x2000U)
#define SIUL2_PGPDI5_PPDI13_SHIFT                (13U)
#define SIUL2_PGPDI5_PPDI13_WIDTH                (1U)
#define SIUL2_PGPDI5_PPDI13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI13_SHIFT)) & SIUL2_PGPDI5_PPDI13_MASK)

#define SIUL2_PGPDI5_PPDI14_MASK                 (0x4000U)
#define SIUL2_PGPDI5_PPDI14_SHIFT                (14U)
#define SIUL2_PGPDI5_PPDI14_WIDTH                (1U)
#define SIUL2_PGPDI5_PPDI14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI14_SHIFT)) & SIUL2_PGPDI5_PPDI14_MASK)

#define SIUL2_PGPDI5_PPDI15_MASK                 (0x8000U)
#define SIUL2_PGPDI5_PPDI15_SHIFT                (15U)
#define SIUL2_PGPDI5_PPDI15_WIDTH                (1U)
#define SIUL2_PGPDI5_PPDI15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI5_PPDI15_SHIFT)) & SIUL2_PGPDI5_PPDI15_MASK)
/*! @} */

/*! @name PGPDI4 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI4_PPDI1_MASK                  (0x2U)
#define SIUL2_PGPDI4_PPDI1_SHIFT                 (1U)
#define SIUL2_PGPDI4_PPDI1_WIDTH                 (1U)
#define SIUL2_PGPDI4_PPDI1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI1_SHIFT)) & SIUL2_PGPDI4_PPDI1_MASK)

#define SIUL2_PGPDI4_PPDI2_MASK                  (0x4U)
#define SIUL2_PGPDI4_PPDI2_SHIFT                 (2U)
#define SIUL2_PGPDI4_PPDI2_WIDTH                 (1U)
#define SIUL2_PGPDI4_PPDI2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI2_SHIFT)) & SIUL2_PGPDI4_PPDI2_MASK)

#define SIUL2_PGPDI4_PPDI3_MASK                  (0x8U)
#define SIUL2_PGPDI4_PPDI3_SHIFT                 (3U)
#define SIUL2_PGPDI4_PPDI3_WIDTH                 (1U)
#define SIUL2_PGPDI4_PPDI3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI3_SHIFT)) & SIUL2_PGPDI4_PPDI3_MASK)

#define SIUL2_PGPDI4_PPDI4_MASK                  (0x10U)
#define SIUL2_PGPDI4_PPDI4_SHIFT                 (4U)
#define SIUL2_PGPDI4_PPDI4_WIDTH                 (1U)
#define SIUL2_PGPDI4_PPDI4(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI4_SHIFT)) & SIUL2_PGPDI4_PPDI4_MASK)

#define SIUL2_PGPDI4_PPDI5_MASK                  (0x20U)
#define SIUL2_PGPDI4_PPDI5_SHIFT                 (5U)
#define SIUL2_PGPDI4_PPDI5_WIDTH                 (1U)
#define SIUL2_PGPDI4_PPDI5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI5_SHIFT)) & SIUL2_PGPDI4_PPDI5_MASK)

#define SIUL2_PGPDI4_PPDI6_MASK                  (0x40U)
#define SIUL2_PGPDI4_PPDI6_SHIFT                 (6U)
#define SIUL2_PGPDI4_PPDI6_WIDTH                 (1U)
#define SIUL2_PGPDI4_PPDI6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI6_SHIFT)) & SIUL2_PGPDI4_PPDI6_MASK)

#define SIUL2_PGPDI4_PPDI7_MASK                  (0x80U)
#define SIUL2_PGPDI4_PPDI7_SHIFT                 (7U)
#define SIUL2_PGPDI4_PPDI7_WIDTH                 (1U)
#define SIUL2_PGPDI4_PPDI7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI7_SHIFT)) & SIUL2_PGPDI4_PPDI7_MASK)

#define SIUL2_PGPDI4_PPDI8_MASK                  (0x100U)
#define SIUL2_PGPDI4_PPDI8_SHIFT                 (8U)
#define SIUL2_PGPDI4_PPDI8_WIDTH                 (1U)
#define SIUL2_PGPDI4_PPDI8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI8_SHIFT)) & SIUL2_PGPDI4_PPDI8_MASK)

#define SIUL2_PGPDI4_PPDI9_MASK                  (0x200U)
#define SIUL2_PGPDI4_PPDI9_SHIFT                 (9U)
#define SIUL2_PGPDI4_PPDI9_WIDTH                 (1U)
#define SIUL2_PGPDI4_PPDI9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI9_SHIFT)) & SIUL2_PGPDI4_PPDI9_MASK)

#define SIUL2_PGPDI4_PPDI10_MASK                 (0x400U)
#define SIUL2_PGPDI4_PPDI10_SHIFT                (10U)
#define SIUL2_PGPDI4_PPDI10_WIDTH                (1U)
#define SIUL2_PGPDI4_PPDI10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI10_SHIFT)) & SIUL2_PGPDI4_PPDI10_MASK)

#define SIUL2_PGPDI4_PPDI11_MASK                 (0x800U)
#define SIUL2_PGPDI4_PPDI11_SHIFT                (11U)
#define SIUL2_PGPDI4_PPDI11_WIDTH                (1U)
#define SIUL2_PGPDI4_PPDI11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI11_SHIFT)) & SIUL2_PGPDI4_PPDI11_MASK)

#define SIUL2_PGPDI4_PPDI12_MASK                 (0x1000U)
#define SIUL2_PGPDI4_PPDI12_SHIFT                (12U)
#define SIUL2_PGPDI4_PPDI12_WIDTH                (1U)
#define SIUL2_PGPDI4_PPDI12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI12_SHIFT)) & SIUL2_PGPDI4_PPDI12_MASK)

#define SIUL2_PGPDI4_PPDI13_MASK                 (0x2000U)
#define SIUL2_PGPDI4_PPDI13_SHIFT                (13U)
#define SIUL2_PGPDI4_PPDI13_WIDTH                (1U)
#define SIUL2_PGPDI4_PPDI13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI13_SHIFT)) & SIUL2_PGPDI4_PPDI13_MASK)

#define SIUL2_PGPDI4_PPDI14_MASK                 (0x4000U)
#define SIUL2_PGPDI4_PPDI14_SHIFT                (14U)
#define SIUL2_PGPDI4_PPDI14_WIDTH                (1U)
#define SIUL2_PGPDI4_PPDI14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI14_SHIFT)) & SIUL2_PGPDI4_PPDI14_MASK)

#define SIUL2_PGPDI4_PPDI15_MASK                 (0x8000U)
#define SIUL2_PGPDI4_PPDI15_SHIFT                (15U)
#define SIUL2_PGPDI4_PPDI15_WIDTH                (1U)
#define SIUL2_PGPDI4_PPDI15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI4_PPDI15_SHIFT)) & SIUL2_PGPDI4_PPDI15_MASK)
/*! @} */

/*! @name PGPDI7 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI7_PPDI0_MASK                  (0x1U)
#define SIUL2_PGPDI7_PPDI0_SHIFT                 (0U)
#define SIUL2_PGPDI7_PPDI0_WIDTH                 (1U)
#define SIUL2_PGPDI7_PPDI0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI7_PPDI0_SHIFT)) & SIUL2_PGPDI7_PPDI0_MASK)

#define SIUL2_PGPDI7_PPDI1_MASK                  (0x2U)
#define SIUL2_PGPDI7_PPDI1_SHIFT                 (1U)
#define SIUL2_PGPDI7_PPDI1_WIDTH                 (1U)
#define SIUL2_PGPDI7_PPDI1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI7_PPDI1_SHIFT)) & SIUL2_PGPDI7_PPDI1_MASK)

#define SIUL2_PGPDI7_PPDI11_MASK                 (0x800U)
#define SIUL2_PGPDI7_PPDI11_SHIFT                (11U)
#define SIUL2_PGPDI7_PPDI11_WIDTH                (1U)
#define SIUL2_PGPDI7_PPDI11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI7_PPDI11_SHIFT)) & SIUL2_PGPDI7_PPDI11_MASK)

#define SIUL2_PGPDI7_PPDI12_MASK                 (0x1000U)
#define SIUL2_PGPDI7_PPDI12_SHIFT                (12U)
#define SIUL2_PGPDI7_PPDI12_WIDTH                (1U)
#define SIUL2_PGPDI7_PPDI12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI7_PPDI12_SHIFT)) & SIUL2_PGPDI7_PPDI12_MASK)

#define SIUL2_PGPDI7_PPDI13_MASK                 (0x2000U)
#define SIUL2_PGPDI7_PPDI13_SHIFT                (13U)
#define SIUL2_PGPDI7_PPDI13_WIDTH                (1U)
#define SIUL2_PGPDI7_PPDI13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI7_PPDI13_SHIFT)) & SIUL2_PGPDI7_PPDI13_MASK)

#define SIUL2_PGPDI7_PPDI14_MASK                 (0x4000U)
#define SIUL2_PGPDI7_PPDI14_SHIFT                (14U)
#define SIUL2_PGPDI7_PPDI14_WIDTH                (1U)
#define SIUL2_PGPDI7_PPDI14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI7_PPDI14_SHIFT)) & SIUL2_PGPDI7_PPDI14_MASK)

#define SIUL2_PGPDI7_PPDI15_MASK                 (0x8000U)
#define SIUL2_PGPDI7_PPDI15_SHIFT                (15U)
#define SIUL2_PGPDI7_PPDI15_WIDTH                (1U)
#define SIUL2_PGPDI7_PPDI15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI7_PPDI15_SHIFT)) & SIUL2_PGPDI7_PPDI15_MASK)
/*! @} */

/*! @name PGPDI6 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI6_PPDI0_MASK                  (0x1U)
#define SIUL2_PGPDI6_PPDI0_SHIFT                 (0U)
#define SIUL2_PGPDI6_PPDI0_WIDTH                 (1U)
#define SIUL2_PGPDI6_PPDI0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI0_SHIFT)) & SIUL2_PGPDI6_PPDI0_MASK)

#define SIUL2_PGPDI6_PPDI1_MASK                  (0x2U)
#define SIUL2_PGPDI6_PPDI1_SHIFT                 (1U)
#define SIUL2_PGPDI6_PPDI1_WIDTH                 (1U)
#define SIUL2_PGPDI6_PPDI1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI1_SHIFT)) & SIUL2_PGPDI6_PPDI1_MASK)

#define SIUL2_PGPDI6_PPDI2_MASK                  (0x4U)
#define SIUL2_PGPDI6_PPDI2_SHIFT                 (2U)
#define SIUL2_PGPDI6_PPDI2_WIDTH                 (1U)
#define SIUL2_PGPDI6_PPDI2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI2_SHIFT)) & SIUL2_PGPDI6_PPDI2_MASK)

#define SIUL2_PGPDI6_PPDI3_MASK                  (0x8U)
#define SIUL2_PGPDI6_PPDI3_SHIFT                 (3U)
#define SIUL2_PGPDI6_PPDI3_WIDTH                 (1U)
#define SIUL2_PGPDI6_PPDI3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI3_SHIFT)) & SIUL2_PGPDI6_PPDI3_MASK)

#define SIUL2_PGPDI6_PPDI4_MASK                  (0x10U)
#define SIUL2_PGPDI6_PPDI4_SHIFT                 (4U)
#define SIUL2_PGPDI6_PPDI4_WIDTH                 (1U)
#define SIUL2_PGPDI6_PPDI4(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI4_SHIFT)) & SIUL2_PGPDI6_PPDI4_MASK)

#define SIUL2_PGPDI6_PPDI5_MASK                  (0x20U)
#define SIUL2_PGPDI6_PPDI5_SHIFT                 (5U)
#define SIUL2_PGPDI6_PPDI5_WIDTH                 (1U)
#define SIUL2_PGPDI6_PPDI5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI5_SHIFT)) & SIUL2_PGPDI6_PPDI5_MASK)

#define SIUL2_PGPDI6_PPDI6_MASK                  (0x40U)
#define SIUL2_PGPDI6_PPDI6_SHIFT                 (6U)
#define SIUL2_PGPDI6_PPDI6_WIDTH                 (1U)
#define SIUL2_PGPDI6_PPDI6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI6_SHIFT)) & SIUL2_PGPDI6_PPDI6_MASK)

#define SIUL2_PGPDI6_PPDI7_MASK                  (0x80U)
#define SIUL2_PGPDI6_PPDI7_SHIFT                 (7U)
#define SIUL2_PGPDI6_PPDI7_WIDTH                 (1U)
#define SIUL2_PGPDI6_PPDI7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI7_SHIFT)) & SIUL2_PGPDI6_PPDI7_MASK)

#define SIUL2_PGPDI6_PPDI8_MASK                  (0x100U)
#define SIUL2_PGPDI6_PPDI8_SHIFT                 (8U)
#define SIUL2_PGPDI6_PPDI8_WIDTH                 (1U)
#define SIUL2_PGPDI6_PPDI8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI8_SHIFT)) & SIUL2_PGPDI6_PPDI8_MASK)

#define SIUL2_PGPDI6_PPDI9_MASK                  (0x200U)
#define SIUL2_PGPDI6_PPDI9_SHIFT                 (9U)
#define SIUL2_PGPDI6_PPDI9_WIDTH                 (1U)
#define SIUL2_PGPDI6_PPDI9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI9_SHIFT)) & SIUL2_PGPDI6_PPDI9_MASK)

#define SIUL2_PGPDI6_PPDI10_MASK                 (0x400U)
#define SIUL2_PGPDI6_PPDI10_SHIFT                (10U)
#define SIUL2_PGPDI6_PPDI10_WIDTH                (1U)
#define SIUL2_PGPDI6_PPDI10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI10_SHIFT)) & SIUL2_PGPDI6_PPDI10_MASK)

#define SIUL2_PGPDI6_PPDI11_MASK                 (0x800U)
#define SIUL2_PGPDI6_PPDI11_SHIFT                (11U)
#define SIUL2_PGPDI6_PPDI11_WIDTH                (1U)
#define SIUL2_PGPDI6_PPDI11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI11_SHIFT)) & SIUL2_PGPDI6_PPDI11_MASK)

#define SIUL2_PGPDI6_PPDI12_MASK                 (0x1000U)
#define SIUL2_PGPDI6_PPDI12_SHIFT                (12U)
#define SIUL2_PGPDI6_PPDI12_WIDTH                (1U)
#define SIUL2_PGPDI6_PPDI12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI12_SHIFT)) & SIUL2_PGPDI6_PPDI12_MASK)

#define SIUL2_PGPDI6_PPDI13_MASK                 (0x2000U)
#define SIUL2_PGPDI6_PPDI13_SHIFT                (13U)
#define SIUL2_PGPDI6_PPDI13_WIDTH                (1U)
#define SIUL2_PGPDI6_PPDI13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI13_SHIFT)) & SIUL2_PGPDI6_PPDI13_MASK)

#define SIUL2_PGPDI6_PPDI14_MASK                 (0x4000U)
#define SIUL2_PGPDI6_PPDI14_SHIFT                (14U)
#define SIUL2_PGPDI6_PPDI14_WIDTH                (1U)
#define SIUL2_PGPDI6_PPDI14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI14_SHIFT)) & SIUL2_PGPDI6_PPDI14_MASK)

#define SIUL2_PGPDI6_PPDI15_MASK                 (0x8000U)
#define SIUL2_PGPDI6_PPDI15_SHIFT                (15U)
#define SIUL2_PGPDI6_PPDI15_WIDTH                (1U)
#define SIUL2_PGPDI6_PPDI15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI6_PPDI15_SHIFT)) & SIUL2_PGPDI6_PPDI15_MASK)
/*! @} */

/*! @name PGPDI9 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI9_PPDI0_MASK                  (0x1U)
#define SIUL2_PGPDI9_PPDI0_SHIFT                 (0U)
#define SIUL2_PGPDI9_PPDI0_WIDTH                 (1U)
#define SIUL2_PGPDI9_PPDI0(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI9_PPDI0_SHIFT)) & SIUL2_PGPDI9_PPDI0_MASK)

#define SIUL2_PGPDI9_PPDI1_MASK                  (0x2U)
#define SIUL2_PGPDI9_PPDI1_SHIFT                 (1U)
#define SIUL2_PGPDI9_PPDI1_WIDTH                 (1U)
#define SIUL2_PGPDI9_PPDI1(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI9_PPDI1_SHIFT)) & SIUL2_PGPDI9_PPDI1_MASK)

#define SIUL2_PGPDI9_PPDI2_MASK                  (0x4U)
#define SIUL2_PGPDI9_PPDI2_SHIFT                 (2U)
#define SIUL2_PGPDI9_PPDI2_WIDTH                 (1U)
#define SIUL2_PGPDI9_PPDI2(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI9_PPDI2_SHIFT)) & SIUL2_PGPDI9_PPDI2_MASK)

#define SIUL2_PGPDI9_PPDI3_MASK                  (0x8U)
#define SIUL2_PGPDI9_PPDI3_SHIFT                 (3U)
#define SIUL2_PGPDI9_PPDI3_WIDTH                 (1U)
#define SIUL2_PGPDI9_PPDI3(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI9_PPDI3_SHIFT)) & SIUL2_PGPDI9_PPDI3_MASK)

#define SIUL2_PGPDI9_PPDI11_MASK                 (0x800U)
#define SIUL2_PGPDI9_PPDI11_SHIFT                (11U)
#define SIUL2_PGPDI9_PPDI11_WIDTH                (1U)
#define SIUL2_PGPDI9_PPDI11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI9_PPDI11_SHIFT)) & SIUL2_PGPDI9_PPDI11_MASK)
/*! @} */

/*! @name PGPDI8 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI8_PPDI5_MASK                  (0x20U)
#define SIUL2_PGPDI8_PPDI5_SHIFT                 (5U)
#define SIUL2_PGPDI8_PPDI5_WIDTH                 (1U)
#define SIUL2_PGPDI8_PPDI5(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI8_PPDI5_SHIFT)) & SIUL2_PGPDI8_PPDI5_MASK)

#define SIUL2_PGPDI8_PPDI6_MASK                  (0x40U)
#define SIUL2_PGPDI8_PPDI6_SHIFT                 (6U)
#define SIUL2_PGPDI8_PPDI6_WIDTH                 (1U)
#define SIUL2_PGPDI8_PPDI6(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI8_PPDI6_SHIFT)) & SIUL2_PGPDI8_PPDI6_MASK)

#define SIUL2_PGPDI8_PPDI7_MASK                  (0x80U)
#define SIUL2_PGPDI8_PPDI7_SHIFT                 (7U)
#define SIUL2_PGPDI8_PPDI7_WIDTH                 (1U)
#define SIUL2_PGPDI8_PPDI7(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI8_PPDI7_SHIFT)) & SIUL2_PGPDI8_PPDI7_MASK)

#define SIUL2_PGPDI8_PPDI8_MASK                  (0x100U)
#define SIUL2_PGPDI8_PPDI8_SHIFT                 (8U)
#define SIUL2_PGPDI8_PPDI8_WIDTH                 (1U)
#define SIUL2_PGPDI8_PPDI8(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI8_PPDI8_SHIFT)) & SIUL2_PGPDI8_PPDI8_MASK)

#define SIUL2_PGPDI8_PPDI9_MASK                  (0x200U)
#define SIUL2_PGPDI8_PPDI9_SHIFT                 (9U)
#define SIUL2_PGPDI8_PPDI9_WIDTH                 (1U)
#define SIUL2_PGPDI8_PPDI9(x)                    (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI8_PPDI9_SHIFT)) & SIUL2_PGPDI8_PPDI9_MASK)

#define SIUL2_PGPDI8_PPDI10_MASK                 (0x400U)
#define SIUL2_PGPDI8_PPDI10_SHIFT                (10U)
#define SIUL2_PGPDI8_PPDI10_WIDTH                (1U)
#define SIUL2_PGPDI8_PPDI10(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI8_PPDI10_SHIFT)) & SIUL2_PGPDI8_PPDI10_MASK)

#define SIUL2_PGPDI8_PPDI11_MASK                 (0x800U)
#define SIUL2_PGPDI8_PPDI11_SHIFT                (11U)
#define SIUL2_PGPDI8_PPDI11_WIDTH                (1U)
#define SIUL2_PGPDI8_PPDI11(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI8_PPDI11_SHIFT)) & SIUL2_PGPDI8_PPDI11_MASK)

#define SIUL2_PGPDI8_PPDI12_MASK                 (0x1000U)
#define SIUL2_PGPDI8_PPDI12_SHIFT                (12U)
#define SIUL2_PGPDI8_PPDI12_WIDTH                (1U)
#define SIUL2_PGPDI8_PPDI12(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI8_PPDI12_SHIFT)) & SIUL2_PGPDI8_PPDI12_MASK)

#define SIUL2_PGPDI8_PPDI13_MASK                 (0x2000U)
#define SIUL2_PGPDI8_PPDI13_SHIFT                (13U)
#define SIUL2_PGPDI8_PPDI13_WIDTH                (1U)
#define SIUL2_PGPDI8_PPDI13(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI8_PPDI13_SHIFT)) & SIUL2_PGPDI8_PPDI13_MASK)

#define SIUL2_PGPDI8_PPDI14_MASK                 (0x4000U)
#define SIUL2_PGPDI8_PPDI14_SHIFT                (14U)
#define SIUL2_PGPDI8_PPDI14_WIDTH                (1U)
#define SIUL2_PGPDI8_PPDI14(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI8_PPDI14_SHIFT)) & SIUL2_PGPDI8_PPDI14_MASK)

#define SIUL2_PGPDI8_PPDI15_MASK                 (0x8000U)
#define SIUL2_PGPDI8_PPDI15_SHIFT                (15U)
#define SIUL2_PGPDI8_PPDI15_WIDTH                (1U)
#define SIUL2_PGPDI8_PPDI15(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI8_PPDI15_SHIFT)) & SIUL2_PGPDI8_PPDI15_MASK)
/*! @} */

/*! @name PGPDI11 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI11_PPDI0_MASK                 (0x1U)
#define SIUL2_PGPDI11_PPDI0_SHIFT                (0U)
#define SIUL2_PGPDI11_PPDI0_WIDTH                (1U)
#define SIUL2_PGPDI11_PPDI0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI0_SHIFT)) & SIUL2_PGPDI11_PPDI0_MASK)

#define SIUL2_PGPDI11_PPDI1_MASK                 (0x2U)
#define SIUL2_PGPDI11_PPDI1_SHIFT                (1U)
#define SIUL2_PGPDI11_PPDI1_WIDTH                (1U)
#define SIUL2_PGPDI11_PPDI1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI1_SHIFT)) & SIUL2_PGPDI11_PPDI1_MASK)

#define SIUL2_PGPDI11_PPDI2_MASK                 (0x4U)
#define SIUL2_PGPDI11_PPDI2_SHIFT                (2U)
#define SIUL2_PGPDI11_PPDI2_WIDTH                (1U)
#define SIUL2_PGPDI11_PPDI2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI2_SHIFT)) & SIUL2_PGPDI11_PPDI2_MASK)

#define SIUL2_PGPDI11_PPDI3_MASK                 (0x8U)
#define SIUL2_PGPDI11_PPDI3_SHIFT                (3U)
#define SIUL2_PGPDI11_PPDI3_WIDTH                (1U)
#define SIUL2_PGPDI11_PPDI3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI3_SHIFT)) & SIUL2_PGPDI11_PPDI3_MASK)

#define SIUL2_PGPDI11_PPDI4_MASK                 (0x10U)
#define SIUL2_PGPDI11_PPDI4_SHIFT                (4U)
#define SIUL2_PGPDI11_PPDI4_WIDTH                (1U)
#define SIUL2_PGPDI11_PPDI4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI4_SHIFT)) & SIUL2_PGPDI11_PPDI4_MASK)

#define SIUL2_PGPDI11_PPDI5_MASK                 (0x20U)
#define SIUL2_PGPDI11_PPDI5_SHIFT                (5U)
#define SIUL2_PGPDI11_PPDI5_WIDTH                (1U)
#define SIUL2_PGPDI11_PPDI5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI5_SHIFT)) & SIUL2_PGPDI11_PPDI5_MASK)

#define SIUL2_PGPDI11_PPDI6_MASK                 (0x40U)
#define SIUL2_PGPDI11_PPDI6_SHIFT                (6U)
#define SIUL2_PGPDI11_PPDI6_WIDTH                (1U)
#define SIUL2_PGPDI11_PPDI6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI6_SHIFT)) & SIUL2_PGPDI11_PPDI6_MASK)

#define SIUL2_PGPDI11_PPDI7_MASK                 (0x80U)
#define SIUL2_PGPDI11_PPDI7_SHIFT                (7U)
#define SIUL2_PGPDI11_PPDI7_WIDTH                (1U)
#define SIUL2_PGPDI11_PPDI7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI7_SHIFT)) & SIUL2_PGPDI11_PPDI7_MASK)

#define SIUL2_PGPDI11_PPDI8_MASK                 (0x100U)
#define SIUL2_PGPDI11_PPDI8_SHIFT                (8U)
#define SIUL2_PGPDI11_PPDI8_WIDTH                (1U)
#define SIUL2_PGPDI11_PPDI8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI8_SHIFT)) & SIUL2_PGPDI11_PPDI8_MASK)

#define SIUL2_PGPDI11_PPDI9_MASK                 (0x200U)
#define SIUL2_PGPDI11_PPDI9_SHIFT                (9U)
#define SIUL2_PGPDI11_PPDI9_WIDTH                (1U)
#define SIUL2_PGPDI11_PPDI9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI9_SHIFT)) & SIUL2_PGPDI11_PPDI9_MASK)

#define SIUL2_PGPDI11_PPDI10_MASK                (0x400U)
#define SIUL2_PGPDI11_PPDI10_SHIFT               (10U)
#define SIUL2_PGPDI11_PPDI10_WIDTH               (1U)
#define SIUL2_PGPDI11_PPDI10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI10_SHIFT)) & SIUL2_PGPDI11_PPDI10_MASK)

#define SIUL2_PGPDI11_PPDI11_MASK                (0x800U)
#define SIUL2_PGPDI11_PPDI11_SHIFT               (11U)
#define SIUL2_PGPDI11_PPDI11_WIDTH               (1U)
#define SIUL2_PGPDI11_PPDI11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI11_SHIFT)) & SIUL2_PGPDI11_PPDI11_MASK)

#define SIUL2_PGPDI11_PPDI12_MASK                (0x1000U)
#define SIUL2_PGPDI11_PPDI12_SHIFT               (12U)
#define SIUL2_PGPDI11_PPDI12_WIDTH               (1U)
#define SIUL2_PGPDI11_PPDI12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI12_SHIFT)) & SIUL2_PGPDI11_PPDI12_MASK)

#define SIUL2_PGPDI11_PPDI13_MASK                (0x2000U)
#define SIUL2_PGPDI11_PPDI13_SHIFT               (13U)
#define SIUL2_PGPDI11_PPDI13_WIDTH               (1U)
#define SIUL2_PGPDI11_PPDI13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI13_SHIFT)) & SIUL2_PGPDI11_PPDI13_MASK)

#define SIUL2_PGPDI11_PPDI14_MASK                (0x4000U)
#define SIUL2_PGPDI11_PPDI14_SHIFT               (14U)
#define SIUL2_PGPDI11_PPDI14_WIDTH               (1U)
#define SIUL2_PGPDI11_PPDI14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI14_SHIFT)) & SIUL2_PGPDI11_PPDI14_MASK)

#define SIUL2_PGPDI11_PPDI15_MASK                (0x8000U)
#define SIUL2_PGPDI11_PPDI15_SHIFT               (15U)
#define SIUL2_PGPDI11_PPDI15_WIDTH               (1U)
#define SIUL2_PGPDI11_PPDI15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI11_PPDI15_SHIFT)) & SIUL2_PGPDI11_PPDI15_MASK)
/*! @} */

/*! @name PGPDI10 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI10_PPDI0_MASK                 (0x1U)
#define SIUL2_PGPDI10_PPDI0_SHIFT                (0U)
#define SIUL2_PGPDI10_PPDI0_WIDTH                (1U)
#define SIUL2_PGPDI10_PPDI0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI0_SHIFT)) & SIUL2_PGPDI10_PPDI0_MASK)

#define SIUL2_PGPDI10_PPDI1_MASK                 (0x2U)
#define SIUL2_PGPDI10_PPDI1_SHIFT                (1U)
#define SIUL2_PGPDI10_PPDI1_WIDTH                (1U)
#define SIUL2_PGPDI10_PPDI1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI1_SHIFT)) & SIUL2_PGPDI10_PPDI1_MASK)

#define SIUL2_PGPDI10_PPDI2_MASK                 (0x4U)
#define SIUL2_PGPDI10_PPDI2_SHIFT                (2U)
#define SIUL2_PGPDI10_PPDI2_WIDTH                (1U)
#define SIUL2_PGPDI10_PPDI2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI2_SHIFT)) & SIUL2_PGPDI10_PPDI2_MASK)

#define SIUL2_PGPDI10_PPDI3_MASK                 (0x8U)
#define SIUL2_PGPDI10_PPDI3_SHIFT                (3U)
#define SIUL2_PGPDI10_PPDI3_WIDTH                (1U)
#define SIUL2_PGPDI10_PPDI3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI3_SHIFT)) & SIUL2_PGPDI10_PPDI3_MASK)

#define SIUL2_PGPDI10_PPDI4_MASK                 (0x10U)
#define SIUL2_PGPDI10_PPDI4_SHIFT                (4U)
#define SIUL2_PGPDI10_PPDI4_WIDTH                (1U)
#define SIUL2_PGPDI10_PPDI4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI4_SHIFT)) & SIUL2_PGPDI10_PPDI4_MASK)

#define SIUL2_PGPDI10_PPDI5_MASK                 (0x20U)
#define SIUL2_PGPDI10_PPDI5_SHIFT                (5U)
#define SIUL2_PGPDI10_PPDI5_WIDTH                (1U)
#define SIUL2_PGPDI10_PPDI5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI5_SHIFT)) & SIUL2_PGPDI10_PPDI5_MASK)

#define SIUL2_PGPDI10_PPDI6_MASK                 (0x40U)
#define SIUL2_PGPDI10_PPDI6_SHIFT                (6U)
#define SIUL2_PGPDI10_PPDI6_WIDTH                (1U)
#define SIUL2_PGPDI10_PPDI6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI6_SHIFT)) & SIUL2_PGPDI10_PPDI6_MASK)

#define SIUL2_PGPDI10_PPDI7_MASK                 (0x80U)
#define SIUL2_PGPDI10_PPDI7_SHIFT                (7U)
#define SIUL2_PGPDI10_PPDI7_WIDTH                (1U)
#define SIUL2_PGPDI10_PPDI7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI7_SHIFT)) & SIUL2_PGPDI10_PPDI7_MASK)

#define SIUL2_PGPDI10_PPDI8_MASK                 (0x100U)
#define SIUL2_PGPDI10_PPDI8_SHIFT                (8U)
#define SIUL2_PGPDI10_PPDI8_WIDTH                (1U)
#define SIUL2_PGPDI10_PPDI8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI8_SHIFT)) & SIUL2_PGPDI10_PPDI8_MASK)

#define SIUL2_PGPDI10_PPDI9_MASK                 (0x200U)
#define SIUL2_PGPDI10_PPDI9_SHIFT                (9U)
#define SIUL2_PGPDI10_PPDI9_WIDTH                (1U)
#define SIUL2_PGPDI10_PPDI9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI9_SHIFT)) & SIUL2_PGPDI10_PPDI9_MASK)

#define SIUL2_PGPDI10_PPDI10_MASK                (0x400U)
#define SIUL2_PGPDI10_PPDI10_SHIFT               (10U)
#define SIUL2_PGPDI10_PPDI10_WIDTH               (1U)
#define SIUL2_PGPDI10_PPDI10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI10_SHIFT)) & SIUL2_PGPDI10_PPDI10_MASK)

#define SIUL2_PGPDI10_PPDI11_MASK                (0x800U)
#define SIUL2_PGPDI10_PPDI11_SHIFT               (11U)
#define SIUL2_PGPDI10_PPDI11_WIDTH               (1U)
#define SIUL2_PGPDI10_PPDI11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI11_SHIFT)) & SIUL2_PGPDI10_PPDI11_MASK)

#define SIUL2_PGPDI10_PPDI12_MASK                (0x1000U)
#define SIUL2_PGPDI10_PPDI12_SHIFT               (12U)
#define SIUL2_PGPDI10_PPDI12_WIDTH               (1U)
#define SIUL2_PGPDI10_PPDI12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI12_SHIFT)) & SIUL2_PGPDI10_PPDI12_MASK)

#define SIUL2_PGPDI10_PPDI13_MASK                (0x2000U)
#define SIUL2_PGPDI10_PPDI13_SHIFT               (13U)
#define SIUL2_PGPDI10_PPDI13_WIDTH               (1U)
#define SIUL2_PGPDI10_PPDI13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI13_SHIFT)) & SIUL2_PGPDI10_PPDI13_MASK)

#define SIUL2_PGPDI10_PPDI14_MASK                (0x4000U)
#define SIUL2_PGPDI10_PPDI14_SHIFT               (14U)
#define SIUL2_PGPDI10_PPDI14_WIDTH               (1U)
#define SIUL2_PGPDI10_PPDI14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI14_SHIFT)) & SIUL2_PGPDI10_PPDI14_MASK)

#define SIUL2_PGPDI10_PPDI15_MASK                (0x8000U)
#define SIUL2_PGPDI10_PPDI15_SHIFT               (15U)
#define SIUL2_PGPDI10_PPDI15_WIDTH               (1U)
#define SIUL2_PGPDI10_PPDI15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI10_PPDI15_SHIFT)) & SIUL2_PGPDI10_PPDI15_MASK)
/*! @} */

/*! @name PGPDI13 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI13_PPDI0_MASK                 (0x1U)
#define SIUL2_PGPDI13_PPDI0_SHIFT                (0U)
#define SIUL2_PGPDI13_PPDI0_WIDTH                (1U)
#define SIUL2_PGPDI13_PPDI0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI0_SHIFT)) & SIUL2_PGPDI13_PPDI0_MASK)

#define SIUL2_PGPDI13_PPDI1_MASK                 (0x2U)
#define SIUL2_PGPDI13_PPDI1_SHIFT                (1U)
#define SIUL2_PGPDI13_PPDI1_WIDTH                (1U)
#define SIUL2_PGPDI13_PPDI1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI1_SHIFT)) & SIUL2_PGPDI13_PPDI1_MASK)

#define SIUL2_PGPDI13_PPDI2_MASK                 (0x4U)
#define SIUL2_PGPDI13_PPDI2_SHIFT                (2U)
#define SIUL2_PGPDI13_PPDI2_WIDTH                (1U)
#define SIUL2_PGPDI13_PPDI2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI2_SHIFT)) & SIUL2_PGPDI13_PPDI2_MASK)

#define SIUL2_PGPDI13_PPDI3_MASK                 (0x8U)
#define SIUL2_PGPDI13_PPDI3_SHIFT                (3U)
#define SIUL2_PGPDI13_PPDI3_WIDTH                (1U)
#define SIUL2_PGPDI13_PPDI3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI3_SHIFT)) & SIUL2_PGPDI13_PPDI3_MASK)

#define SIUL2_PGPDI13_PPDI4_MASK                 (0x10U)
#define SIUL2_PGPDI13_PPDI4_SHIFT                (4U)
#define SIUL2_PGPDI13_PPDI4_WIDTH                (1U)
#define SIUL2_PGPDI13_PPDI4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI4_SHIFT)) & SIUL2_PGPDI13_PPDI4_MASK)

#define SIUL2_PGPDI13_PPDI5_MASK                 (0x20U)
#define SIUL2_PGPDI13_PPDI5_SHIFT                (5U)
#define SIUL2_PGPDI13_PPDI5_WIDTH                (1U)
#define SIUL2_PGPDI13_PPDI5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI5_SHIFT)) & SIUL2_PGPDI13_PPDI5_MASK)

#define SIUL2_PGPDI13_PPDI6_MASK                 (0x40U)
#define SIUL2_PGPDI13_PPDI6_SHIFT                (6U)
#define SIUL2_PGPDI13_PPDI6_WIDTH                (1U)
#define SIUL2_PGPDI13_PPDI6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI6_SHIFT)) & SIUL2_PGPDI13_PPDI6_MASK)

#define SIUL2_PGPDI13_PPDI7_MASK                 (0x80U)
#define SIUL2_PGPDI13_PPDI7_SHIFT                (7U)
#define SIUL2_PGPDI13_PPDI7_WIDTH                (1U)
#define SIUL2_PGPDI13_PPDI7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI7_SHIFT)) & SIUL2_PGPDI13_PPDI7_MASK)

#define SIUL2_PGPDI13_PPDI8_MASK                 (0x100U)
#define SIUL2_PGPDI13_PPDI8_SHIFT                (8U)
#define SIUL2_PGPDI13_PPDI8_WIDTH                (1U)
#define SIUL2_PGPDI13_PPDI8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI8_SHIFT)) & SIUL2_PGPDI13_PPDI8_MASK)

#define SIUL2_PGPDI13_PPDI9_MASK                 (0x200U)
#define SIUL2_PGPDI13_PPDI9_SHIFT                (9U)
#define SIUL2_PGPDI13_PPDI9_WIDTH                (1U)
#define SIUL2_PGPDI13_PPDI9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI9_SHIFT)) & SIUL2_PGPDI13_PPDI9_MASK)

#define SIUL2_PGPDI13_PPDI10_MASK                (0x400U)
#define SIUL2_PGPDI13_PPDI10_SHIFT               (10U)
#define SIUL2_PGPDI13_PPDI10_WIDTH               (1U)
#define SIUL2_PGPDI13_PPDI10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI10_SHIFT)) & SIUL2_PGPDI13_PPDI10_MASK)

#define SIUL2_PGPDI13_PPDI11_MASK                (0x800U)
#define SIUL2_PGPDI13_PPDI11_SHIFT               (11U)
#define SIUL2_PGPDI13_PPDI11_WIDTH               (1U)
#define SIUL2_PGPDI13_PPDI11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI11_SHIFT)) & SIUL2_PGPDI13_PPDI11_MASK)

#define SIUL2_PGPDI13_PPDI12_MASK                (0x1000U)
#define SIUL2_PGPDI13_PPDI12_SHIFT               (12U)
#define SIUL2_PGPDI13_PPDI12_WIDTH               (1U)
#define SIUL2_PGPDI13_PPDI12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI12_SHIFT)) & SIUL2_PGPDI13_PPDI12_MASK)

#define SIUL2_PGPDI13_PPDI13_MASK                (0x2000U)
#define SIUL2_PGPDI13_PPDI13_SHIFT               (13U)
#define SIUL2_PGPDI13_PPDI13_WIDTH               (1U)
#define SIUL2_PGPDI13_PPDI13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI13_SHIFT)) & SIUL2_PGPDI13_PPDI13_MASK)

#define SIUL2_PGPDI13_PPDI14_MASK                (0x4000U)
#define SIUL2_PGPDI13_PPDI14_SHIFT               (14U)
#define SIUL2_PGPDI13_PPDI14_WIDTH               (1U)
#define SIUL2_PGPDI13_PPDI14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI14_SHIFT)) & SIUL2_PGPDI13_PPDI14_MASK)

#define SIUL2_PGPDI13_PPDI15_MASK                (0x8000U)
#define SIUL2_PGPDI13_PPDI15_SHIFT               (15U)
#define SIUL2_PGPDI13_PPDI15_WIDTH               (1U)
#define SIUL2_PGPDI13_PPDI15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI13_PPDI15_SHIFT)) & SIUL2_PGPDI13_PPDI15_MASK)
/*! @} */

/*! @name PGPDI12 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI12_PPDI0_MASK                 (0x1U)
#define SIUL2_PGPDI12_PPDI0_SHIFT                (0U)
#define SIUL2_PGPDI12_PPDI0_WIDTH                (1U)
#define SIUL2_PGPDI12_PPDI0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI0_SHIFT)) & SIUL2_PGPDI12_PPDI0_MASK)

#define SIUL2_PGPDI12_PPDI1_MASK                 (0x2U)
#define SIUL2_PGPDI12_PPDI1_SHIFT                (1U)
#define SIUL2_PGPDI12_PPDI1_WIDTH                (1U)
#define SIUL2_PGPDI12_PPDI1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI1_SHIFT)) & SIUL2_PGPDI12_PPDI1_MASK)

#define SIUL2_PGPDI12_PPDI2_MASK                 (0x4U)
#define SIUL2_PGPDI12_PPDI2_SHIFT                (2U)
#define SIUL2_PGPDI12_PPDI2_WIDTH                (1U)
#define SIUL2_PGPDI12_PPDI2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI2_SHIFT)) & SIUL2_PGPDI12_PPDI2_MASK)

#define SIUL2_PGPDI12_PPDI3_MASK                 (0x8U)
#define SIUL2_PGPDI12_PPDI3_SHIFT                (3U)
#define SIUL2_PGPDI12_PPDI3_WIDTH                (1U)
#define SIUL2_PGPDI12_PPDI3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI3_SHIFT)) & SIUL2_PGPDI12_PPDI3_MASK)

#define SIUL2_PGPDI12_PPDI4_MASK                 (0x10U)
#define SIUL2_PGPDI12_PPDI4_SHIFT                (4U)
#define SIUL2_PGPDI12_PPDI4_WIDTH                (1U)
#define SIUL2_PGPDI12_PPDI4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI4_SHIFT)) & SIUL2_PGPDI12_PPDI4_MASK)

#define SIUL2_PGPDI12_PPDI5_MASK                 (0x20U)
#define SIUL2_PGPDI12_PPDI5_SHIFT                (5U)
#define SIUL2_PGPDI12_PPDI5_WIDTH                (1U)
#define SIUL2_PGPDI12_PPDI5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI5_SHIFT)) & SIUL2_PGPDI12_PPDI5_MASK)

#define SIUL2_PGPDI12_PPDI6_MASK                 (0x40U)
#define SIUL2_PGPDI12_PPDI6_SHIFT                (6U)
#define SIUL2_PGPDI12_PPDI6_WIDTH                (1U)
#define SIUL2_PGPDI12_PPDI6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI6_SHIFT)) & SIUL2_PGPDI12_PPDI6_MASK)

#define SIUL2_PGPDI12_PPDI7_MASK                 (0x80U)
#define SIUL2_PGPDI12_PPDI7_SHIFT                (7U)
#define SIUL2_PGPDI12_PPDI7_WIDTH                (1U)
#define SIUL2_PGPDI12_PPDI7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI7_SHIFT)) & SIUL2_PGPDI12_PPDI7_MASK)

#define SIUL2_PGPDI12_PPDI8_MASK                 (0x100U)
#define SIUL2_PGPDI12_PPDI8_SHIFT                (8U)
#define SIUL2_PGPDI12_PPDI8_WIDTH                (1U)
#define SIUL2_PGPDI12_PPDI8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI8_SHIFT)) & SIUL2_PGPDI12_PPDI8_MASK)

#define SIUL2_PGPDI12_PPDI9_MASK                 (0x200U)
#define SIUL2_PGPDI12_PPDI9_SHIFT                (9U)
#define SIUL2_PGPDI12_PPDI9_WIDTH                (1U)
#define SIUL2_PGPDI12_PPDI9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI9_SHIFT)) & SIUL2_PGPDI12_PPDI9_MASK)

#define SIUL2_PGPDI12_PPDI10_MASK                (0x400U)
#define SIUL2_PGPDI12_PPDI10_SHIFT               (10U)
#define SIUL2_PGPDI12_PPDI10_WIDTH               (1U)
#define SIUL2_PGPDI12_PPDI10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI10_SHIFT)) & SIUL2_PGPDI12_PPDI10_MASK)

#define SIUL2_PGPDI12_PPDI11_MASK                (0x800U)
#define SIUL2_PGPDI12_PPDI11_SHIFT               (11U)
#define SIUL2_PGPDI12_PPDI11_WIDTH               (1U)
#define SIUL2_PGPDI12_PPDI11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI11_SHIFT)) & SIUL2_PGPDI12_PPDI11_MASK)

#define SIUL2_PGPDI12_PPDI12_MASK                (0x1000U)
#define SIUL2_PGPDI12_PPDI12_SHIFT               (12U)
#define SIUL2_PGPDI12_PPDI12_WIDTH               (1U)
#define SIUL2_PGPDI12_PPDI12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI12_SHIFT)) & SIUL2_PGPDI12_PPDI12_MASK)

#define SIUL2_PGPDI12_PPDI13_MASK                (0x2000U)
#define SIUL2_PGPDI12_PPDI13_SHIFT               (13U)
#define SIUL2_PGPDI12_PPDI13_WIDTH               (1U)
#define SIUL2_PGPDI12_PPDI13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI13_SHIFT)) & SIUL2_PGPDI12_PPDI13_MASK)

#define SIUL2_PGPDI12_PPDI14_MASK                (0x4000U)
#define SIUL2_PGPDI12_PPDI14_SHIFT               (14U)
#define SIUL2_PGPDI12_PPDI14_WIDTH               (1U)
#define SIUL2_PGPDI12_PPDI14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI14_SHIFT)) & SIUL2_PGPDI12_PPDI14_MASK)

#define SIUL2_PGPDI12_PPDI15_MASK                (0x8000U)
#define SIUL2_PGPDI12_PPDI15_SHIFT               (15U)
#define SIUL2_PGPDI12_PPDI15_WIDTH               (1U)
#define SIUL2_PGPDI12_PPDI15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI12_PPDI15_SHIFT)) & SIUL2_PGPDI12_PPDI15_MASK)
/*! @} */

/*! @name PGPDI15 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI15_PPDI0_MASK                 (0x1U)
#define SIUL2_PGPDI15_PPDI0_SHIFT                (0U)
#define SIUL2_PGPDI15_PPDI0_WIDTH                (1U)
#define SIUL2_PGPDI15_PPDI0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI0_SHIFT)) & SIUL2_PGPDI15_PPDI0_MASK)

#define SIUL2_PGPDI15_PPDI1_MASK                 (0x2U)
#define SIUL2_PGPDI15_PPDI1_SHIFT                (1U)
#define SIUL2_PGPDI15_PPDI1_WIDTH                (1U)
#define SIUL2_PGPDI15_PPDI1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI1_SHIFT)) & SIUL2_PGPDI15_PPDI1_MASK)

#define SIUL2_PGPDI15_PPDI2_MASK                 (0x4U)
#define SIUL2_PGPDI15_PPDI2_SHIFT                (2U)
#define SIUL2_PGPDI15_PPDI2_WIDTH                (1U)
#define SIUL2_PGPDI15_PPDI2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI2_SHIFT)) & SIUL2_PGPDI15_PPDI2_MASK)

#define SIUL2_PGPDI15_PPDI3_MASK                 (0x8U)
#define SIUL2_PGPDI15_PPDI3_SHIFT                (3U)
#define SIUL2_PGPDI15_PPDI3_WIDTH                (1U)
#define SIUL2_PGPDI15_PPDI3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI3_SHIFT)) & SIUL2_PGPDI15_PPDI3_MASK)

#define SIUL2_PGPDI15_PPDI4_MASK                 (0x10U)
#define SIUL2_PGPDI15_PPDI4_SHIFT                (4U)
#define SIUL2_PGPDI15_PPDI4_WIDTH                (1U)
#define SIUL2_PGPDI15_PPDI4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI4_SHIFT)) & SIUL2_PGPDI15_PPDI4_MASK)

#define SIUL2_PGPDI15_PPDI5_MASK                 (0x20U)
#define SIUL2_PGPDI15_PPDI5_SHIFT                (5U)
#define SIUL2_PGPDI15_PPDI5_WIDTH                (1U)
#define SIUL2_PGPDI15_PPDI5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI5_SHIFT)) & SIUL2_PGPDI15_PPDI5_MASK)

#define SIUL2_PGPDI15_PPDI6_MASK                 (0x40U)
#define SIUL2_PGPDI15_PPDI6_SHIFT                (6U)
#define SIUL2_PGPDI15_PPDI6_WIDTH                (1U)
#define SIUL2_PGPDI15_PPDI6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI6_SHIFT)) & SIUL2_PGPDI15_PPDI6_MASK)

#define SIUL2_PGPDI15_PPDI7_MASK                 (0x80U)
#define SIUL2_PGPDI15_PPDI7_SHIFT                (7U)
#define SIUL2_PGPDI15_PPDI7_WIDTH                (1U)
#define SIUL2_PGPDI15_PPDI7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI7_SHIFT)) & SIUL2_PGPDI15_PPDI7_MASK)

#define SIUL2_PGPDI15_PPDI8_MASK                 (0x100U)
#define SIUL2_PGPDI15_PPDI8_SHIFT                (8U)
#define SIUL2_PGPDI15_PPDI8_WIDTH                (1U)
#define SIUL2_PGPDI15_PPDI8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI8_SHIFT)) & SIUL2_PGPDI15_PPDI8_MASK)

#define SIUL2_PGPDI15_PPDI9_MASK                 (0x200U)
#define SIUL2_PGPDI15_PPDI9_SHIFT                (9U)
#define SIUL2_PGPDI15_PPDI9_WIDTH                (1U)
#define SIUL2_PGPDI15_PPDI9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI9_SHIFT)) & SIUL2_PGPDI15_PPDI9_MASK)

#define SIUL2_PGPDI15_PPDI10_MASK                (0x400U)
#define SIUL2_PGPDI15_PPDI10_SHIFT               (10U)
#define SIUL2_PGPDI15_PPDI10_WIDTH               (1U)
#define SIUL2_PGPDI15_PPDI10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI10_SHIFT)) & SIUL2_PGPDI15_PPDI10_MASK)

#define SIUL2_PGPDI15_PPDI11_MASK                (0x800U)
#define SIUL2_PGPDI15_PPDI11_SHIFT               (11U)
#define SIUL2_PGPDI15_PPDI11_WIDTH               (1U)
#define SIUL2_PGPDI15_PPDI11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI11_SHIFT)) & SIUL2_PGPDI15_PPDI11_MASK)

#define SIUL2_PGPDI15_PPDI12_MASK                (0x1000U)
#define SIUL2_PGPDI15_PPDI12_SHIFT               (12U)
#define SIUL2_PGPDI15_PPDI12_WIDTH               (1U)
#define SIUL2_PGPDI15_PPDI12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI12_SHIFT)) & SIUL2_PGPDI15_PPDI12_MASK)

#define SIUL2_PGPDI15_PPDI13_MASK                (0x2000U)
#define SIUL2_PGPDI15_PPDI13_SHIFT               (13U)
#define SIUL2_PGPDI15_PPDI13_WIDTH               (1U)
#define SIUL2_PGPDI15_PPDI13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI13_SHIFT)) & SIUL2_PGPDI15_PPDI13_MASK)

#define SIUL2_PGPDI15_PPDI14_MASK                (0x4000U)
#define SIUL2_PGPDI15_PPDI14_SHIFT               (14U)
#define SIUL2_PGPDI15_PPDI14_WIDTH               (1U)
#define SIUL2_PGPDI15_PPDI14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI14_SHIFT)) & SIUL2_PGPDI15_PPDI14_MASK)

#define SIUL2_PGPDI15_PPDI15_MASK                (0x8000U)
#define SIUL2_PGPDI15_PPDI15_SHIFT               (15U)
#define SIUL2_PGPDI15_PPDI15_WIDTH               (1U)
#define SIUL2_PGPDI15_PPDI15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI15_PPDI15_SHIFT)) & SIUL2_PGPDI15_PPDI15_MASK)
/*! @} */

/*! @name PGPDI14 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI14_PPDI0_MASK                 (0x1U)
#define SIUL2_PGPDI14_PPDI0_SHIFT                (0U)
#define SIUL2_PGPDI14_PPDI0_WIDTH                (1U)
#define SIUL2_PGPDI14_PPDI0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI0_SHIFT)) & SIUL2_PGPDI14_PPDI0_MASK)

#define SIUL2_PGPDI14_PPDI1_MASK                 (0x2U)
#define SIUL2_PGPDI14_PPDI1_SHIFT                (1U)
#define SIUL2_PGPDI14_PPDI1_WIDTH                (1U)
#define SIUL2_PGPDI14_PPDI1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI1_SHIFT)) & SIUL2_PGPDI14_PPDI1_MASK)

#define SIUL2_PGPDI14_PPDI2_MASK                 (0x4U)
#define SIUL2_PGPDI14_PPDI2_SHIFT                (2U)
#define SIUL2_PGPDI14_PPDI2_WIDTH                (1U)
#define SIUL2_PGPDI14_PPDI2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI2_SHIFT)) & SIUL2_PGPDI14_PPDI2_MASK)

#define SIUL2_PGPDI14_PPDI3_MASK                 (0x8U)
#define SIUL2_PGPDI14_PPDI3_SHIFT                (3U)
#define SIUL2_PGPDI14_PPDI3_WIDTH                (1U)
#define SIUL2_PGPDI14_PPDI3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI3_SHIFT)) & SIUL2_PGPDI14_PPDI3_MASK)

#define SIUL2_PGPDI14_PPDI4_MASK                 (0x10U)
#define SIUL2_PGPDI14_PPDI4_SHIFT                (4U)
#define SIUL2_PGPDI14_PPDI4_WIDTH                (1U)
#define SIUL2_PGPDI14_PPDI4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI4_SHIFT)) & SIUL2_PGPDI14_PPDI4_MASK)

#define SIUL2_PGPDI14_PPDI5_MASK                 (0x20U)
#define SIUL2_PGPDI14_PPDI5_SHIFT                (5U)
#define SIUL2_PGPDI14_PPDI5_WIDTH                (1U)
#define SIUL2_PGPDI14_PPDI5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI5_SHIFT)) & SIUL2_PGPDI14_PPDI5_MASK)

#define SIUL2_PGPDI14_PPDI6_MASK                 (0x40U)
#define SIUL2_PGPDI14_PPDI6_SHIFT                (6U)
#define SIUL2_PGPDI14_PPDI6_WIDTH                (1U)
#define SIUL2_PGPDI14_PPDI6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI6_SHIFT)) & SIUL2_PGPDI14_PPDI6_MASK)

#define SIUL2_PGPDI14_PPDI7_MASK                 (0x80U)
#define SIUL2_PGPDI14_PPDI7_SHIFT                (7U)
#define SIUL2_PGPDI14_PPDI7_WIDTH                (1U)
#define SIUL2_PGPDI14_PPDI7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI7_SHIFT)) & SIUL2_PGPDI14_PPDI7_MASK)

#define SIUL2_PGPDI14_PPDI8_MASK                 (0x100U)
#define SIUL2_PGPDI14_PPDI8_SHIFT                (8U)
#define SIUL2_PGPDI14_PPDI8_WIDTH                (1U)
#define SIUL2_PGPDI14_PPDI8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI8_SHIFT)) & SIUL2_PGPDI14_PPDI8_MASK)

#define SIUL2_PGPDI14_PPDI10_MASK                (0x400U)
#define SIUL2_PGPDI14_PPDI10_SHIFT               (10U)
#define SIUL2_PGPDI14_PPDI10_WIDTH               (1U)
#define SIUL2_PGPDI14_PPDI10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI10_SHIFT)) & SIUL2_PGPDI14_PPDI10_MASK)

#define SIUL2_PGPDI14_PPDI11_MASK                (0x800U)
#define SIUL2_PGPDI14_PPDI11_SHIFT               (11U)
#define SIUL2_PGPDI14_PPDI11_WIDTH               (1U)
#define SIUL2_PGPDI14_PPDI11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI11_SHIFT)) & SIUL2_PGPDI14_PPDI11_MASK)

#define SIUL2_PGPDI14_PPDI12_MASK                (0x1000U)
#define SIUL2_PGPDI14_PPDI12_SHIFT               (12U)
#define SIUL2_PGPDI14_PPDI12_WIDTH               (1U)
#define SIUL2_PGPDI14_PPDI12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI12_SHIFT)) & SIUL2_PGPDI14_PPDI12_MASK)

#define SIUL2_PGPDI14_PPDI13_MASK                (0x2000U)
#define SIUL2_PGPDI14_PPDI13_SHIFT               (13U)
#define SIUL2_PGPDI14_PPDI13_WIDTH               (1U)
#define SIUL2_PGPDI14_PPDI13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI13_SHIFT)) & SIUL2_PGPDI14_PPDI13_MASK)

#define SIUL2_PGPDI14_PPDI14_MASK                (0x4000U)
#define SIUL2_PGPDI14_PPDI14_SHIFT               (14U)
#define SIUL2_PGPDI14_PPDI14_WIDTH               (1U)
#define SIUL2_PGPDI14_PPDI14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI14_SHIFT)) & SIUL2_PGPDI14_PPDI14_MASK)

#define SIUL2_PGPDI14_PPDI15_MASK                (0x8000U)
#define SIUL2_PGPDI14_PPDI15_SHIFT               (15U)
#define SIUL2_PGPDI14_PPDI15_WIDTH               (1U)
#define SIUL2_PGPDI14_PPDI15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI14_PPDI15_SHIFT)) & SIUL2_PGPDI14_PPDI15_MASK)
/*! @} */

/*! @name PGPDI16 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI16_PPDI7_MASK                 (0x80U)
#define SIUL2_PGPDI16_PPDI7_SHIFT                (7U)
#define SIUL2_PGPDI16_PPDI7_WIDTH                (1U)
#define SIUL2_PGPDI16_PPDI7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI16_PPDI7_SHIFT)) & SIUL2_PGPDI16_PPDI7_MASK)

#define SIUL2_PGPDI16_PPDI8_MASK                 (0x100U)
#define SIUL2_PGPDI16_PPDI8_SHIFT                (8U)
#define SIUL2_PGPDI16_PPDI8_WIDTH                (1U)
#define SIUL2_PGPDI16_PPDI8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI16_PPDI8_SHIFT)) & SIUL2_PGPDI16_PPDI8_MASK)

#define SIUL2_PGPDI16_PPDI9_MASK                 (0x200U)
#define SIUL2_PGPDI16_PPDI9_SHIFT                (9U)
#define SIUL2_PGPDI16_PPDI9_WIDTH                (1U)
#define SIUL2_PGPDI16_PPDI9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI16_PPDI9_SHIFT)) & SIUL2_PGPDI16_PPDI9_MASK)

#define SIUL2_PGPDI16_PPDI10_MASK                (0x400U)
#define SIUL2_PGPDI16_PPDI10_SHIFT               (10U)
#define SIUL2_PGPDI16_PPDI10_WIDTH               (1U)
#define SIUL2_PGPDI16_PPDI10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI16_PPDI10_SHIFT)) & SIUL2_PGPDI16_PPDI10_MASK)

#define SIUL2_PGPDI16_PPDI11_MASK                (0x800U)
#define SIUL2_PGPDI16_PPDI11_SHIFT               (11U)
#define SIUL2_PGPDI16_PPDI11_WIDTH               (1U)
#define SIUL2_PGPDI16_PPDI11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI16_PPDI11_SHIFT)) & SIUL2_PGPDI16_PPDI11_MASK)

#define SIUL2_PGPDI16_PPDI12_MASK                (0x1000U)
#define SIUL2_PGPDI16_PPDI12_SHIFT               (12U)
#define SIUL2_PGPDI16_PPDI12_WIDTH               (1U)
#define SIUL2_PGPDI16_PPDI12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI16_PPDI12_SHIFT)) & SIUL2_PGPDI16_PPDI12_MASK)

#define SIUL2_PGPDI16_PPDI13_MASK                (0x2000U)
#define SIUL2_PGPDI16_PPDI13_SHIFT               (13U)
#define SIUL2_PGPDI16_PPDI13_WIDTH               (1U)
#define SIUL2_PGPDI16_PPDI13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI16_PPDI13_SHIFT)) & SIUL2_PGPDI16_PPDI13_MASK)

#define SIUL2_PGPDI16_PPDI14_MASK                (0x4000U)
#define SIUL2_PGPDI16_PPDI14_SHIFT               (14U)
#define SIUL2_PGPDI16_PPDI14_WIDTH               (1U)
#define SIUL2_PGPDI16_PPDI14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI16_PPDI14_SHIFT)) & SIUL2_PGPDI16_PPDI14_MASK)

#define SIUL2_PGPDI16_PPDI15_MASK                (0x8000U)
#define SIUL2_PGPDI16_PPDI15_SHIFT               (15U)
#define SIUL2_PGPDI16_PPDI15_WIDTH               (1U)
#define SIUL2_PGPDI16_PPDI15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI16_PPDI15_SHIFT)) & SIUL2_PGPDI16_PPDI15_MASK)
/*! @} */

/*! @name PGPDI19 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI19_PPDI0_MASK                 (0x1U)
#define SIUL2_PGPDI19_PPDI0_SHIFT                (0U)
#define SIUL2_PGPDI19_PPDI0_WIDTH                (1U)
#define SIUL2_PGPDI19_PPDI0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI0_SHIFT)) & SIUL2_PGPDI19_PPDI0_MASK)

#define SIUL2_PGPDI19_PPDI1_MASK                 (0x2U)
#define SIUL2_PGPDI19_PPDI1_SHIFT                (1U)
#define SIUL2_PGPDI19_PPDI1_WIDTH                (1U)
#define SIUL2_PGPDI19_PPDI1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI1_SHIFT)) & SIUL2_PGPDI19_PPDI1_MASK)

#define SIUL2_PGPDI19_PPDI2_MASK                 (0x4U)
#define SIUL2_PGPDI19_PPDI2_SHIFT                (2U)
#define SIUL2_PGPDI19_PPDI2_WIDTH                (1U)
#define SIUL2_PGPDI19_PPDI2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI2_SHIFT)) & SIUL2_PGPDI19_PPDI2_MASK)

#define SIUL2_PGPDI19_PPDI3_MASK                 (0x8U)
#define SIUL2_PGPDI19_PPDI3_SHIFT                (3U)
#define SIUL2_PGPDI19_PPDI3_WIDTH                (1U)
#define SIUL2_PGPDI19_PPDI3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI3_SHIFT)) & SIUL2_PGPDI19_PPDI3_MASK)

#define SIUL2_PGPDI19_PPDI4_MASK                 (0x10U)
#define SIUL2_PGPDI19_PPDI4_SHIFT                (4U)
#define SIUL2_PGPDI19_PPDI4_WIDTH                (1U)
#define SIUL2_PGPDI19_PPDI4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI4_SHIFT)) & SIUL2_PGPDI19_PPDI4_MASK)

#define SIUL2_PGPDI19_PPDI5_MASK                 (0x20U)
#define SIUL2_PGPDI19_PPDI5_SHIFT                (5U)
#define SIUL2_PGPDI19_PPDI5_WIDTH                (1U)
#define SIUL2_PGPDI19_PPDI5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI5_SHIFT)) & SIUL2_PGPDI19_PPDI5_MASK)

#define SIUL2_PGPDI19_PPDI6_MASK                 (0x40U)
#define SIUL2_PGPDI19_PPDI6_SHIFT                (6U)
#define SIUL2_PGPDI19_PPDI6_WIDTH                (1U)
#define SIUL2_PGPDI19_PPDI6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI6_SHIFT)) & SIUL2_PGPDI19_PPDI6_MASK)

#define SIUL2_PGPDI19_PPDI7_MASK                 (0x80U)
#define SIUL2_PGPDI19_PPDI7_SHIFT                (7U)
#define SIUL2_PGPDI19_PPDI7_WIDTH                (1U)
#define SIUL2_PGPDI19_PPDI7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI7_SHIFT)) & SIUL2_PGPDI19_PPDI7_MASK)

#define SIUL2_PGPDI19_PPDI8_MASK                 (0x100U)
#define SIUL2_PGPDI19_PPDI8_SHIFT                (8U)
#define SIUL2_PGPDI19_PPDI8_WIDTH                (1U)
#define SIUL2_PGPDI19_PPDI8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI8_SHIFT)) & SIUL2_PGPDI19_PPDI8_MASK)

#define SIUL2_PGPDI19_PPDI9_MASK                 (0x200U)
#define SIUL2_PGPDI19_PPDI9_SHIFT                (9U)
#define SIUL2_PGPDI19_PPDI9_WIDTH                (1U)
#define SIUL2_PGPDI19_PPDI9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI9_SHIFT)) & SIUL2_PGPDI19_PPDI9_MASK)

#define SIUL2_PGPDI19_PPDI10_MASK                (0x400U)
#define SIUL2_PGPDI19_PPDI10_SHIFT               (10U)
#define SIUL2_PGPDI19_PPDI10_WIDTH               (1U)
#define SIUL2_PGPDI19_PPDI10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI10_SHIFT)) & SIUL2_PGPDI19_PPDI10_MASK)

#define SIUL2_PGPDI19_PPDI11_MASK                (0x800U)
#define SIUL2_PGPDI19_PPDI11_SHIFT               (11U)
#define SIUL2_PGPDI19_PPDI11_WIDTH               (1U)
#define SIUL2_PGPDI19_PPDI11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI11_SHIFT)) & SIUL2_PGPDI19_PPDI11_MASK)

#define SIUL2_PGPDI19_PPDI12_MASK                (0x1000U)
#define SIUL2_PGPDI19_PPDI12_SHIFT               (12U)
#define SIUL2_PGPDI19_PPDI12_WIDTH               (1U)
#define SIUL2_PGPDI19_PPDI12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI12_SHIFT)) & SIUL2_PGPDI19_PPDI12_MASK)

#define SIUL2_PGPDI19_PPDI13_MASK                (0x2000U)
#define SIUL2_PGPDI19_PPDI13_SHIFT               (13U)
#define SIUL2_PGPDI19_PPDI13_WIDTH               (1U)
#define SIUL2_PGPDI19_PPDI13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI13_SHIFT)) & SIUL2_PGPDI19_PPDI13_MASK)

#define SIUL2_PGPDI19_PPDI14_MASK                (0x4000U)
#define SIUL2_PGPDI19_PPDI14_SHIFT               (14U)
#define SIUL2_PGPDI19_PPDI14_WIDTH               (1U)
#define SIUL2_PGPDI19_PPDI14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI14_SHIFT)) & SIUL2_PGPDI19_PPDI14_MASK)

#define SIUL2_PGPDI19_PPDI15_MASK                (0x8000U)
#define SIUL2_PGPDI19_PPDI15_SHIFT               (15U)
#define SIUL2_PGPDI19_PPDI15_WIDTH               (1U)
#define SIUL2_PGPDI19_PPDI15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI19_PPDI15_SHIFT)) & SIUL2_PGPDI19_PPDI15_MASK)
/*! @} */

/*! @name PGPDI21 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI21_PPDI0_MASK                 (0x1U)
#define SIUL2_PGPDI21_PPDI0_SHIFT                (0U)
#define SIUL2_PGPDI21_PPDI0_WIDTH                (1U)
#define SIUL2_PGPDI21_PPDI0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI0_SHIFT)) & SIUL2_PGPDI21_PPDI0_MASK)

#define SIUL2_PGPDI21_PPDI1_MASK                 (0x2U)
#define SIUL2_PGPDI21_PPDI1_SHIFT                (1U)
#define SIUL2_PGPDI21_PPDI1_WIDTH                (1U)
#define SIUL2_PGPDI21_PPDI1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI1_SHIFT)) & SIUL2_PGPDI21_PPDI1_MASK)

#define SIUL2_PGPDI21_PPDI2_MASK                 (0x4U)
#define SIUL2_PGPDI21_PPDI2_SHIFT                (2U)
#define SIUL2_PGPDI21_PPDI2_WIDTH                (1U)
#define SIUL2_PGPDI21_PPDI2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI2_SHIFT)) & SIUL2_PGPDI21_PPDI2_MASK)

#define SIUL2_PGPDI21_PPDI3_MASK                 (0x8U)
#define SIUL2_PGPDI21_PPDI3_SHIFT                (3U)
#define SIUL2_PGPDI21_PPDI3_WIDTH                (1U)
#define SIUL2_PGPDI21_PPDI3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI3_SHIFT)) & SIUL2_PGPDI21_PPDI3_MASK)

#define SIUL2_PGPDI21_PPDI4_MASK                 (0x10U)
#define SIUL2_PGPDI21_PPDI4_SHIFT                (4U)
#define SIUL2_PGPDI21_PPDI4_WIDTH                (1U)
#define SIUL2_PGPDI21_PPDI4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI4_SHIFT)) & SIUL2_PGPDI21_PPDI4_MASK)

#define SIUL2_PGPDI21_PPDI5_MASK                 (0x20U)
#define SIUL2_PGPDI21_PPDI5_SHIFT                (5U)
#define SIUL2_PGPDI21_PPDI5_WIDTH                (1U)
#define SIUL2_PGPDI21_PPDI5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI5_SHIFT)) & SIUL2_PGPDI21_PPDI5_MASK)

#define SIUL2_PGPDI21_PPDI6_MASK                 (0x40U)
#define SIUL2_PGPDI21_PPDI6_SHIFT                (6U)
#define SIUL2_PGPDI21_PPDI6_WIDTH                (1U)
#define SIUL2_PGPDI21_PPDI6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI6_SHIFT)) & SIUL2_PGPDI21_PPDI6_MASK)

#define SIUL2_PGPDI21_PPDI7_MASK                 (0x80U)
#define SIUL2_PGPDI21_PPDI7_SHIFT                (7U)
#define SIUL2_PGPDI21_PPDI7_WIDTH                (1U)
#define SIUL2_PGPDI21_PPDI7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI7_SHIFT)) & SIUL2_PGPDI21_PPDI7_MASK)

#define SIUL2_PGPDI21_PPDI8_MASK                 (0x100U)
#define SIUL2_PGPDI21_PPDI8_SHIFT                (8U)
#define SIUL2_PGPDI21_PPDI8_WIDTH                (1U)
#define SIUL2_PGPDI21_PPDI8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI8_SHIFT)) & SIUL2_PGPDI21_PPDI8_MASK)

#define SIUL2_PGPDI21_PPDI9_MASK                 (0x200U)
#define SIUL2_PGPDI21_PPDI9_SHIFT                (9U)
#define SIUL2_PGPDI21_PPDI9_WIDTH                (1U)
#define SIUL2_PGPDI21_PPDI9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI9_SHIFT)) & SIUL2_PGPDI21_PPDI9_MASK)

#define SIUL2_PGPDI21_PPDI10_MASK                (0x400U)
#define SIUL2_PGPDI21_PPDI10_SHIFT               (10U)
#define SIUL2_PGPDI21_PPDI10_WIDTH               (1U)
#define SIUL2_PGPDI21_PPDI10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI10_SHIFT)) & SIUL2_PGPDI21_PPDI10_MASK)

#define SIUL2_PGPDI21_PPDI11_MASK                (0x800U)
#define SIUL2_PGPDI21_PPDI11_SHIFT               (11U)
#define SIUL2_PGPDI21_PPDI11_WIDTH               (1U)
#define SIUL2_PGPDI21_PPDI11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI11_SHIFT)) & SIUL2_PGPDI21_PPDI11_MASK)

#define SIUL2_PGPDI21_PPDI12_MASK                (0x1000U)
#define SIUL2_PGPDI21_PPDI12_SHIFT               (12U)
#define SIUL2_PGPDI21_PPDI12_WIDTH               (1U)
#define SIUL2_PGPDI21_PPDI12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI12_SHIFT)) & SIUL2_PGPDI21_PPDI12_MASK)

#define SIUL2_PGPDI21_PPDI13_MASK                (0x2000U)
#define SIUL2_PGPDI21_PPDI13_SHIFT               (13U)
#define SIUL2_PGPDI21_PPDI13_WIDTH               (1U)
#define SIUL2_PGPDI21_PPDI13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI13_SHIFT)) & SIUL2_PGPDI21_PPDI13_MASK)

#define SIUL2_PGPDI21_PPDI14_MASK                (0x4000U)
#define SIUL2_PGPDI21_PPDI14_SHIFT               (14U)
#define SIUL2_PGPDI21_PPDI14_WIDTH               (1U)
#define SIUL2_PGPDI21_PPDI14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI14_SHIFT)) & SIUL2_PGPDI21_PPDI14_MASK)

#define SIUL2_PGPDI21_PPDI15_MASK                (0x8000U)
#define SIUL2_PGPDI21_PPDI15_SHIFT               (15U)
#define SIUL2_PGPDI21_PPDI15_WIDTH               (1U)
#define SIUL2_PGPDI21_PPDI15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI21_PPDI15_SHIFT)) & SIUL2_PGPDI21_PPDI15_MASK)
/*! @} */

/*! @name PGPDI20 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI20_PPDI0_MASK                 (0x1U)
#define SIUL2_PGPDI20_PPDI0_SHIFT                (0U)
#define SIUL2_PGPDI20_PPDI0_WIDTH                (1U)
#define SIUL2_PGPDI20_PPDI0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI0_SHIFT)) & SIUL2_PGPDI20_PPDI0_MASK)

#define SIUL2_PGPDI20_PPDI1_MASK                 (0x2U)
#define SIUL2_PGPDI20_PPDI1_SHIFT                (1U)
#define SIUL2_PGPDI20_PPDI1_WIDTH                (1U)
#define SIUL2_PGPDI20_PPDI1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI1_SHIFT)) & SIUL2_PGPDI20_PPDI1_MASK)

#define SIUL2_PGPDI20_PPDI2_MASK                 (0x4U)
#define SIUL2_PGPDI20_PPDI2_SHIFT                (2U)
#define SIUL2_PGPDI20_PPDI2_WIDTH                (1U)
#define SIUL2_PGPDI20_PPDI2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI2_SHIFT)) & SIUL2_PGPDI20_PPDI2_MASK)

#define SIUL2_PGPDI20_PPDI3_MASK                 (0x8U)
#define SIUL2_PGPDI20_PPDI3_SHIFT                (3U)
#define SIUL2_PGPDI20_PPDI3_WIDTH                (1U)
#define SIUL2_PGPDI20_PPDI3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI3_SHIFT)) & SIUL2_PGPDI20_PPDI3_MASK)

#define SIUL2_PGPDI20_PPDI4_MASK                 (0x10U)
#define SIUL2_PGPDI20_PPDI4_SHIFT                (4U)
#define SIUL2_PGPDI20_PPDI4_WIDTH                (1U)
#define SIUL2_PGPDI20_PPDI4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI4_SHIFT)) & SIUL2_PGPDI20_PPDI4_MASK)

#define SIUL2_PGPDI20_PPDI5_MASK                 (0x20U)
#define SIUL2_PGPDI20_PPDI5_SHIFT                (5U)
#define SIUL2_PGPDI20_PPDI5_WIDTH                (1U)
#define SIUL2_PGPDI20_PPDI5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI5_SHIFT)) & SIUL2_PGPDI20_PPDI5_MASK)

#define SIUL2_PGPDI20_PPDI6_MASK                 (0x40U)
#define SIUL2_PGPDI20_PPDI6_SHIFT                (6U)
#define SIUL2_PGPDI20_PPDI6_WIDTH                (1U)
#define SIUL2_PGPDI20_PPDI6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI6_SHIFT)) & SIUL2_PGPDI20_PPDI6_MASK)

#define SIUL2_PGPDI20_PPDI7_MASK                 (0x80U)
#define SIUL2_PGPDI20_PPDI7_SHIFT                (7U)
#define SIUL2_PGPDI20_PPDI7_WIDTH                (1U)
#define SIUL2_PGPDI20_PPDI7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI7_SHIFT)) & SIUL2_PGPDI20_PPDI7_MASK)

#define SIUL2_PGPDI20_PPDI8_MASK                 (0x100U)
#define SIUL2_PGPDI20_PPDI8_SHIFT                (8U)
#define SIUL2_PGPDI20_PPDI8_WIDTH                (1U)
#define SIUL2_PGPDI20_PPDI8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI8_SHIFT)) & SIUL2_PGPDI20_PPDI8_MASK)

#define SIUL2_PGPDI20_PPDI9_MASK                 (0x200U)
#define SIUL2_PGPDI20_PPDI9_SHIFT                (9U)
#define SIUL2_PGPDI20_PPDI9_WIDTH                (1U)
#define SIUL2_PGPDI20_PPDI9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI9_SHIFT)) & SIUL2_PGPDI20_PPDI9_MASK)

#define SIUL2_PGPDI20_PPDI10_MASK                (0x400U)
#define SIUL2_PGPDI20_PPDI10_SHIFT               (10U)
#define SIUL2_PGPDI20_PPDI10_WIDTH               (1U)
#define SIUL2_PGPDI20_PPDI10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI10_SHIFT)) & SIUL2_PGPDI20_PPDI10_MASK)

#define SIUL2_PGPDI20_PPDI11_MASK                (0x800U)
#define SIUL2_PGPDI20_PPDI11_SHIFT               (11U)
#define SIUL2_PGPDI20_PPDI11_WIDTH               (1U)
#define SIUL2_PGPDI20_PPDI11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI11_SHIFT)) & SIUL2_PGPDI20_PPDI11_MASK)

#define SIUL2_PGPDI20_PPDI12_MASK                (0x1000U)
#define SIUL2_PGPDI20_PPDI12_SHIFT               (12U)
#define SIUL2_PGPDI20_PPDI12_WIDTH               (1U)
#define SIUL2_PGPDI20_PPDI12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI12_SHIFT)) & SIUL2_PGPDI20_PPDI12_MASK)

#define SIUL2_PGPDI20_PPDI13_MASK                (0x2000U)
#define SIUL2_PGPDI20_PPDI13_SHIFT               (13U)
#define SIUL2_PGPDI20_PPDI13_WIDTH               (1U)
#define SIUL2_PGPDI20_PPDI13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI13_SHIFT)) & SIUL2_PGPDI20_PPDI13_MASK)

#define SIUL2_PGPDI20_PPDI14_MASK                (0x4000U)
#define SIUL2_PGPDI20_PPDI14_SHIFT               (14U)
#define SIUL2_PGPDI20_PPDI14_WIDTH               (1U)
#define SIUL2_PGPDI20_PPDI14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI14_SHIFT)) & SIUL2_PGPDI20_PPDI14_MASK)

#define SIUL2_PGPDI20_PPDI15_MASK                (0x8000U)
#define SIUL2_PGPDI20_PPDI15_SHIFT               (15U)
#define SIUL2_PGPDI20_PPDI15_WIDTH               (1U)
#define SIUL2_PGPDI20_PPDI15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI20_PPDI15_SHIFT)) & SIUL2_PGPDI20_PPDI15_MASK)
/*! @} */

/*! @name PGPDI23 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI23_PPDI12_MASK                (0x1000U)
#define SIUL2_PGPDI23_PPDI12_SHIFT               (12U)
#define SIUL2_PGPDI23_PPDI12_WIDTH               (1U)
#define SIUL2_PGPDI23_PPDI12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI23_PPDI12_SHIFT)) & SIUL2_PGPDI23_PPDI12_MASK)

#define SIUL2_PGPDI23_PPDI13_MASK                (0x2000U)
#define SIUL2_PGPDI23_PPDI13_SHIFT               (13U)
#define SIUL2_PGPDI23_PPDI13_WIDTH               (1U)
#define SIUL2_PGPDI23_PPDI13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI23_PPDI13_SHIFT)) & SIUL2_PGPDI23_PPDI13_MASK)

#define SIUL2_PGPDI23_PPDI14_MASK                (0x4000U)
#define SIUL2_PGPDI23_PPDI14_SHIFT               (14U)
#define SIUL2_PGPDI23_PPDI14_WIDTH               (1U)
#define SIUL2_PGPDI23_PPDI14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI23_PPDI14_SHIFT)) & SIUL2_PGPDI23_PPDI14_MASK)

#define SIUL2_PGPDI23_PPDI15_MASK                (0x8000U)
#define SIUL2_PGPDI23_PPDI15_SHIFT               (15U)
#define SIUL2_PGPDI23_PPDI15_WIDTH               (1U)
#define SIUL2_PGPDI23_PPDI15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI23_PPDI15_SHIFT)) & SIUL2_PGPDI23_PPDI15_MASK)
/*! @} */

/*! @name PGPDI22 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI22_PPDI0_MASK                 (0x1U)
#define SIUL2_PGPDI22_PPDI0_SHIFT                (0U)
#define SIUL2_PGPDI22_PPDI0_WIDTH                (1U)
#define SIUL2_PGPDI22_PPDI0(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI0_SHIFT)) & SIUL2_PGPDI22_PPDI0_MASK)

#define SIUL2_PGPDI22_PPDI1_MASK                 (0x2U)
#define SIUL2_PGPDI22_PPDI1_SHIFT                (1U)
#define SIUL2_PGPDI22_PPDI1_WIDTH                (1U)
#define SIUL2_PGPDI22_PPDI1(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI1_SHIFT)) & SIUL2_PGPDI22_PPDI1_MASK)

#define SIUL2_PGPDI22_PPDI2_MASK                 (0x4U)
#define SIUL2_PGPDI22_PPDI2_SHIFT                (2U)
#define SIUL2_PGPDI22_PPDI2_WIDTH                (1U)
#define SIUL2_PGPDI22_PPDI2(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI2_SHIFT)) & SIUL2_PGPDI22_PPDI2_MASK)

#define SIUL2_PGPDI22_PPDI3_MASK                 (0x8U)
#define SIUL2_PGPDI22_PPDI3_SHIFT                (3U)
#define SIUL2_PGPDI22_PPDI3_WIDTH                (1U)
#define SIUL2_PGPDI22_PPDI3(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI3_SHIFT)) & SIUL2_PGPDI22_PPDI3_MASK)

#define SIUL2_PGPDI22_PPDI4_MASK                 (0x10U)
#define SIUL2_PGPDI22_PPDI4_SHIFT                (4U)
#define SIUL2_PGPDI22_PPDI4_WIDTH                (1U)
#define SIUL2_PGPDI22_PPDI4(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI4_SHIFT)) & SIUL2_PGPDI22_PPDI4_MASK)

#define SIUL2_PGPDI22_PPDI5_MASK                 (0x20U)
#define SIUL2_PGPDI22_PPDI5_SHIFT                (5U)
#define SIUL2_PGPDI22_PPDI5_WIDTH                (1U)
#define SIUL2_PGPDI22_PPDI5(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI5_SHIFT)) & SIUL2_PGPDI22_PPDI5_MASK)

#define SIUL2_PGPDI22_PPDI6_MASK                 (0x40U)
#define SIUL2_PGPDI22_PPDI6_SHIFT                (6U)
#define SIUL2_PGPDI22_PPDI6_WIDTH                (1U)
#define SIUL2_PGPDI22_PPDI6(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI6_SHIFT)) & SIUL2_PGPDI22_PPDI6_MASK)

#define SIUL2_PGPDI22_PPDI7_MASK                 (0x80U)
#define SIUL2_PGPDI22_PPDI7_SHIFT                (7U)
#define SIUL2_PGPDI22_PPDI7_WIDTH                (1U)
#define SIUL2_PGPDI22_PPDI7(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI7_SHIFT)) & SIUL2_PGPDI22_PPDI7_MASK)

#define SIUL2_PGPDI22_PPDI8_MASK                 (0x100U)
#define SIUL2_PGPDI22_PPDI8_SHIFT                (8U)
#define SIUL2_PGPDI22_PPDI8_WIDTH                (1U)
#define SIUL2_PGPDI22_PPDI8(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI8_SHIFT)) & SIUL2_PGPDI22_PPDI8_MASK)

#define SIUL2_PGPDI22_PPDI9_MASK                 (0x200U)
#define SIUL2_PGPDI22_PPDI9_SHIFT                (9U)
#define SIUL2_PGPDI22_PPDI9_WIDTH                (1U)
#define SIUL2_PGPDI22_PPDI9(x)                   (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI9_SHIFT)) & SIUL2_PGPDI22_PPDI9_MASK)

#define SIUL2_PGPDI22_PPDI10_MASK                (0x400U)
#define SIUL2_PGPDI22_PPDI10_SHIFT               (10U)
#define SIUL2_PGPDI22_PPDI10_WIDTH               (1U)
#define SIUL2_PGPDI22_PPDI10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI10_SHIFT)) & SIUL2_PGPDI22_PPDI10_MASK)

#define SIUL2_PGPDI22_PPDI11_MASK                (0x800U)
#define SIUL2_PGPDI22_PPDI11_SHIFT               (11U)
#define SIUL2_PGPDI22_PPDI11_WIDTH               (1U)
#define SIUL2_PGPDI22_PPDI11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI11_SHIFT)) & SIUL2_PGPDI22_PPDI11_MASK)

#define SIUL2_PGPDI22_PPDI12_MASK                (0x1000U)
#define SIUL2_PGPDI22_PPDI12_SHIFT               (12U)
#define SIUL2_PGPDI22_PPDI12_WIDTH               (1U)
#define SIUL2_PGPDI22_PPDI12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI12_SHIFT)) & SIUL2_PGPDI22_PPDI12_MASK)

#define SIUL2_PGPDI22_PPDI13_MASK                (0x2000U)
#define SIUL2_PGPDI22_PPDI13_SHIFT               (13U)
#define SIUL2_PGPDI22_PPDI13_WIDTH               (1U)
#define SIUL2_PGPDI22_PPDI13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI13_SHIFT)) & SIUL2_PGPDI22_PPDI13_MASK)

#define SIUL2_PGPDI22_PPDI14_MASK                (0x4000U)
#define SIUL2_PGPDI22_PPDI14_SHIFT               (14U)
#define SIUL2_PGPDI22_PPDI14_WIDTH               (1U)
#define SIUL2_PGPDI22_PPDI14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI14_SHIFT)) & SIUL2_PGPDI22_PPDI14_MASK)

#define SIUL2_PGPDI22_PPDI15_MASK                (0x8000U)
#define SIUL2_PGPDI22_PPDI15_SHIFT               (15U)
#define SIUL2_PGPDI22_PPDI15_WIDTH               (1U)
#define SIUL2_PGPDI22_PPDI15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI22_PPDI15_SHIFT)) & SIUL2_PGPDI22_PPDI15_MASK)
/*! @} */

/*! @name PGPDI27 - Parallel GPIO Pad Data Input */
/*! @{ */

#define SIUL2_PGPDI27_PPDI10_MASK                (0x400U)
#define SIUL2_PGPDI27_PPDI10_SHIFT               (10U)
#define SIUL2_PGPDI27_PPDI10_WIDTH               (1U)
#define SIUL2_PGPDI27_PPDI10(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI27_PPDI10_SHIFT)) & SIUL2_PGPDI27_PPDI10_MASK)

#define SIUL2_PGPDI27_PPDI11_MASK                (0x800U)
#define SIUL2_PGPDI27_PPDI11_SHIFT               (11U)
#define SIUL2_PGPDI27_PPDI11_WIDTH               (1U)
#define SIUL2_PGPDI27_PPDI11(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI27_PPDI11_SHIFT)) & SIUL2_PGPDI27_PPDI11_MASK)

#define SIUL2_PGPDI27_PPDI12_MASK                (0x1000U)
#define SIUL2_PGPDI27_PPDI12_SHIFT               (12U)
#define SIUL2_PGPDI27_PPDI12_WIDTH               (1U)
#define SIUL2_PGPDI27_PPDI12(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI27_PPDI12_SHIFT)) & SIUL2_PGPDI27_PPDI12_MASK)

#define SIUL2_PGPDI27_PPDI13_MASK                (0x2000U)
#define SIUL2_PGPDI27_PPDI13_SHIFT               (13U)
#define SIUL2_PGPDI27_PPDI13_WIDTH               (1U)
#define SIUL2_PGPDI27_PPDI13(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI27_PPDI13_SHIFT)) & SIUL2_PGPDI27_PPDI13_MASK)

#define SIUL2_PGPDI27_PPDI14_MASK                (0x4000U)
#define SIUL2_PGPDI27_PPDI14_SHIFT               (14U)
#define SIUL2_PGPDI27_PPDI14_WIDTH               (1U)
#define SIUL2_PGPDI27_PPDI14(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI27_PPDI14_SHIFT)) & SIUL2_PGPDI27_PPDI14_MASK)

#define SIUL2_PGPDI27_PPDI15_MASK                (0x8000U)
#define SIUL2_PGPDI27_PPDI15_SHIFT               (15U)
#define SIUL2_PGPDI27_PPDI15_WIDTH               (1U)
#define SIUL2_PGPDI27_PPDI15(x)                  (((uint16_t)(((uint16_t)(x)) << SIUL2_PGPDI27_PPDI15_SHIFT)) & SIUL2_PGPDI27_PPDI15_MASK)
/*! @} */

/*! @name MPGPDO - Masked Parallel GPIO Pad Data Output */
/*! @{ */

#define SIUL2_MPGPDO_MPPDO0_MASK                 (0x1U)
#define SIUL2_MPGPDO_MPPDO0_SHIFT                (0U)
#define SIUL2_MPGPDO_MPPDO0_WIDTH                (1U)
#define SIUL2_MPGPDO_MPPDO0(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO0_SHIFT)) & SIUL2_MPGPDO_MPPDO0_MASK)

#define SIUL2_MPGPDO_MPPDO1_MASK                 (0x2U)
#define SIUL2_MPGPDO_MPPDO1_SHIFT                (1U)
#define SIUL2_MPGPDO_MPPDO1_WIDTH                (1U)
#define SIUL2_MPGPDO_MPPDO1(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO1_SHIFT)) & SIUL2_MPGPDO_MPPDO1_MASK)

#define SIUL2_MPGPDO_MPPDO2_MASK                 (0x4U)
#define SIUL2_MPGPDO_MPPDO2_SHIFT                (2U)
#define SIUL2_MPGPDO_MPPDO2_WIDTH                (1U)
#define SIUL2_MPGPDO_MPPDO2(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO2_SHIFT)) & SIUL2_MPGPDO_MPPDO2_MASK)

#define SIUL2_MPGPDO_MPPDO3_MASK                 (0x8U)
#define SIUL2_MPGPDO_MPPDO3_SHIFT                (3U)
#define SIUL2_MPGPDO_MPPDO3_WIDTH                (1U)
#define SIUL2_MPGPDO_MPPDO3(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO3_SHIFT)) & SIUL2_MPGPDO_MPPDO3_MASK)

#define SIUL2_MPGPDO_MPPDO4_MASK                 (0x10U)
#define SIUL2_MPGPDO_MPPDO4_SHIFT                (4U)
#define SIUL2_MPGPDO_MPPDO4_WIDTH                (1U)
#define SIUL2_MPGPDO_MPPDO4(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO4_SHIFT)) & SIUL2_MPGPDO_MPPDO4_MASK)

#define SIUL2_MPGPDO_MPPDO5_MASK                 (0x20U)
#define SIUL2_MPGPDO_MPPDO5_SHIFT                (5U)
#define SIUL2_MPGPDO_MPPDO5_WIDTH                (1U)
#define SIUL2_MPGPDO_MPPDO5(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO5_SHIFT)) & SIUL2_MPGPDO_MPPDO5_MASK)

#define SIUL2_MPGPDO_MPPDO6_MASK                 (0x40U)
#define SIUL2_MPGPDO_MPPDO6_SHIFT                (6U)
#define SIUL2_MPGPDO_MPPDO6_WIDTH                (1U)
#define SIUL2_MPGPDO_MPPDO6(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO6_SHIFT)) & SIUL2_MPGPDO_MPPDO6_MASK)

#define SIUL2_MPGPDO_MPPDO7_MASK                 (0x80U)
#define SIUL2_MPGPDO_MPPDO7_SHIFT                (7U)
#define SIUL2_MPGPDO_MPPDO7_WIDTH                (1U)
#define SIUL2_MPGPDO_MPPDO7(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO7_SHIFT)) & SIUL2_MPGPDO_MPPDO7_MASK)

#define SIUL2_MPGPDO_MPPDO8_MASK                 (0x100U)
#define SIUL2_MPGPDO_MPPDO8_SHIFT                (8U)
#define SIUL2_MPGPDO_MPPDO8_WIDTH                (1U)
#define SIUL2_MPGPDO_MPPDO8(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO8_SHIFT)) & SIUL2_MPGPDO_MPPDO8_MASK)

#define SIUL2_MPGPDO_MPPDO9_MASK                 (0x200U)
#define SIUL2_MPGPDO_MPPDO9_SHIFT                (9U)
#define SIUL2_MPGPDO_MPPDO9_WIDTH                (1U)
#define SIUL2_MPGPDO_MPPDO9(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO9_SHIFT)) & SIUL2_MPGPDO_MPPDO9_MASK)

#define SIUL2_MPGPDO_MPPDO10_MASK                (0x400U)
#define SIUL2_MPGPDO_MPPDO10_SHIFT               (10U)
#define SIUL2_MPGPDO_MPPDO10_WIDTH               (1U)
#define SIUL2_MPGPDO_MPPDO10(x)                  (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO10_SHIFT)) & SIUL2_MPGPDO_MPPDO10_MASK)

#define SIUL2_MPGPDO_MPPDO11_MASK                (0x800U)
#define SIUL2_MPGPDO_MPPDO11_SHIFT               (11U)
#define SIUL2_MPGPDO_MPPDO11_WIDTH               (1U)
#define SIUL2_MPGPDO_MPPDO11(x)                  (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO11_SHIFT)) & SIUL2_MPGPDO_MPPDO11_MASK)

#define SIUL2_MPGPDO_MPPDO12_MASK                (0x1000U)
#define SIUL2_MPGPDO_MPPDO12_SHIFT               (12U)
#define SIUL2_MPGPDO_MPPDO12_WIDTH               (1U)
#define SIUL2_MPGPDO_MPPDO12(x)                  (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO12_SHIFT)) & SIUL2_MPGPDO_MPPDO12_MASK)

#define SIUL2_MPGPDO_MPPDO13_MASK                (0x2000U)
#define SIUL2_MPGPDO_MPPDO13_SHIFT               (13U)
#define SIUL2_MPGPDO_MPPDO13_WIDTH               (1U)
#define SIUL2_MPGPDO_MPPDO13(x)                  (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO13_SHIFT)) & SIUL2_MPGPDO_MPPDO13_MASK)

#define SIUL2_MPGPDO_MPPDO14_MASK                (0x4000U)
#define SIUL2_MPGPDO_MPPDO14_SHIFT               (14U)
#define SIUL2_MPGPDO_MPPDO14_WIDTH               (1U)
#define SIUL2_MPGPDO_MPPDO14(x)                  (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO14_SHIFT)) & SIUL2_MPGPDO_MPPDO14_MASK)

#define SIUL2_MPGPDO_MPPDO15_MASK                (0x8000U)
#define SIUL2_MPGPDO_MPPDO15_SHIFT               (15U)
#define SIUL2_MPGPDO_MPPDO15_WIDTH               (1U)
#define SIUL2_MPGPDO_MPPDO15(x)                  (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MPPDO15_SHIFT)) & SIUL2_MPGPDO_MPPDO15_MASK)

#define SIUL2_MPGPDO_MASK0_MASK                  (0x10000U)
#define SIUL2_MPGPDO_MASK0_SHIFT                 (16U)
#define SIUL2_MPGPDO_MASK0_WIDTH                 (1U)
#define SIUL2_MPGPDO_MASK0(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK0_SHIFT)) & SIUL2_MPGPDO_MASK0_MASK)

#define SIUL2_MPGPDO_MASK1_MASK                  (0x20000U)
#define SIUL2_MPGPDO_MASK1_SHIFT                 (17U)
#define SIUL2_MPGPDO_MASK1_WIDTH                 (1U)
#define SIUL2_MPGPDO_MASK1(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK1_SHIFT)) & SIUL2_MPGPDO_MASK1_MASK)

#define SIUL2_MPGPDO_MASK2_MASK                  (0x40000U)
#define SIUL2_MPGPDO_MASK2_SHIFT                 (18U)
#define SIUL2_MPGPDO_MASK2_WIDTH                 (1U)
#define SIUL2_MPGPDO_MASK2(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK2_SHIFT)) & SIUL2_MPGPDO_MASK2_MASK)

#define SIUL2_MPGPDO_MASK3_MASK                  (0x80000U)
#define SIUL2_MPGPDO_MASK3_SHIFT                 (19U)
#define SIUL2_MPGPDO_MASK3_WIDTH                 (1U)
#define SIUL2_MPGPDO_MASK3(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK3_SHIFT)) & SIUL2_MPGPDO_MASK3_MASK)

#define SIUL2_MPGPDO_MASK4_MASK                  (0x100000U)
#define SIUL2_MPGPDO_MASK4_SHIFT                 (20U)
#define SIUL2_MPGPDO_MASK4_WIDTH                 (1U)
#define SIUL2_MPGPDO_MASK4(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK4_SHIFT)) & SIUL2_MPGPDO_MASK4_MASK)

#define SIUL2_MPGPDO_MASK5_MASK                  (0x200000U)
#define SIUL2_MPGPDO_MASK5_SHIFT                 (21U)
#define SIUL2_MPGPDO_MASK5_WIDTH                 (1U)
#define SIUL2_MPGPDO_MASK5(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK5_SHIFT)) & SIUL2_MPGPDO_MASK5_MASK)

#define SIUL2_MPGPDO_MASK6_MASK                  (0x400000U)
#define SIUL2_MPGPDO_MASK6_SHIFT                 (22U)
#define SIUL2_MPGPDO_MASK6_WIDTH                 (1U)
#define SIUL2_MPGPDO_MASK6(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK6_SHIFT)) & SIUL2_MPGPDO_MASK6_MASK)

#define SIUL2_MPGPDO_MASK7_MASK                  (0x800000U)
#define SIUL2_MPGPDO_MASK7_SHIFT                 (23U)
#define SIUL2_MPGPDO_MASK7_WIDTH                 (1U)
#define SIUL2_MPGPDO_MASK7(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK7_SHIFT)) & SIUL2_MPGPDO_MASK7_MASK)

#define SIUL2_MPGPDO_MASK8_MASK                  (0x1000000U)
#define SIUL2_MPGPDO_MASK8_SHIFT                 (24U)
#define SIUL2_MPGPDO_MASK8_WIDTH                 (1U)
#define SIUL2_MPGPDO_MASK8(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK8_SHIFT)) & SIUL2_MPGPDO_MASK8_MASK)

#define SIUL2_MPGPDO_MASK9_MASK                  (0x2000000U)
#define SIUL2_MPGPDO_MASK9_SHIFT                 (25U)
#define SIUL2_MPGPDO_MASK9_WIDTH                 (1U)
#define SIUL2_MPGPDO_MASK9(x)                    (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK9_SHIFT)) & SIUL2_MPGPDO_MASK9_MASK)

#define SIUL2_MPGPDO_MASK10_MASK                 (0x4000000U)
#define SIUL2_MPGPDO_MASK10_SHIFT                (26U)
#define SIUL2_MPGPDO_MASK10_WIDTH                (1U)
#define SIUL2_MPGPDO_MASK10(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK10_SHIFT)) & SIUL2_MPGPDO_MASK10_MASK)

#define SIUL2_MPGPDO_MASK11_MASK                 (0x8000000U)
#define SIUL2_MPGPDO_MASK11_SHIFT                (27U)
#define SIUL2_MPGPDO_MASK11_WIDTH                (1U)
#define SIUL2_MPGPDO_MASK11(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK11_SHIFT)) & SIUL2_MPGPDO_MASK11_MASK)

#define SIUL2_MPGPDO_MASK12_MASK                 (0x10000000U)
#define SIUL2_MPGPDO_MASK12_SHIFT                (28U)
#define SIUL2_MPGPDO_MASK12_WIDTH                (1U)
#define SIUL2_MPGPDO_MASK12(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK12_SHIFT)) & SIUL2_MPGPDO_MASK12_MASK)

#define SIUL2_MPGPDO_MASK13_MASK                 (0x20000000U)
#define SIUL2_MPGPDO_MASK13_SHIFT                (29U)
#define SIUL2_MPGPDO_MASK13_WIDTH                (1U)
#define SIUL2_MPGPDO_MASK13(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK13_SHIFT)) & SIUL2_MPGPDO_MASK13_MASK)

#define SIUL2_MPGPDO_MASK14_MASK                 (0x40000000U)
#define SIUL2_MPGPDO_MASK14_SHIFT                (30U)
#define SIUL2_MPGPDO_MASK14_WIDTH                (1U)
#define SIUL2_MPGPDO_MASK14(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK14_SHIFT)) & SIUL2_MPGPDO_MASK14_MASK)

#define SIUL2_MPGPDO_MASK15_MASK                 (0x80000000U)
#define SIUL2_MPGPDO_MASK15_SHIFT                (31U)
#define SIUL2_MPGPDO_MASK15_WIDTH                (1U)
#define SIUL2_MPGPDO_MASK15(x)                   (((uint32_t)(((uint32_t)(x)) << SIUL2_MPGPDO_MASK15_SHIFT)) & SIUL2_MPGPDO_MASK15_MASK)
/*! @} */

/*!
 * @}
 */ /* end of group SIUL2_Register_Masks */

/*!
 * @}
 */ /* end of group SIUL2_Peripheral_Access_Layer */

#endif  /* #if !defined(S32K566_SIUL2_H_) */
