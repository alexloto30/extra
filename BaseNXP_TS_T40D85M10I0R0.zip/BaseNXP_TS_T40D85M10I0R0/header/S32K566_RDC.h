/*
** ###################################################################
**     Processor:           S32K566_M7
**     Compiler:            Keil ARM C/C++ Compiler
**     Reference manual:    S32K5 RM Rev 3
**     Version:             rev. 2.7, 2026-09-09
**     Build:               b260908
**
**     Abstract:
**         Peripheral Access Layer for S32K566_M7
**
**     Copyright 1997-2016 Freescale Semiconductor, Inc.
**     Copyright 2016-2026 NXP
**
**     NXP Confidential and Proprietary. This software is owned or controlled
**     by NXP and may only be used strictly in accordance with the applicable
**     license terms. By expressly accepting such terms or by downloading,
**     installing, activating and/or otherwise using the software, you are
**     agreeing that you have read, and that you agree to comply with and are
**     bound by, such license terms. If you do not agree to be bound by the
**     applicable license terms, then you may not retain, install, activate
**     or otherwise use the software.
**
**     http:                 www.nxp.com
**     mail:                 support@nxp.com
**
** ###################################################################
*/

/*!
 * @file S32K566_RDC.h
 * @version 2.7
 * @date 2026-09-09
 * @brief Peripheral Access Layer for S32K566_RDC
 *
 * This file contains register definitions and macros for easy access to their
 * bit fields.
 *
 * This file assumes LITTLE endian system.
 */

/**
* @page misra_violations MISRA-C:2012 violations
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.3, local typedef not referenced
* The SoC header defines typedef for all modules.
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.5, local macro not referenced
* The SoC header defines macros for all modules and registers.
*
* @section [global]
* Violates MISRA 2012 Advisory Directive 4.9, Function-like macro
* These are generated macros used for accessing the bit-fields from registers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.1, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.2, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.4, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.5, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 21.1, defined macro '__I' is reserved to the compiler
* This type qualifier is needed to ensure correct I/O access and addressing.
*/

/* Prevention from multiple including the same memory map */
#if !defined(S32K566_RDC_H_)  /* Check if memory map has not been already included */
#define S32K566_RDC_H_

#include "S32K566_COMMON.h"

/* ----------------------------------------------------------------------------
   -- RDC Peripheral Access Layer
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup RDC_Peripheral_Access_Layer RDC Peripheral Access Layer
 * @{
 */

/** RDC - Register Layout Typedef */
typedef struct RDC_Struct {
  uint8_t RESERVED_0[4];
  __IO uint32_t RD1_CTRL_REG;                      /**< Software Reset Domain Control, offset: 0x4 */
} RDC_Type, *RDC_MemMapPtr;

/** Number of instances of the RDC module. */
#define RDC_INSTANCE_COUNT                       (2u)

/* RDC - Peripheral instance base addresses */
/** Peripheral RDC_C0 base address */
#define IP_RDC_C0_BASE                           (0x408EC000u)
/** Peripheral RDC_C0 base pointer */
#define IP_RDC_C0                                ((RDC_Type *)IP_RDC_C0_BASE)
/** Peripheral RDC_REST base address */
#define IP_RDC_REST_BASE                         (0x408E8000u)
/** Peripheral RDC_REST base pointer */
#define IP_RDC_REST                              ((RDC_Type *)IP_RDC_REST_BASE)
/** Array initializer of RDC peripheral base addresses */
#define IP_RDC_BASE_ADDRS                        { IP_RDC_C0_BASE, IP_RDC_REST_BASE }
/** Array initializer of RDC peripheral base pointers */
#define IP_RDC_BASE_PTRS                         { IP_RDC_C0, IP_RDC_REST }

/* ----------------------------------------------------------------------------
   -- RDC Register Masks
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup RDC_Register_Masks RDC Register Masks
 * @{
 */

/*! @name RD1_CTRL_REG - Software Reset Domain Control */
/*! @{ */

#define RDC_RD1_CTRL_REG_RD1_INTERCONNECT_INTERFACE_DISABLE_MASK (0x8U)
#define RDC_RD1_CTRL_REG_RD1_INTERCONNECT_INTERFACE_DISABLE_SHIFT (3U)
#define RDC_RD1_CTRL_REG_RD1_INTERCONNECT_INTERFACE_DISABLE_WIDTH (1U)
#define RDC_RD1_CTRL_REG_RD1_INTERCONNECT_INTERFACE_DISABLE(x) (((uint32_t)(((uint32_t)(x)) << RDC_RD1_CTRL_REG_RD1_INTERCONNECT_INTERFACE_DISABLE_SHIFT)) & RDC_RD1_CTRL_REG_RD1_INTERCONNECT_INTERFACE_DISABLE_MASK)

#define RDC_RD1_CTRL_REG_RD1_CTRL_UNLOCK_MASK    (0x80000000U)
#define RDC_RD1_CTRL_REG_RD1_CTRL_UNLOCK_SHIFT   (31U)
#define RDC_RD1_CTRL_REG_RD1_CTRL_UNLOCK_WIDTH   (1U)
#define RDC_RD1_CTRL_REG_RD1_CTRL_UNLOCK(x)      (((uint32_t)(((uint32_t)(x)) << RDC_RD1_CTRL_REG_RD1_CTRL_UNLOCK_SHIFT)) & RDC_RD1_CTRL_REG_RD1_CTRL_UNLOCK_MASK)
/*! @} */

/*!
 * @}
 */ /* end of group RDC_Register_Masks */

/*!
 * @}
 */ /* end of group RDC_Peripheral_Access_Layer */

#endif  /* #if !defined(S32K566_RDC_H_) */
