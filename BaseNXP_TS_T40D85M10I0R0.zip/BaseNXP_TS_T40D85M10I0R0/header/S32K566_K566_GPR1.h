/*
** ###################################################################
**     Processor:           S32K566_M7
**     Compiler:            Keil ARM C/C++ Compiler
**     Reference manual:    S32K5 RM Rev 3
**     Version:             rev. 2.7, 2026-09-09
**     Build:               b260908
**
**     Abstract:
**         Peripheral Access Layer for S32K566_M7
**
**     Copyright 1997-2016 Freescale Semiconductor, Inc.
**     Copyright 2016-2026 NXP
**
**     NXP Confidential and Proprietary. This software is owned or controlled
**     by NXP and may only be used strictly in accordance with the applicable
**     license terms. By expressly accepting such terms or by downloading,
**     installing, activating and/or otherwise using the software, you are
**     agreeing that you have read, and that you agree to comply with and are
**     bound by, such license terms. If you do not agree to be bound by the
**     applicable license terms, then you may not retain, install, activate
**     or otherwise use the software.
**
**     http:                 www.nxp.com
**     mail:                 support@nxp.com
**
** ###################################################################
*/

/*!
 * @file S32K566_K566_GPR1.h
 * @version 2.7
 * @date 2026-09-09
 * @brief Peripheral Access Layer for S32K566_K566_GPR1
 *
 * This file contains register definitions and macros for easy access to their
 * bit fields.
 *
 * This file assumes LITTLE endian system.
 */

/**
* @page misra_violations MISRA-C:2012 violations
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.3, local typedef not referenced
* The SoC header defines typedef for all modules.
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.5, local macro not referenced
* The SoC header defines macros for all modules and registers.
*
* @section [global]
* Violates MISRA 2012 Advisory Directive 4.9, Function-like macro
* These are generated macros used for accessing the bit-fields from registers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.1, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.2, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.4, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.5, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 21.1, defined macro '__I' is reserved to the compiler
* This type qualifier is needed to ensure correct I/O access and addressing.
*/

/* Prevention from multiple including the same memory map */
#if !defined(S32K566_K566_GPR1_H_)  /* Check if memory map has not been already included */
#define S32K566_K566_GPR1_H_

#include "S32K566_COMMON.h"

/* ----------------------------------------------------------------------------
   -- K566_GPR1 Peripheral Access Layer
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup K566_GPR1_Peripheral_Access_Layer K566_GPR1 Peripheral Access Layer
 * @{
 */

/** K566_GPR1 - Register Layout Typedef */
typedef struct K566_GPR1_Struct {
  uint8_t RESERVED_0[4096];
  __IO uint32_t GPR_RWD_0;                         /**< Read Write DEST 0, offset: 0x1000 */
  __IO uint32_t GPR_RWD_1;                         /**< Read Write DEST 1, offset: 0x1004 */
  __IO uint32_t GPR_RWD_2;                         /**< Read Write DEST 2, offset: 0x1008 */
  __IO uint32_t GPR_RWD_3;                         /**< Read Write DEST 3, offset: 0x100C */
  __IO uint32_t GPR_RWD_4;                         /**< Read Write DEST 4, offset: 0x1010 */
  __IO uint32_t GPR_RWD_5;                         /**< Read Write DEST 5, offset: 0x1014 */
  __IO uint32_t GPR_RWD_6;                         /**< Read Write DEST 6, offset: 0x1018 */
  __IO uint32_t GPR_RWD_7;                         /**< Read Write DEST 7, offset: 0x101C */
  __IO uint32_t GPR_RWD_8;                         /**< Read Write DEST 8, offset: 0x1020 */
  __IO uint32_t GPR_RWD_9;                         /**< Read Write DEST 9, offset: 0x1024 */
  __IO uint32_t GPR_RWD_10;                        /**< Read Write DEST 10, offset: 0x1028 */
  __IO uint32_t GPR_RWD_11;                        /**< Read Write DEST 11, offset: 0x102C */
  __IO uint32_t GPR_RWD_12;                        /**< Read Write DEST 12, offset: 0x1030 */
  __IO uint32_t GPR_RWD_13;                        /**< Read Write DEST 13, offset: 0x1034 */
  __IO uint32_t GPR_RWD_14;                        /**< Read Write DEST 14, offset: 0x1038 */
  __IO uint32_t GPR_RWD_15;                        /**< Read Write DEST 15, offset: 0x103C */
  __IO uint32_t GPR_RWD_16;                        /**< Read Write DEST 16, offset: 0x1040 */
  __IO uint32_t GPR_RWD_17;                        /**< Read Write DEST 17, offset: 0x1044 */
  __IO uint32_t GPR_RWD_18;                        /**< Read Write DEST 18, offset: 0x1048 */
  uint8_t RESERVED_1[12];
  __IO uint32_t GPR_RWD_22;                        /**< Read Write DEST 22, offset: 0x1058 */
  __IO uint32_t GPR_RWD_23;                        /**< Read Write DEST 23, offset: 0x105C */
  __IO uint32_t GPR_RWD_24;                        /**< Read Write DEST 24, offset: 0x1060 */
  __IO uint32_t GPR_RWD_25;                        /**< Read Write DEST 25, offset: 0x1064 */
  __IO uint32_t GPR_RWD_26;                        /**< Read Write DEST 26, offset: 0x1068 */
  __IO uint32_t GPR_RWD_27;                        /**< Read Write DEST 27, offset: 0x106C */
  __IO uint32_t GPR_RWD_28;                        /**< Read Write DEST 28, offset: 0x1070 */
  __IO uint32_t GPR_RWD_29;                        /**< Read Write DEST 29, offset: 0x1074 */
  __IO uint32_t GPR_RWD_30;                        /**< Read Write DEST 30, offset: 0x1078 */
  uint8_t RESERVED_2[12];
  __IO uint32_t GPR_RWD_34;                        /**< Read Write DEST 34, offset: 0x1088 */
  __IO uint32_t GPR_RWD_35;                        /**< Read Write DEST 35, offset: 0x108C */
  __IO uint32_t GPR_RWD_36;                        /**< Read Write DEST 36, offset: 0x1090 */
  __IO uint32_t GPR_RWD_37;                        /**< Read Write DEST 37, offset: 0x1094 */
  __IO uint32_t GPR_RWD_38;                        /**< Read Write DEST 38, offset: 0x1098 */
  __IO uint32_t GPR_RWD_39;                        /**< Read Write DEST 39, offset: 0x109C */
  __IO uint32_t GPR_RWD_40;                        /**< Read Write DEST 40, offset: 0x10A0 */
  __IO uint32_t GPR_RWD_41;                        /**< Read Write DEST 41, offset: 0x10A4 */
  __IO uint32_t GPR_RWD_42;                        /**< Read Write DEST 42, offset: 0x10A8 */
  __IO uint32_t GPR_RWD_43;                        /**< Read Write DEST 43, offset: 0x10AC */
  uint8_t RESERVED_3[4];
  __IO uint32_t GPR_RWD_45;                        /**< Read Write DEST 40, offset: 0x10B4 */
  __IO uint32_t GPR_RWD_46;                        /**< Read Write DEST 42, offset: 0x10B8 */
  uint8_t RESERVED_4[1860];
  __I  uint32_t GPR_ROD_0;                         /**< Read Only DEST 0, offset: 0x1800 */
  __I  uint32_t GPR_ROD_1;                         /**< Read Only DEST 1, offset: 0x1804 */
  __I  uint32_t GPR_ROD_2;                         /**< Read Only DEST 2, offset: 0x1808 */
  __I  uint32_t GPR_ROD_3;                         /**< Read Only DEST 3, offset: 0x180C */
  __IO uint32_t GPR_ROD_4;                         /**< Read Only DEST 4, offset: 0x1810 */
  __IO uint32_t GPR_ROD_5;                         /**< Read Only DEST 5, offset: 0x1814 */
  __IO uint32_t GPR_ROD_6;                         /**< Read Only DEST 6, offset: 0x1818 */
  __IO uint32_t GPR_ROD_7;                         /**< Read Only DEST 7, offset: 0x181C */
  __IO uint32_t GPR_ROD_8;                         /**< Read Only DEST 8, offset: 0x1820 */
  __IO uint32_t GPR_ROD_9;                         /**< Read Only DEST 9, offset: 0x1824 */
  uint8_t RESERVED_5[32];
  __I  uint32_t GPR_ROD_11;                        /**< Read Only DEST 4, offset: 0x1848 */
  __IO uint32_t GPR_ROD_12;                        /**< Read Only DEST 5, offset: 0x184C */
  uint8_t RESERVED_6[1968];
  __IO uint32_t GPR_RWF_0;                         /**< Read Write FUNC 0, offset: 0x2000 */
  __IO uint32_t GPR_RWF_1;                         /**< Read Write FUNC 1, offset: 0x2004 */
  __IO uint32_t GPR_RWF_2;                         /**< Read Write FUNC 2, offset: 0x2008 */
  __IO uint32_t GPR_RWF_3;                         /**< Read Write FUNC 3, offset: 0x200C */
  __IO uint32_t GPR_RWF_4;                         /**< Read Write FUNC 4, offset: 0x2010 */
  __IO uint32_t GPR_RWF_5;                         /**< Read Write FUNC 5, offset: 0x2014 */
  __IO uint32_t GPR_RWF_6;                         /**< Read Write FUNC 6, offset: 0x2018 */
  __IO uint32_t GPR_RWF_7;                         /**< Read Write FUNC 7, offset: 0x201C */
  __IO uint32_t GPR_RWF_8;                         /**< Read Write FUNC 3, offset: 0x2020 */
  uint8_t RESERVED_7[2012];
  __IO uint32_t GPR_ROF_0;                         /**< Read Only FUNC 0, offset: 0x2800 */
  __I  uint32_t GPR_ROF_1;                         /**< Read Only FUNC 1, offset: 0x2804 */
  __I  uint32_t GPR_ROF_2;                         /**< Read Only FUNC 2, offset: 0x2808 */
} K566_GPR1_Type, *K566_GPR1_MemMapPtr;

/** Number of instances of the K566_GPR1 module. */
#define K566_GPR1_INSTANCE_COUNT                 (1u)

/* K566_GPR1 - Peripheral instance base addresses */
/** Peripheral GPR_1 base address */
#define IP_GPR_1_BASE                            (0x40458000u)
/** Peripheral GPR_1 base pointer */
#define IP_GPR_1                                 ((K566_GPR1_Type *)IP_GPR_1_BASE)
/** Array initializer of K566_GPR1 peripheral base addresses */
#define IP_K566_GPR1_BASE_ADDRS                  { IP_GPR_1_BASE }
/** Array initializer of K566_GPR1 peripheral base pointers */
#define IP_K566_GPR1_BASE_PTRS                   { IP_GPR_1 }

/* ----------------------------------------------------------------------------
   -- K566_GPR1 Register Masks
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup K566_GPR1_Register_Masks K566_GPR1 Register Masks
 * @{
 */

/*! @name GPR_RWD_0 - Read Write DEST 0 */
/*! @{ */

#define K566_GPR1_GPR_RWD_0_OTA_SEL_MASK         (0x20U)
#define K566_GPR1_GPR_RWD_0_OTA_SEL_SHIFT        (5U)
#define K566_GPR1_GPR_RWD_0_OTA_SEL_WIDTH        (1U)
#define K566_GPR1_GPR_RWD_0_OTA_SEL(x)           (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_OTA_SEL_SHIFT)) & K566_GPR1_GPR_RWD_0_OTA_SEL_MASK)

#define K566_GPR1_GPR_RWD_0_OTA_NUM_FIXED_LPART_MASK (0xFC0U)
#define K566_GPR1_GPR_RWD_0_OTA_NUM_FIXED_LPART_SHIFT (6U)
#define K566_GPR1_GPR_RWD_0_OTA_NUM_FIXED_LPART_WIDTH (6U)
#define K566_GPR1_GPR_RWD_0_OTA_NUM_FIXED_LPART(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_OTA_NUM_FIXED_LPART_SHIFT)) & K566_GPR1_GPR_RWD_0_OTA_NUM_FIXED_LPART_MASK)

#define K566_GPR1_GPR_RWD_0_MUX_SEL12_MASK       (0x1000U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL12_SHIFT      (12U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL12_WIDTH      (1U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL12(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_MUX_SEL12_SHIFT)) & K566_GPR1_GPR_RWD_0_MUX_SEL12_MASK)

#define K566_GPR1_GPR_RWD_0_MUX_SEL13_MASK       (0x2000U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL13_SHIFT      (13U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL13_WIDTH      (1U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL13(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_MUX_SEL13_SHIFT)) & K566_GPR1_GPR_RWD_0_MUX_SEL13_MASK)

#define K566_GPR1_GPR_RWD_0_MUX_SEL14_MASK       (0x4000U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL14_SHIFT      (14U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL14_WIDTH      (1U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL14(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_MUX_SEL14_SHIFT)) & K566_GPR1_GPR_RWD_0_MUX_SEL14_MASK)

#define K566_GPR1_GPR_RWD_0_MUX_SEL15_MASK       (0x8000U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL15_SHIFT      (15U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL15_WIDTH      (1U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL15(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_MUX_SEL15_SHIFT)) & K566_GPR1_GPR_RWD_0_MUX_SEL15_MASK)

#define K566_GPR1_GPR_RWD_0_MUX_SEL16_MASK       (0x10000U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL16_SHIFT      (16U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL16_WIDTH      (1U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL16(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_MUX_SEL16_SHIFT)) & K566_GPR1_GPR_RWD_0_MUX_SEL16_MASK)

#define K566_GPR1_GPR_RWD_0_MUX_SEL17_MASK       (0x20000U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL17_SHIFT      (17U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL17_WIDTH      (1U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL17(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_MUX_SEL17_SHIFT)) & K566_GPR1_GPR_RWD_0_MUX_SEL17_MASK)

#define K566_GPR1_GPR_RWD_0_MUX_SEL18_MASK       (0x40000U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL18_SHIFT      (18U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL18_WIDTH      (1U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL18(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_MUX_SEL18_SHIFT)) & K566_GPR1_GPR_RWD_0_MUX_SEL18_MASK)

#define K566_GPR1_GPR_RWD_0_MUX_SEL19_MASK       (0x80000U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL19_SHIFT      (19U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL19_WIDTH      (1U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL19(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_MUX_SEL19_SHIFT)) & K566_GPR1_GPR_RWD_0_MUX_SEL19_MASK)

#define K566_GPR1_GPR_RWD_0_MUX_SEL20_MASK       (0x100000U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL20_SHIFT      (20U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL20_WIDTH      (1U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL20(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_MUX_SEL20_SHIFT)) & K566_GPR1_GPR_RWD_0_MUX_SEL20_MASK)

#define K566_GPR1_GPR_RWD_0_MUX_SEL21_MASK       (0x200000U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL21_SHIFT      (21U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL21_WIDTH      (1U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL21(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_MUX_SEL21_SHIFT)) & K566_GPR1_GPR_RWD_0_MUX_SEL21_MASK)

#define K566_GPR1_GPR_RWD_0_MUX_SEL22_MASK       (0x400000U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL22_SHIFT      (22U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL22_WIDTH      (1U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL22(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_MUX_SEL22_SHIFT)) & K566_GPR1_GPR_RWD_0_MUX_SEL22_MASK)

#define K566_GPR1_GPR_RWD_0_MUX_SEL23_MASK       (0x800000U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL23_SHIFT      (23U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL23_WIDTH      (1U)
#define K566_GPR1_GPR_RWD_0_MUX_SEL23(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_MUX_SEL23_SHIFT)) & K566_GPR1_GPR_RWD_0_MUX_SEL23_MASK)

#define K566_GPR1_GPR_RWD_0_FIRC_FREQ_SEL_MASK   (0x1000000U)
#define K566_GPR1_GPR_RWD_0_FIRC_FREQ_SEL_SHIFT  (24U)
#define K566_GPR1_GPR_RWD_0_FIRC_FREQ_SEL_WIDTH  (1U)
#define K566_GPR1_GPR_RWD_0_FIRC_FREQ_SEL(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_FIRC_FREQ_SEL_SHIFT)) & K566_GPR1_GPR_RWD_0_FIRC_FREQ_SEL_MASK)

#define K566_GPR1_GPR_RWD_0_FIRC_STDBY_EN_MASK   (0x2000000U)
#define K566_GPR1_GPR_RWD_0_FIRC_STDBY_EN_SHIFT  (25U)
#define K566_GPR1_GPR_RWD_0_FIRC_STDBY_EN_WIDTH  (1U)
#define K566_GPR1_GPR_RWD_0_FIRC_STDBY_EN(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_FIRC_STDBY_EN_SHIFT)) & K566_GPR1_GPR_RWD_0_FIRC_STDBY_EN_MASK)

#define K566_GPR1_GPR_RWD_0_LOCK_EN0_MASK        (0x40000000U)
#define K566_GPR1_GPR_RWD_0_LOCK_EN0_SHIFT       (30U)
#define K566_GPR1_GPR_RWD_0_LOCK_EN0_WIDTH       (1U)
#define K566_GPR1_GPR_RWD_0_LOCK_EN0(x)          (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_LOCK_EN0_SHIFT)) & K566_GPR1_GPR_RWD_0_LOCK_EN0_MASK)

#define K566_GPR1_GPR_RWD_0_LOCK_EN1_MASK        (0x80000000U)
#define K566_GPR1_GPR_RWD_0_LOCK_EN1_SHIFT       (31U)
#define K566_GPR1_GPR_RWD_0_LOCK_EN1_WIDTH       (1U)
#define K566_GPR1_GPR_RWD_0_LOCK_EN1(x)          (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_0_LOCK_EN1_SHIFT)) & K566_GPR1_GPR_RWD_0_LOCK_EN1_MASK)
/*! @} */

/*! @name GPR_RWD_1 - Read Write DEST 1 */
/*! @{ */

#define K566_GPR1_GPR_RWD_1_CM7_0_FAULT_MASK     (0x1U)
#define K566_GPR1_GPR_RWD_1_CM7_0_FAULT_SHIFT    (0U)
#define K566_GPR1_GPR_RWD_1_CM7_0_FAULT_WIDTH    (1U)
#define K566_GPR1_GPR_RWD_1_CM7_0_FAULT(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_1_CM7_0_FAULT_SHIFT)) & K566_GPR1_GPR_RWD_1_CM7_0_FAULT_MASK)

#define K566_GPR1_GPR_RWD_1_CM7_1_FAULT_MASK     (0x2U)
#define K566_GPR1_GPR_RWD_1_CM7_1_FAULT_SHIFT    (1U)
#define K566_GPR1_GPR_RWD_1_CM7_1_FAULT_WIDTH    (1U)
#define K566_GPR1_GPR_RWD_1_CM7_1_FAULT(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_1_CM7_1_FAULT_SHIFT)) & K566_GPR1_GPR_RWD_1_CM7_1_FAULT_MASK)

#define K566_GPR1_GPR_RWD_1_CM7_2_FAULT_MASK     (0x4U)
#define K566_GPR1_GPR_RWD_1_CM7_2_FAULT_SHIFT    (2U)
#define K566_GPR1_GPR_RWD_1_CM7_2_FAULT_WIDTH    (1U)
#define K566_GPR1_GPR_RWD_1_CM7_2_FAULT(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_1_CM7_2_FAULT_SHIFT)) & K566_GPR1_GPR_RWD_1_CM7_2_FAULT_MASK)

#define K566_GPR1_GPR_RWD_1_CM7_3_FAULT_MASK     (0x8U)
#define K566_GPR1_GPR_RWD_1_CM7_3_FAULT_SHIFT    (3U)
#define K566_GPR1_GPR_RWD_1_CM7_3_FAULT_WIDTH    (1U)
#define K566_GPR1_GPR_RWD_1_CM7_3_FAULT(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_1_CM7_3_FAULT_SHIFT)) & K566_GPR1_GPR_RWD_1_CM7_3_FAULT_MASK)

#define K566_GPR1_GPR_RWD_1_CM7_0_WAIT_MASK      (0x10U)
#define K566_GPR1_GPR_RWD_1_CM7_0_WAIT_SHIFT     (4U)
#define K566_GPR1_GPR_RWD_1_CM7_0_WAIT_WIDTH     (1U)
#define K566_GPR1_GPR_RWD_1_CM7_0_WAIT(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_1_CM7_0_WAIT_SHIFT)) & K566_GPR1_GPR_RWD_1_CM7_0_WAIT_MASK)

#define K566_GPR1_GPR_RWD_1_CM7_1_WAIT_MASK      (0x20U)
#define K566_GPR1_GPR_RWD_1_CM7_1_WAIT_SHIFT     (5U)
#define K566_GPR1_GPR_RWD_1_CM7_1_WAIT_WIDTH     (1U)
#define K566_GPR1_GPR_RWD_1_CM7_1_WAIT(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_1_CM7_1_WAIT_SHIFT)) & K566_GPR1_GPR_RWD_1_CM7_1_WAIT_MASK)

#define K566_GPR1_GPR_RWD_1_CM7_2_WAIT_MASK      (0x40U)
#define K566_GPR1_GPR_RWD_1_CM7_2_WAIT_SHIFT     (6U)
#define K566_GPR1_GPR_RWD_1_CM7_2_WAIT_WIDTH     (1U)
#define K566_GPR1_GPR_RWD_1_CM7_2_WAIT(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_1_CM7_2_WAIT_SHIFT)) & K566_GPR1_GPR_RWD_1_CM7_2_WAIT_MASK)

#define K566_GPR1_GPR_RWD_1_CM7_3_WAIT_MASK      (0x80U)
#define K566_GPR1_GPR_RWD_1_CM7_3_WAIT_SHIFT     (7U)
#define K566_GPR1_GPR_RWD_1_CM7_3_WAIT_WIDTH     (1U)
#define K566_GPR1_GPR_RWD_1_CM7_3_WAIT(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_1_CM7_3_WAIT_SHIFT)) & K566_GPR1_GPR_RWD_1_CM7_3_WAIT_MASK)
/*! @} */

/*! @name GPR_RWD_2 - Read Write DEST 2 */
/*! @{ */

#define K566_GPR1_GPR_RWD_2_MUX_SEL0_MASK        (0x3U)
#define K566_GPR1_GPR_RWD_2_MUX_SEL0_SHIFT       (0U)
#define K566_GPR1_GPR_RWD_2_MUX_SEL0_WIDTH       (2U)
#define K566_GPR1_GPR_RWD_2_MUX_SEL0(x)          (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_2_MUX_SEL0_SHIFT)) & K566_GPR1_GPR_RWD_2_MUX_SEL0_MASK)

#define K566_GPR1_GPR_RWD_2_MUX_SEL1_MASK        (0xCU)
#define K566_GPR1_GPR_RWD_2_MUX_SEL1_SHIFT       (2U)
#define K566_GPR1_GPR_RWD_2_MUX_SEL1_WIDTH       (2U)
#define K566_GPR1_GPR_RWD_2_MUX_SEL1(x)          (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_2_MUX_SEL1_SHIFT)) & K566_GPR1_GPR_RWD_2_MUX_SEL1_MASK)

#define K566_GPR1_GPR_RWD_2_LOCK_EN0_MASK        (0x40000000U)
#define K566_GPR1_GPR_RWD_2_LOCK_EN0_SHIFT       (30U)
#define K566_GPR1_GPR_RWD_2_LOCK_EN0_WIDTH       (1U)
#define K566_GPR1_GPR_RWD_2_LOCK_EN0(x)          (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_2_LOCK_EN0_SHIFT)) & K566_GPR1_GPR_RWD_2_LOCK_EN0_MASK)

#define K566_GPR1_GPR_RWD_2_LOCK_EN1_MASK        (0x80000000U)
#define K566_GPR1_GPR_RWD_2_LOCK_EN1_SHIFT       (31U)
#define K566_GPR1_GPR_RWD_2_LOCK_EN1_WIDTH       (1U)
#define K566_GPR1_GPR_RWD_2_LOCK_EN1(x)          (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_2_LOCK_EN1_SHIFT)) & K566_GPR1_GPR_RWD_2_LOCK_EN1_MASK)
/*! @} */

/*! @name GPR_RWD_3 - Read Write DEST 3 */
/*! @{ */

#define K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_CLK_EN_MASK (0x1U)
#define K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_CLK_EN_SHIFT (0U)
#define K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_CLK_EN_WIDTH (1U)
#define K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_CLK_EN(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_CLK_EN_SHIFT)) & K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_CLK_EN_MASK)

#define K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_DIV_VAL_MASK (0x1FEU)
#define K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_DIV_VAL_SHIFT (1U)
#define K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_DIV_VAL_WIDTH (8U)
#define K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_DIV_VAL(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_DIV_VAL_SHIFT)) & K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_DIV_VAL_MASK)

#define K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_MUX_SEL_MASK (0x7E00U)
#define K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_MUX_SEL_SHIFT (9U)
#define K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_MUX_SEL_WIDTH (6U)
#define K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_MUX_SEL(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_MUX_SEL_SHIFT)) & K566_GPR1_GPR_RWD_3_CLOCKOUT_RUN_MUX_SEL_MASK)
/*! @} */

/*! @name GPR_RWD_4 - Read Write DEST 4 */
/*! @{ */

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE0_MASK  (0x1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE0(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE1_MASK  (0x2U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE1(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE2_MASK  (0x4U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE2(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE3_MASK  (0x8U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE3(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE4_MASK  (0x10U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE4(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE5_MASK  (0x20U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE5(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE6_MASK  (0x40U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE6(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE7_MASK  (0x80U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE7(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE8_MASK  (0x100U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE8(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE9_MASK  (0x200U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE9(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE10(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE11(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE12(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE13(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE14(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE15(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE16(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE17(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE18(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE19(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE20(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE21(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE22(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE23(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE24(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE25(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE26(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE27(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE28(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_4_DEBUG_DISABLE29(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_4_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_4_DEBUG_DISABLE29_MASK)
/*! @} */

/*! @name GPR_RWD_5 - Read Write DEST 5 */
/*! @{ */

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE0_MASK  (0x1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE0(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE1_MASK  (0x2U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE1(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE2_MASK  (0x4U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE2(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE3_MASK  (0x8U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE3(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE4_MASK  (0x10U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE4(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE5_MASK  (0x20U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE5(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE6_MASK  (0x40U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE6(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE7_MASK  (0x80U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE7(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE8_MASK  (0x100U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE8(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE9_MASK  (0x200U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE9(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE10(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE11(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE12(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE13(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE14(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE15(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE16(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE17(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE18(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE19(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE20(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE21(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE22(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE23(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE24(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE25(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE26(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE27(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE28(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE29(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE29_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE30(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE30_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE30_MASK)

#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_5_DEBUG_DISABLE31(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_5_DEBUG_DISABLE31_SHIFT)) & K566_GPR1_GPR_RWD_5_DEBUG_DISABLE31_MASK)
/*! @} */

/*! @name GPR_RWD_6 - Read Write DEST 6 */
/*! @{ */

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE0_MASK  (0x1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE0(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE1_MASK  (0x2U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE1(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE2_MASK  (0x4U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE2(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE3_MASK  (0x8U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE3(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE4_MASK  (0x10U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE4(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE5_MASK  (0x20U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE5(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE6_MASK  (0x40U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE6(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE7_MASK  (0x80U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE7(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE8_MASK  (0x100U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE8(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE9_MASK  (0x200U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE9(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE10(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE11(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE12(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE13(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE14(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE15(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_6_DEBUG_DISABLE16(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_6_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_6_DEBUG_DISABLE16_MASK)
/*! @} */

/*! @name GPR_RWD_7 - Read Write DEST 7 */
/*! @{ */

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE0_MASK  (0x1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE0(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE1_MASK  (0x2U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE1(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE2_MASK  (0x4U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE2(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE3_MASK  (0x8U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE3(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE4_MASK  (0x10U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE4(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE5_MASK  (0x20U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE5(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE6_MASK  (0x40U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE6(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE7_MASK  (0x80U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE7(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE8_MASK  (0x100U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE8(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE9_MASK  (0x200U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE9(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE10(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE11(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE12(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE13(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE14(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE15(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE16(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE17(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE18(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE19(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE20(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE21(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE22(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE23(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE24(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE25(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE26(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE27(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE28(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_7_DEBUG_DISABLE29(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_7_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_7_DEBUG_DISABLE29_MASK)
/*! @} */

/*! @name GPR_RWD_8 - Read Write DEST 8 */
/*! @{ */

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE0_MASK  (0x1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE0(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE1_MASK  (0x2U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE1(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE2_MASK  (0x4U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE2(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE3_MASK  (0x8U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE3(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE4_MASK  (0x10U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE4(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE5_MASK  (0x20U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE5(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE6_MASK  (0x40U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE6(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE7_MASK  (0x80U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE7(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE8_MASK  (0x100U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE8(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE9_MASK  (0x200U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE9(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE10(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE11(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE12(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE13(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE14(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE15(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE16(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE17(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE18(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE19(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE20(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE21(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE22(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE23(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE24(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE25(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE26(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE27(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE28(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE29(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE29_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE30(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE30_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE30_MASK)

#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_8_DEBUG_DISABLE31(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_8_DEBUG_DISABLE31_SHIFT)) & K566_GPR1_GPR_RWD_8_DEBUG_DISABLE31_MASK)
/*! @} */

/*! @name GPR_RWD_9 - Read Write DEST 9 */
/*! @{ */

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE0_MASK  (0x1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE0(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE1_MASK  (0x2U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE1(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE2_MASK  (0x4U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE2(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE3_MASK  (0x8U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE3(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE4_MASK  (0x10U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE4(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE5_MASK  (0x20U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE5(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE6_MASK  (0x40U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE6(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE7_MASK  (0x80U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE7(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE8_MASK  (0x100U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE8(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE9_MASK  (0x200U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE9(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE10(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE11(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE12(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE13(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE14(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE15(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_9_DEBUG_DISABLE16(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_9_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_9_DEBUG_DISABLE16_MASK)
/*! @} */

/*! @name GPR_RWD_10 - Read Write DEST 10 */
/*! @{ */

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_10_DEBUG_DISABLE29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_10_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_10_DEBUG_DISABLE29_MASK)
/*! @} */

/*! @name GPR_RWD_11 - Read Write DEST 11 */
/*! @{ */

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE29_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE30_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE30_MASK)

#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_11_DEBUG_DISABLE31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_11_DEBUG_DISABLE31_SHIFT)) & K566_GPR1_GPR_RWD_11_DEBUG_DISABLE31_MASK)
/*! @} */

/*! @name GPR_RWD_12 - Read Write DEST 12 */
/*! @{ */

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_12_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_12_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_12_DEBUG_DISABLE16_MASK)
/*! @} */

/*! @name GPR_RWD_13 - Read Write DEST 13 */
/*! @{ */

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_13_DEBUG_DISABLE29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_13_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_13_DEBUG_DISABLE29_MASK)
/*! @} */

/*! @name GPR_RWD_14 - Read Write DEST 14 */
/*! @{ */

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE29_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE30_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE30_MASK)

#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_14_DEBUG_DISABLE31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_14_DEBUG_DISABLE31_SHIFT)) & K566_GPR1_GPR_RWD_14_DEBUG_DISABLE31_MASK)
/*! @} */

/*! @name GPR_RWD_15 - Read Write DEST 15 */
/*! @{ */

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_15_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_15_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_15_DEBUG_DISABLE16_MASK)
/*! @} */

/*! @name GPR_RWD_16 - Read Write DEST 16 */
/*! @{ */

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_16_DEBUG_DISABLE29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_16_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_16_DEBUG_DISABLE29_MASK)
/*! @} */

/*! @name GPR_RWD_17 - Read Write DEST 17 */
/*! @{ */

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE29_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE30_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE30_MASK)

#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_17_DEBUG_DISABLE31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_17_DEBUG_DISABLE31_SHIFT)) & K566_GPR1_GPR_RWD_17_DEBUG_DISABLE31_MASK)
/*! @} */

/*! @name GPR_RWD_18 - Read Write DEST 18 */
/*! @{ */

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_18_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_18_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_18_DEBUG_DISABLE16_MASK)
/*! @} */

/*! @name GPR_RWD_22 - Read Write DEST 22 */
/*! @{ */

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_22_DEBUG_DISABLE29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_22_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_22_DEBUG_DISABLE29_MASK)
/*! @} */

/*! @name GPR_RWD_23 - Read Write DEST 23 */
/*! @{ */

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE29_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE30_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE30_MASK)

#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_23_DEBUG_DISABLE31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_23_DEBUG_DISABLE31_SHIFT)) & K566_GPR1_GPR_RWD_23_DEBUG_DISABLE31_MASK)
/*! @} */

/*! @name GPR_RWD_24 - Read Write DEST 24 */
/*! @{ */

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_24_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_24_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_24_DEBUG_DISABLE16_MASK)
/*! @} */

/*! @name GPR_RWD_25 - Read Write DEST 25 */
/*! @{ */

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_25_DEBUG_DISABLE29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_25_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_25_DEBUG_DISABLE29_MASK)
/*! @} */

/*! @name GPR_RWD_26 - Read Write DEST 26 */
/*! @{ */

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE29_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE30_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE30_MASK)

#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_26_DEBUG_DISABLE31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_26_DEBUG_DISABLE31_SHIFT)) & K566_GPR1_GPR_RWD_26_DEBUG_DISABLE31_MASK)
/*! @} */

/*! @name GPR_RWD_27 - Read Write DEST 27 */
/*! @{ */

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_27_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_27_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_27_DEBUG_DISABLE16_MASK)
/*! @} */

/*! @name GPR_RWD_28 - Read Write DEST 28 */
/*! @{ */

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_28_DEBUG_DISABLE29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_28_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_28_DEBUG_DISABLE29_MASK)
/*! @} */

/*! @name GPR_RWD_29 - Read Write DEST 29 */
/*! @{ */

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE16_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE17_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE17_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE18_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE18_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE19_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE19_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE20_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE20_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE21_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE21_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE22_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE22_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE23_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE23_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE24_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE24_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE25_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE25_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE26_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE26_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE27_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE27_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE28_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE28_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE29_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE29_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE30_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE30_MASK)

#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_29_DEBUG_DISABLE31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_29_DEBUG_DISABLE31_SHIFT)) & K566_GPR1_GPR_RWD_29_DEBUG_DISABLE31_MASK)
/*! @} */

/*! @name GPR_RWD_30 - Read Write DEST 30 */
/*! @{ */

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE0_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE0_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE1_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE1_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE2_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE2_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE3_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE3_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE4_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE4_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE5_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE5_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE6_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE6_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE7_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE7_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE8_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE8_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE9_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE9_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE10_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE10_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE11_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE11_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE12_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE12_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE13_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE13_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE14_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE14_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE15_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE15_MASK)

#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_30_DEBUG_DISABLE16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_30_DEBUG_DISABLE16_SHIFT)) & K566_GPR1_GPR_RWD_30_DEBUG_DISABLE16_MASK)
/*! @} */

/*! @name GPR_RWD_34 - Read Write DEST 34 */
/*! @{ */

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN0_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN0_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN1_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN1_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN2_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN2_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN3_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN3_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN4_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN4_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN5_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN5_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN6_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN6_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN7_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN7_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN8_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN8_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN9_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN9_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN10_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN10_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN11_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN11_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN12_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN12_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN13_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN13_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN14_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN14_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN15_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN15_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN16_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN16_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN17_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN17_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN18_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN18_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN19_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN19_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN20_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN20_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN21_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN21_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN22_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN22_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN23_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN23_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN24_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN24_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN25_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN25_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN26_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN26_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN27_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN27_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN28_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN28_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN29_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN29_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN30_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN30_MASK)

#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN31_SHIFT)) & K566_GPR1_GPR_RWD_34_FAULT_CH_A_EN31_MASK)
/*! @} */

/*! @name GPR_RWD_35 - Read Write DEST 35 */
/*! @{ */

#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN0_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN0_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN1_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN1_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN2_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN2_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN3_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN3_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN4_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN4_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN5_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN5_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN6_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN6_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN7_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN7_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN8_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN8_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN9_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN9_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN10_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN10_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN11_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN11_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN12_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_A_EN12_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN13_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN13_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN14_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN14_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN15_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN15_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN16_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN16_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN17_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN17_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN18_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN18_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN19_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN19_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN20_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN20_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN21_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN21_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN22_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN22_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN23_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN23_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN24_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN24_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN25_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN25_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN26_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN26_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN27_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN27_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN28_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN28_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN29_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN29_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN30_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN30_MASK)

#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN31_SHIFT)) & K566_GPR1_GPR_RWD_35_FAULT_CH_B_EN31_MASK)
/*! @} */

/*! @name GPR_RWD_36 - Read Write DEST 36 */
/*! @{ */

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN0_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN0_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN1_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN1_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN2_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN2_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN3_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN3_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN4_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN4_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN5_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN5_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN6_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN6_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN7_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN7_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN8_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN8_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN9_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN9_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN10_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN10_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN11_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN11_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN12_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN12_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN13_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN13_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN14_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN14_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN15_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN15_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN16_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN16_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN17_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN17_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN18_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN18_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN19_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN19_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN20_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN20_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN21_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN21_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN22_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN22_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN23_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN23_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN24_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN24_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN25_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_B_EN25_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN26_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN26_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN27_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN27_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN28_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN28_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN29_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN29_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN30_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN30_MASK)

#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN31_SHIFT)) & K566_GPR1_GPR_RWD_36_FAULT_CH_A_EN31_MASK)
/*! @} */

/*! @name GPR_RWD_37 - Read Write DEST 37 */
/*! @{ */

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN0_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN0_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN1_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN1_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN2_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN2_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN3_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN3_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN4_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN4_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN5_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN5_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN6_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN6_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN7_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN7_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN8_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN8_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN9_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN9_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN10_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN10_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN11_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN11_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN12_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN12_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN13_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN13_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN14_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN14_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN15_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN15_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN16_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN16_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN17_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN17_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN18_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN18_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN19_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN19_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN20_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN20_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN21_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN21_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN22_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN22_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN23_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN23_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN24_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN24_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN25_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN25_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN26_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN26_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN27_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN27_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN28_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN28_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN29_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN29_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN30_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN30_MASK)

#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN31_SHIFT)) & K566_GPR1_GPR_RWD_37_FAULT_CH_A_EN31_MASK)
/*! @} */

/*! @name GPR_RWD_38 - Read Write DEST 38 */
/*! @{ */

#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN0_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN0_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN1_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN1_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN2_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN2_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN3_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN3_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN4_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN4_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN5_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN5_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN6_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN6_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN7_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_A_EN7_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN8_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN8_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN9_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN9_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN10_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN10_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN11_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN11_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN12_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN12_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN13_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN13_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN14_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN14_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN15_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN15_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN16_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN16_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN17_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN17_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN18_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN18_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN19_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN19_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN20_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN20_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN21_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN21_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN22_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN22_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN23_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN23_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN24_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN24_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN25_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN25_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN26_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN26_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN27_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN27_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN28_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN28_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN29_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN29_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN30_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN30_MASK)

#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN31_SHIFT)) & K566_GPR1_GPR_RWD_38_FAULT_CH_B_EN31_MASK)
/*! @} */

/*! @name GPR_RWD_39 - Read Write DEST 39 */
/*! @{ */

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN0_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN0_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN1_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN1_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN2_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN2_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN3_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN3_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN4_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN4_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN5_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN5_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN6_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN6_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN7_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN7_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN8_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN8_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN9_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN9_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN10_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN10_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN11_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN11_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN12_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN12_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN13_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN13_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN14_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN14_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN15_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN15_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN16_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN16_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN17_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN17_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN18_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN18_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN19_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN19_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN20_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN20_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN21_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_B_EN21_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN22_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN22_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN23_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN23_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN24_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN24_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN25_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN25_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN26_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN26_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN27_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN27_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN28_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN28_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN29_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN29_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN30_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN30_MASK)

#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN31_SHIFT)) & K566_GPR1_GPR_RWD_39_FAULT_CH_A_EN31_MASK)
/*! @} */

/*! @name GPR_RWD_40 - Read Write DEST 40 */
/*! @{ */

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN0_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN0_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN1_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN1_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN2_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN2_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN3_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN3_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN4_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN4_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN5_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN5_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN6_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN6_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN7_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN7_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN8_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN8_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN9_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN9_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN10_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN10_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN11_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN11_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN12_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN12_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN13_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN13_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN14_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN14_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN15_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN15_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN16_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN16_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN17_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN17_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN18_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN18_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN19_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN19_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN20_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN20_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN21_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN21_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN22_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN22_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN23_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN23_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN24_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN24_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN25_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN25_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN26_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN26_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN27_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN27_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN28_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN28_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN29_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN29_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN30_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN30_MASK)

#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN31_SHIFT)) & K566_GPR1_GPR_RWD_40_FAULT_CH_A_EN31_MASK)
/*! @} */

/*! @name GPR_RWD_41 - Read Write DEST 41 */
/*! @{ */

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN0_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN0_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN1_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN1_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN2_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN2_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN3_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN3_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN4_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN4_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN5_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN5_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN6_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN6_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN7_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN7_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN8_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN8_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN9_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN9_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN10_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN10_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN11_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN11_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN12_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN12_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN13_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN13_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN14_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN14_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN15_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN15_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN16_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN16_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN17_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_A_EN17_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN18_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN18_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN19_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN19_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN20_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN20_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN21_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN21_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN22_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN22_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN23_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN23_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN24_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN24_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN25_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN25_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN26_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN26_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN27_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN27_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN28_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN28_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN29_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN29_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN30_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN30_MASK)

#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN31_SHIFT)) & K566_GPR1_GPR_RWD_41_FAULT_CH_B_EN31_MASK)
/*! @} */

/*! @name GPR_RWD_42 - Read Write DEST 42 */
/*! @{ */

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN0_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN0_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN1_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN1_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN2_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN2_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN3_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN3_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN4_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN4_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN5_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN5_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN6_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN6_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN7_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN7_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN8_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN8_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN9_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN9_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN10_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN10_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN11_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN11_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN12_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN12_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN13_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN13_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN14_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN14_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN15_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN15_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN16_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN16_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN17_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN17_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN18_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN18_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN19_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN19_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN20_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN20_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN21_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN21_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN22_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN22_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN23_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN23_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN24_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN24_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN25_MASK (0x2000000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN25_SHIFT (25U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN25_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN25(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN25_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN25_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN26_MASK (0x4000000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN26_SHIFT (26U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN26_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN26(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN26_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN26_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN27_SHIFT (27U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN27_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN27_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN27_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN28_SHIFT (28U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN28_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN28_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN28_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN29_SHIFT (29U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN29_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN29_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN29_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN30_SHIFT (30U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN30_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN30_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN30_MASK)

#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN31_SHIFT (31U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN31_WIDTH (1U)
#define K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN31_SHIFT)) & K566_GPR1_GPR_RWD_42_FAULT_CH_B_EN31_MASK)
/*! @} */

/*! @name GPR_RWD_43 - Read Write DEST 43 */
/*! @{ */

#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN0_SHIFT)) & K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN0_MASK)

#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN1_SHIFT)) & K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN1_MASK)

#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN2_SHIFT)) & K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN2_MASK)

#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN3_SHIFT)) & K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN3_MASK)

#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN4_SHIFT)) & K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN4_MASK)

#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN5_SHIFT)) & K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN5_MASK)

#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN6_SHIFT)) & K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN6_MASK)

#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN7_SHIFT)) & K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN7_MASK)

#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN8_SHIFT)) & K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN8_MASK)

#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN9_SHIFT)) & K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN9_MASK)

#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN10_SHIFT)) & K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN10_MASK)

#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN11_SHIFT)) & K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN11_MASK)

#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN12_SHIFT)) & K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN12_MASK)

#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN13_SHIFT)) & K566_GPR1_GPR_RWD_43_FAULT_CH_B_EN13_MASK)
/*! @} */

/*! @name GPR_RWD_45 - Read Write DEST 40 */
/*! @{ */

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN0_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN0_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN1_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN1_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN2_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN2_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN3_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN3_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN4_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN4_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN5_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN5_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN6_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN6_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN7_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN7_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN8_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN8_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN9_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN9_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN10_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN10_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN11_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN11_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN12_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN12_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN13_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN13_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN14_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN14_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN15_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN15_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN16_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN16_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN17_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN17_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN18_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN18_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN19_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN19_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN20_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN20_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN21_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN21_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN22_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN22_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN23_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN23_MASK)

#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN24_SHIFT)) & K566_GPR1_GPR_RWD_45_FAULT_CH_A_EN24_MASK)
/*! @} */

/*! @name GPR_RWD_46 - Read Write DEST 42 */
/*! @{ */

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN0_MASK (0x1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN0_SHIFT (0U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN0_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN0(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN0_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN0_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN1_MASK (0x2U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN1_SHIFT (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN1_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN1(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN1_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN1_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN2_MASK (0x4U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN2_SHIFT (2U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN2_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN2(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN2_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN2_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN3_MASK (0x8U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN3_SHIFT (3U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN3_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN3(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN3_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN3_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN4_MASK (0x10U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN4_SHIFT (4U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN4_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN4(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN4_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN4_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN5_MASK (0x20U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN5_SHIFT (5U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN5_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN5(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN5_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN5_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN6_MASK (0x40U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN6_SHIFT (6U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN6_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN6(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN6_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN6_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN7_MASK (0x80U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN7_SHIFT (7U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN7_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN7_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN7_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN8_MASK (0x100U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN8_SHIFT (8U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN8_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN8(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN8_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN8_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN9_MASK (0x200U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN9_SHIFT (9U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN9_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN9(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN9_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN9_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN10_MASK (0x400U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN10_SHIFT (10U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN10_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN10(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN10_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN10_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN11_MASK (0x800U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN11_SHIFT (11U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN11_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN11(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN11_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN11_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN12_MASK (0x1000U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN12_SHIFT (12U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN12_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN12(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN12_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN12_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN13_MASK (0x2000U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN13_SHIFT (13U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN13_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN13(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN13_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN13_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN14_MASK (0x4000U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN14_SHIFT (14U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN14_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN14(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN14_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN14_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN15_MASK (0x8000U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN15_SHIFT (15U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN15_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN15(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN15_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN15_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN16_MASK (0x10000U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN16_SHIFT (16U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN16_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN16(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN16_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN16_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN17_MASK (0x20000U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN17_SHIFT (17U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN17_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN17(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN17_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN17_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN18_MASK (0x40000U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN18_SHIFT (18U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN18_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN18_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN18_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN19_MASK (0x80000U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN19_SHIFT (19U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN19_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN19_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN19_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN20_MASK (0x100000U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN20_SHIFT (20U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN20_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN20_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN20_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN21_MASK (0x200000U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN21_SHIFT (21U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN21_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN21_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN21_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN22_MASK (0x400000U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN22_SHIFT (22U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN22_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN22_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN22_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN23_MASK (0x800000U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN23_SHIFT (23U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN23_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN23_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN23_MASK)

#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN24_MASK (0x1000000U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN24_SHIFT (24U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN24_WIDTH (1U)
#define K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN24(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN24_SHIFT)) & K566_GPR1_GPR_RWD_46_FAULT_CH_B_EN24_MASK)
/*! @} */

/*! @name GPR_ROD_0 - Read Only DEST 0 */
/*! @{ */

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE0_MASK (0x1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE0_SHIFT (0U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE0_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE0_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE0_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE1_MASK (0x2U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE1_SHIFT (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE1_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE1_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE1_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE2_MASK (0x4U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE2_SHIFT (2U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE2_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE2(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE2_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE2_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE3_MASK (0x8U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE3_SHIFT (3U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE3_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE3(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE3_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE3_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE4_MASK (0x10U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE4_SHIFT (4U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE4_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE4(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE4_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE4_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE5_MASK (0x20U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE5_SHIFT (5U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE5_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE5(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE5_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE5_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE6_MASK (0x40U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE6_SHIFT (6U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE6_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE6(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE6_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE6_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE7_MASK (0x80U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE7_SHIFT (7U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE7_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE7(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE7_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE7_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE8_MASK (0x100U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE8_SHIFT (8U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE8_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE8(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE8_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE8_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE9_MASK (0x200U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE9_SHIFT (9U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE9_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE9(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE9_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE9_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE10_MASK (0x400U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE10_SHIFT (10U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE10_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE10(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE10_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE10_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE11_MASK (0x800U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE11_SHIFT (11U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE11_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE11(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE11_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE11_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE12_MASK (0x1000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE12_SHIFT (12U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE12_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE12(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE12_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE12_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE13_MASK (0x2000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE13_SHIFT (13U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE13_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE13(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE13_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE13_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE14_MASK (0x4000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE14_SHIFT (14U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE14_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE14(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE14_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE14_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE15_MASK (0x8000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE15_SHIFT (15U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE15_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE15(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE15_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE15_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE16_MASK (0x10000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE16_SHIFT (16U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE16_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE16(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE16_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE16_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE17_MASK (0x20000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE17_SHIFT (17U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE17_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE17(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE17_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE17_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE18_MASK (0x40000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE18_SHIFT (18U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE18_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE18(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE18_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE18_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE19_MASK (0x80000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE19_SHIFT (19U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE19_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE19(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE19_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE19_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE20_MASK (0x100000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE20_SHIFT (20U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE20_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE20(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE20_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE20_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE21_MASK (0x200000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE21_SHIFT (21U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE21_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE21(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE21_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE21_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE22_MASK (0x400000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE22_SHIFT (22U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE22_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE22(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE22_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE22_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE23_MASK (0x800000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE23_SHIFT (23U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE23_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE23(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE23_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE23_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE24_MASK (0x1000000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE24_SHIFT (24U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE24_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE24(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE24_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE24_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE25_MASK (0x2000000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE25_SHIFT (25U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE25_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE25(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE25_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE25_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE26_MASK (0x4000000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE26_SHIFT (26U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE26_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE26(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE26_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE26_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE27_MASK (0x8000000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE27_SHIFT (27U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE27_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE27(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE27_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE27_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE28_MASK (0x10000000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE28_SHIFT (28U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE28_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE28(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE28_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE28_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE29_MASK (0x20000000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE29_SHIFT (29U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE29_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE29(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE29_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE29_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE30_MASK (0x40000000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE30_SHIFT (30U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE30_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE30(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE30_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE30_MASK)

#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE31_MASK (0x80000000U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE31_SHIFT (31U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE31_WIDTH (1U)
#define K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE31(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE31_SHIFT)) & K566_GPR1_GPR_ROD_0_CURRENT_INJ_ACTIVE31_MASK)
/*! @} */

/*! @name GPR_ROD_1 - Read Only DEST 1 */
/*! @{ */

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE0_MASK (0x1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE0_SHIFT (0U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE0_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE0_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE0_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE1_MASK (0x2U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE1_SHIFT (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE1_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE1_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE1_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE2_MASK (0x4U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE2_SHIFT (2U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE2_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE2(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE2_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE2_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE3_MASK (0x8U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE3_SHIFT (3U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE3_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE3(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE3_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE3_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE4_MASK (0x10U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE4_SHIFT (4U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE4_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE4(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE4_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE4_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE5_MASK (0x20U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE5_SHIFT (5U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE5_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE5(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE5_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE5_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE6_MASK (0x40U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE6_SHIFT (6U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE6_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE6(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE6_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE6_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE7_MASK (0x80U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE7_SHIFT (7U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE7_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE7(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE7_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE7_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE8_MASK (0x100U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE8_SHIFT (8U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE8_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE8(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE8_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE8_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE9_MASK (0x200U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE9_SHIFT (9U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE9_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE9(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE9_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE9_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE10_MASK (0x400U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE10_SHIFT (10U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE10_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE10(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE10_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE10_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE11_MASK (0x800U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE11_SHIFT (11U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE11_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE11(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE11_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE11_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE12_MASK (0x1000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE12_SHIFT (12U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE12_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE12(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE12_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE12_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE13_MASK (0x2000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE13_SHIFT (13U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE13_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE13(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE13_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE13_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE14_MASK (0x4000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE14_SHIFT (14U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE14_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE14(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE14_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE14_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE15_MASK (0x8000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE15_SHIFT (15U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE15_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE15(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE15_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE15_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE16_MASK (0x10000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE16_SHIFT (16U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE16_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE16(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE16_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE16_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE17_MASK (0x20000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE17_SHIFT (17U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE17_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE17(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE17_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE17_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE18_MASK (0x40000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE18_SHIFT (18U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE18_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE18(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE18_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE18_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE19_MASK (0x80000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE19_SHIFT (19U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE19_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE19(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE19_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE19_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE20_MASK (0x100000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE20_SHIFT (20U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE20_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE20(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE20_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE20_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE21_MASK (0x200000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE21_SHIFT (21U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE21_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE21(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE21_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE21_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE22_MASK (0x400000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE22_SHIFT (22U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE22_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE22(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE22_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE22_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE23_MASK (0x800000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE23_SHIFT (23U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE23_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE23(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE23_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE23_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE24_MASK (0x1000000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE24_SHIFT (24U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE24_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE24(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE24_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE24_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE25_MASK (0x2000000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE25_SHIFT (25U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE25_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE25(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE25_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE25_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE26_MASK (0x4000000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE26_SHIFT (26U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE26_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE26(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE26_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE26_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE27_MASK (0x8000000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE27_SHIFT (27U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE27_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE27(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE27_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE27_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE28_MASK (0x10000000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE28_SHIFT (28U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE28_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE28(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE28_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE28_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE29_MASK (0x20000000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE29_SHIFT (29U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE29_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE29(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE29_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE29_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE30_MASK (0x40000000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE30_SHIFT (30U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE30_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE30(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE30_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE30_MASK)

#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE31_MASK (0x80000000U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE31_SHIFT (31U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE31_WIDTH (1U)
#define K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE31(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE31_SHIFT)) & K566_GPR1_GPR_ROD_1_CURRENT_INJ_ACTIVE31_MASK)
/*! @} */

/*! @name GPR_ROD_2 - Read Only DEST 2 */
/*! @{ */

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE0_MASK (0x1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE0_SHIFT (0U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE0_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE0_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE0_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE1_MASK (0x2U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE1_SHIFT (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE1_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE1_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE1_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE2_MASK (0x4U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE2_SHIFT (2U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE2_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE2(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE2_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE2_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE3_MASK (0x8U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE3_SHIFT (3U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE3_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE3(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE3_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE3_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE4_MASK (0x10U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE4_SHIFT (4U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE4_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE4(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE4_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE4_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE5_MASK (0x20U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE5_SHIFT (5U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE5_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE5(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE5_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE5_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE6_MASK (0x40U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE6_SHIFT (6U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE6_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE6(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE6_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE6_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE7_MASK (0x80U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE7_SHIFT (7U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE7_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE7(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE7_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE7_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE8_MASK (0x100U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE8_SHIFT (8U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE8_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE8(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE8_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE8_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE9_MASK (0x200U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE9_SHIFT (9U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE9_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE9(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE9_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE9_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE10_MASK (0x400U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE10_SHIFT (10U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE10_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE10(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE10_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE10_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE11_MASK (0x800U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE11_SHIFT (11U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE11_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE11(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE11_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE11_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE12_MASK (0x1000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE12_SHIFT (12U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE12_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE12(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE12_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE12_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE13_MASK (0x2000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE13_SHIFT (13U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE13_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE13(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE13_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE13_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE14_MASK (0x4000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE14_SHIFT (14U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE14_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE14(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE14_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE14_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE15_MASK (0x8000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE15_SHIFT (15U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE15_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE15(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE15_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE15_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE16_MASK (0x10000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE16_SHIFT (16U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE16_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE16(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE16_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE16_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE17_MASK (0x20000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE17_SHIFT (17U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE17_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE17(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE17_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE17_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE18_MASK (0x40000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE18_SHIFT (18U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE18_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE18(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE18_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE18_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE19_MASK (0x80000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE19_SHIFT (19U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE19_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE19(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE19_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE19_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE20_MASK (0x100000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE20_SHIFT (20U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE20_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE20(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE20_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE20_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE21_MASK (0x200000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE21_SHIFT (21U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE21_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE21(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE21_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE21_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE22_MASK (0x400000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE22_SHIFT (22U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE22_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE22(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE22_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE22_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE23_MASK (0x800000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE23_SHIFT (23U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE23_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE23(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE23_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE23_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE24_MASK (0x1000000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE24_SHIFT (24U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE24_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE24(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE24_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE24_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE25_MASK (0x2000000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE25_SHIFT (25U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE25_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE25(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE25_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE25_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE26_MASK (0x4000000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE26_SHIFT (26U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE26_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE26(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE26_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE26_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE27_MASK (0x8000000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE27_SHIFT (27U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE27_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE27(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE27_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE27_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE28_MASK (0x10000000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE28_SHIFT (28U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE28_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE28(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE28_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE28_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE29_MASK (0x20000000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE29_SHIFT (29U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE29_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE29(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE29_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE29_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE30_MASK (0x40000000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE30_SHIFT (30U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE30_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE30(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE30_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE30_MASK)

#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE31_MASK (0x80000000U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE31_SHIFT (31U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE31_WIDTH (1U)
#define K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE31(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE31_SHIFT)) & K566_GPR1_GPR_ROD_2_CURRENT_INJ_ACTIVE31_MASK)
/*! @} */

/*! @name GPR_ROD_3 - Read Only DEST 3 */
/*! @{ */

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE0_MASK (0x1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE0_SHIFT (0U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE0_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE0_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE0_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE1_MASK (0x2U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE1_SHIFT (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE1_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE1_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE1_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE2_MASK (0x4U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE2_SHIFT (2U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE2_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE2(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE2_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE2_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE3_MASK (0x8U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE3_SHIFT (3U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE3_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE3(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE3_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE3_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE4_MASK (0x10U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE4_SHIFT (4U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE4_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE4(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE4_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE4_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE5_MASK (0x20U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE5_SHIFT (5U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE5_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE5(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE5_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE5_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE6_MASK (0x40U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE6_SHIFT (6U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE6_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE6(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE6_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE6_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE7_MASK (0x80U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE7_SHIFT (7U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE7_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE7(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE7_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE7_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE8_MASK (0x100U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE8_SHIFT (8U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE8_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE8(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE8_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE8_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE9_MASK (0x200U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE9_SHIFT (9U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE9_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE9(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE9_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE9_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE10_MASK (0x400U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE10_SHIFT (10U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE10_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE10(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE10_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE10_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE11_MASK (0x800U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE11_SHIFT (11U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE11_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE11(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE11_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE11_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE12_MASK (0x1000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE12_SHIFT (12U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE12_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE12(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE12_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE12_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE13_MASK (0x2000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE13_SHIFT (13U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE13_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE13(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE13_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE13_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE14_MASK (0x4000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE14_SHIFT (14U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE14_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE14(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE14_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE14_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE15_MASK (0x8000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE15_SHIFT (15U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE15_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE15(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE15_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE15_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE16_MASK (0x10000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE16_SHIFT (16U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE16_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE16(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE16_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE16_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE17_MASK (0x20000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE17_SHIFT (17U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE17_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE17(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE17_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE17_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE18_MASK (0x40000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE18_SHIFT (18U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE18_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE18(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE18_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE18_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE19_MASK (0x80000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE19_SHIFT (19U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE19_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE19(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE19_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE19_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE20_MASK (0x100000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE20_SHIFT (20U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE20_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE20(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE20_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE20_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE21_MASK (0x200000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE21_SHIFT (21U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE21_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE21(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE21_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE21_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE22_MASK (0x400000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE22_SHIFT (22U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE22_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE22(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE22_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE22_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE23_MASK (0x800000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE23_SHIFT (23U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE23_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE23(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE23_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE23_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE24_MASK (0x1000000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE24_SHIFT (24U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE24_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE24(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE24_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE24_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE25_MASK (0x2000000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE25_SHIFT (25U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE25_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE25(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE25_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE25_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE26_MASK (0x4000000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE26_SHIFT (26U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE26_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE26(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE26_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE26_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE27_MASK (0x8000000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE27_SHIFT (27U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE27_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE27(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE27_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE27_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE28_MASK (0x10000000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE28_SHIFT (28U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE28_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE28(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE28_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE28_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE29_MASK (0x20000000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE29_SHIFT (29U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE29_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE29(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE29_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE29_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE30_MASK (0x40000000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE30_SHIFT (30U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE30_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE30(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE30_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE30_MASK)

#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE31_MASK (0x80000000U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE31_SHIFT (31U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE31_WIDTH (1U)
#define K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE31(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE31_SHIFT)) & K566_GPR1_GPR_ROD_3_CURRENT_INJ_ACTIVE31_MASK)
/*! @} */

/*! @name GPR_ROD_4 - Read Only DEST 4 */
/*! @{ */

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE0_MASK (0x1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE0_SHIFT (0U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE0_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE0_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE0_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE1_MASK (0x2U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE1_SHIFT (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE1_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE1_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE1_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE2_MASK (0x4U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE2_SHIFT (2U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE2_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE2(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE2_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE2_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE3_MASK (0x8U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE3_SHIFT (3U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE3_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE3(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE3_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE3_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE4_MASK (0x10U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE4_SHIFT (4U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE4_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE4(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE4_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE4_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE5_MASK (0x20U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE5_SHIFT (5U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE5_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE5(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE5_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE5_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE6_MASK (0x40U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE6_SHIFT (6U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE6_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE6(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE6_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE6_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE7_MASK (0x80U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE7_SHIFT (7U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE7_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE7(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE7_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE7_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE8_MASK (0x100U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE8_SHIFT (8U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE8_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE8(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE8_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE8_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE9_MASK (0x200U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE9_SHIFT (9U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE9_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE9(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE9_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE9_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE10_MASK (0x400U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE10_SHIFT (10U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE10_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE10(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE10_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE10_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE11_MASK (0x800U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE11_SHIFT (11U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE11_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE11(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE11_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE11_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE12_MASK (0x1000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE12_SHIFT (12U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE12_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE12(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE12_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE12_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE13_MASK (0x2000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE13_SHIFT (13U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE13_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE13(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE13_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE13_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE14_MASK (0x4000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE14_SHIFT (14U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE14_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE14(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE14_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE14_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE15_MASK (0x8000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE15_SHIFT (15U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE15_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE15(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE15_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE15_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE16_MASK (0x10000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE16_SHIFT (16U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE16_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE16(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE16_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE16_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE17_MASK (0x20000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE17_SHIFT (17U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE17_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE17(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE17_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE17_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE18_MASK (0x40000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE18_SHIFT (18U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE18_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE18(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE18_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE18_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE19_MASK (0x80000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE19_SHIFT (19U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE19_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE19(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE19_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE19_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE20_MASK (0x100000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE20_SHIFT (20U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE20_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE20(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE20_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE20_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE21_MASK (0x200000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE21_SHIFT (21U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE21_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE21(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE21_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE21_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE22_MASK (0x400000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE22_SHIFT (22U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE22_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE22(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE22_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_ACTIVE22_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE23_MASK (0x800000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE23_SHIFT (23U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE23_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE23(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE23_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE23_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE24_MASK (0x1000000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE24_SHIFT (24U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE24_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE24(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE24_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE24_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE25_MASK (0x2000000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE25_SHIFT (25U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE25_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE25(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE25_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE25_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE26_MASK (0x4000000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE26_SHIFT (26U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE26_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE26(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE26_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE26_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE27_MASK (0x8000000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE27_SHIFT (27U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE27_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE27(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE27_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE27_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE28_MASK (0x10000000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE28_SHIFT (28U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE28_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE28(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE28_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE28_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE29_MASK (0x20000000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE29_SHIFT (29U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE29_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE29(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE29_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE29_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE30_MASK (0x40000000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE30_SHIFT (30U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE30_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE30(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE30_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE30_MASK)

#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE31_MASK (0x80000000U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE31_SHIFT (31U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE31_WIDTH (1U)
#define K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE31(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE31_SHIFT)) & K566_GPR1_GPR_ROD_4_CURRENT_INJ_COMPLETE31_MASK)
/*! @} */

/*! @name GPR_ROD_5 - Read Only DEST 5 */
/*! @{ */

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE0_MASK (0x1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE0_SHIFT (0U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE0_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE0_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE0_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE1_MASK (0x2U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE1_SHIFT (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE1_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE1_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE1_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE2_MASK (0x4U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE2_SHIFT (2U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE2_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE2(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE2_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE2_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE3_MASK (0x8U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE3_SHIFT (3U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE3_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE3(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE3_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE3_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE4_MASK (0x10U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE4_SHIFT (4U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE4_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE4(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE4_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE4_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE5_MASK (0x20U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE5_SHIFT (5U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE5_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE5(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE5_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE5_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE6_MASK (0x40U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE6_SHIFT (6U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE6_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE6(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE6_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE6_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE7_MASK (0x80U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE7_SHIFT (7U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE7_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE7(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE7_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE7_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE8_MASK (0x100U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE8_SHIFT (8U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE8_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE8(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE8_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE8_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE9_MASK (0x200U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE9_SHIFT (9U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE9_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE9(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE9_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE9_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE10_MASK (0x400U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE10_SHIFT (10U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE10_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE10(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE10_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE10_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE11_MASK (0x800U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE11_SHIFT (11U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE11_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE11(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE11_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE11_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE12_MASK (0x1000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE12_SHIFT (12U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE12_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE12(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE12_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE12_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE13_MASK (0x2000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE13_SHIFT (13U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE13_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE13(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE13_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE13_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE14_MASK (0x4000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE14_SHIFT (14U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE14_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE14(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE14_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE14_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE15_MASK (0x8000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE15_SHIFT (15U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE15_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE15(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE15_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE15_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE16_MASK (0x10000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE16_SHIFT (16U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE16_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE16(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE16_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE16_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE17_MASK (0x20000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE17_SHIFT (17U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE17_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE17(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE17_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE17_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE18_MASK (0x40000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE18_SHIFT (18U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE18_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE18(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE18_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE18_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE19_MASK (0x80000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE19_SHIFT (19U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE19_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE19(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE19_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE19_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE20_MASK (0x100000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE20_SHIFT (20U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE20_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE20(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE20_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE20_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE21_MASK (0x200000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE21_SHIFT (21U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE21_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE21(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE21_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE21_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE22_MASK (0x400000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE22_SHIFT (22U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE22_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE22(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE22_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE22_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE23_MASK (0x800000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE23_SHIFT (23U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE23_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE23(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE23_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE23_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE24_MASK (0x1000000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE24_SHIFT (24U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE24_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE24(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE24_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE24_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE25_MASK (0x2000000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE25_SHIFT (25U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE25_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE25(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE25_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE25_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE26_MASK (0x4000000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE26_SHIFT (26U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE26_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE26(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE26_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE26_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE27_MASK (0x8000000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE27_SHIFT (27U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE27_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE27(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE27_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE27_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE28_MASK (0x10000000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE28_SHIFT (28U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE28_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE28(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE28_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE28_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE29_MASK (0x20000000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE29_SHIFT (29U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE29_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE29(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE29_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE29_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE30_MASK (0x40000000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE30_SHIFT (30U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE30_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE30(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE30_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE30_MASK)

#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE31_MASK (0x80000000U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE31_SHIFT (31U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE31_WIDTH (1U)
#define K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE31(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE31_SHIFT)) & K566_GPR1_GPR_ROD_5_CURRENT_INJ_COMPLETE31_MASK)
/*! @} */

/*! @name GPR_ROD_6 - Read Only DEST 6 */
/*! @{ */

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE0_MASK (0x1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE0_SHIFT (0U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE0_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE0_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE0_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE1_MASK (0x2U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE1_SHIFT (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE1_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE1_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE1_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE2_MASK (0x4U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE2_SHIFT (2U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE2_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE2(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE2_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE2_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE3_MASK (0x8U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE3_SHIFT (3U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE3_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE3(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE3_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE3_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE4_MASK (0x10U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE4_SHIFT (4U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE4_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE4(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE4_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE4_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE5_MASK (0x20U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE5_SHIFT (5U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE5_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE5(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE5_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE5_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE6_MASK (0x40U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE6_SHIFT (6U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE6_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE6(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE6_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE6_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE7_MASK (0x80U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE7_SHIFT (7U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE7_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE7(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE7_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE7_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE8_MASK (0x100U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE8_SHIFT (8U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE8_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE8(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE8_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE8_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE10_MASK (0x400U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE10_SHIFT (10U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE10_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE10(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE10_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE10_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE11_MASK (0x800U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE11_SHIFT (11U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE11_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE11(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE11_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE11_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE12_MASK (0x1000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE12_SHIFT (12U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE12_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE12(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE12_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE12_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE13_MASK (0x2000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE13_SHIFT (13U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE13_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE13(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE13_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE13_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE14_MASK (0x4000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE14_SHIFT (14U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE14_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE14(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE14_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE14_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE15_MASK (0x8000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE15_SHIFT (15U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE15_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE15(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE15_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE15_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE16_MASK (0x10000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE16_SHIFT (16U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE16_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE16(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE16_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE16_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE17_MASK (0x20000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE17_SHIFT (17U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE17_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE17(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE17_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE17_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE18_MASK (0x40000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE18_SHIFT (18U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE18_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE18(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE18_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE18_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE19_MASK (0x80000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE19_SHIFT (19U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE19_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE19(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE19_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE19_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE20_MASK (0x100000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE20_SHIFT (20U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE20_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE20(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE20_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE20_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE21_MASK (0x200000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE21_SHIFT (21U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE21_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE21(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE21_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE21_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE22_MASK (0x400000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE22_SHIFT (22U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE22_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE22(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE22_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE22_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE23_MASK (0x800000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE23_SHIFT (23U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE23_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE23(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE23_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE23_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE24_MASK (0x1000000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE24_SHIFT (24U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE24_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE24(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE24_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE24_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE25_MASK (0x2000000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE25_SHIFT (25U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE25_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE25(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE25_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE25_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE26_MASK (0x4000000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE26_SHIFT (26U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE26_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE26(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE26_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE26_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE27_MASK (0x8000000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE27_SHIFT (27U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE27_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE27(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE27_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE27_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE28_MASK (0x10000000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE28_SHIFT (28U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE28_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE28(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE28_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE28_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE29_MASK (0x20000000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE29_SHIFT (29U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE29_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE29(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE29_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE29_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE30_MASK (0x40000000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE30_SHIFT (30U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE30_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE30(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE30_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE30_MASK)

#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE31_MASK (0x80000000U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE31_SHIFT (31U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE31_WIDTH (1U)
#define K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE31(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE31_SHIFT)) & K566_GPR1_GPR_ROD_6_CURRENT_INJ_COMPLETE31_MASK)
/*! @} */

/*! @name GPR_ROD_7 - Read Only DEST 7 */
/*! @{ */

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE0_MASK (0x1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE0_SHIFT (0U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE0_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE0_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE0_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE1_MASK (0x2U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE1_SHIFT (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE1_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE1_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE1_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE2_MASK (0x4U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE2_SHIFT (2U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE2_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE2(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE2_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE2_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE3_MASK (0x8U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE3_SHIFT (3U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE3_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE3(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE3_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE3_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE4_MASK (0x10U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE4_SHIFT (4U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE4_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE4(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE4_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE4_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE5_MASK (0x20U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE5_SHIFT (5U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE5_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE5(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE5_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE5_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE6_MASK (0x40U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE6_SHIFT (6U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE6_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE6(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE6_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE6_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE7_MASK (0x80U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE7_SHIFT (7U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE7_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE7(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE7_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE7_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE8_MASK (0x100U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE8_SHIFT (8U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE8_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE8(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE8_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE8_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE9_MASK (0x200U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE9_SHIFT (9U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE9_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE9(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE9_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE9_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE10_MASK (0x400U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE10_SHIFT (10U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE10_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE10(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE10_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE10_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE11_MASK (0x800U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE11_SHIFT (11U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE11_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE11(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE11_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE11_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE12_MASK (0x1000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE12_SHIFT (12U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE12_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE12(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE12_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE12_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE13_MASK (0x2000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE13_SHIFT (13U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE13_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE13(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE13_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE13_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE14_MASK (0x4000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE14_SHIFT (14U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE14_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE14(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE14_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE14_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE15_MASK (0x8000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE15_SHIFT (15U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE15_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE15(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE15_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE15_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE16_MASK (0x10000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE16_SHIFT (16U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE16_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE16(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE16_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE16_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE17_MASK (0x20000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE17_SHIFT (17U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE17_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE17(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE17_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE17_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE18_MASK (0x40000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE18_SHIFT (18U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE18_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE18(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE18_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE18_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE19_MASK (0x80000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE19_SHIFT (19U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE19_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE19(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE19_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE19_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE20_MASK (0x100000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE20_SHIFT (20U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE20_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE20(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE20_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE20_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE21_MASK (0x200000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE21_SHIFT (21U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE21_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE21(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE21_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE21_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE22_MASK (0x400000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE22_SHIFT (22U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE22_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE22(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE22_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE22_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE23_MASK (0x800000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE23_SHIFT (23U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE23_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE23(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE23_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE23_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE24_MASK (0x1000000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE24_SHIFT (24U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE24_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE24(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE24_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE24_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE25_MASK (0x2000000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE25_SHIFT (25U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE25_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE25(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE25_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE25_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE26_MASK (0x4000000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE26_SHIFT (26U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE26_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE26(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE26_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE26_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE27_MASK (0x8000000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE27_SHIFT (27U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE27_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE27(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE27_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE27_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE28_MASK (0x10000000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE28_SHIFT (28U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE28_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE28(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE28_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE28_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE30_MASK (0x40000000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE30_SHIFT (30U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE30_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE30(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE30_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE30_MASK)

#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE31_MASK (0x80000000U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE31_SHIFT (31U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE31_WIDTH (1U)
#define K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE31(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE31_SHIFT)) & K566_GPR1_GPR_ROD_7_CURRENT_INJ_COMPLETE31_MASK)
/*! @} */

/*! @name GPR_ROD_8 - Read Only DEST 8 */
/*! @{ */

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE0_MASK (0x1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE0_SHIFT (0U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE0_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE0_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE0_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE1_MASK (0x2U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE1_SHIFT (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE1_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE1_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE1_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE2_MASK (0x4U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE2_SHIFT (2U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE2_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE2(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE2_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE2_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE3_MASK (0x8U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE3_SHIFT (3U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE3_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE3(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE3_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE3_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE4_MASK (0x10U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE4_SHIFT (4U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE4_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE4(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE4_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE4_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE5_MASK (0x20U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE5_SHIFT (5U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE5_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE5(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE5_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE5_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE6_MASK (0x40U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE6_SHIFT (6U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE6_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE6(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE6_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE6_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE7_MASK (0x80U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE7_SHIFT (7U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE7_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE7(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE7_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE7_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE8_MASK (0x100U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE8_SHIFT (8U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE8_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE8(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE8_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE8_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE9_MASK (0x200U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE9_SHIFT (9U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE9_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE9(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE9_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE9_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE10_MASK (0x400U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE10_SHIFT (10U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE10_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE10(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE10_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE10_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE11_MASK (0x800U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE11_SHIFT (11U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE11_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE11(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE11_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE11_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE12_MASK (0x1000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE12_SHIFT (12U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE12_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE12(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE12_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE12_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE13_MASK (0x2000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE13_SHIFT (13U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE13_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE13(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE13_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE13_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE14_MASK (0x4000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE14_SHIFT (14U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE14_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE14(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE14_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE14_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE15_MASK (0x8000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE15_SHIFT (15U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE15_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE15(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE15_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE15_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE16_MASK (0x10000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE16_SHIFT (16U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE16_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE16(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE16_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE16_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE17_MASK (0x20000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE17_SHIFT (17U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE17_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE17(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE17_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE17_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE18_MASK (0x40000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE18_SHIFT (18U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE18_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE18(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE18_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE18_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE19_MASK (0x80000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE19_SHIFT (19U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE19_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE19(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE19_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE19_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE20_MASK (0x100000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE20_SHIFT (20U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE20_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE20(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE20_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE20_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE21_MASK (0x200000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE21_SHIFT (21U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE21_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE21(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE21_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE21_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE22_MASK (0x400000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE22_SHIFT (22U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE22_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE22(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE22_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE22_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE23_MASK (0x800000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE23_SHIFT (23U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE23_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE23(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE23_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE23_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE24_MASK (0x1000000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE24_SHIFT (24U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE24_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE24(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE24_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE24_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE25_MASK (0x2000000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE25_SHIFT (25U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE25_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE25(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE25_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE25_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE26_MASK (0x4000000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE26_SHIFT (26U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE26_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE26(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE26_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE26_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE27_MASK (0x8000000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE27_SHIFT (27U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE27_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE27(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE27_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE27_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE28_MASK (0x10000000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE28_SHIFT (28U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE28_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE28(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE28_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE28_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE29_MASK (0x20000000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE29_SHIFT (29U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE29_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE29(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE29_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE29_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE30_MASK (0x40000000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE30_SHIFT (30U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE30_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE30(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE30_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE30_MASK)

#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE31_MASK (0x80000000U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE31_SHIFT (31U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE31_WIDTH (1U)
#define K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE31(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE31_SHIFT)) & K566_GPR1_GPR_ROD_8_CURRENT_INJ_COMPLETE31_MASK)
/*! @} */

/*! @name GPR_ROD_9 - Read Only DEST 9 */
/*! @{ */

#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE0_MASK (0x1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE0_SHIFT (0U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE0_WIDTH (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE0_SHIFT)) & K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE0_MASK)

#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE1_MASK (0x2U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE1_SHIFT (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE1_WIDTH (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE1_SHIFT)) & K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE1_MASK)

#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE2_MASK (0x4U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE2_SHIFT (2U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE2_WIDTH (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE2(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE2_SHIFT)) & K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE2_MASK)

#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE3_MASK (0x8U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE3_SHIFT (3U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE3_WIDTH (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE3(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE3_SHIFT)) & K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE3_MASK)

#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE4_MASK (0x10U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE4_SHIFT (4U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE4_WIDTH (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE4(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE4_SHIFT)) & K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE4_MASK)

#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE5_MASK (0x20U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE5_SHIFT (5U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE5_WIDTH (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE5(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE5_SHIFT)) & K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE5_MASK)

#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE6_MASK (0x40U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE6_SHIFT (6U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE6_WIDTH (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE6(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE6_SHIFT)) & K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE6_MASK)

#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE7_MASK (0x80U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE7_SHIFT (7U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE7_WIDTH (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE7(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE7_SHIFT)) & K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE7_MASK)

#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE8_MASK (0x100U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE8_SHIFT (8U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE8_WIDTH (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE8(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE8_SHIFT)) & K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE8_MASK)

#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE9_MASK (0x200U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE9_SHIFT (9U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE9_WIDTH (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE9(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE9_SHIFT)) & K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE9_MASK)

#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE10_MASK (0x400U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE10_SHIFT (10U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE10_WIDTH (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE10(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE10_SHIFT)) & K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE10_MASK)

#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE11_MASK (0x800U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE11_SHIFT (11U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE11_WIDTH (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE11(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE11_SHIFT)) & K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE11_MASK)

#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE12_MASK (0x1000U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE12_SHIFT (12U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE12_WIDTH (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE12(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE12_SHIFT)) & K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE12_MASK)

#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE13_MASK (0x2000U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE13_SHIFT (13U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE13_WIDTH (1U)
#define K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE13(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE13_SHIFT)) & K566_GPR1_GPR_ROD_9_CURRENT_INJ_COMPLETE13_MASK)
/*! @} */

/*! @name GPR_ROD_11 - Read Only DEST 4 */
/*! @{ */

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE0_MASK (0x1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE0_SHIFT (0U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE0_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE0_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE0_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE1_MASK (0x2U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE1_SHIFT (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE1_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE1_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE1_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE2_MASK (0x4U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE2_SHIFT (2U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE2_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE2(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE2_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE2_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE3_MASK (0x8U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE3_SHIFT (3U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE3_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE3(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE3_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE3_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE4_MASK (0x10U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE4_SHIFT (4U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE4_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE4(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE4_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE4_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE5_MASK (0x20U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE5_SHIFT (5U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE5_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE5(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE5_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE5_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE6_MASK (0x40U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE6_SHIFT (6U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE6_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE6(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE6_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE6_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE7_MASK (0x80U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE7_SHIFT (7U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE7_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE7(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE7_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE7_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE8_MASK (0x100U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE8_SHIFT (8U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE8_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE8(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE8_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE8_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE11_MASK (0x200U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE11_SHIFT (9U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE11_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE11(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE11_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE11_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE12_MASK (0x400U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE12_SHIFT (10U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE12_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE12(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE12_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE12_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE13_MASK (0x800U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE13_SHIFT (11U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE13_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE13(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE13_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE13_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE14_MASK (0x1000U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE14_SHIFT (12U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE14_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE14(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE14_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE14_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE15_MASK (0x2000U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE15_SHIFT (13U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE15_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE15(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE15_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE15_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE16_MASK (0x4000U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE16_SHIFT (14U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE16_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE16(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE16_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE16_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE17_MASK (0x8000U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE17_SHIFT (15U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE17_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE17(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE17_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE17_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE18_MASK (0x10000U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE18_SHIFT (16U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE18_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE18(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE18_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE18_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE19_MASK (0x20000U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE19_SHIFT (17U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE19_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE19(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE19_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE19_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE20_MASK (0x40000U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE20_SHIFT (18U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE20_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE20(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE20_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE20_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE21_MASK (0x80000U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE21_SHIFT (19U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE21_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE21(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE21_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE21_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE22_MASK (0x100000U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE22_SHIFT (20U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE22_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE22(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE22_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE22_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE23_MASK (0x200000U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE23_SHIFT (21U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE23_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE23(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE23_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE23_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE24_MASK (0x400000U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE24_SHIFT (22U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE24_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE24(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE24_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE24_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE9_MASK (0x800000U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE9_SHIFT (23U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE9_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE9(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE9_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE9_MASK)

#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE10_MASK (0x1000000U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE10_SHIFT (24U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE10_WIDTH (1U)
#define K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE10(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE10_SHIFT)) & K566_GPR1_GPR_ROD_11_CURRENT_INJ_ACTIVE10_MASK)
/*! @} */

/*! @name GPR_ROD_12 - Read Only DEST 5 */
/*! @{ */

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE0_MASK (0x1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE0_SHIFT (0U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE0_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE0_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE0_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE1_MASK (0x2U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE1_SHIFT (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE1_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE1_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE1_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE2_MASK (0x4U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE2_SHIFT (2U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE2_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE2(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE2_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE2_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE3_MASK (0x8U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE3_SHIFT (3U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE3_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE3(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE3_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE3_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE4_MASK (0x10U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE4_SHIFT (4U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE4_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE4(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE4_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE4_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE5_MASK (0x20U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE5_SHIFT (5U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE5_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE5(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE5_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE5_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE6_MASK (0x40U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE6_SHIFT (6U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE6_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE6(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE6_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE6_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE7_MASK (0x80U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE7_SHIFT (7U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE7_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE7(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE7_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE7_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE8_MASK (0x100U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE8_SHIFT (8U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE8_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE8(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE8_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE8_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE9_MASK (0x200U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE9_SHIFT (9U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE9_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE9(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE9_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE9_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE10_MASK (0x400U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE10_SHIFT (10U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE10_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE10(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE10_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE10_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE11_MASK (0x800U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE11_SHIFT (11U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE11_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE11(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE11_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE11_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE12_MASK (0x1000U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE12_SHIFT (12U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE12_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE12(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE12_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE12_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE13_MASK (0x2000U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE13_SHIFT (13U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE13_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE13(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE13_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE13_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE14_MASK (0x4000U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE14_SHIFT (14U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE14_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE14(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE14_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE14_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE15_MASK (0x8000U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE15_SHIFT (15U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE15_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE15(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE15_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE15_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE16_MASK (0x10000U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE16_SHIFT (16U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE16_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE16(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE16_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE16_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE17_MASK (0x20000U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE17_SHIFT (17U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE17_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE17(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE17_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE17_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE18_MASK (0x40000U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE18_SHIFT (18U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE18_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE18(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE18_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE18_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE19_MASK (0x80000U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE19_SHIFT (19U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE19_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE19(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE19_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE19_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE20_MASK (0x100000U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE20_SHIFT (20U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE20_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE20(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE20_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE20_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE21_MASK (0x200000U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE21_SHIFT (21U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE21_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE21(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE21_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE21_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE22_MASK (0x400000U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE22_SHIFT (22U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE22_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE22(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE22_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE22_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE23_MASK (0x800000U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE23_SHIFT (23U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE23_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE23(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE23_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE23_MASK)

#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE24_MASK (0x1000000U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE24_SHIFT (24U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE24_WIDTH (1U)
#define K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE24(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE24_SHIFT)) & K566_GPR1_GPR_ROD_12_CURRENT_INJ_COMPLETE24_MASK)
/*! @} */

/*! @name GPR_RWF_0 - Read Write FUNC 0 */
/*! @{ */

#define K566_GPR1_GPR_RWF_0_AXI_ACC_PORT_FD_REQ_MASK (0x1U)
#define K566_GPR1_GPR_RWF_0_AXI_ACC_PORT_FD_REQ_SHIFT (0U)
#define K566_GPR1_GPR_RWF_0_AXI_ACC_PORT_FD_REQ_WIDTH (1U)
#define K566_GPR1_GPR_RWF_0_AXI_ACC_PORT_FD_REQ(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_AXI_ACC_PORT_FD_REQ_SHIFT)) & K566_GPR1_GPR_RWF_0_AXI_ACC_PORT_FD_REQ_MASK)

#define K566_GPR1_GPR_RWF_0_CORE0_FD_REQ_MASK    (0x2U)
#define K566_GPR1_GPR_RWF_0_CORE0_FD_REQ_SHIFT   (1U)
#define K566_GPR1_GPR_RWF_0_CORE0_FD_REQ_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_0_CORE0_FD_REQ(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_CORE0_FD_REQ_SHIFT)) & K566_GPR1_GPR_RWF_0_CORE0_FD_REQ_MASK)

#define K566_GPR1_GPR_RWF_0_CORE1_FD_REQ_MASK    (0x4U)
#define K566_GPR1_GPR_RWF_0_CORE1_FD_REQ_SHIFT   (2U)
#define K566_GPR1_GPR_RWF_0_CORE1_FD_REQ_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_0_CORE1_FD_REQ(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_CORE1_FD_REQ_SHIFT)) & K566_GPR1_GPR_RWF_0_CORE1_FD_REQ_MASK)

#define K566_GPR1_GPR_RWF_0_CORE2_FD_REQ_MASK    (0x8U)
#define K566_GPR1_GPR_RWF_0_CORE2_FD_REQ_SHIFT   (3U)
#define K566_GPR1_GPR_RWF_0_CORE2_FD_REQ_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_0_CORE2_FD_REQ(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_CORE2_FD_REQ_SHIFT)) & K566_GPR1_GPR_RWF_0_CORE2_FD_REQ_MASK)

#define K566_GPR1_GPR_RWF_0_CORE3_FD_REQ_MASK    (0x10U)
#define K566_GPR1_GPR_RWF_0_CORE3_FD_REQ_SHIFT   (4U)
#define K566_GPR1_GPR_RWF_0_CORE3_FD_REQ_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_0_CORE3_FD_REQ(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_CORE3_FD_REQ_SHIFT)) & K566_GPR1_GPR_RWF_0_CORE3_FD_REQ_MASK)

#define K566_GPR1_GPR_RWF_0_ETR_FD_REQ_MASK      (0x20U)
#define K566_GPR1_GPR_RWF_0_ETR_FD_REQ_SHIFT     (5U)
#define K566_GPR1_GPR_RWF_0_ETR_FD_REQ_WIDTH     (1U)
#define K566_GPR1_GPR_RWF_0_ETR_FD_REQ(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_ETR_FD_REQ_SHIFT)) & K566_GPR1_GPR_RWF_0_ETR_FD_REQ_MASK)

#define K566_GPR1_GPR_RWF_0_NUM_ZONE_MASK        (0xE00U)
#define K566_GPR1_GPR_RWF_0_NUM_ZONE_SHIFT       (9U)
#define K566_GPR1_GPR_RWF_0_NUM_ZONE_WIDTH       (3U)
#define K566_GPR1_GPR_RWF_0_NUM_ZONE(x)          (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_NUM_ZONE_SHIFT)) & K566_GPR1_GPR_RWF_0_NUM_ZONE_MASK)

#define K566_GPR1_GPR_RWF_0_TCM_XBAR_FAULT_ACK12_MASK (0x1000U)
#define K566_GPR1_GPR_RWF_0_TCM_XBAR_FAULT_ACK12_SHIFT (12U)
#define K566_GPR1_GPR_RWF_0_TCM_XBAR_FAULT_ACK12_WIDTH (1U)
#define K566_GPR1_GPR_RWF_0_TCM_XBAR_FAULT_ACK12(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_TCM_XBAR_FAULT_ACK12_SHIFT)) & K566_GPR1_GPR_RWF_0_TCM_XBAR_FAULT_ACK12_MASK)

#define K566_GPR1_GPR_RWF_0_AXBS_XBAR_FAULT_ACK13_MASK (0x2000U)
#define K566_GPR1_GPR_RWF_0_AXBS_XBAR_FAULT_ACK13_SHIFT (13U)
#define K566_GPR1_GPR_RWF_0_AXBS_XBAR_FAULT_ACK13_WIDTH (1U)
#define K566_GPR1_GPR_RWF_0_AXBS_XBAR_FAULT_ACK13(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_AXBS_XBAR_FAULT_ACK13_SHIFT)) & K566_GPR1_GPR_RWF_0_AXBS_XBAR_FAULT_ACK13_MASK)

#define K566_GPR1_GPR_RWF_0_PERIPH_XBAR_FAULT_ACK14_MASK (0x4000U)
#define K566_GPR1_GPR_RWF_0_PERIPH_XBAR_FAULT_ACK14_SHIFT (14U)
#define K566_GPR1_GPR_RWF_0_PERIPH_XBAR_FAULT_ACK14_WIDTH (1U)
#define K566_GPR1_GPR_RWF_0_PERIPH_XBAR_FAULT_ACK14(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_PERIPH_XBAR_FAULT_ACK14_SHIFT)) & K566_GPR1_GPR_RWF_0_PERIPH_XBAR_FAULT_ACK14_MASK)

#define K566_GPR1_GPR_RWF_0_ADC_CH18_MASK        (0x40000U)
#define K566_GPR1_GPR_RWF_0_ADC_CH18_SHIFT       (18U)
#define K566_GPR1_GPR_RWF_0_ADC_CH18_WIDTH       (1U)
#define K566_GPR1_GPR_RWF_0_ADC_CH18(x)          (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_ADC_CH18_SHIFT)) & K566_GPR1_GPR_RWF_0_ADC_CH18_MASK)

#define K566_GPR1_GPR_RWF_0_ADC_CH19_MASK        (0x80000U)
#define K566_GPR1_GPR_RWF_0_ADC_CH19_SHIFT       (19U)
#define K566_GPR1_GPR_RWF_0_ADC_CH19_WIDTH       (1U)
#define K566_GPR1_GPR_RWF_0_ADC_CH19(x)          (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_ADC_CH19_SHIFT)) & K566_GPR1_GPR_RWF_0_ADC_CH19_MASK)

#define K566_GPR1_GPR_RWF_0_ADC_CH20_MASK        (0x100000U)
#define K566_GPR1_GPR_RWF_0_ADC_CH20_SHIFT       (20U)
#define K566_GPR1_GPR_RWF_0_ADC_CH20_WIDTH       (1U)
#define K566_GPR1_GPR_RWF_0_ADC_CH20(x)          (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_ADC_CH20_SHIFT)) & K566_GPR1_GPR_RWF_0_ADC_CH20_MASK)

#define K566_GPR1_GPR_RWF_0_ADC_CH21_MASK        (0x200000U)
#define K566_GPR1_GPR_RWF_0_ADC_CH21_SHIFT       (21U)
#define K566_GPR1_GPR_RWF_0_ADC_CH21_WIDTH       (1U)
#define K566_GPR1_GPR_RWF_0_ADC_CH21(x)          (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_ADC_CH21_SHIFT)) & K566_GPR1_GPR_RWF_0_ADC_CH21_MASK)

#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN0_MASK  (0x400000U)
#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN0_SHIFT (22U)
#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN0_WIDTH (1U)
#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN0(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_SAFE_STATE_EN0_SHIFT)) & K566_GPR1_GPR_RWF_0_SAFE_STATE_EN0_MASK)

#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN1_MASK  (0x800000U)
#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN1_SHIFT (23U)
#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN1_WIDTH (1U)
#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN1(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_SAFE_STATE_EN1_SHIFT)) & K566_GPR1_GPR_RWF_0_SAFE_STATE_EN1_MASK)

#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN2_MASK  (0x1000000U)
#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN2_SHIFT (24U)
#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN2_WIDTH (1U)
#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN2(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_SAFE_STATE_EN2_SHIFT)) & K566_GPR1_GPR_RWF_0_SAFE_STATE_EN2_MASK)

#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN3_MASK  (0x2000000U)
#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN3_SHIFT (25U)
#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN3_WIDTH (1U)
#define K566_GPR1_GPR_RWF_0_SAFE_STATE_EN3(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_SAFE_STATE_EN3_SHIFT)) & K566_GPR1_GPR_RWF_0_SAFE_STATE_EN3_MASK)

#define K566_GPR1_GPR_RWF_0_CORE0_TCM_BLOCK_MASK (0x8000000U)
#define K566_GPR1_GPR_RWF_0_CORE0_TCM_BLOCK_SHIFT (27U)
#define K566_GPR1_GPR_RWF_0_CORE0_TCM_BLOCK_WIDTH (1U)
#define K566_GPR1_GPR_RWF_0_CORE0_TCM_BLOCK(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_CORE0_TCM_BLOCK_SHIFT)) & K566_GPR1_GPR_RWF_0_CORE0_TCM_BLOCK_MASK)

#define K566_GPR1_GPR_RWF_0_CORE1_TCM_BLOCK_MASK (0x10000000U)
#define K566_GPR1_GPR_RWF_0_CORE1_TCM_BLOCK_SHIFT (28U)
#define K566_GPR1_GPR_RWF_0_CORE1_TCM_BLOCK_WIDTH (1U)
#define K566_GPR1_GPR_RWF_0_CORE1_TCM_BLOCK(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_CORE1_TCM_BLOCK_SHIFT)) & K566_GPR1_GPR_RWF_0_CORE1_TCM_BLOCK_MASK)

#define K566_GPR1_GPR_RWF_0_CORE2_TCM_BLOCK_MASK (0x20000000U)
#define K566_GPR1_GPR_RWF_0_CORE2_TCM_BLOCK_SHIFT (29U)
#define K566_GPR1_GPR_RWF_0_CORE2_TCM_BLOCK_WIDTH (1U)
#define K566_GPR1_GPR_RWF_0_CORE2_TCM_BLOCK(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_CORE2_TCM_BLOCK_SHIFT)) & K566_GPR1_GPR_RWF_0_CORE2_TCM_BLOCK_MASK)

#define K566_GPR1_GPR_RWF_0_CORE3_TCM_BLOCK_MASK (0x40000000U)
#define K566_GPR1_GPR_RWF_0_CORE3_TCM_BLOCK_SHIFT (30U)
#define K566_GPR1_GPR_RWF_0_CORE3_TCM_BLOCK_WIDTH (1U)
#define K566_GPR1_GPR_RWF_0_CORE3_TCM_BLOCK(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_0_CORE3_TCM_BLOCK_SHIFT)) & K566_GPR1_GPR_RWF_0_CORE3_TCM_BLOCK_MASK)
/*! @} */

/*! @name GPR_RWF_1 - Read Write FUNC 1 */
/*! @{ */

#define K566_GPR1_GPR_RWF_1_SSI0_BLACK_HOLE_MASK (0x1U)
#define K566_GPR1_GPR_RWF_1_SSI0_BLACK_HOLE_SHIFT (0U)
#define K566_GPR1_GPR_RWF_1_SSI0_BLACK_HOLE_WIDTH (1U)
#define K566_GPR1_GPR_RWF_1_SSI0_BLACK_HOLE(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_SSI0_BLACK_HOLE_SHIFT)) & K566_GPR1_GPR_RWF_1_SSI0_BLACK_HOLE_MASK)

#define K566_GPR1_GPR_RWF_1_SSI0_PAUSE_MASK      (0x2U)
#define K566_GPR1_GPR_RWF_1_SSI0_PAUSE_SHIFT     (1U)
#define K566_GPR1_GPR_RWF_1_SSI0_PAUSE_WIDTH     (1U)
#define K566_GPR1_GPR_RWF_1_SSI0_PAUSE(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_SSI0_PAUSE_SHIFT)) & K566_GPR1_GPR_RWF_1_SSI0_PAUSE_MASK)

#define K566_GPR1_GPR_RWF_1_SSI0_ISO_CTRL_MASK   (0x8U)
#define K566_GPR1_GPR_RWF_1_SSI0_ISO_CTRL_SHIFT  (3U)
#define K566_GPR1_GPR_RWF_1_SSI0_ISO_CTRL_WIDTH  (1U)
#define K566_GPR1_GPR_RWF_1_SSI0_ISO_CTRL(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_SSI0_ISO_CTRL_SHIFT)) & K566_GPR1_GPR_RWF_1_SSI0_ISO_CTRL_MASK)

#define K566_GPR1_GPR_RWF_1_SSI1_ISO_CTRL_MASK   (0x20U)
#define K566_GPR1_GPR_RWF_1_SSI1_ISO_CTRL_SHIFT  (5U)
#define K566_GPR1_GPR_RWF_1_SSI1_ISO_CTRL_WIDTH  (1U)
#define K566_GPR1_GPR_RWF_1_SSI1_ISO_CTRL(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_SSI1_ISO_CTRL_SHIFT)) & K566_GPR1_GPR_RWF_1_SSI1_ISO_CTRL_MASK)

#define K566_GPR1_GPR_RWF_1_SSI2_ISO_CTRL_MASK   (0x100U)
#define K566_GPR1_GPR_RWF_1_SSI2_ISO_CTRL_SHIFT  (8U)
#define K566_GPR1_GPR_RWF_1_SSI2_ISO_CTRL_WIDTH  (1U)
#define K566_GPR1_GPR_RWF_1_SSI2_ISO_CTRL(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_SSI2_ISO_CTRL_SHIFT)) & K566_GPR1_GPR_RWF_1_SSI2_ISO_CTRL_MASK)

#define K566_GPR1_GPR_RWF_1_SSI3_ISO_CTRL_MASK   (0x800U)
#define K566_GPR1_GPR_RWF_1_SSI3_ISO_CTRL_SHIFT  (11U)
#define K566_GPR1_GPR_RWF_1_SSI3_ISO_CTRL_WIDTH  (1U)
#define K566_GPR1_GPR_RWF_1_SSI3_ISO_CTRL(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_SSI3_ISO_CTRL_SHIFT)) & K566_GPR1_GPR_RWF_1_SSI3_ISO_CTRL_MASK)

#define K566_GPR1_GPR_RWF_1_NPU_DISABLE_MASK     (0x4000U)
#define K566_GPR1_GPR_RWF_1_NPU_DISABLE_SHIFT    (14U)
#define K566_GPR1_GPR_RWF_1_NPU_DISABLE_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_1_NPU_DISABLE(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_NPU_DISABLE_SHIFT)) & K566_GPR1_GPR_RWF_1_NPU_DISABLE_MASK)

#define K566_GPR1_GPR_RWF_1_CURR_INJ_CLEAR_MASK  (0x8000U)
#define K566_GPR1_GPR_RWF_1_CURR_INJ_CLEAR_SHIFT (15U)
#define K566_GPR1_GPR_RWF_1_CURR_INJ_CLEAR_WIDTH (1U)
#define K566_GPR1_GPR_RWF_1_CURR_INJ_CLEAR(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_CURR_INJ_CLEAR_SHIFT)) & K566_GPR1_GPR_RWF_1_CURR_INJ_CLEAR_MASK)

#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN0_MASK   (0x200000U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN0_SHIFT  (21U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN0_WIDTH  (1U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN0(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_TIME_BASE_EN0_SHIFT)) & K566_GPR1_GPR_RWF_1_TIME_BASE_EN0_MASK)

#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN1_MASK   (0x400000U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN1_SHIFT  (22U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN1_WIDTH  (1U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN1(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_TIME_BASE_EN1_SHIFT)) & K566_GPR1_GPR_RWF_1_TIME_BASE_EN1_MASK)

#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN2_MASK   (0x800000U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN2_SHIFT  (23U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN2_WIDTH  (1U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN2(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_TIME_BASE_EN2_SHIFT)) & K566_GPR1_GPR_RWF_1_TIME_BASE_EN2_MASK)

#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN3_MASK   (0x1000000U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN3_SHIFT  (24U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN3_WIDTH  (1U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN3(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_TIME_BASE_EN3_SHIFT)) & K566_GPR1_GPR_RWF_1_TIME_BASE_EN3_MASK)

#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN4_MASK   (0x2000000U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN4_SHIFT  (25U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN4_WIDTH  (1U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN4(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_TIME_BASE_EN4_SHIFT)) & K566_GPR1_GPR_RWF_1_TIME_BASE_EN4_MASK)

#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN5_MASK   (0x4000000U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN5_SHIFT  (26U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN5_WIDTH  (1U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN5(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_TIME_BASE_EN5_SHIFT)) & K566_GPR1_GPR_RWF_1_TIME_BASE_EN5_MASK)

#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN6_MASK   (0x8000000U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN6_SHIFT  (27U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN6_WIDTH  (1U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN6(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_TIME_BASE_EN6_SHIFT)) & K566_GPR1_GPR_RWF_1_TIME_BASE_EN6_MASK)

#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN7_MASK   (0x10000000U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN7_SHIFT  (28U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN7_WIDTH  (1U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN7(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_TIME_BASE_EN7_SHIFT)) & K566_GPR1_GPR_RWF_1_TIME_BASE_EN7_MASK)

#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN8_MASK   (0x20000000U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN8_SHIFT  (29U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN8_WIDTH  (1U)
#define K566_GPR1_GPR_RWF_1_TIME_BASE_EN8(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_1_TIME_BASE_EN8_SHIFT)) & K566_GPR1_GPR_RWF_1_TIME_BASE_EN8_MASK)
/*! @} */

/*! @name GPR_RWF_2 - Read Write FUNC 2 */
/*! @{ */

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL0_MASK     (0x1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL0_SHIFT    (0U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL0_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL0(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL0_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL0_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL1_MASK     (0x2U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL1_SHIFT    (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL1_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL1(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL1_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL1_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL2_MASK     (0x4U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL2_SHIFT    (2U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL2_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL2(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL2_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL2_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL3_MASK     (0x8U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL3_SHIFT    (3U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL3_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL3(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL3_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL3_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL4_MASK     (0x10U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL4_SHIFT    (4U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL4_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL4(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL4_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL4_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL5_MASK     (0x20U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL5_SHIFT    (5U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL5_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL5(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL5_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL5_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL6_MASK     (0x40U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL6_SHIFT    (6U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL6_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL6(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL6_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL6_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL7_MASK     (0x80U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL7_SHIFT    (7U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL7_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL7(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL7_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL7_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL8_MASK     (0x100U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL8_SHIFT    (8U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL8_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL8(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL8_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL8_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL9_MASK     (0x200U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL9_SHIFT    (9U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL9_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL9(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL9_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL9_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL10_MASK    (0x400U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL10_SHIFT   (10U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL10_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL10(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL10_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL10_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL11_MASK    (0x800U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL11_SHIFT   (11U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL11_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL11(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL11_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL11_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL12_MASK    (0x1000U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL12_SHIFT   (12U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL12_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL12(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL12_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL12_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL13_MASK    (0x2000U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL13_SHIFT   (13U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL13_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL13(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL13_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL13_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL14_MASK    (0x4000U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL14_SHIFT   (14U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL14_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL14(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL14_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL14_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL15_MASK    (0x8000U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL15_SHIFT   (15U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL15_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL15(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL15_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL15_MASK)

#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL16_MASK    (0x10000U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL16_SHIFT   (16U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL16_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_2_CAN_TS_SEL16(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_CAN_TS_SEL16_SHIFT)) & K566_GPR1_GPR_RWF_2_CAN_TS_SEL16_MASK)

#define K566_GPR1_GPR_RWF_2_RTU_SAFE_CLK_GATING_EN_MASK (0x20000U)
#define K566_GPR1_GPR_RWF_2_RTU_SAFE_CLK_GATING_EN_SHIFT (17U)
#define K566_GPR1_GPR_RWF_2_RTU_SAFE_CLK_GATING_EN_WIDTH (1U)
#define K566_GPR1_GPR_RWF_2_RTU_SAFE_CLK_GATING_EN(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_2_RTU_SAFE_CLK_GATING_EN_SHIFT)) & K566_GPR1_GPR_RWF_2_RTU_SAFE_CLK_GATING_EN_MASK)
/*! @} */

/*! @name GPR_RWF_3 - Read Write FUNC 3 */
/*! @{ */

#define K566_GPR1_GPR_RWF_3_SSI0_CLR_UNINT_MASK  (0x1U)
#define K566_GPR1_GPR_RWF_3_SSI0_CLR_UNINT_SHIFT (0U)
#define K566_GPR1_GPR_RWF_3_SSI0_CLR_UNINT_WIDTH (1U)
#define K566_GPR1_GPR_RWF_3_SSI0_CLR_UNINT(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI0_CLR_UNINT_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI0_CLR_UNINT_MASK)

#define K566_GPR1_GPR_RWF_3_SSI0_FAULT_INJ_MASK  (0x2U)
#define K566_GPR1_GPR_RWF_3_SSI0_FAULT_INJ_SHIFT (1U)
#define K566_GPR1_GPR_RWF_3_SSI0_FAULT_INJ_WIDTH (1U)
#define K566_GPR1_GPR_RWF_3_SSI0_FAULT_INJ(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI0_FAULT_INJ_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI0_FAULT_INJ_MASK)

#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI0_MASK (0x1CU)
#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI0_SHIFT (2U)
#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI0_WIDTH (3U)
#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI0_SHIFT)) & K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI0_MASK)

#define K566_GPR1_GPR_RWF_3_SSI0_ERR_CLR_MASK    (0x20U)
#define K566_GPR1_GPR_RWF_3_SSI0_ERR_CLR_SHIFT   (5U)
#define K566_GPR1_GPR_RWF_3_SSI0_ERR_CLR_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_3_SSI0_ERR_CLR(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI0_ERR_CLR_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI0_ERR_CLR_MASK)

#define K566_GPR1_GPR_RWF_3_SSI0_BIST_TEST_MASK  (0x40U)
#define K566_GPR1_GPR_RWF_3_SSI0_BIST_TEST_SHIFT (6U)
#define K566_GPR1_GPR_RWF_3_SSI0_BIST_TEST_WIDTH (1U)
#define K566_GPR1_GPR_RWF_3_SSI0_BIST_TEST(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI0_BIST_TEST_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI0_BIST_TEST_MASK)

#define K566_GPR1_GPR_RWF_3_SSI0_ERR_INJ_MASK    (0x80U)
#define K566_GPR1_GPR_RWF_3_SSI0_ERR_INJ_SHIFT   (7U)
#define K566_GPR1_GPR_RWF_3_SSI0_ERR_INJ_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_3_SSI0_ERR_INJ(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI0_ERR_INJ_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI0_ERR_INJ_MASK)

#define K566_GPR1_GPR_RWF_3_SSI1_CLR_UNINT_MASK  (0x100U)
#define K566_GPR1_GPR_RWF_3_SSI1_CLR_UNINT_SHIFT (8U)
#define K566_GPR1_GPR_RWF_3_SSI1_CLR_UNINT_WIDTH (1U)
#define K566_GPR1_GPR_RWF_3_SSI1_CLR_UNINT(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI1_CLR_UNINT_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI1_CLR_UNINT_MASK)

#define K566_GPR1_GPR_RWF_3_SSI1_FAULT_INJ_MASK  (0x200U)
#define K566_GPR1_GPR_RWF_3_SSI1_FAULT_INJ_SHIFT (9U)
#define K566_GPR1_GPR_RWF_3_SSI1_FAULT_INJ_WIDTH (1U)
#define K566_GPR1_GPR_RWF_3_SSI1_FAULT_INJ(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI1_FAULT_INJ_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI1_FAULT_INJ_MASK)

#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI1_MASK (0x1C00U)
#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI1_SHIFT (10U)
#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI1_WIDTH (3U)
#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI1_SHIFT)) & K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI1_MASK)

#define K566_GPR1_GPR_RWF_3_SSI1_ERR_CLR_MASK    (0x2000U)
#define K566_GPR1_GPR_RWF_3_SSI1_ERR_CLR_SHIFT   (13U)
#define K566_GPR1_GPR_RWF_3_SSI1_ERR_CLR_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_3_SSI1_ERR_CLR(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI1_ERR_CLR_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI1_ERR_CLR_MASK)

#define K566_GPR1_GPR_RWF_3_SSI1_BIST_TEST_MASK  (0x4000U)
#define K566_GPR1_GPR_RWF_3_SSI1_BIST_TEST_SHIFT (14U)
#define K566_GPR1_GPR_RWF_3_SSI1_BIST_TEST_WIDTH (1U)
#define K566_GPR1_GPR_RWF_3_SSI1_BIST_TEST(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI1_BIST_TEST_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI1_BIST_TEST_MASK)

#define K566_GPR1_GPR_RWF_3_SSI1_ERR_INJ_MASK    (0x8000U)
#define K566_GPR1_GPR_RWF_3_SSI1_ERR_INJ_SHIFT   (15U)
#define K566_GPR1_GPR_RWF_3_SSI1_ERR_INJ_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_3_SSI1_ERR_INJ(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI1_ERR_INJ_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI1_ERR_INJ_MASK)

#define K566_GPR1_GPR_RWF_3_SSI2_CLR_UNINT_MASK  (0x10000U)
#define K566_GPR1_GPR_RWF_3_SSI2_CLR_UNINT_SHIFT (16U)
#define K566_GPR1_GPR_RWF_3_SSI2_CLR_UNINT_WIDTH (1U)
#define K566_GPR1_GPR_RWF_3_SSI2_CLR_UNINT(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI2_CLR_UNINT_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI2_CLR_UNINT_MASK)

#define K566_GPR1_GPR_RWF_3_SSI2_FAULT_INJ_MASK  (0x20000U)
#define K566_GPR1_GPR_RWF_3_SSI2_FAULT_INJ_SHIFT (17U)
#define K566_GPR1_GPR_RWF_3_SSI2_FAULT_INJ_WIDTH (1U)
#define K566_GPR1_GPR_RWF_3_SSI2_FAULT_INJ(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI2_FAULT_INJ_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI2_FAULT_INJ_MASK)

#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI2_MASK (0x1C0000U)
#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI2_SHIFT (18U)
#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI2_WIDTH (3U)
#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI2(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI2_SHIFT)) & K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI2_MASK)

#define K566_GPR1_GPR_RWF_3_SSI2_ERR_CLR_MASK    (0x200000U)
#define K566_GPR1_GPR_RWF_3_SSI2_ERR_CLR_SHIFT   (21U)
#define K566_GPR1_GPR_RWF_3_SSI2_ERR_CLR_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_3_SSI2_ERR_CLR(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI2_ERR_CLR_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI2_ERR_CLR_MASK)

#define K566_GPR1_GPR_RWF_3_SSI2_BIST_TEST_MASK  (0x400000U)
#define K566_GPR1_GPR_RWF_3_SSI2_BIST_TEST_SHIFT (22U)
#define K566_GPR1_GPR_RWF_3_SSI2_BIST_TEST_WIDTH (1U)
#define K566_GPR1_GPR_RWF_3_SSI2_BIST_TEST(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI2_BIST_TEST_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI2_BIST_TEST_MASK)

#define K566_GPR1_GPR_RWF_3_SSI2_ERR_INJ_MASK    (0x800000U)
#define K566_GPR1_GPR_RWF_3_SSI2_ERR_INJ_SHIFT   (23U)
#define K566_GPR1_GPR_RWF_3_SSI2_ERR_INJ_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_3_SSI2_ERR_INJ(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI2_ERR_INJ_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI2_ERR_INJ_MASK)

#define K566_GPR1_GPR_RWF_3_SSI3_CLR_UNINT_MASK  (0x1000000U)
#define K566_GPR1_GPR_RWF_3_SSI3_CLR_UNINT_SHIFT (24U)
#define K566_GPR1_GPR_RWF_3_SSI3_CLR_UNINT_WIDTH (1U)
#define K566_GPR1_GPR_RWF_3_SSI3_CLR_UNINT(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI3_CLR_UNINT_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI3_CLR_UNINT_MASK)

#define K566_GPR1_GPR_RWF_3_SSI3_FAULT_INJ_MASK  (0x2000000U)
#define K566_GPR1_GPR_RWF_3_SSI3_FAULT_INJ_SHIFT (25U)
#define K566_GPR1_GPR_RWF_3_SSI3_FAULT_INJ_WIDTH (1U)
#define K566_GPR1_GPR_RWF_3_SSI3_FAULT_INJ(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI3_FAULT_INJ_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI3_FAULT_INJ_MASK)

#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI3_MASK (0x1C000000U)
#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI3_SHIFT (26U)
#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI3_WIDTH (3U)
#define K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI3(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI3_SHIFT)) & K566_GPR1_GPR_RWF_3_INJ_SM_FAULT_SM_SSI3_MASK)

#define K566_GPR1_GPR_RWF_3_SSI3_ERR_CLR_MASK    (0x20000000U)
#define K566_GPR1_GPR_RWF_3_SSI3_ERR_CLR_SHIFT   (29U)
#define K566_GPR1_GPR_RWF_3_SSI3_ERR_CLR_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_3_SSI3_ERR_CLR(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI3_ERR_CLR_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI3_ERR_CLR_MASK)

#define K566_GPR1_GPR_RWF_3_SSI3_BIST_TEST_MASK  (0x40000000U)
#define K566_GPR1_GPR_RWF_3_SSI3_BIST_TEST_SHIFT (30U)
#define K566_GPR1_GPR_RWF_3_SSI3_BIST_TEST_WIDTH (1U)
#define K566_GPR1_GPR_RWF_3_SSI3_BIST_TEST(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI3_BIST_TEST_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI3_BIST_TEST_MASK)

#define K566_GPR1_GPR_RWF_3_SSI3_ERR_INJ_MASK    (0x80000000U)
#define K566_GPR1_GPR_RWF_3_SSI3_ERR_INJ_SHIFT   (31U)
#define K566_GPR1_GPR_RWF_3_SSI3_ERR_INJ_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_3_SSI3_ERR_INJ(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_3_SSI3_ERR_INJ_SHIFT)) & K566_GPR1_GPR_RWF_3_SSI3_ERR_INJ_MASK)
/*! @} */

/*! @name GPR_RWF_4 - Read Write FUNC 4 */
/*! @{ */

#define K566_GPR1_GPR_RWF_4_LPE_RW_BLOCK_EN_MASK (0x1U)
#define K566_GPR1_GPR_RWF_4_LPE_RW_BLOCK_EN_SHIFT (0U)
#define K566_GPR1_GPR_RWF_4_LPE_RW_BLOCK_EN_WIDTH (1U)
#define K566_GPR1_GPR_RWF_4_LPE_RW_BLOCK_EN(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_4_LPE_RW_BLOCK_EN_SHIFT)) & K566_GPR1_GPR_RWF_4_LPE_RW_BLOCK_EN_MASK)

#define K566_GPR1_GPR_RWF_4_LOCK_EN0_MASK        (0x40000000U)
#define K566_GPR1_GPR_RWF_4_LOCK_EN0_SHIFT       (30U)
#define K566_GPR1_GPR_RWF_4_LOCK_EN0_WIDTH       (1U)
#define K566_GPR1_GPR_RWF_4_LOCK_EN0(x)          (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_4_LOCK_EN0_SHIFT)) & K566_GPR1_GPR_RWF_4_LOCK_EN0_MASK)

#define K566_GPR1_GPR_RWF_4_LOCK_EN1_MASK        (0x80000000U)
#define K566_GPR1_GPR_RWF_4_LOCK_EN1_SHIFT       (31U)
#define K566_GPR1_GPR_RWF_4_LOCK_EN1_WIDTH       (1U)
#define K566_GPR1_GPR_RWF_4_LOCK_EN1(x)          (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_4_LOCK_EN1_SHIFT)) & K566_GPR1_GPR_RWF_4_LOCK_EN1_MASK)
/*! @} */

/*! @name GPR_RWF_5 - Read Write FUNC 5 */
/*! @{ */

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN0_MASK      (0x1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN0_SHIFT     (0U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN0_WIDTH     (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN0(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN0_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN0_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN1_MASK      (0x2U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN1_SHIFT     (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN1_WIDTH     (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN1(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN1_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN1_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN2_MASK      (0x4U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN2_SHIFT     (2U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN2_WIDTH     (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN2(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN2_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN2_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN3_MASK      (0x8U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN3_SHIFT     (3U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN3_WIDTH     (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN3(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN3_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN3_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN4_MASK      (0x10U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN4_SHIFT     (4U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN4_WIDTH     (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN4(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN4_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN4_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN5_MASK      (0x20U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN5_SHIFT     (5U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN5_WIDTH     (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN5(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN5_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN5_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN6_MASK      (0x40U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN6_SHIFT     (6U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN6_WIDTH     (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN6(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN6_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN6_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN7_MASK      (0x80U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN7_SHIFT     (7U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN7_WIDTH     (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN7(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN7_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN7_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN8_MASK      (0x100U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN8_SHIFT     (8U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN8_WIDTH     (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN8(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN8_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN8_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN9_MASK      (0x200U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN9_SHIFT     (9U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN9_WIDTH     (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN9(x)        (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN9_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN9_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN10_MASK     (0x400U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN10_SHIFT    (10U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN10_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN10(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN10_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN10_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN11_MASK     (0x800U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN11_SHIFT    (11U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN11_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN11(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN11_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN11_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN12_MASK     (0x1000U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN12_SHIFT    (12U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN12_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN12(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN12_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN12_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN13_MASK     (0x2000U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN13_SHIFT    (13U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN13_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN13(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN13_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN13_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN14_MASK     (0x4000U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN14_SHIFT    (14U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN14_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN14(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN14_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN14_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN15_MASK     (0x8000U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN15_SHIFT    (15U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN15_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN15(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN15_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN15_MASK)

#define K566_GPR1_GPR_RWF_5_CAN_TS_EN16_MASK     (0x10000U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN16_SHIFT    (16U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN16_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_5_CAN_TS_EN16(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_CAN_TS_EN16_SHIFT)) & K566_GPR1_GPR_RWF_5_CAN_TS_EN16_MASK)

#define K566_GPR1_GPR_RWF_5_SSI0_REPORT_CTRL_LOGIC_FAILURE_MASK (0x20000U)
#define K566_GPR1_GPR_RWF_5_SSI0_REPORT_CTRL_LOGIC_FAILURE_SHIFT (17U)
#define K566_GPR1_GPR_RWF_5_SSI0_REPORT_CTRL_LOGIC_FAILURE_WIDTH (1U)
#define K566_GPR1_GPR_RWF_5_SSI0_REPORT_CTRL_LOGIC_FAILURE(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_SSI0_REPORT_CTRL_LOGIC_FAILURE_SHIFT)) & K566_GPR1_GPR_RWF_5_SSI0_REPORT_CTRL_LOGIC_FAILURE_MASK)

#define K566_GPR1_GPR_RWF_5_SSI0_REPORT_SLICE_LOST_MASK (0x40000U)
#define K566_GPR1_GPR_RWF_5_SSI0_REPORT_SLICE_LOST_SHIFT (18U)
#define K566_GPR1_GPR_RWF_5_SSI0_REPORT_SLICE_LOST_WIDTH (1U)
#define K566_GPR1_GPR_RWF_5_SSI0_REPORT_SLICE_LOST(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_SSI0_REPORT_SLICE_LOST_SHIFT)) & K566_GPR1_GPR_RWF_5_SSI0_REPORT_SLICE_LOST_MASK)

#define K566_GPR1_GPR_RWF_5_SSI0_USE_REPORT_PORT_VALUES_MASK (0x80000U)
#define K566_GPR1_GPR_RWF_5_SSI0_USE_REPORT_PORT_VALUES_SHIFT (19U)
#define K566_GPR1_GPR_RWF_5_SSI0_USE_REPORT_PORT_VALUES_WIDTH (1U)
#define K566_GPR1_GPR_RWF_5_SSI0_USE_REPORT_PORT_VALUES(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_SSI0_USE_REPORT_PORT_VALUES_SHIFT)) & K566_GPR1_GPR_RWF_5_SSI0_USE_REPORT_PORT_VALUES_MASK)

#define K566_GPR1_GPR_RWF_5_SSI1_REPORT_CTRL_LOGIC_FAILURE_MASK (0x100000U)
#define K566_GPR1_GPR_RWF_5_SSI1_REPORT_CTRL_LOGIC_FAILURE_SHIFT (20U)
#define K566_GPR1_GPR_RWF_5_SSI1_REPORT_CTRL_LOGIC_FAILURE_WIDTH (1U)
#define K566_GPR1_GPR_RWF_5_SSI1_REPORT_CTRL_LOGIC_FAILURE(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_SSI1_REPORT_CTRL_LOGIC_FAILURE_SHIFT)) & K566_GPR1_GPR_RWF_5_SSI1_REPORT_CTRL_LOGIC_FAILURE_MASK)

#define K566_GPR1_GPR_RWF_5_SSI1_REPORT_SLICE_LOST_MASK (0x200000U)
#define K566_GPR1_GPR_RWF_5_SSI1_REPORT_SLICE_LOST_SHIFT (21U)
#define K566_GPR1_GPR_RWF_5_SSI1_REPORT_SLICE_LOST_WIDTH (1U)
#define K566_GPR1_GPR_RWF_5_SSI1_REPORT_SLICE_LOST(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_SSI1_REPORT_SLICE_LOST_SHIFT)) & K566_GPR1_GPR_RWF_5_SSI1_REPORT_SLICE_LOST_MASK)

#define K566_GPR1_GPR_RWF_5_SSI1_USE_REPORT_PORT_VALUES_MASK (0x400000U)
#define K566_GPR1_GPR_RWF_5_SSI1_USE_REPORT_PORT_VALUES_SHIFT (22U)
#define K566_GPR1_GPR_RWF_5_SSI1_USE_REPORT_PORT_VALUES_WIDTH (1U)
#define K566_GPR1_GPR_RWF_5_SSI1_USE_REPORT_PORT_VALUES(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_SSI1_USE_REPORT_PORT_VALUES_SHIFT)) & K566_GPR1_GPR_RWF_5_SSI1_USE_REPORT_PORT_VALUES_MASK)

#define K566_GPR1_GPR_RWF_5_SSI2_REPORT_CTRL_LOGIC_FAILURE_MASK (0x800000U)
#define K566_GPR1_GPR_RWF_5_SSI2_REPORT_CTRL_LOGIC_FAILURE_SHIFT (23U)
#define K566_GPR1_GPR_RWF_5_SSI2_REPORT_CTRL_LOGIC_FAILURE_WIDTH (1U)
#define K566_GPR1_GPR_RWF_5_SSI2_REPORT_CTRL_LOGIC_FAILURE(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_SSI2_REPORT_CTRL_LOGIC_FAILURE_SHIFT)) & K566_GPR1_GPR_RWF_5_SSI2_REPORT_CTRL_LOGIC_FAILURE_MASK)

#define K566_GPR1_GPR_RWF_5_SSI2_REPORT_SLICE_LOST_MASK (0x1000000U)
#define K566_GPR1_GPR_RWF_5_SSI2_REPORT_SLICE_LOST_SHIFT (24U)
#define K566_GPR1_GPR_RWF_5_SSI2_REPORT_SLICE_LOST_WIDTH (1U)
#define K566_GPR1_GPR_RWF_5_SSI2_REPORT_SLICE_LOST(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_SSI2_REPORT_SLICE_LOST_SHIFT)) & K566_GPR1_GPR_RWF_5_SSI2_REPORT_SLICE_LOST_MASK)

#define K566_GPR1_GPR_RWF_5_SSI2_USE_REPORT_PORT_VALUES_MASK (0x2000000U)
#define K566_GPR1_GPR_RWF_5_SSI2_USE_REPORT_PORT_VALUES_SHIFT (25U)
#define K566_GPR1_GPR_RWF_5_SSI2_USE_REPORT_PORT_VALUES_WIDTH (1U)
#define K566_GPR1_GPR_RWF_5_SSI2_USE_REPORT_PORT_VALUES(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_SSI2_USE_REPORT_PORT_VALUES_SHIFT)) & K566_GPR1_GPR_RWF_5_SSI2_USE_REPORT_PORT_VALUES_MASK)

#define K566_GPR1_GPR_RWF_5_SSI3_REPORT_CTRL_LOGIC_FAILURE_MASK (0x4000000U)
#define K566_GPR1_GPR_RWF_5_SSI3_REPORT_CTRL_LOGIC_FAILURE_SHIFT (26U)
#define K566_GPR1_GPR_RWF_5_SSI3_REPORT_CTRL_LOGIC_FAILURE_WIDTH (1U)
#define K566_GPR1_GPR_RWF_5_SSI3_REPORT_CTRL_LOGIC_FAILURE(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_SSI3_REPORT_CTRL_LOGIC_FAILURE_SHIFT)) & K566_GPR1_GPR_RWF_5_SSI3_REPORT_CTRL_LOGIC_FAILURE_MASK)

#define K566_GPR1_GPR_RWF_5_SSI3_REPORT_SLICE_LOST_MASK (0x8000000U)
#define K566_GPR1_GPR_RWF_5_SSI3_REPORT_SLICE_LOST_SHIFT (27U)
#define K566_GPR1_GPR_RWF_5_SSI3_REPORT_SLICE_LOST_WIDTH (1U)
#define K566_GPR1_GPR_RWF_5_SSI3_REPORT_SLICE_LOST(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_SSI3_REPORT_SLICE_LOST_SHIFT)) & K566_GPR1_GPR_RWF_5_SSI3_REPORT_SLICE_LOST_MASK)

#define K566_GPR1_GPR_RWF_5_SSI3_USE_REPORT_PORT_VALUES_MASK (0x10000000U)
#define K566_GPR1_GPR_RWF_5_SSI3_USE_REPORT_PORT_VALUES_SHIFT (28U)
#define K566_GPR1_GPR_RWF_5_SSI3_USE_REPORT_PORT_VALUES_WIDTH (1U)
#define K566_GPR1_GPR_RWF_5_SSI3_USE_REPORT_PORT_VALUES(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_SSI3_USE_REPORT_PORT_VALUES_SHIFT)) & K566_GPR1_GPR_RWF_5_SSI3_USE_REPORT_PORT_VALUES_MASK)

#define K566_GPR1_GPR_RWF_5_RTU_DEBUG_CLK_GATING_EN_MASK (0x20000000U)
#define K566_GPR1_GPR_RWF_5_RTU_DEBUG_CLK_GATING_EN_SHIFT (29U)
#define K566_GPR1_GPR_RWF_5_RTU_DEBUG_CLK_GATING_EN_WIDTH (1U)
#define K566_GPR1_GPR_RWF_5_RTU_DEBUG_CLK_GATING_EN(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_5_RTU_DEBUG_CLK_GATING_EN_SHIFT)) & K566_GPR1_GPR_RWF_5_RTU_DEBUG_CLK_GATING_EN_MASK)
/*! @} */

/*! @name GPR_RWF_6 - Read Write FUNC 6 */
/*! @{ */

#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_7_MASK (0x80U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_7_SHIFT (7U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_7_WIDTH (1U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_7(x)   (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_7_SHIFT)) & K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_7_MASK)

#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_18_MASK (0x40000U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_18_SHIFT (18U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_18_WIDTH (1U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_18(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_18_SHIFT)) & K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_18_MASK)

#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_19_MASK (0x80000U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_19_SHIFT (19U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_19_WIDTH (1U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_19(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_19_SHIFT)) & K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_19_MASK)

#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_20_MASK (0x100000U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_20_SHIFT (20U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_20_WIDTH (1U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_20(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_20_SHIFT)) & K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_20_MASK)

#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_21_MASK (0x200000U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_21_SHIFT (21U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_21_WIDTH (1U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_21(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_21_SHIFT)) & K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_21_MASK)

#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_22_MASK (0x400000U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_22_SHIFT (22U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_22_WIDTH (1U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_22(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_22_SHIFT)) & K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_22_MASK)

#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_23_MASK (0x800000U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_23_SHIFT (23U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_23_WIDTH (1U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_23(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_23_SHIFT)) & K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_23_MASK)

#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_27_MASK (0x8000000U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_27_SHIFT (27U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_27_WIDTH (1U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_27(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_27_SHIFT)) & K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_27_MASK)

#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_28_MASK (0x10000000U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_28_SHIFT (28U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_28_WIDTH (1U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_28(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_28_SHIFT)) & K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_28_MASK)

#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_29_MASK (0x20000000U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_29_SHIFT (29U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_29_WIDTH (1U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_29(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_29_SHIFT)) & K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_29_MASK)

#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_30_MASK (0x40000000U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_30_SHIFT (30U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_30_WIDTH (1U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_30(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_30_SHIFT)) & K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_30_MASK)

#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_31_MASK (0x80000000U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_31_SHIFT (31U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_31_WIDTH (1U)
#define K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_31(x)  (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_31_SHIFT)) & K566_GPR1_GPR_RWF_6_APP_HSE2_COMM_31_MASK)
/*! @} */

/*! @name GPR_RWF_7 - Read Write FUNC 7 */
/*! @{ */

#define K566_GPR1_GPR_RWF_7_PB3_CREF_EN_MASK     (0x1U)
#define K566_GPR1_GPR_RWF_7_PB3_CREF_EN_SHIFT    (0U)
#define K566_GPR1_GPR_RWF_7_PB3_CREF_EN_WIDTH    (1U)
#define K566_GPR1_GPR_RWF_7_PB3_CREF_EN(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_7_PB3_CREF_EN_SHIFT)) & K566_GPR1_GPR_RWF_7_PB3_CREF_EN_MASK)

#define K566_GPR1_GPR_RWF_7_PLL0_CLK_DIVIDER_DISABLE_MASK (0x2U)
#define K566_GPR1_GPR_RWF_7_PLL0_CLK_DIVIDER_DISABLE_SHIFT (1U)
#define K566_GPR1_GPR_RWF_7_PLL0_CLK_DIVIDER_DISABLE_WIDTH (1U)
#define K566_GPR1_GPR_RWF_7_PLL0_CLK_DIVIDER_DISABLE(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_7_PLL0_CLK_DIVIDER_DISABLE_SHIFT)) & K566_GPR1_GPR_RWF_7_PLL0_CLK_DIVIDER_DISABLE_MASK)
/*! @} */

/*! @name GPR_RWF_8 - Read Write FUNC 3 */
/*! @{ */

#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_R52_0_MASK (0x1U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_R52_0_SHIFT (0U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_R52_0_WIDTH (1U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_R52_0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_R52_0_SHIFT)) & K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_R52_0_MASK)

#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_R52_1_MASK (0x2U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_R52_1_SHIFT (1U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_R52_1_WIDTH (1U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_R52_1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_R52_1_SHIFT)) & K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_R52_1_MASK)

#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_0_MASK (0x4U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_0_SHIFT (2U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_0_WIDTH (1U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_0(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_0_SHIFT)) & K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_0_MASK)

#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_1_MASK (0x8U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_1_SHIFT (3U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_1_WIDTH (1U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_1(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_1_SHIFT)) & K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_1_MASK)

#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_2_MASK (0x10U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_2_SHIFT (4U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_2_WIDTH (1U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_2(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_2_SHIFT)) & K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_2_MASK)

#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_3_MASK (0x20U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_3_SHIFT (5U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_3_WIDTH (1U)
#define K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_3(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_3_SHIFT)) & K566_GPR1_GPR_RWF_8_WFI_BYPASS_ACK_CM7_3_MASK)

#define K566_GPR1_GPR_RWF_8_XBIC_ERR_ACK_MASK    (0x80U)
#define K566_GPR1_GPR_RWF_8_XBIC_ERR_ACK_SHIFT   (7U)
#define K566_GPR1_GPR_RWF_8_XBIC_ERR_ACK_WIDTH   (1U)
#define K566_GPR1_GPR_RWF_8_XBIC_ERR_ACK(x)      (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_RWF_8_XBIC_ERR_ACK_SHIFT)) & K566_GPR1_GPR_RWF_8_XBIC_ERR_ACK_MASK)
/*! @} */

/*! @name GPR_ROF_0 - Read Only FUNC 0 */
/*! @{ */

#define K566_GPR1_GPR_ROF_0_SSI0_IDLE_MASK       (0x1U)
#define K566_GPR1_GPR_ROF_0_SSI0_IDLE_SHIFT      (0U)
#define K566_GPR1_GPR_ROF_0_SSI0_IDLE_WIDTH      (1U)
#define K566_GPR1_GPR_ROF_0_SSI0_IDLE(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_SSI0_IDLE_SHIFT)) & K566_GPR1_GPR_ROF_0_SSI0_IDLE_MASK)

#define K566_GPR1_GPR_ROF_0_SSI1_IDLE_MASK       (0x2U)
#define K566_GPR1_GPR_ROF_0_SSI1_IDLE_SHIFT      (1U)
#define K566_GPR1_GPR_ROF_0_SSI1_IDLE_WIDTH      (1U)
#define K566_GPR1_GPR_ROF_0_SSI1_IDLE(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_SSI1_IDLE_SHIFT)) & K566_GPR1_GPR_ROF_0_SSI1_IDLE_MASK)

#define K566_GPR1_GPR_ROF_0_SSI2_IDLE_MASK       (0x4U)
#define K566_GPR1_GPR_ROF_0_SSI2_IDLE_SHIFT      (2U)
#define K566_GPR1_GPR_ROF_0_SSI2_IDLE_WIDTH      (1U)
#define K566_GPR1_GPR_ROF_0_SSI2_IDLE(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_SSI2_IDLE_SHIFT)) & K566_GPR1_GPR_ROF_0_SSI2_IDLE_MASK)

#define K566_GPR1_GPR_ROF_0_SSI3_IDLE_MASK       (0x8U)
#define K566_GPR1_GPR_ROF_0_SSI3_IDLE_SHIFT      (3U)
#define K566_GPR1_GPR_ROF_0_SSI3_IDLE_WIDTH      (1U)
#define K566_GPR1_GPR_ROF_0_SSI3_IDLE(x)         (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_SSI3_IDLE_SHIFT)) & K566_GPR1_GPR_ROF_0_SSI3_IDLE_MASK)

#define K566_GPR1_GPR_ROF_0_AXI_ACC_PORT_FD_IDLE_MASK (0x10U)
#define K566_GPR1_GPR_ROF_0_AXI_ACC_PORT_FD_IDLE_SHIFT (4U)
#define K566_GPR1_GPR_ROF_0_AXI_ACC_PORT_FD_IDLE_WIDTH (1U)
#define K566_GPR1_GPR_ROF_0_AXI_ACC_PORT_FD_IDLE(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_AXI_ACC_PORT_FD_IDLE_SHIFT)) & K566_GPR1_GPR_ROF_0_AXI_ACC_PORT_FD_IDLE_MASK)

#define K566_GPR1_GPR_ROF_0_CORE0_FD_IDLE_MASK   (0x20U)
#define K566_GPR1_GPR_ROF_0_CORE0_FD_IDLE_SHIFT  (5U)
#define K566_GPR1_GPR_ROF_0_CORE0_FD_IDLE_WIDTH  (1U)
#define K566_GPR1_GPR_ROF_0_CORE0_FD_IDLE(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_CORE0_FD_IDLE_SHIFT)) & K566_GPR1_GPR_ROF_0_CORE0_FD_IDLE_MASK)

#define K566_GPR1_GPR_ROF_0_CORE1_FD_IDLE_MASK   (0x40U)
#define K566_GPR1_GPR_ROF_0_CORE1_FD_IDLE_SHIFT  (6U)
#define K566_GPR1_GPR_ROF_0_CORE1_FD_IDLE_WIDTH  (1U)
#define K566_GPR1_GPR_ROF_0_CORE1_FD_IDLE(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_CORE1_FD_IDLE_SHIFT)) & K566_GPR1_GPR_ROF_0_CORE1_FD_IDLE_MASK)

#define K566_GPR1_GPR_ROF_0_CORE2_FD_IDLE_MASK   (0x80U)
#define K566_GPR1_GPR_ROF_0_CORE2_FD_IDLE_SHIFT  (7U)
#define K566_GPR1_GPR_ROF_0_CORE2_FD_IDLE_WIDTH  (1U)
#define K566_GPR1_GPR_ROF_0_CORE2_FD_IDLE(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_CORE2_FD_IDLE_SHIFT)) & K566_GPR1_GPR_ROF_0_CORE2_FD_IDLE_MASK)

#define K566_GPR1_GPR_ROF_0_CORE3_FD_IDLE_MASK   (0x100U)
#define K566_GPR1_GPR_ROF_0_CORE3_FD_IDLE_SHIFT  (8U)
#define K566_GPR1_GPR_ROF_0_CORE3_FD_IDLE_WIDTH  (1U)
#define K566_GPR1_GPR_ROF_0_CORE3_FD_IDLE(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_CORE3_FD_IDLE_SHIFT)) & K566_GPR1_GPR_ROF_0_CORE3_FD_IDLE_MASK)

#define K566_GPR1_GPR_ROF_0_ETR_FD_IDLE_MASK     (0x200U)
#define K566_GPR1_GPR_ROF_0_ETR_FD_IDLE_SHIFT    (9U)
#define K566_GPR1_GPR_ROF_0_ETR_FD_IDLE_WIDTH    (1U)
#define K566_GPR1_GPR_ROF_0_ETR_FD_IDLE(x)       (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_ETR_FD_IDLE_SHIFT)) & K566_GPR1_GPR_ROF_0_ETR_FD_IDLE_MASK)

#define K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_PRIV_MASK (0x2000U)
#define K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_PRIV_SHIFT (13U)
#define K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_PRIV_WIDTH (1U)
#define K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_PRIV(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_PRIV_SHIFT)) & K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_PRIV_MASK)

#define K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_NS_MASK (0x4000U)
#define K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_NS_SHIFT (14U)
#define K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_NS_WIDTH (1U)
#define K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_NS(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_NS_SHIFT)) & K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_NS_MASK)

#define K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_DID_MASK (0x78000U)
#define K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_DID_SHIFT (15U)
#define K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_DID_WIDTH (4U)
#define K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_DID(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_DID_SHIFT)) & K566_GPR1_GPR_ROF_0_AES_SAFETY_ERR_DID_MASK)

#define K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_PRIV_MASK (0x80000U)
#define K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_PRIV_SHIFT (19U)
#define K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_PRIV_WIDTH (1U)
#define K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_PRIV(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_PRIV_SHIFT)) & K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_PRIV_MASK)

#define K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_NS_MASK (0x100000U)
#define K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_NS_SHIFT (20U)
#define K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_NS_WIDTH (1U)
#define K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_NS(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_NS_SHIFT)) & K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_NS_MASK)

#define K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_DID_MASK (0x1E00000U)
#define K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_DID_SHIFT (21U)
#define K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_DID_WIDTH (4U)
#define K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_DID(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_DID_SHIFT)) & K566_GPR1_GPR_ROF_0_AES_FEED_DID_ERR_DID_MASK)

#define K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_PRIV_MASK (0x2000000U)
#define K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_PRIV_SHIFT (25U)
#define K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_PRIV_WIDTH (1U)
#define K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_PRIV(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_PRIV_SHIFT)) & K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_PRIV_MASK)

#define K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_NS_MASK (0x4000000U)
#define K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_NS_SHIFT (26U)
#define K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_NS_WIDTH (1U)
#define K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_NS(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_NS_SHIFT)) & K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_NS_MASK)

#define K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_DID_MASK (0x78000000U)
#define K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_DID_SHIFT (27U)
#define K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_DID_WIDTH (4U)
#define K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_DID(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_DID_SHIFT)) & K566_GPR1_GPR_ROF_0_AES_RESULT_DID_ERR_DID_MASK)
/*! @} */

/*! @name GPR_ROF_1 - Read Only FUNC 1 */
/*! @{ */

#define K566_GPR1_GPR_ROF_1_CM7_0_GSKT_HLT_MASK  (0x1U)
#define K566_GPR1_GPR_ROF_1_CM7_0_GSKT_HLT_SHIFT (0U)
#define K566_GPR1_GPR_ROF_1_CM7_0_GSKT_HLT_WIDTH (1U)
#define K566_GPR1_GPR_ROF_1_CM7_0_GSKT_HLT(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_1_CM7_0_GSKT_HLT_SHIFT)) & K566_GPR1_GPR_ROF_1_CM7_0_GSKT_HLT_MASK)

#define K566_GPR1_GPR_ROF_1_CM7_1_GSKT_HLT_MASK  (0x2U)
#define K566_GPR1_GPR_ROF_1_CM7_1_GSKT_HLT_SHIFT (1U)
#define K566_GPR1_GPR_ROF_1_CM7_1_GSKT_HLT_WIDTH (1U)
#define K566_GPR1_GPR_ROF_1_CM7_1_GSKT_HLT(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_1_CM7_1_GSKT_HLT_SHIFT)) & K566_GPR1_GPR_ROF_1_CM7_1_GSKT_HLT_MASK)

#define K566_GPR1_GPR_ROF_1_CM7_2_GSKT_HLT_MASK  (0x4U)
#define K566_GPR1_GPR_ROF_1_CM7_2_GSKT_HLT_SHIFT (2U)
#define K566_GPR1_GPR_ROF_1_CM7_2_GSKT_HLT_WIDTH (1U)
#define K566_GPR1_GPR_ROF_1_CM7_2_GSKT_HLT(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_1_CM7_2_GSKT_HLT_SHIFT)) & K566_GPR1_GPR_ROF_1_CM7_2_GSKT_HLT_MASK)

#define K566_GPR1_GPR_ROF_1_CM7_3_GSKT_HLT_MASK  (0x8U)
#define K566_GPR1_GPR_ROF_1_CM7_3_GSKT_HLT_SHIFT (3U)
#define K566_GPR1_GPR_ROF_1_CM7_3_GSKT_HLT_WIDTH (1U)
#define K566_GPR1_GPR_ROF_1_CM7_3_GSKT_HLT(x)    (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_1_CM7_3_GSKT_HLT_SHIFT)) & K566_GPR1_GPR_ROF_1_CM7_3_GSKT_HLT_MASK)

#define K566_GPR1_GPR_ROF_1_INIT_OCM_DONE_MASK   (0x10U)
#define K566_GPR1_GPR_ROF_1_INIT_OCM_DONE_SHIFT  (4U)
#define K566_GPR1_GPR_ROF_1_INIT_OCM_DONE_WIDTH  (1U)
#define K566_GPR1_GPR_ROF_1_INIT_OCM_DONE(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_1_INIT_OCM_DONE_SHIFT)) & K566_GPR1_GPR_ROF_1_INIT_OCM_DONE_MASK)

#define K566_GPR1_GPR_ROF_1_INT_PEND_MASK        (0x20U)
#define K566_GPR1_GPR_ROF_1_INT_PEND_SHIFT       (5U)
#define K566_GPR1_GPR_ROF_1_INT_PEND_WIDTH       (1U)
#define K566_GPR1_GPR_ROF_1_INT_PEND(x)          (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_1_INT_PEND_SHIFT)) & K566_GPR1_GPR_ROF_1_INT_PEND_MASK)

#define K566_GPR1_GPR_ROF_1_RTU_SSI0_IDLE_MASK   (0x40U)
#define K566_GPR1_GPR_ROF_1_RTU_SSI0_IDLE_SHIFT  (6U)
#define K566_GPR1_GPR_ROF_1_RTU_SSI0_IDLE_WIDTH  (1U)
#define K566_GPR1_GPR_ROF_1_RTU_SSI0_IDLE(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_1_RTU_SSI0_IDLE_SHIFT)) & K566_GPR1_GPR_ROF_1_RTU_SSI0_IDLE_MASK)

#define K566_GPR1_GPR_ROF_1_RTU_SSI1_IDLE_MASK   (0x80U)
#define K566_GPR1_GPR_ROF_1_RTU_SSI1_IDLE_SHIFT  (7U)
#define K566_GPR1_GPR_ROF_1_RTU_SSI1_IDLE_WIDTH  (1U)
#define K566_GPR1_GPR_ROF_1_RTU_SSI1_IDLE(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_1_RTU_SSI1_IDLE_SHIFT)) & K566_GPR1_GPR_ROF_1_RTU_SSI1_IDLE_MASK)

#define K566_GPR1_GPR_ROF_1_RTU_SSI2_IDLE_MASK   (0x100U)
#define K566_GPR1_GPR_ROF_1_RTU_SSI2_IDLE_SHIFT  (8U)
#define K566_GPR1_GPR_ROF_1_RTU_SSI2_IDLE_WIDTH  (1U)
#define K566_GPR1_GPR_ROF_1_RTU_SSI2_IDLE(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_1_RTU_SSI2_IDLE_SHIFT)) & K566_GPR1_GPR_ROF_1_RTU_SSI2_IDLE_MASK)

#define K566_GPR1_GPR_ROF_1_RTU_SSI3_IDLE_MASK   (0x200U)
#define K566_GPR1_GPR_ROF_1_RTU_SSI3_IDLE_SHIFT  (9U)
#define K566_GPR1_GPR_ROF_1_RTU_SSI3_IDLE_WIDTH  (1U)
#define K566_GPR1_GPR_ROF_1_RTU_SSI3_IDLE(x)     (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_1_RTU_SSI3_IDLE_SHIFT)) & K566_GPR1_GPR_ROF_1_RTU_SSI3_IDLE_MASK)
/*! @} */

/*! @name GPR_ROF_2 - Read Only FUNC 2 */
/*! @{ */

#define K566_GPR1_GPR_ROF_2_PLL0_CLK_DIVIDER_DISABLE_ACK_MASK (0x1U)
#define K566_GPR1_GPR_ROF_2_PLL0_CLK_DIVIDER_DISABLE_ACK_SHIFT (0U)
#define K566_GPR1_GPR_ROF_2_PLL0_CLK_DIVIDER_DISABLE_ACK_WIDTH (1U)
#define K566_GPR1_GPR_ROF_2_PLL0_CLK_DIVIDER_DISABLE_ACK(x) (((uint32_t)(((uint32_t)(x)) << K566_GPR1_GPR_ROF_2_PLL0_CLK_DIVIDER_DISABLE_ACK_SHIFT)) & K566_GPR1_GPR_ROF_2_PLL0_CLK_DIVIDER_DISABLE_ACK_MASK)
/*! @} */

/*!
 * @}
 */ /* end of group K566_GPR1_Register_Masks */

/*!
 * @}
 */ /* end of group K566_GPR1_Peripheral_Access_Layer */

#endif  /* #if !defined(S32K566_K566_GPR1_H_) */
