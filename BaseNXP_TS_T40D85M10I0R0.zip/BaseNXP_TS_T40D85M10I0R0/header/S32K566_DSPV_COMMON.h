/*
** ###################################################################
**     Processor:           S32K566_DSPV
**     Compiler:            Keil ARM C/C++ Compiler
**     Reference manual:    S32K5 RM Rev 3
**     Version:             rev. 2.7, 2026-09-09
**     Build:               b260908
**
**     Abstract:
**         Peripheral Access Layer for S32K566_DSPV
**
**     Copyright 1997-2016 Freescale Semiconductor, Inc.
**     Copyright 2016-2026 NXP
**
**     NXP Confidential and Proprietary. This software is owned or controlled
**     by NXP and may only be used strictly in accordance with the applicable
**     license terms. By expressly accepting such terms or by downloading,
**     installing, activating and/or otherwise using the software, you are
**     agreeing that you have read, and that you agree to comply with and are
**     bound by, such license terms. If you do not agree to be bound by the
**     applicable license terms, then you may not retain, install, activate
**     or otherwise use the software.
**
**     http:                 www.nxp.com
**     mail:                 support@nxp.com
**
** ###################################################################
*/

/*!
 * @file S32K566.h
 * @version 2.7
 * @date 2026-09-09
 * @brief Peripheral Access Layer for S32K566
 *
 * This file contains register definitions and macros for easy access to their
 * bit fields.
 *
 * This file assumes LITTLE endian system.
 */

/**
* @page misra_violations MISRA-C:2012 violations
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.3, local typedef not referenced
* The SoC header defines typedef for all modules.
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.5, local macro not referenced
* The SoC header defines macros for all modules and registers.
*
* @section [global]
* Violates MISRA 2012 Advisory Directive 4.9, Function-like macro
* These are generated macros used for accessing the bit-fields from registers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.1, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.2, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.4, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.5, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 21.1, defined macro '__I' is reserved to the compiler
* This type qualifier is needed to ensure correct I/O access and addressing.
*/


/* ----------------------------------------------------------------------------
   -- MCU activation
   ---------------------------------------------------------------------------- */

/* Prevention from multiple including the same memory map */
#if !defined(S32K566_DSPV_COMMON_H_)  /* Check if memory map has not been already included */
#define S32K566_DSPV_COMMON_H_
#define MCU_S32K566

/* Check if another memory map has not been also included */
#if (defined(MCU_ACTIVE))
  #error S32K566 memory map: There is already included another memory map. Only one memory map can be included.
#endif /* (defined(MCU_ACTIVE)) */
#define MCU_ACTIVE

#include <stdint.h>

/** Memory map major version (memory maps with equal major version number are
 * compatible) */
#define MCU_MEM_MAP_VERSION 0x0200U
/** Memory map minor version */
#define MCU_MEM_MAP_VERSION_MINOR 0x0007U

/* ----------------------------------------------------------------------------
   -- Generic macros
   ---------------------------------------------------------------------------- */

/* IO definitions (access restrictions to peripheral registers) */
/**
*   IO Type Qualifiers are used
*   \li to specify the access to peripheral variables.
*   \li for automatic generation of peripheral register debug information.
*/
#ifndef __IO
#ifdef __cplusplus
  #define   __I     volatile             /*!< Defines 'read only' permissions                 */
#else
  #define   __I     volatile const       /*!< Defines 'read only' permissions                 */
#endif
#define     __O     volatile             /*!< Defines 'write only' permissions                */
#define     __IO    volatile             /*!< Defines 'read / write' permissions              */
#endif


/**
* @brief 32 bits memory read macro.
*/
#if !defined(REG_READ32)
  #define REG_READ32(address)               (*(volatile uint32_t*)(address))
#endif

/**
* @brief 32 bits memory write macro.
*/
#if !defined(REG_WRITE32)
  #define REG_WRITE32(address, value)       ((*(volatile uint32_t*)(address))= (uint32_t)(value))
#endif

/**
* @brief 32 bits bits setting macro.
*/
#if !defined(REG_BIT_SET32)
  #define REG_BIT_SET32(address, mask)      ((*(volatile uint32_t*)(address))|= (uint32_t)(mask))
#endif

/**
* @brief 32 bits bits clearing macro.
*/
#if !defined(REG_BIT_CLEAR32)
  #define REG_BIT_CLEAR32(address, mask)    ((*(volatile uint32_t*)(address))&= ((uint32_t)~((uint32_t)(mask))))
#endif

/**
* @brief 32 bit clear bits and set with new value
* @note It is user's responsability to make sure that value has only "mask" bits set - (value&~mask)==0
*/
#if !defined(REG_RMW32)
  #define REG_RMW32(address, mask, value)   (REG_WRITE32((address), ((REG_READ32(address)& ((uint32_t)~((uint32_t)(mask))))| ((uint32_t)(value)))))
#endif


/* ----------------------------------------------------------------------------
   -- Interrupt vector numbers
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup Interrupt_vector_numbers Interrupt vector numbers
 * @{
 */

/** Interrupt Number Definitions */
#define NUMBER_OF_INT_VECTORS 75                 /**< Number of interrupts in the Vector table */

typedef enum {
  /* Auxiliary constants */
  NotAvail_IRQn                = -128,             /**< Not available device specific interrupt */

  /* Device specific interrupts */
  SGI_INT1_IRQn                = 0,                /**< Software Generated Interrupt 1 */
  SGI_INT2_IRQn                = 1,                /**< Software Generated Interrupt 2 */
  SGI_INT3_IRQn                = 2,                /**< Software Generated Interrupt 3 */
  SGI_INT4_IRQn                = 3,                /**< Software Generated Interrupt 4 */
  SGI_INT5_IRQn                = 4,                /**< Software Generated Interrupt 5 */
  SGI_INT6_IRQn                = 5,                /**< Software Generated Interrupt 6 */
  SGI_INT7_IRQn                = 6,                /**< Software Generated Interrupt 7 */
  SGI_INT8_IRQn                = 7,                /**< Software Generated Interrupt 8 */
  SWT_INT_IRQn                 = 8,                /**< Watchdog service */
  MU0_INT_IRQn                 = 9,                /**< ORed requests to MU0_B */
  MU1_INT_IRQn                 = 10,               /**< ORed requests to MU1_B */
  MU2_INT_IRQn                 = 11,               /**< ORed requests to MU2_B */
  MU3_INT_IRQn                 = 12,               /**< ORed requests to MU3_B */
  STM_INT0_IRQn                = 13,               /**< Channel 0 */
  STM_INT1_IRQn                = 14,               /**< Channel 1 */
  STM_INT2_IRQn                = 15,               /**< Channel 2 */
  STM_INT3_IRQn                = 16,               /**< Channel 3 */
  eDMA5_TCD0_1_INT_IRQn        = 17,               /**< DMA transfer complete and error channel 0/DMA transfer complete and error channel 1 */
  eDMA5_TCD2_3_INT_IRQn        = 18,               /**< DMA transfer complete and error channel 2/DMA transfer complete and error channel 3 */
  eDMA5_TCD16_17_INT_IRQn      = 19,               /**< DMA transfer complete and error channel 16/DMA transfer complete and error channel 17 */
  eDMA5_TCD18_19_INT_IRQn      = 20,               /**< DMA transfer complete and error channel 18/DMA transfer complete and error channel 19 */
  NEUTRON_ACCEL_INT0_1_IRQn    = 21,               /**< Functional/Fault */
  SARADC0_INT0_2_BCTU0_INT0_5_IRQn = 22,           /**< End of conversion/Error/Analog watchdog/ADC conversion triggered/ADC0 conversion data ready/ADC1 conversion data ready/ADC last command of list issued/FIFO1/FIFO2 */
  SARADC1_INT0_2_BCTU1_INT0_5_IRQn = 23,           /**< End of conversion/Error/Analog watchdog/ADC conversion triggered/ADC0 conversion data ready/ADC1 conversion data ready/ADC last command of list issued/FIFO1/FIFO2 */
  SINC_INT0_3_IRQn             = 25,               /**< Channel 0/Channel 1/Channel 2/Channel 3 */
  CANXL0_INT0_20_IRQn          = 26,               /**< CAN frame transmission from one of the Tx message buffers 0-31 completed/CAN frame transmission from one of the Tx message buffers 32-63 completed/CAN frame reception into one of the Rx message buffers 0-31 completed/CAN frame reception into one of the Rx message buffers 32-63 completed/The Rx FIFO used for reception of selected CAN frames has reached its programmable threshold/The Rx FIFO used for reception of selected CAN frames has experienced underflow or overflow/Message Receive Unit/Protocol engine error occurred related to reception or transmission of CAN frames/Receive Error Counter Interrupt/Transmit Error Counter Interrupt/Bus Off Recovery Ready Interrupt/Bus Off Interrupt/Protocol Exception Error Interrupt/Passive Error State Interrupt/Frame error during arbitration/data phase 1/Frame error during arbitration/data phase 2/Frame error during arbitration/data phase 3/Internal exception is detected/Non-correctable error occurred within internal data RAM/Correctable error occurred within internal data RAM/IP has entered or exited freeze mode */
  FLEXCAN0_INT0_13_IRQn        = 27,               /**< CAN bus went to Bus Off state/CAN has completed the Bus Off count process (it has counted 11 recessive bits 128 times) and is ready for bus off recover/Errors detected on the CAN bus/Errors detected on the CAN bus for FD messages in the Fast Bit Rate region/Transmit Error Counter transition from < 128 to >= 128/Receive Error Counter transition from < 128 to >= 128/Correctable error detected in memory read access/Non-correctable error detected in memory read access by host (cpu)/Non-correctable error detected in memory read access by CAN/The number of messages stored in FIFO is greater than the FIFO watermarker/At least one message stored in FIFO/An underflow occurs in the FIFO/An overflow occurs in the FIFO/All Message Buffers */
  FLEXCAN1_INT0_13_IRQn        = 29,               /**< CAN bus went to Bus Off state/CAN has completed the Bus Off count process (it has counted 11 recessive bits 128 times) and is ready for bus off recover/Errors detected on the CAN bus/Errors detected on the CAN bus for FD messages in the Fast Bit Rate region/Transmit Error Counter transition from < 128 to >= 128/Receive Error Counter transition from < 128 to >= 128/Correctable error detected in memory read access/Non-correctable error detected in memory read access by host (cpu)/Non-correctable error detected in memory read access by CAN/The number of messages stored in FIFO is greater than the FIFO watermarker/At least one message stored in FIFO/An underflow occurs in the FIFO/An overflow occurs in the FIFO/All Message Buffers */
  FLEXCAN2_INT0_13_IRQn        = 31,               /**< CAN bus went to Bus Off state/CAN has completed the Bus Off count process (it has counted 11 recessive bits 128 times) and is ready for bus off recover/Errors detected on the CAN bus/Errors detected on the CAN bus for FD messages in the Fast Bit Rate region/Transmit Error Counter transition from < 128 to >= 128/Receive Error Counter transition from < 128 to >= 128/Correctable error detected in memory read access/Non-correctable error detected in memory read access by host (cpu)/Non-correctable error detected in memory read access by CAN/The number of messages stored in FIFO is greater than the FIFO watermarker/At least one message stored in FIFO/An underflow occurs in the FIFO/An overflow occurs in the FIFO/All Message Buffers */
  FLEXCAN3_INT0_13_IRQn        = 33,               /**< CAN bus went to Bus Off state/CAN has completed the Bus Off count process (it has counted 11 recessive bits 128 times) and is ready for bus off recover/Errors detected on the CAN bus/Errors detected on the CAN bus for FD messages in the Fast Bit Rate region/Transmit Error Counter transition from < 128 to >= 128/Receive Error Counter transition from < 128 to >= 128/Correctable error detected in memory read access/Non-correctable error detected in memory read access by host (cpu)/Non-correctable error detected in memory read access by CAN/The number of messages stored in FIFO is greater than the FIFO watermarker/At least one message stored in FIFO/An underflow occurs in the FIFO/An overflow occurs in the FIFO/All Message Buffers */
  FLEXCAN4_INT0_13_IRQn        = 35,               /**< CAN bus went to Bus Off state/CAN has completed the Bus Off count process (it has counted 11 recessive bits 128 times) and is ready for bus off recover/Errors detected on the CAN bus/Errors detected on the CAN bus for FD messages in the Fast Bit Rate region/Transmit Error Counter transition from < 128 to >= 128/Receive Error Counter transition from < 128 to >= 128/Correctable error detected in memory read access/Non-correctable error detected in memory read access by host (cpu)/Non-correctable error detected in memory read access by CAN/The number of messages stored in FIFO is greater than the FIFO watermarker/At least one message stored in FIFO/An underflow occurs in the FIFO/An overflow occurs in the FIFO/All Message Buffers */
  FLEXCAN5_INT0_13_IRQn        = 37,               /**< CAN bus went to Bus Off state/CAN has completed the Bus Off count process (it has counted 11 recessive bits 128 times) and is ready for bus off recover/Errors detected on the CAN bus/Errors detected on the CAN bus for FD messages in the Fast Bit Rate region/Transmit Error Counter transition from < 128 to >= 128/Receive Error Counter transition from < 128 to >= 128/Correctable error detected in memory read access/Non-correctable error detected in memory read access by host (cpu)/Non-correctable error detected in memory read access by CAN/The number of messages stored in FIFO is greater than the FIFO watermarker/At least one message stored in FIFO/An underflow occurs in the FIFO/An overflow occurs in the FIFO/All Message Buffers */
  FLEXCAN6_INT0_13_IRQn        = 39,               /**< CAN bus went to Bus Off state/CAN has completed the Bus Off count process (it has counted 11 recessive bits 128 times) and is ready for bus off recover/Errors detected on the CAN bus/Errors detected on the CAN bus for FD messages in the Fast Bit Rate region/Transmit Error Counter transition from < 128 to >= 128/Receive Error Counter transition from < 128 to >= 128/Correctable error detected in memory read access/Non-correctable error detected in memory read access by host (cpu)/Non-correctable error detected in memory read access by CAN/The number of messages stored in FIFO is greater than the FIFO watermarker/At least one message stored in FIFO/An underflow occurs in the FIFO/An overflow occurs in the FIFO/All Message Buffers */
  FLEXCAN7_INT0_13_IRQn        = 41,               /**< CAN bus went to Bus Off state/CAN has completed the Bus Off count process (it has counted 11 recessive bits 128 times) and is ready for bus off recover/Errors detected on the CAN bus/Errors detected on the CAN bus for FD messages in the Fast Bit Rate region/Transmit Error Counter transition from < 128 to >= 128/Receive Error Counter transition from < 128 to >= 128/Correctable error detected in memory read access/Non-correctable error detected in memory read access by host (cpu)/Non-correctable error detected in memory read access by CAN/The number of messages stored in FIFO is greater than the FIFO watermarker/At least one message stored in FIFO/An underflow occurs in the FIFO/An overflow occurs in the FIFO/All Message Buffers */
  FLEXCAN8_INT0_13_IRQn        = 43,               /**< CAN bus went to Bus Off state/CAN has completed the Bus Off count process (it has counted 11 recessive bits 128 times) and is ready for bus off recover/Errors detected on the CAN bus/Errors detected on the CAN bus for FD messages in the Fast Bit Rate region/Transmit Error Counter transition from < 128 to >= 128/Receive Error Counter transition from < 128 to >= 128/Correctable error detected in memory read access/Non-correctable error detected in memory read access by host (cpu)/Non-correctable error detected in memory read access by CAN/The number of messages stored in FIFO is greater than the FIFO watermarker/At least one message stored in FIFO/An underflow occurs in the FIFO/An overflow occurs in the FIFO/All Message Buffers */
  FLEXIO0_INT_IRQn             = 45,               /**< FlexIO */
  FLEXIO1_INT_IRQn             = 46,               /**< FlexIO */
  LPI2C0_INT0_1_IRQn           = 47,               /**< Master/Slave */
  LPI2C1_INT0_1_IRQn           = 48,               /**< Master/Slave */
  LPSPI0_INT_IRQn              = 49,               /**< Transmit and receive data and errors */
  LPSPI1_INT_IRQn              = 50,               /**< Transmit and receive data and errors */
  LPUART0_INT0_1_IRQn          = 51,               /**< Transmit data and errors/Receive data and errors */
  LPUART1_INT0_1_IRQn          = 52,               /**< Transmit data and errors/Receive data and errors */
  LPUART2_INT0_1_IRQn          = 53,               /**< Transmit data and errors/Receive data and errors */
  LPUART3_INT0_1_IRQn          = 54,               /**< Transmit data and errors/Receive data and errors */
  LPUART4_INT0_1_IRQn          = 55,               /**< Transmit data and errors/Receive data and errors */
  LPUART5_INT0_1_IRQn          = 56,               /**< Transmit data and errors/Receive data and errors */
  LPUART6_INT0_1_IRQn          = 57,               /**< Transmit data and errors/Receive data and errors */
  LPUART7_INT0_1_IRQn          = 58,               /**< Transmit data and errors/Receive data and errors */
  LPUART8_INT0_1_IRQn          = 59,               /**< Transmit data and errors/Receive data and errors */
  LPUART9_INT0_1_IRQn          = 60,               /**< Transmit data and errors/Receive data and errors */
  LPUART10_INT0_1_IRQn         = 61,               /**< Transmit data and errors/Receive data and errors */
  LPUART11_INT0_1_IRQn         = 62,               /**< Transmit data and errors/Receive data and errors */
  LPUART12_INT0_1_IRQn         = 63,               /**< Transmit data and errors/Receive data and errors */
  MSGINTR0_INT0_2_IRQn         = 64,               /**< Message signaled interrupt register 0/Message signaled interrupt register 1/Message signaled interrupt register 2 */
  MSGINTR1_INT0_2_IRQn         = 65,               /**< Message signaled interrupt register 0/Message signaled interrupt register 1/Message signaled interrupt register 2 */
  MSGINTR2_INT0_2_IRQn         = 66,               /**< Message signaled interrupt register 0/Message signaled interrupt register 1/Message signaled interrupt register 2 */
  MSGINTR3_INT0_2_IRQn         = 67,               /**< Message signaled interrupt register 0/Message signaled interrupt register 1/Message signaled interrupt register 2 */
  MSGINTR4_INT0_2_IRQn         = 68,               /**< Message signaled interrupt register 0/Message signaled interrupt register 1/Message signaled interrupt register 2 */
  NETC_IEPRC_INT0_1_IRQn       = 71,               /**< NETC Root Complex PCI 0/NETC Root Complex PCI 1 */
  RXLUT_INT_IRQn               = 72,               /**< RXLUT */
  SAI0_INT0_1_IRQn             = 73,               /**< Receive/Transmit */
  SAI1_INT0_1_IRQn             = 74                /**< Receive/Transmit */
} IRQn_Type;

/*!
 * @}
 */ /* end of group Interrupt_vector_numbers */


/* ----------------------------------------------------------------------------
   -- SDK Compatibility
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup SDK_Compatibility_Symbols SDK Compatibility
 * @{
 */

/* No SDK compatibility issues. */

/*!
 * @}
 */ /* end of group SDK_Compatibility_Symbols */


#endif  /* #if !defined(S32K566_DSPV_COMMON_H_) */

