/*
** ###################################################################
**     Processor:           S32K566_M7
**     Compiler:            Keil ARM C/C++ Compiler
**     Reference manual:    S32K5 RM Rev 3
**     Version:             rev. 2.7, 2026-09-09
**     Build:               b260908
**
**     Abstract:
**         Peripheral Access Layer for S32K566_M7
**
**     Copyright 1997-2016 Freescale Semiconductor, Inc.
**     Copyright 2016-2026 NXP
**
**     NXP Confidential and Proprietary. This software is owned or controlled
**     by NXP and may only be used strictly in accordance with the applicable
**     license terms. By expressly accepting such terms or by downloading,
**     installing, activating and/or otherwise using the software, you are
**     agreeing that you have read, and that you agree to comply with and are
**     bound by, such license terms. If you do not agree to be bound by the
**     applicable license terms, then you may not retain, install, activate
**     or otherwise use the software.
**
**     http:                 www.nxp.com
**     mail:                 support@nxp.com
**
** ###################################################################
*/

/*!
 * @file S32K566_K566_RTU_GPR.h
 * @version 2.7
 * @date 2026-09-09
 * @brief Peripheral Access Layer for S32K566_K566_RTU_GPR
 *
 * This file contains register definitions and macros for easy access to their
 * bit fields.
 *
 * This file assumes LITTLE endian system.
 */

/**
* @page misra_violations MISRA-C:2012 violations
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.3, local typedef not referenced
* The SoC header defines typedef for all modules.
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.5, local macro not referenced
* The SoC header defines macros for all modules and registers.
*
* @section [global]
* Violates MISRA 2012 Advisory Directive 4.9, Function-like macro
* These are generated macros used for accessing the bit-fields from registers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.1, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.2, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.4, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.5, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 21.1, defined macro '__I' is reserved to the compiler
* This type qualifier is needed to ensure correct I/O access and addressing.
*/

/* Prevention from multiple including the same memory map */
#if !defined(S32K566_K566_RTU_GPR_H_)  /* Check if memory map has not been already included */
#define S32K566_K566_RTU_GPR_H_

#include "S32K566_COMMON.h"

/* ----------------------------------------------------------------------------
   -- K566_RTU_GPR Peripheral Access Layer
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup K566_RTU_GPR_Peripheral_Access_Layer K566_RTU_GPR Peripheral Access Layer
 * @{
 */

/** K566_RTU_GPR - Register Layout Typedef */
typedef struct K566_RTU_GPR_Struct {
  __IO uint32_t R52_CLUSTER0;                      /**< R52 Cluster0 Configuration, offset: 0x0 */
  __IO uint32_t FD_EN;                             /**< Fence And Drain Enable, offset: 0x4 */
  __IO uint32_t CR52_CNT_DIV;                      /**< Generic Timer Counter Divider Control, offset: 0x8 */
  __IO uint32_t CR52_HALT;                         /**< Core Halt Control, offset: 0xC */
  __I  uint32_t STAT_FD;                           /**< Fence And Drain Status, offset: 0x10 */
  __I  uint32_t SSI_IDLE_STAT;                     /**< SSI Idle Status, offset: 0x14 */
  __I  uint32_t CR52_STANDBYWFI;                   /**< R52 Standby Wait For Interrupt (WFI) Status, offset: 0x18 */
  __I  uint32_t CR52_STANDBYWFE;                   /**< R52 Standby Wait For Event (WFE) Status, offset: 0x1C */
  __I  uint32_t CR52_RESETREQ;                     /**< R52 Reset Request, offset: 0x20 */
  __IO uint32_t PMCMBISTDIS;                       /**< Programmable MBIST Controller (PMC) Disable, offset: 0x24 */
  __IO uint32_t MBUSPARDIS;                        /**< Bus Parity Error Disable Group 0, offset: 0x28 */
  __IO uint32_t NBUSPARDIS;                        /**< Bus Parity Error Disable Group 1, offset: 0x2C */
  uint8_t RESERVED_0[16];
  __IO uint32_t SSI_0;                             /**< Source Synchronous Interface (SSI) Gasket 0 configurations, offset: 0x40 */
  __IO uint32_t SSI_1;                             /**< Source Synchronous Interface (SSI) Gasket 0 configurations, offset: 0x44 */
  __IO uint32_t SSI_2;                             /**< Source Synchronous Interface (SSI) Gasket 0 configurations, offset: 0x48 */
  __IO uint32_t SSI_3;                             /**< Source Synchronous Interface (SSI) Gasket 0 configurations, offset: 0x4C */
  __IO uint32_t MRAM_ECC_DATA;                     /**< MRAM ECC Data correction Status, offset: 0x50 */
  __IO uint32_t R52_CORE_0_SW_FAULT;               /**< Software Fault Control 0, offset: 0x54 */
  __IO uint32_t R52_CORE_1_SW_FAULT;               /**< Software Fault Control 1, offset: 0x58 */
  __IO uint32_t ERREVENT0;                         /**< Core0 External Event Status, offset: 0x5C */
  __IO uint32_t ERREVENT1;                         /**< Core1 External Event Status, offset: 0x60 */
  __IO uint32_t PRIMEMERR0;                        /**< Primary Error Interface Memory Identifier Core0, offset: 0x64 */
  __IO uint32_t PRIMEMERRIDX0;                     /**< Primary Error Interface Index Core0, offset: 0x68 */
  __IO uint32_t SECMEMERR0;                        /**< Secondary Error Interface Memory Identifier Core0, offset: 0x6C */
  __IO uint32_t SECMEMERRIDX0;                     /**< Secondary Error Interface Index Core0, offset: 0x70 */
  __IO uint32_t PRIMEMERR1;                        /**< Primary Error Interface Memory Identifier Core1, offset: 0x74 */
  __IO uint32_t PRIMEMERRIDX1;                     /**< Primary Error Interface Index Core1, offset: 0x78 */
  __IO uint32_t SECMEMERR1;                        /**< Secondary Error Interface Memory Identifier Core1, offset: 0x7C */
  __IO uint32_t SECMEMERRIDX1;                     /**< Secondary Error Interface Index Core1, offset: 0x80 */
  __IO uint32_t PMUEVENTSTAT0;                     /**< PMU Event Core0 Group0, offset: 0x84 */
  __IO uint32_t PMUEVENTSTAT1;                     /**< PMU Event Core0 Group1, offset: 0x88 */
  __IO uint32_t PMUEVENTSTAT2;                     /**< PMU Event Core1 Group0, offset: 0x8C */
  __IO uint32_t PMUEVENTSTAT3;                     /**< PMU Event Core1 Group1, offset: 0x90 */
  __IO uint32_t PLL_PD_RGM_REQ;                    /**< PLL Power Down Request, offset: 0x94 */
  __I  uint32_t PLL_PD_RGM_ACK;                    /**< PLL Power Down Acknowledgement, offset: 0x98 */
  uint8_t RESERVED_1[8];
  __IO uint32_t R52_PMC_CPE_PERIPH_BRIDGE_ISOLATION; /**< R52_PMC TO CPE_PERIPH_BRIDGE Isolation, offset: 0xA4 */
  uint8_t RESERVED_2[32];
  __IO uint32_t CPE_CLKOUT_MUX;                    /**< CPE CLKOUT_MUX configuration register, offset: 0xC8 */
  __IO uint32_t LOCK_STEP_CONTROL;                 /**< offset: 0xCC */
  __IO uint32_t OMU_CAL_DIS_CONTROL;               /**< offset: 0xD0 */
} K566_RTU_GPR_Type, *K566_RTU_GPR_MemMapPtr;

/** Number of instances of the K566_RTU_GPR module. */
#define K566_RTU_GPR_INSTANCE_COUNT              (1u)

/* K566_RTU_GPR - Peripheral instance base addresses */
/** Peripheral CPE_GPR base address */
#define IP_CPE_GPR_BASE                          (0x41004000u)
/** Peripheral CPE_GPR base pointer */
#define IP_CPE_GPR                               ((K566_RTU_GPR_Type *)IP_CPE_GPR_BASE)
/** Array initializer of K566_RTU_GPR peripheral base addresses */
#define IP_K566_RTU_GPR_BASE_ADDRS               { IP_CPE_GPR_BASE }
/** Array initializer of K566_RTU_GPR peripheral base pointers */
#define IP_K566_RTU_GPR_BASE_PTRS                { IP_CPE_GPR }

/* ----------------------------------------------------------------------------
   -- K566_RTU_GPR Register Masks
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup K566_RTU_GPR_Register_Masks K566_RTU_GPR Register Masks
 * @{
 */

/*! @name R52_CLUSTER0 - R52 Cluster0 Configuration */
/*! @{ */

#define K566_RTU_GPR_R52_CLUSTER0_TCMBOOT0_MASK  (0x1U)
#define K566_RTU_GPR_R52_CLUSTER0_TCMBOOT0_SHIFT (0U)
#define K566_RTU_GPR_R52_CLUSTER0_TCMBOOT0_WIDTH (1U)
#define K566_RTU_GPR_R52_CLUSTER0_TCMBOOT0(x)    (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_R52_CLUSTER0_TCMBOOT0_SHIFT)) & K566_RTU_GPR_R52_CLUSTER0_TCMBOOT0_MASK)

#define K566_RTU_GPR_R52_CLUSTER0_TCMBOOT1_MASK  (0x2U)
#define K566_RTU_GPR_R52_CLUSTER0_TCMBOOT1_SHIFT (1U)
#define K566_RTU_GPR_R52_CLUSTER0_TCMBOOT1_WIDTH (1U)
#define K566_RTU_GPR_R52_CLUSTER0_TCMBOOT1(x)    (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_R52_CLUSTER0_TCMBOOT1_SHIFT)) & K566_RTU_GPR_R52_CLUSTER0_TCMBOOT1_MASK)

#define K566_RTU_GPR_R52_CLUSTER0_THUMB0_MASK    (0x4U)
#define K566_RTU_GPR_R52_CLUSTER0_THUMB0_SHIFT   (2U)
#define K566_RTU_GPR_R52_CLUSTER0_THUMB0_WIDTH   (1U)
#define K566_RTU_GPR_R52_CLUSTER0_THUMB0(x)      (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_R52_CLUSTER0_THUMB0_SHIFT)) & K566_RTU_GPR_R52_CLUSTER0_THUMB0_MASK)

#define K566_RTU_GPR_R52_CLUSTER0_THUMB1_MASK    (0x8U)
#define K566_RTU_GPR_R52_CLUSTER0_THUMB1_SHIFT   (3U)
#define K566_RTU_GPR_R52_CLUSTER0_THUMB1_WIDTH   (1U)
#define K566_RTU_GPR_R52_CLUSTER0_THUMB1(x)      (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_R52_CLUSTER0_THUMB1_SHIFT)) & K566_RTU_GPR_R52_CLUSTER0_THUMB1_MASK)

#define K566_RTU_GPR_R52_CLUSTER0_CAINV0_MASK    (0x10U)
#define K566_RTU_GPR_R52_CLUSTER0_CAINV0_SHIFT   (4U)
#define K566_RTU_GPR_R52_CLUSTER0_CAINV0_WIDTH   (1U)
#define K566_RTU_GPR_R52_CLUSTER0_CAINV0(x)      (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_R52_CLUSTER0_CAINV0_SHIFT)) & K566_RTU_GPR_R52_CLUSTER0_CAINV0_MASK)

#define K566_RTU_GPR_R52_CLUSTER0_CAINV1_MASK    (0x20U)
#define K566_RTU_GPR_R52_CLUSTER0_CAINV1_SHIFT   (5U)
#define K566_RTU_GPR_R52_CLUSTER0_CAINV1_WIDTH   (1U)
#define K566_RTU_GPR_R52_CLUSTER0_CAINV1(x)      (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_R52_CLUSTER0_CAINV1_SHIFT)) & K566_RTU_GPR_R52_CLUSTER0_CAINV1_MASK)

#define K566_RTU_GPR_R52_CLUSTER0_INITREG_MASK   (0x40U)
#define K566_RTU_GPR_R52_CLUSTER0_INITREG_SHIFT  (6U)
#define K566_RTU_GPR_R52_CLUSTER0_INITREG_WIDTH  (1U)
#define K566_RTU_GPR_R52_CLUSTER0_INITREG(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_R52_CLUSTER0_INITREG_SHIFT)) & K566_RTU_GPR_R52_CLUSTER0_INITREG_MASK)

#define K566_RTU_GPR_R52_CLUSTER0_ENDIANESS0_MASK (0x80U)
#define K566_RTU_GPR_R52_CLUSTER0_ENDIANESS0_SHIFT (7U)
#define K566_RTU_GPR_R52_CLUSTER0_ENDIANESS0_WIDTH (1U)
#define K566_RTU_GPR_R52_CLUSTER0_ENDIANESS0(x)  (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_R52_CLUSTER0_ENDIANESS0_SHIFT)) & K566_RTU_GPR_R52_CLUSTER0_ENDIANESS0_MASK)

#define K566_RTU_GPR_R52_CLUSTER0_ENDIANESS1_MASK (0x100U)
#define K566_RTU_GPR_R52_CLUSTER0_ENDIANESS1_SHIFT (8U)
#define K566_RTU_GPR_R52_CLUSTER0_ENDIANESS1_WIDTH (1U)
#define K566_RTU_GPR_R52_CLUSTER0_ENDIANESS1(x)  (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_R52_CLUSTER0_ENDIANESS1_SHIFT)) & K566_RTU_GPR_R52_CLUSTER0_ENDIANESS1_MASK)
/*! @} */

/*! @name FD_EN - Fence And Drain Enable */
/*! @{ */

#define K566_RTU_GPR_FD_EN_MFDEN0_MASK           (0x1U)
#define K566_RTU_GPR_FD_EN_MFDEN0_SHIFT          (0U)
#define K566_RTU_GPR_FD_EN_MFDEN0_WIDTH          (1U)
#define K566_RTU_GPR_FD_EN_MFDEN0(x)             (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_FD_EN_MFDEN0_SHIFT)) & K566_RTU_GPR_FD_EN_MFDEN0_MASK)

#define K566_RTU_GPR_FD_EN_MFDEN1_MASK           (0x2U)
#define K566_RTU_GPR_FD_EN_MFDEN1_SHIFT          (1U)
#define K566_RTU_GPR_FD_EN_MFDEN1_WIDTH          (1U)
#define K566_RTU_GPR_FD_EN_MFDEN1(x)             (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_FD_EN_MFDEN1_SHIFT)) & K566_RTU_GPR_FD_EN_MFDEN1_MASK)

#define K566_RTU_GPR_FD_EN_LFDEN0_MASK           (0x4U)
#define K566_RTU_GPR_FD_EN_LFDEN0_SHIFT          (2U)
#define K566_RTU_GPR_FD_EN_LFDEN0_WIDTH          (1U)
#define K566_RTU_GPR_FD_EN_LFDEN0(x)             (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_FD_EN_LFDEN0_SHIFT)) & K566_RTU_GPR_FD_EN_LFDEN0_MASK)

#define K566_RTU_GPR_FD_EN_LFDEN1_MASK           (0x8U)
#define K566_RTU_GPR_FD_EN_LFDEN1_SHIFT          (3U)
#define K566_RTU_GPR_FD_EN_LFDEN1_WIDTH          (1U)
#define K566_RTU_GPR_FD_EN_LFDEN1(x)             (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_FD_EN_LFDEN1_SHIFT)) & K566_RTU_GPR_FD_EN_LFDEN1_MASK)

#define K566_RTU_GPR_FD_EN_SFDEN_MASK            (0x10U)
#define K566_RTU_GPR_FD_EN_SFDEN_SHIFT           (4U)
#define K566_RTU_GPR_FD_EN_SFDEN_WIDTH           (1U)
#define K566_RTU_GPR_FD_EN_SFDEN(x)              (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_FD_EN_SFDEN_SHIFT)) & K566_RTU_GPR_FD_EN_SFDEN_MASK)

#define K566_RTU_GPR_FD_EN_ISOLEN0_MASK          (0x20U)
#define K566_RTU_GPR_FD_EN_ISOLEN0_SHIFT         (5U)
#define K566_RTU_GPR_FD_EN_ISOLEN0_WIDTH         (1U)
#define K566_RTU_GPR_FD_EN_ISOLEN0(x)            (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_FD_EN_ISOLEN0_SHIFT)) & K566_RTU_GPR_FD_EN_ISOLEN0_MASK)

#define K566_RTU_GPR_FD_EN_ISOLEN1_MASK          (0x40U)
#define K566_RTU_GPR_FD_EN_ISOLEN1_SHIFT         (6U)
#define K566_RTU_GPR_FD_EN_ISOLEN1_WIDTH         (1U)
#define K566_RTU_GPR_FD_EN_ISOLEN1(x)            (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_FD_EN_ISOLEN1_SHIFT)) & K566_RTU_GPR_FD_EN_ISOLEN1_MASK)
/*! @} */

/*! @name CR52_CNT_DIV - Generic Timer Counter Divider Control */
/*! @{ */

#define K566_RTU_GPR_CR52_CNT_DIV_CNTDV_MASK     (0x7U)
#define K566_RTU_GPR_CR52_CNT_DIV_CNTDV_SHIFT    (0U)
#define K566_RTU_GPR_CR52_CNT_DIV_CNTDV_WIDTH    (3U)
#define K566_RTU_GPR_CR52_CNT_DIV_CNTDV(x)       (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_CR52_CNT_DIV_CNTDV_SHIFT)) & K566_RTU_GPR_CR52_CNT_DIV_CNTDV_MASK)
/*! @} */

/*! @name CR52_HALT - Core Halt Control */
/*! @{ */

#define K566_RTU_GPR_CR52_HALT_HALT0_MASK        (0x1U)
#define K566_RTU_GPR_CR52_HALT_HALT0_SHIFT       (0U)
#define K566_RTU_GPR_CR52_HALT_HALT0_WIDTH       (1U)
#define K566_RTU_GPR_CR52_HALT_HALT0(x)          (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_CR52_HALT_HALT0_SHIFT)) & K566_RTU_GPR_CR52_HALT_HALT0_MASK)

#define K566_RTU_GPR_CR52_HALT_HALT1_MASK        (0x2U)
#define K566_RTU_GPR_CR52_HALT_HALT1_SHIFT       (1U)
#define K566_RTU_GPR_CR52_HALT_HALT1_WIDTH       (1U)
#define K566_RTU_GPR_CR52_HALT_HALT1(x)          (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_CR52_HALT_HALT1_SHIFT)) & K566_RTU_GPR_CR52_HALT_HALT1_MASK)
/*! @} */

/*! @name STAT_FD - Fence And Drain Status */
/*! @{ */

#define K566_RTU_GPR_STAT_FD_MFDID0_MASK         (0x1U)
#define K566_RTU_GPR_STAT_FD_MFDID0_SHIFT        (0U)
#define K566_RTU_GPR_STAT_FD_MFDID0_WIDTH        (1U)
#define K566_RTU_GPR_STAT_FD_MFDID0(x)           (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_STAT_FD_MFDID0_SHIFT)) & K566_RTU_GPR_STAT_FD_MFDID0_MASK)

#define K566_RTU_GPR_STAT_FD_MFDID1_MASK         (0x2U)
#define K566_RTU_GPR_STAT_FD_MFDID1_SHIFT        (1U)
#define K566_RTU_GPR_STAT_FD_MFDID1_WIDTH        (1U)
#define K566_RTU_GPR_STAT_FD_MFDID1(x)           (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_STAT_FD_MFDID1_SHIFT)) & K566_RTU_GPR_STAT_FD_MFDID1_MASK)

#define K566_RTU_GPR_STAT_FD_LFDID0_MASK         (0x4U)
#define K566_RTU_GPR_STAT_FD_LFDID0_SHIFT        (2U)
#define K566_RTU_GPR_STAT_FD_LFDID0_WIDTH        (1U)
#define K566_RTU_GPR_STAT_FD_LFDID0(x)           (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_STAT_FD_LFDID0_SHIFT)) & K566_RTU_GPR_STAT_FD_LFDID0_MASK)

#define K566_RTU_GPR_STAT_FD_LFDID1_MASK         (0x8U)
#define K566_RTU_GPR_STAT_FD_LFDID1_SHIFT        (3U)
#define K566_RTU_GPR_STAT_FD_LFDID1_WIDTH        (1U)
#define K566_RTU_GPR_STAT_FD_LFDID1(x)           (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_STAT_FD_LFDID1_SHIFT)) & K566_RTU_GPR_STAT_FD_LFDID1_MASK)

#define K566_RTU_GPR_STAT_FD_SFDID1_MASK         (0x10U)
#define K566_RTU_GPR_STAT_FD_SFDID1_SHIFT        (4U)
#define K566_RTU_GPR_STAT_FD_SFDID1_WIDTH        (1U)
#define K566_RTU_GPR_STAT_FD_SFDID1(x)           (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_STAT_FD_SFDID1_SHIFT)) & K566_RTU_GPR_STAT_FD_SFDID1_MASK)
/*! @} */

/*! @name SSI_IDLE_STAT - SSI Idle Status */
/*! @{ */

#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_0_MASK   (0x1U)
#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_0_SHIFT  (0U)
#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_0_WIDTH  (1U)
#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_0(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_IDLE_STAT_STAT_0_SHIFT)) & K566_RTU_GPR_SSI_IDLE_STAT_STAT_0_MASK)

#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_1_MASK   (0x2U)
#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_1_SHIFT  (1U)
#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_1_WIDTH  (1U)
#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_1(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_IDLE_STAT_STAT_1_SHIFT)) & K566_RTU_GPR_SSI_IDLE_STAT_STAT_1_MASK)

#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_2_MASK   (0x4U)
#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_2_SHIFT  (2U)
#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_2_WIDTH  (1U)
#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_2(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_IDLE_STAT_STAT_2_SHIFT)) & K566_RTU_GPR_SSI_IDLE_STAT_STAT_2_MASK)

#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_3_MASK   (0x8U)
#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_3_SHIFT  (3U)
#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_3_WIDTH  (1U)
#define K566_RTU_GPR_SSI_IDLE_STAT_STAT_3(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_IDLE_STAT_STAT_3_SHIFT)) & K566_RTU_GPR_SSI_IDLE_STAT_STAT_3_MASK)
/*! @} */

/*! @name CR52_STANDBYWFI - R52 Standby Wait For Interrupt (WFI) Status */
/*! @{ */

#define K566_RTU_GPR_CR52_STANDBYWFI_WFI0_MASK   (0x1U)
#define K566_RTU_GPR_CR52_STANDBYWFI_WFI0_SHIFT  (0U)
#define K566_RTU_GPR_CR52_STANDBYWFI_WFI0_WIDTH  (1U)
#define K566_RTU_GPR_CR52_STANDBYWFI_WFI0(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_CR52_STANDBYWFI_WFI0_SHIFT)) & K566_RTU_GPR_CR52_STANDBYWFI_WFI0_MASK)

#define K566_RTU_GPR_CR52_STANDBYWFI_WFI1_MASK   (0x2U)
#define K566_RTU_GPR_CR52_STANDBYWFI_WFI1_SHIFT  (1U)
#define K566_RTU_GPR_CR52_STANDBYWFI_WFI1_WIDTH  (1U)
#define K566_RTU_GPR_CR52_STANDBYWFI_WFI1(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_CR52_STANDBYWFI_WFI1_SHIFT)) & K566_RTU_GPR_CR52_STANDBYWFI_WFI1_MASK)
/*! @} */

/*! @name CR52_STANDBYWFE - R52 Standby Wait For Event (WFE) Status */
/*! @{ */

#define K566_RTU_GPR_CR52_STANDBYWFE_WFE0_MASK   (0x1U)
#define K566_RTU_GPR_CR52_STANDBYWFE_WFE0_SHIFT  (0U)
#define K566_RTU_GPR_CR52_STANDBYWFE_WFE0_WIDTH  (1U)
#define K566_RTU_GPR_CR52_STANDBYWFE_WFE0(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_CR52_STANDBYWFE_WFE0_SHIFT)) & K566_RTU_GPR_CR52_STANDBYWFE_WFE0_MASK)

#define K566_RTU_GPR_CR52_STANDBYWFE_WFE1_MASK   (0x2U)
#define K566_RTU_GPR_CR52_STANDBYWFE_WFE1_SHIFT  (1U)
#define K566_RTU_GPR_CR52_STANDBYWFE_WFE1_WIDTH  (1U)
#define K566_RTU_GPR_CR52_STANDBYWFE_WFE1(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_CR52_STANDBYWFE_WFE1_SHIFT)) & K566_RTU_GPR_CR52_STANDBYWFE_WFE1_MASK)
/*! @} */

/*! @name CR52_RESETREQ - R52 Reset Request */
/*! @{ */

#define K566_RTU_GPR_CR52_RESETREQ_WARMRSTREQ0_MASK (0x1U)
#define K566_RTU_GPR_CR52_RESETREQ_WARMRSTREQ0_SHIFT (0U)
#define K566_RTU_GPR_CR52_RESETREQ_WARMRSTREQ0_WIDTH (1U)
#define K566_RTU_GPR_CR52_RESETREQ_WARMRSTREQ0(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_CR52_RESETREQ_WARMRSTREQ0_SHIFT)) & K566_RTU_GPR_CR52_RESETREQ_WARMRSTREQ0_MASK)

#define K566_RTU_GPR_CR52_RESETREQ_WARMRSTREQ1_MASK (0x2U)
#define K566_RTU_GPR_CR52_RESETREQ_WARMRSTREQ1_SHIFT (1U)
#define K566_RTU_GPR_CR52_RESETREQ_WARMRSTREQ1_WIDTH (1U)
#define K566_RTU_GPR_CR52_RESETREQ_WARMRSTREQ1(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_CR52_RESETREQ_WARMRSTREQ1_SHIFT)) & K566_RTU_GPR_CR52_RESETREQ_WARMRSTREQ1_MASK)
/*! @} */

/*! @name PMCMBISTDIS - Programmable MBIST Controller (PMC) Disable */
/*! @{ */

#define K566_RTU_GPR_PMCMBISTDIS_DIS_MASK        (0x1U)
#define K566_RTU_GPR_PMCMBISTDIS_DIS_SHIFT       (0U)
#define K566_RTU_GPR_PMCMBISTDIS_DIS_WIDTH       (1U)
#define K566_RTU_GPR_PMCMBISTDIS_DIS(x)          (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_PMCMBISTDIS_DIS_SHIFT)) & K566_RTU_GPR_PMCMBISTDIS_DIS_MASK)
/*! @} */

/*! @name MBUSPARDIS - Bus Parity Error Disable Group 0 */
/*! @{ */

#define K566_RTU_GPR_MBUSPARDIS_BUPERR0_MASK     (0x1U)
#define K566_RTU_GPR_MBUSPARDIS_BUPERR0_SHIFT    (0U)
#define K566_RTU_GPR_MBUSPARDIS_BUPERR0_WIDTH    (1U)
#define K566_RTU_GPR_MBUSPARDIS_BUPERR0(x)       (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_MBUSPARDIS_BUPERR0_SHIFT)) & K566_RTU_GPR_MBUSPARDIS_BUPERR0_MASK)

#define K566_RTU_GPR_MBUSPARDIS_BUPERR1_MASK     (0x2U)
#define K566_RTU_GPR_MBUSPARDIS_BUPERR1_SHIFT    (1U)
#define K566_RTU_GPR_MBUSPARDIS_BUPERR1_WIDTH    (1U)
#define K566_RTU_GPR_MBUSPARDIS_BUPERR1(x)       (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_MBUSPARDIS_BUPERR1_SHIFT)) & K566_RTU_GPR_MBUSPARDIS_BUPERR1_MASK)

#define K566_RTU_GPR_MBUSPARDIS_BUPERR2_MASK     (0x4U)
#define K566_RTU_GPR_MBUSPARDIS_BUPERR2_SHIFT    (2U)
#define K566_RTU_GPR_MBUSPARDIS_BUPERR2_WIDTH    (1U)
#define K566_RTU_GPR_MBUSPARDIS_BUPERR2(x)       (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_MBUSPARDIS_BUPERR2_SHIFT)) & K566_RTU_GPR_MBUSPARDIS_BUPERR2_MASK)
/*! @} */

/*! @name NBUSPARDIS - Bus Parity Error Disable Group 1 */
/*! @{ */

#define K566_RTU_GPR_NBUSPARDIS_BUPERR0_MASK     (0x1U)
#define K566_RTU_GPR_NBUSPARDIS_BUPERR0_SHIFT    (0U)
#define K566_RTU_GPR_NBUSPARDIS_BUPERR0_WIDTH    (1U)
#define K566_RTU_GPR_NBUSPARDIS_BUPERR0(x)       (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_NBUSPARDIS_BUPERR0_SHIFT)) & K566_RTU_GPR_NBUSPARDIS_BUPERR0_MASK)
/*! @} */

/*! @name SSI_0 - Source Synchronous Interface (SSI) Gasket 0 configurations */
/*! @{ */

#define K566_RTU_GPR_SSI_0_iso_control_MASK      (0x8U)
#define K566_RTU_GPR_SSI_0_iso_control_SHIFT     (3U)
#define K566_RTU_GPR_SSI_0_iso_control_WIDTH     (1U)
#define K566_RTU_GPR_SSI_0_iso_control(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_0_iso_control_SHIFT)) & K566_RTU_GPR_SSI_0_iso_control_MASK)

#define K566_RTU_GPR_SSI_0_inject_error_en_MASK  (0x20U)
#define K566_RTU_GPR_SSI_0_inject_error_en_SHIFT (5U)
#define K566_RTU_GPR_SSI_0_inject_error_en_WIDTH (1U)
#define K566_RTU_GPR_SSI_0_inject_error_en(x)    (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_0_inject_error_en_SHIFT)) & K566_RTU_GPR_SSI_0_inject_error_en_MASK)

#define K566_RTU_GPR_SSI_0_report_slice_lost_MASK (0x40U)
#define K566_RTU_GPR_SSI_0_report_slice_lost_SHIFT (6U)
#define K566_RTU_GPR_SSI_0_report_slice_lost_WIDTH (1U)
#define K566_RTU_GPR_SSI_0_report_slice_lost(x)  (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_0_report_slice_lost_SHIFT)) & K566_RTU_GPR_SSI_0_report_slice_lost_MASK)

#define K566_RTU_GPR_SSI_0_report_ctrl_logic_failure_MASK (0x100U)
#define K566_RTU_GPR_SSI_0_report_ctrl_logic_failure_SHIFT (8U)
#define K566_RTU_GPR_SSI_0_report_ctrl_logic_failure_WIDTH (1U)
#define K566_RTU_GPR_SSI_0_report_ctrl_logic_failure(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_0_report_ctrl_logic_failure_SHIFT)) & K566_RTU_GPR_SSI_0_report_ctrl_logic_failure_MASK)

#define K566_RTU_GPR_SSI_0_use_report_port_values_MASK (0x200U)
#define K566_RTU_GPR_SSI_0_use_report_port_values_SHIFT (9U)
#define K566_RTU_GPR_SSI_0_use_report_port_values_WIDTH (1U)
#define K566_RTU_GPR_SSI_0_use_report_port_values(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_0_use_report_port_values_SHIFT)) & K566_RTU_GPR_SSI_0_use_report_port_values_MASK)

#define K566_RTU_GPR_SSI_0_clr_parity_err_MASK   (0x400U)
#define K566_RTU_GPR_SSI_0_clr_parity_err_SHIFT  (10U)
#define K566_RTU_GPR_SSI_0_clr_parity_err_WIDTH  (1U)
#define K566_RTU_GPR_SSI_0_clr_parity_err(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_0_clr_parity_err_SHIFT)) & K566_RTU_GPR_SSI_0_clr_parity_err_MASK)

#define K566_RTU_GPR_SSI_0_inj_err_on_ctrl_logic_id_MASK (0x800U)
#define K566_RTU_GPR_SSI_0_inj_err_on_ctrl_logic_id_SHIFT (11U)
#define K566_RTU_GPR_SSI_0_inj_err_on_ctrl_logic_id_WIDTH (1U)
#define K566_RTU_GPR_SSI_0_inj_err_on_ctrl_logic_id(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_0_inj_err_on_ctrl_logic_id_SHIFT)) & K566_RTU_GPR_SSI_0_inj_err_on_ctrl_logic_id_MASK)

#define K566_RTU_GPR_SSI_0_clr_unint_mode_trans_det_MASK (0x1000U)
#define K566_RTU_GPR_SSI_0_clr_unint_mode_trans_det_SHIFT (12U)
#define K566_RTU_GPR_SSI_0_clr_unint_mode_trans_det_WIDTH (1U)
#define K566_RTU_GPR_SSI_0_clr_unint_mode_trans_det(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_0_clr_unint_mode_trans_det_SHIFT)) & K566_RTU_GPR_SSI_0_clr_unint_mode_trans_det_MASK)

#define K566_RTU_GPR_SSI_0_test_using_reg_MASK   (0x2000U)
#define K566_RTU_GPR_SSI_0_test_using_reg_SHIFT  (13U)
#define K566_RTU_GPR_SSI_0_test_using_reg_WIDTH  (1U)
#define K566_RTU_GPR_SSI_0_test_using_reg(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_0_test_using_reg_SHIFT)) & K566_RTU_GPR_SSI_0_test_using_reg_MASK)

#define K566_RTU_GPR_SSI_0_inj_sm_fault_sm_MASK  (0x1C000U)
#define K566_RTU_GPR_SSI_0_inj_sm_fault_sm_SHIFT (14U)
#define K566_RTU_GPR_SSI_0_inj_sm_fault_sm_WIDTH (3U)
#define K566_RTU_GPR_SSI_0_inj_sm_fault_sm(x)    (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_0_inj_sm_fault_sm_SHIFT)) & K566_RTU_GPR_SSI_0_inj_sm_fault_sm_MASK)
/*! @} */

/*! @name SSI_1 - Source Synchronous Interface (SSI) Gasket 0 configurations */
/*! @{ */

#define K566_RTU_GPR_SSI_1_black_hole_mode_b_MASK (0x1U)
#define K566_RTU_GPR_SSI_1_black_hole_mode_b_SHIFT (0U)
#define K566_RTU_GPR_SSI_1_black_hole_mode_b_WIDTH (1U)
#define K566_RTU_GPR_SSI_1_black_hole_mode_b(x)  (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_1_black_hole_mode_b_SHIFT)) & K566_RTU_GPR_SSI_1_black_hole_mode_b_MASK)

#define K566_RTU_GPR_SSI_1_pause_mode_MASK       (0x2U)
#define K566_RTU_GPR_SSI_1_pause_mode_SHIFT      (1U)
#define K566_RTU_GPR_SSI_1_pause_mode_WIDTH      (1U)
#define K566_RTU_GPR_SSI_1_pause_mode(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_1_pause_mode_SHIFT)) & K566_RTU_GPR_SSI_1_pause_mode_MASK)

#define K566_RTU_GPR_SSI_1_iso_control_MASK      (0x8U)
#define K566_RTU_GPR_SSI_1_iso_control_SHIFT     (3U)
#define K566_RTU_GPR_SSI_1_iso_control_WIDTH     (1U)
#define K566_RTU_GPR_SSI_1_iso_control(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_1_iso_control_SHIFT)) & K566_RTU_GPR_SSI_1_iso_control_MASK)

#define K566_RTU_GPR_SSI_1_inject_error_en_MASK  (0x20U)
#define K566_RTU_GPR_SSI_1_inject_error_en_SHIFT (5U)
#define K566_RTU_GPR_SSI_1_inject_error_en_WIDTH (1U)
#define K566_RTU_GPR_SSI_1_inject_error_en(x)    (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_1_inject_error_en_SHIFT)) & K566_RTU_GPR_SSI_1_inject_error_en_MASK)

#define K566_RTU_GPR_SSI_1_report_slice_lost_MASK (0x40U)
#define K566_RTU_GPR_SSI_1_report_slice_lost_SHIFT (6U)
#define K566_RTU_GPR_SSI_1_report_slice_lost_WIDTH (1U)
#define K566_RTU_GPR_SSI_1_report_slice_lost(x)  (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_1_report_slice_lost_SHIFT)) & K566_RTU_GPR_SSI_1_report_slice_lost_MASK)

#define K566_RTU_GPR_SSI_1_report_ctrl_logic_failure_MASK (0x100U)
#define K566_RTU_GPR_SSI_1_report_ctrl_logic_failure_SHIFT (8U)
#define K566_RTU_GPR_SSI_1_report_ctrl_logic_failure_WIDTH (1U)
#define K566_RTU_GPR_SSI_1_report_ctrl_logic_failure(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_1_report_ctrl_logic_failure_SHIFT)) & K566_RTU_GPR_SSI_1_report_ctrl_logic_failure_MASK)

#define K566_RTU_GPR_SSI_1_use_report_port_values_MASK (0x200U)
#define K566_RTU_GPR_SSI_1_use_report_port_values_SHIFT (9U)
#define K566_RTU_GPR_SSI_1_use_report_port_values_WIDTH (1U)
#define K566_RTU_GPR_SSI_1_use_report_port_values(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_1_use_report_port_values_SHIFT)) & K566_RTU_GPR_SSI_1_use_report_port_values_MASK)

#define K566_RTU_GPR_SSI_1_clr_parity_err_MASK   (0x400U)
#define K566_RTU_GPR_SSI_1_clr_parity_err_SHIFT  (10U)
#define K566_RTU_GPR_SSI_1_clr_parity_err_WIDTH  (1U)
#define K566_RTU_GPR_SSI_1_clr_parity_err(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_1_clr_parity_err_SHIFT)) & K566_RTU_GPR_SSI_1_clr_parity_err_MASK)

#define K566_RTU_GPR_SSI_1_inj_err_on_ctrl_logic_id_MASK (0x800U)
#define K566_RTU_GPR_SSI_1_inj_err_on_ctrl_logic_id_SHIFT (11U)
#define K566_RTU_GPR_SSI_1_inj_err_on_ctrl_logic_id_WIDTH (1U)
#define K566_RTU_GPR_SSI_1_inj_err_on_ctrl_logic_id(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_1_inj_err_on_ctrl_logic_id_SHIFT)) & K566_RTU_GPR_SSI_1_inj_err_on_ctrl_logic_id_MASK)

#define K566_RTU_GPR_SSI_1_clr_unint_mode_trans_det_MASK (0x1000U)
#define K566_RTU_GPR_SSI_1_clr_unint_mode_trans_det_SHIFT (12U)
#define K566_RTU_GPR_SSI_1_clr_unint_mode_trans_det_WIDTH (1U)
#define K566_RTU_GPR_SSI_1_clr_unint_mode_trans_det(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_1_clr_unint_mode_trans_det_SHIFT)) & K566_RTU_GPR_SSI_1_clr_unint_mode_trans_det_MASK)

#define K566_RTU_GPR_SSI_1_test_using_reg_MASK   (0x2000U)
#define K566_RTU_GPR_SSI_1_test_using_reg_SHIFT  (13U)
#define K566_RTU_GPR_SSI_1_test_using_reg_WIDTH  (1U)
#define K566_RTU_GPR_SSI_1_test_using_reg(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_1_test_using_reg_SHIFT)) & K566_RTU_GPR_SSI_1_test_using_reg_MASK)

#define K566_RTU_GPR_SSI_1_inj_sm_fault_sm_MASK  (0x1C000U)
#define K566_RTU_GPR_SSI_1_inj_sm_fault_sm_SHIFT (14U)
#define K566_RTU_GPR_SSI_1_inj_sm_fault_sm_WIDTH (3U)
#define K566_RTU_GPR_SSI_1_inj_sm_fault_sm(x)    (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_1_inj_sm_fault_sm_SHIFT)) & K566_RTU_GPR_SSI_1_inj_sm_fault_sm_MASK)
/*! @} */

/*! @name SSI_2 - Source Synchronous Interface (SSI) Gasket 0 configurations */
/*! @{ */

#define K566_RTU_GPR_SSI_2_black_hole_mode_b_MASK (0x1U)
#define K566_RTU_GPR_SSI_2_black_hole_mode_b_SHIFT (0U)
#define K566_RTU_GPR_SSI_2_black_hole_mode_b_WIDTH (1U)
#define K566_RTU_GPR_SSI_2_black_hole_mode_b(x)  (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_2_black_hole_mode_b_SHIFT)) & K566_RTU_GPR_SSI_2_black_hole_mode_b_MASK)

#define K566_RTU_GPR_SSI_2_pause_mode_MASK       (0x2U)
#define K566_RTU_GPR_SSI_2_pause_mode_SHIFT      (1U)
#define K566_RTU_GPR_SSI_2_pause_mode_WIDTH      (1U)
#define K566_RTU_GPR_SSI_2_pause_mode(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_2_pause_mode_SHIFT)) & K566_RTU_GPR_SSI_2_pause_mode_MASK)

#define K566_RTU_GPR_SSI_2_iso_control_MASK      (0x8U)
#define K566_RTU_GPR_SSI_2_iso_control_SHIFT     (3U)
#define K566_RTU_GPR_SSI_2_iso_control_WIDTH     (1U)
#define K566_RTU_GPR_SSI_2_iso_control(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_2_iso_control_SHIFT)) & K566_RTU_GPR_SSI_2_iso_control_MASK)

#define K566_RTU_GPR_SSI_2_inject_error_en_MASK  (0x20U)
#define K566_RTU_GPR_SSI_2_inject_error_en_SHIFT (5U)
#define K566_RTU_GPR_SSI_2_inject_error_en_WIDTH (1U)
#define K566_RTU_GPR_SSI_2_inject_error_en(x)    (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_2_inject_error_en_SHIFT)) & K566_RTU_GPR_SSI_2_inject_error_en_MASK)

#define K566_RTU_GPR_SSI_2_report_slice_lost_MASK (0x40U)
#define K566_RTU_GPR_SSI_2_report_slice_lost_SHIFT (6U)
#define K566_RTU_GPR_SSI_2_report_slice_lost_WIDTH (1U)
#define K566_RTU_GPR_SSI_2_report_slice_lost(x)  (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_2_report_slice_lost_SHIFT)) & K566_RTU_GPR_SSI_2_report_slice_lost_MASK)

#define K566_RTU_GPR_SSI_2_report_ctrl_logic_failure_MASK (0x100U)
#define K566_RTU_GPR_SSI_2_report_ctrl_logic_failure_SHIFT (8U)
#define K566_RTU_GPR_SSI_2_report_ctrl_logic_failure_WIDTH (1U)
#define K566_RTU_GPR_SSI_2_report_ctrl_logic_failure(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_2_report_ctrl_logic_failure_SHIFT)) & K566_RTU_GPR_SSI_2_report_ctrl_logic_failure_MASK)

#define K566_RTU_GPR_SSI_2_use_report_port_values_MASK (0x200U)
#define K566_RTU_GPR_SSI_2_use_report_port_values_SHIFT (9U)
#define K566_RTU_GPR_SSI_2_use_report_port_values_WIDTH (1U)
#define K566_RTU_GPR_SSI_2_use_report_port_values(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_2_use_report_port_values_SHIFT)) & K566_RTU_GPR_SSI_2_use_report_port_values_MASK)

#define K566_RTU_GPR_SSI_2_clr_parity_err_MASK   (0x400U)
#define K566_RTU_GPR_SSI_2_clr_parity_err_SHIFT  (10U)
#define K566_RTU_GPR_SSI_2_clr_parity_err_WIDTH  (1U)
#define K566_RTU_GPR_SSI_2_clr_parity_err(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_2_clr_parity_err_SHIFT)) & K566_RTU_GPR_SSI_2_clr_parity_err_MASK)

#define K566_RTU_GPR_SSI_2_inj_err_on_ctrl_logic_id_MASK (0x800U)
#define K566_RTU_GPR_SSI_2_inj_err_on_ctrl_logic_id_SHIFT (11U)
#define K566_RTU_GPR_SSI_2_inj_err_on_ctrl_logic_id_WIDTH (1U)
#define K566_RTU_GPR_SSI_2_inj_err_on_ctrl_logic_id(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_2_inj_err_on_ctrl_logic_id_SHIFT)) & K566_RTU_GPR_SSI_2_inj_err_on_ctrl_logic_id_MASK)

#define K566_RTU_GPR_SSI_2_clr_unint_mode_trans_det_MASK (0x1000U)
#define K566_RTU_GPR_SSI_2_clr_unint_mode_trans_det_SHIFT (12U)
#define K566_RTU_GPR_SSI_2_clr_unint_mode_trans_det_WIDTH (1U)
#define K566_RTU_GPR_SSI_2_clr_unint_mode_trans_det(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_2_clr_unint_mode_trans_det_SHIFT)) & K566_RTU_GPR_SSI_2_clr_unint_mode_trans_det_MASK)

#define K566_RTU_GPR_SSI_2_test_using_reg_MASK   (0x2000U)
#define K566_RTU_GPR_SSI_2_test_using_reg_SHIFT  (13U)
#define K566_RTU_GPR_SSI_2_test_using_reg_WIDTH  (1U)
#define K566_RTU_GPR_SSI_2_test_using_reg(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_2_test_using_reg_SHIFT)) & K566_RTU_GPR_SSI_2_test_using_reg_MASK)

#define K566_RTU_GPR_SSI_2_inj_sm_fault_sm_MASK  (0x1C000U)
#define K566_RTU_GPR_SSI_2_inj_sm_fault_sm_SHIFT (14U)
#define K566_RTU_GPR_SSI_2_inj_sm_fault_sm_WIDTH (3U)
#define K566_RTU_GPR_SSI_2_inj_sm_fault_sm(x)    (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_2_inj_sm_fault_sm_SHIFT)) & K566_RTU_GPR_SSI_2_inj_sm_fault_sm_MASK)
/*! @} */

/*! @name SSI_3 - Source Synchronous Interface (SSI) Gasket 0 configurations */
/*! @{ */

#define K566_RTU_GPR_SSI_3_black_hole_mode_b_MASK (0x1U)
#define K566_RTU_GPR_SSI_3_black_hole_mode_b_SHIFT (0U)
#define K566_RTU_GPR_SSI_3_black_hole_mode_b_WIDTH (1U)
#define K566_RTU_GPR_SSI_3_black_hole_mode_b(x)  (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_3_black_hole_mode_b_SHIFT)) & K566_RTU_GPR_SSI_3_black_hole_mode_b_MASK)

#define K566_RTU_GPR_SSI_3_pause_mode_MASK       (0x2U)
#define K566_RTU_GPR_SSI_3_pause_mode_SHIFT      (1U)
#define K566_RTU_GPR_SSI_3_pause_mode_WIDTH      (1U)
#define K566_RTU_GPR_SSI_3_pause_mode(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_3_pause_mode_SHIFT)) & K566_RTU_GPR_SSI_3_pause_mode_MASK)

#define K566_RTU_GPR_SSI_3_iso_control_MASK      (0x8U)
#define K566_RTU_GPR_SSI_3_iso_control_SHIFT     (3U)
#define K566_RTU_GPR_SSI_3_iso_control_WIDTH     (1U)
#define K566_RTU_GPR_SSI_3_iso_control(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_3_iso_control_SHIFT)) & K566_RTU_GPR_SSI_3_iso_control_MASK)

#define K566_RTU_GPR_SSI_3_inject_error_en_MASK  (0x20U)
#define K566_RTU_GPR_SSI_3_inject_error_en_SHIFT (5U)
#define K566_RTU_GPR_SSI_3_inject_error_en_WIDTH (1U)
#define K566_RTU_GPR_SSI_3_inject_error_en(x)    (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_3_inject_error_en_SHIFT)) & K566_RTU_GPR_SSI_3_inject_error_en_MASK)

#define K566_RTU_GPR_SSI_3_report_slice_lost_MASK (0x40U)
#define K566_RTU_GPR_SSI_3_report_slice_lost_SHIFT (6U)
#define K566_RTU_GPR_SSI_3_report_slice_lost_WIDTH (1U)
#define K566_RTU_GPR_SSI_3_report_slice_lost(x)  (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_3_report_slice_lost_SHIFT)) & K566_RTU_GPR_SSI_3_report_slice_lost_MASK)

#define K566_RTU_GPR_SSI_3_report_ctrl_logic_failure_MASK (0x100U)
#define K566_RTU_GPR_SSI_3_report_ctrl_logic_failure_SHIFT (8U)
#define K566_RTU_GPR_SSI_3_report_ctrl_logic_failure_WIDTH (1U)
#define K566_RTU_GPR_SSI_3_report_ctrl_logic_failure(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_3_report_ctrl_logic_failure_SHIFT)) & K566_RTU_GPR_SSI_3_report_ctrl_logic_failure_MASK)

#define K566_RTU_GPR_SSI_3_use_report_port_values_MASK (0x200U)
#define K566_RTU_GPR_SSI_3_use_report_port_values_SHIFT (9U)
#define K566_RTU_GPR_SSI_3_use_report_port_values_WIDTH (1U)
#define K566_RTU_GPR_SSI_3_use_report_port_values(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_3_use_report_port_values_SHIFT)) & K566_RTU_GPR_SSI_3_use_report_port_values_MASK)

#define K566_RTU_GPR_SSI_3_clr_parity_err_MASK   (0x400U)
#define K566_RTU_GPR_SSI_3_clr_parity_err_SHIFT  (10U)
#define K566_RTU_GPR_SSI_3_clr_parity_err_WIDTH  (1U)
#define K566_RTU_GPR_SSI_3_clr_parity_err(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_3_clr_parity_err_SHIFT)) & K566_RTU_GPR_SSI_3_clr_parity_err_MASK)

#define K566_RTU_GPR_SSI_3_inj_err_on_ctrl_logic_id_MASK (0x800U)
#define K566_RTU_GPR_SSI_3_inj_err_on_ctrl_logic_id_SHIFT (11U)
#define K566_RTU_GPR_SSI_3_inj_err_on_ctrl_logic_id_WIDTH (1U)
#define K566_RTU_GPR_SSI_3_inj_err_on_ctrl_logic_id(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_3_inj_err_on_ctrl_logic_id_SHIFT)) & K566_RTU_GPR_SSI_3_inj_err_on_ctrl_logic_id_MASK)

#define K566_RTU_GPR_SSI_3_clr_unint_mode_trans_det_MASK (0x1000U)
#define K566_RTU_GPR_SSI_3_clr_unint_mode_trans_det_SHIFT (12U)
#define K566_RTU_GPR_SSI_3_clr_unint_mode_trans_det_WIDTH (1U)
#define K566_RTU_GPR_SSI_3_clr_unint_mode_trans_det(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_3_clr_unint_mode_trans_det_SHIFT)) & K566_RTU_GPR_SSI_3_clr_unint_mode_trans_det_MASK)

#define K566_RTU_GPR_SSI_3_test_using_reg_MASK   (0x2000U)
#define K566_RTU_GPR_SSI_3_test_using_reg_SHIFT  (13U)
#define K566_RTU_GPR_SSI_3_test_using_reg_WIDTH  (1U)
#define K566_RTU_GPR_SSI_3_test_using_reg(x)     (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_3_test_using_reg_SHIFT)) & K566_RTU_GPR_SSI_3_test_using_reg_MASK)

#define K566_RTU_GPR_SSI_3_inj_sm_fault_sm_MASK  (0x1C000U)
#define K566_RTU_GPR_SSI_3_inj_sm_fault_sm_SHIFT (14U)
#define K566_RTU_GPR_SSI_3_inj_sm_fault_sm_WIDTH (3U)
#define K566_RTU_GPR_SSI_3_inj_sm_fault_sm(x)    (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SSI_3_inj_sm_fault_sm_SHIFT)) & K566_RTU_GPR_SSI_3_inj_sm_fault_sm_MASK)
/*! @} */

/*! @name MRAM_ECC_DATA - MRAM ECC Data correction Status */
/*! @{ */

#define K566_RTU_GPR_MRAM_ECC_DATA_STAT_MASK     (0x3FFFFFU)
#define K566_RTU_GPR_MRAM_ECC_DATA_STAT_SHIFT    (0U)
#define K566_RTU_GPR_MRAM_ECC_DATA_STAT_WIDTH    (22U)
#define K566_RTU_GPR_MRAM_ECC_DATA_STAT(x)       (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_MRAM_ECC_DATA_STAT_SHIFT)) & K566_RTU_GPR_MRAM_ECC_DATA_STAT_MASK)
/*! @} */

/*! @name R52_CORE_0_SW_FAULT - Software Fault Control 0 */
/*! @{ */

#define K566_RTU_GPR_R52_CORE_0_SW_FAULT_trig_MASK (0x1U)
#define K566_RTU_GPR_R52_CORE_0_SW_FAULT_trig_SHIFT (0U)
#define K566_RTU_GPR_R52_CORE_0_SW_FAULT_trig_WIDTH (1U)
#define K566_RTU_GPR_R52_CORE_0_SW_FAULT_trig(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_R52_CORE_0_SW_FAULT_trig_SHIFT)) & K566_RTU_GPR_R52_CORE_0_SW_FAULT_trig_MASK)
/*! @} */

/*! @name R52_CORE_1_SW_FAULT - Software Fault Control 1 */
/*! @{ */

#define K566_RTU_GPR_R52_CORE_1_SW_FAULT_trig_MASK (0x1U)
#define K566_RTU_GPR_R52_CORE_1_SW_FAULT_trig_SHIFT (0U)
#define K566_RTU_GPR_R52_CORE_1_SW_FAULT_trig_WIDTH (1U)
#define K566_RTU_GPR_R52_CORE_1_SW_FAULT_trig(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_R52_CORE_1_SW_FAULT_trig_SHIFT)) & K566_RTU_GPR_R52_CORE_1_SW_FAULT_trig_MASK)
/*! @} */

/*! @name ERREVENT0 - Core0 External Event Status */
/*! @{ */

#define K566_RTU_GPR_ERREVENT0_C0_EV0_MASK       (0x1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV0_SHIFT      (0U)
#define K566_RTU_GPR_ERREVENT0_C0_EV0_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV0(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV0_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV0_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV1_MASK       (0x2U)
#define K566_RTU_GPR_ERREVENT0_C0_EV1_SHIFT      (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV1_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV1(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV1_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV1_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV2_MASK       (0x4U)
#define K566_RTU_GPR_ERREVENT0_C0_EV2_SHIFT      (2U)
#define K566_RTU_GPR_ERREVENT0_C0_EV2_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV2(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV2_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV2_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV3_MASK       (0x8U)
#define K566_RTU_GPR_ERREVENT0_C0_EV3_SHIFT      (3U)
#define K566_RTU_GPR_ERREVENT0_C0_EV3_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV3(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV3_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV3_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV4_MASK       (0x10U)
#define K566_RTU_GPR_ERREVENT0_C0_EV4_SHIFT      (4U)
#define K566_RTU_GPR_ERREVENT0_C0_EV4_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV4(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV4_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV4_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV5_MASK       (0x20U)
#define K566_RTU_GPR_ERREVENT0_C0_EV5_SHIFT      (5U)
#define K566_RTU_GPR_ERREVENT0_C0_EV5_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV5(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV5_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV5_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV6_MASK       (0x40U)
#define K566_RTU_GPR_ERREVENT0_C0_EV6_SHIFT      (6U)
#define K566_RTU_GPR_ERREVENT0_C0_EV6_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV6(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV6_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV6_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV7_MASK       (0x80U)
#define K566_RTU_GPR_ERREVENT0_C0_EV7_SHIFT      (7U)
#define K566_RTU_GPR_ERREVENT0_C0_EV7_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV7(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV7_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV7_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV8_MASK       (0x100U)
#define K566_RTU_GPR_ERREVENT0_C0_EV8_SHIFT      (8U)
#define K566_RTU_GPR_ERREVENT0_C0_EV8_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV8(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV8_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV8_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV9_MASK       (0x200U)
#define K566_RTU_GPR_ERREVENT0_C0_EV9_SHIFT      (9U)
#define K566_RTU_GPR_ERREVENT0_C0_EV9_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV9(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV9_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV9_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV10_MASK      (0x400U)
#define K566_RTU_GPR_ERREVENT0_C0_EV10_SHIFT     (10U)
#define K566_RTU_GPR_ERREVENT0_C0_EV10_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV10(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV10_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV10_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV11_MASK      (0x800U)
#define K566_RTU_GPR_ERREVENT0_C0_EV11_SHIFT     (11U)
#define K566_RTU_GPR_ERREVENT0_C0_EV11_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV11(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV11_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV11_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV12_MASK      (0x1000U)
#define K566_RTU_GPR_ERREVENT0_C0_EV12_SHIFT     (12U)
#define K566_RTU_GPR_ERREVENT0_C0_EV12_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV12(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV12_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV12_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV13_MASK      (0x2000U)
#define K566_RTU_GPR_ERREVENT0_C0_EV13_SHIFT     (13U)
#define K566_RTU_GPR_ERREVENT0_C0_EV13_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV13(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV13_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV13_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV14_MASK      (0x4000U)
#define K566_RTU_GPR_ERREVENT0_C0_EV14_SHIFT     (14U)
#define K566_RTU_GPR_ERREVENT0_C0_EV14_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV14(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV14_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV14_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV15_MASK      (0x8000U)
#define K566_RTU_GPR_ERREVENT0_C0_EV15_SHIFT     (15U)
#define K566_RTU_GPR_ERREVENT0_C0_EV15_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV15(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV15_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV15_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV16_MASK      (0x10000U)
#define K566_RTU_GPR_ERREVENT0_C0_EV16_SHIFT     (16U)
#define K566_RTU_GPR_ERREVENT0_C0_EV16_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV16(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV16_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV16_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV17_MASK      (0x20000U)
#define K566_RTU_GPR_ERREVENT0_C0_EV17_SHIFT     (17U)
#define K566_RTU_GPR_ERREVENT0_C0_EV17_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV17(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV17_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV17_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV18_MASK      (0x40000U)
#define K566_RTU_GPR_ERREVENT0_C0_EV18_SHIFT     (18U)
#define K566_RTU_GPR_ERREVENT0_C0_EV18_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV18(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV18_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV18_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV19_MASK      (0x80000U)
#define K566_RTU_GPR_ERREVENT0_C0_EV19_SHIFT     (19U)
#define K566_RTU_GPR_ERREVENT0_C0_EV19_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV19(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV19_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV19_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV20_MASK      (0x100000U)
#define K566_RTU_GPR_ERREVENT0_C0_EV20_SHIFT     (20U)
#define K566_RTU_GPR_ERREVENT0_C0_EV20_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV20(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV20_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV20_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV21_MASK      (0x200000U)
#define K566_RTU_GPR_ERREVENT0_C0_EV21_SHIFT     (21U)
#define K566_RTU_GPR_ERREVENT0_C0_EV21_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV21(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV21_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV21_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV22_MASK      (0x400000U)
#define K566_RTU_GPR_ERREVENT0_C0_EV22_SHIFT     (22U)
#define K566_RTU_GPR_ERREVENT0_C0_EV22_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV22(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV22_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV22_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV23_MASK      (0x800000U)
#define K566_RTU_GPR_ERREVENT0_C0_EV23_SHIFT     (23U)
#define K566_RTU_GPR_ERREVENT0_C0_EV23_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV23(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV23_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV23_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV24_MASK      (0x1000000U)
#define K566_RTU_GPR_ERREVENT0_C0_EV24_SHIFT     (24U)
#define K566_RTU_GPR_ERREVENT0_C0_EV24_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV24(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV24_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV24_MASK)

#define K566_RTU_GPR_ERREVENT0_C0_EV25_MASK      (0x2000000U)
#define K566_RTU_GPR_ERREVENT0_C0_EV25_SHIFT     (25U)
#define K566_RTU_GPR_ERREVENT0_C0_EV25_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT0_C0_EV25(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT0_C0_EV25_SHIFT)) & K566_RTU_GPR_ERREVENT0_C0_EV25_MASK)
/*! @} */

/*! @name ERREVENT1 - Core1 External Event Status */
/*! @{ */

#define K566_RTU_GPR_ERREVENT1_C1_EV0_MASK       (0x1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV0_SHIFT      (0U)
#define K566_RTU_GPR_ERREVENT1_C1_EV0_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV0(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV0_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV0_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV1_MASK       (0x2U)
#define K566_RTU_GPR_ERREVENT1_C1_EV1_SHIFT      (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV1_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV1(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV1_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV1_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV2_MASK       (0x4U)
#define K566_RTU_GPR_ERREVENT1_C1_EV2_SHIFT      (2U)
#define K566_RTU_GPR_ERREVENT1_C1_EV2_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV2(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV2_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV2_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV3_MASK       (0x8U)
#define K566_RTU_GPR_ERREVENT1_C1_EV3_SHIFT      (3U)
#define K566_RTU_GPR_ERREVENT1_C1_EV3_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV3(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV3_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV3_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV4_MASK       (0x10U)
#define K566_RTU_GPR_ERREVENT1_C1_EV4_SHIFT      (4U)
#define K566_RTU_GPR_ERREVENT1_C1_EV4_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV4(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV4_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV4_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV5_MASK       (0x20U)
#define K566_RTU_GPR_ERREVENT1_C1_EV5_SHIFT      (5U)
#define K566_RTU_GPR_ERREVENT1_C1_EV5_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV5(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV5_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV5_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV6_MASK       (0x40U)
#define K566_RTU_GPR_ERREVENT1_C1_EV6_SHIFT      (6U)
#define K566_RTU_GPR_ERREVENT1_C1_EV6_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV6(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV6_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV6_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV7_MASK       (0x80U)
#define K566_RTU_GPR_ERREVENT1_C1_EV7_SHIFT      (7U)
#define K566_RTU_GPR_ERREVENT1_C1_EV7_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV7(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV7_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV7_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV8_MASK       (0x100U)
#define K566_RTU_GPR_ERREVENT1_C1_EV8_SHIFT      (8U)
#define K566_RTU_GPR_ERREVENT1_C1_EV8_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV8(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV8_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV8_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV9_MASK       (0x200U)
#define K566_RTU_GPR_ERREVENT1_C1_EV9_SHIFT      (9U)
#define K566_RTU_GPR_ERREVENT1_C1_EV9_WIDTH      (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV9(x)         (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV9_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV9_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV10_MASK      (0x400U)
#define K566_RTU_GPR_ERREVENT1_C1_EV10_SHIFT     (10U)
#define K566_RTU_GPR_ERREVENT1_C1_EV10_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV10(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV10_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV10_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV11_MASK      (0x800U)
#define K566_RTU_GPR_ERREVENT1_C1_EV11_SHIFT     (11U)
#define K566_RTU_GPR_ERREVENT1_C1_EV11_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV11(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV11_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV11_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV12_MASK      (0x1000U)
#define K566_RTU_GPR_ERREVENT1_C1_EV12_SHIFT     (12U)
#define K566_RTU_GPR_ERREVENT1_C1_EV12_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV12(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV12_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV12_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV13_MASK      (0x2000U)
#define K566_RTU_GPR_ERREVENT1_C1_EV13_SHIFT     (13U)
#define K566_RTU_GPR_ERREVENT1_C1_EV13_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV13(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV13_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV13_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV14_MASK      (0x4000U)
#define K566_RTU_GPR_ERREVENT1_C1_EV14_SHIFT     (14U)
#define K566_RTU_GPR_ERREVENT1_C1_EV14_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV14(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV14_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV14_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV15_MASK      (0x8000U)
#define K566_RTU_GPR_ERREVENT1_C1_EV15_SHIFT     (15U)
#define K566_RTU_GPR_ERREVENT1_C1_EV15_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV15(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV15_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV15_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV16_MASK      (0x10000U)
#define K566_RTU_GPR_ERREVENT1_C1_EV16_SHIFT     (16U)
#define K566_RTU_GPR_ERREVENT1_C1_EV16_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV16(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV16_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV16_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV17_MASK      (0x20000U)
#define K566_RTU_GPR_ERREVENT1_C1_EV17_SHIFT     (17U)
#define K566_RTU_GPR_ERREVENT1_C1_EV17_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV17(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV17_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV17_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV18_MASK      (0x40000U)
#define K566_RTU_GPR_ERREVENT1_C1_EV18_SHIFT     (18U)
#define K566_RTU_GPR_ERREVENT1_C1_EV18_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV18(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV18_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV18_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV19_MASK      (0x80000U)
#define K566_RTU_GPR_ERREVENT1_C1_EV19_SHIFT     (19U)
#define K566_RTU_GPR_ERREVENT1_C1_EV19_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV19(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV19_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV19_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV20_MASK      (0x100000U)
#define K566_RTU_GPR_ERREVENT1_C1_EV20_SHIFT     (20U)
#define K566_RTU_GPR_ERREVENT1_C1_EV20_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV20(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV20_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV20_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV21_MASK      (0x200000U)
#define K566_RTU_GPR_ERREVENT1_C1_EV21_SHIFT     (21U)
#define K566_RTU_GPR_ERREVENT1_C1_EV21_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV21(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV21_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV21_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV22_MASK      (0x400000U)
#define K566_RTU_GPR_ERREVENT1_C1_EV22_SHIFT     (22U)
#define K566_RTU_GPR_ERREVENT1_C1_EV22_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV22(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV22_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV22_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV23_MASK      (0x800000U)
#define K566_RTU_GPR_ERREVENT1_C1_EV23_SHIFT     (23U)
#define K566_RTU_GPR_ERREVENT1_C1_EV23_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV23(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV23_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV23_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV24_MASK      (0x1000000U)
#define K566_RTU_GPR_ERREVENT1_C1_EV24_SHIFT     (24U)
#define K566_RTU_GPR_ERREVENT1_C1_EV24_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV24(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV24_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV24_MASK)

#define K566_RTU_GPR_ERREVENT1_C1_EV25_MASK      (0x2000000U)
#define K566_RTU_GPR_ERREVENT1_C1_EV25_SHIFT     (25U)
#define K566_RTU_GPR_ERREVENT1_C1_EV25_WIDTH     (1U)
#define K566_RTU_GPR_ERREVENT1_C1_EV25(x)        (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_ERREVENT1_C1_EV25_SHIFT)) & K566_RTU_GPR_ERREVENT1_C1_EV25_MASK)
/*! @} */

/*! @name PRIMEMERR0 - Primary Error Interface Memory Identifier Core0 */
/*! @{ */

#define K566_RTU_GPR_PRIMEMERR0_PRIMEMERRMEM0_MASK (0x7FFFU)
#define K566_RTU_GPR_PRIMEMERR0_PRIMEMERRMEM0_SHIFT (0U)
#define K566_RTU_GPR_PRIMEMERR0_PRIMEMERRMEM0_WIDTH (15U)
#define K566_RTU_GPR_PRIMEMERR0_PRIMEMERRMEM0(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_PRIMEMERR0_PRIMEMERRMEM0_SHIFT)) & K566_RTU_GPR_PRIMEMERR0_PRIMEMERRMEM0_MASK)

#define K566_RTU_GPR_PRIMEMERR0_PRIMEMERRMEMV0_MASK (0x80000000U)
#define K566_RTU_GPR_PRIMEMERR0_PRIMEMERRMEMV0_SHIFT (31U)
#define K566_RTU_GPR_PRIMEMERR0_PRIMEMERRMEMV0_WIDTH (1U)
#define K566_RTU_GPR_PRIMEMERR0_PRIMEMERRMEMV0(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_PRIMEMERR0_PRIMEMERRMEMV0_SHIFT)) & K566_RTU_GPR_PRIMEMERR0_PRIMEMERRMEMV0_MASK)
/*! @} */

/*! @name PRIMEMERRIDX0 - Primary Error Interface Index Core0 */
/*! @{ */

#define K566_RTU_GPR_PRIMEMERRIDX0_PRIMEMERRMEIDX0_MASK (0x1FFFFFFU)
#define K566_RTU_GPR_PRIMEMERRIDX0_PRIMEMERRMEIDX0_SHIFT (0U)
#define K566_RTU_GPR_PRIMEMERRIDX0_PRIMEMERRMEIDX0_WIDTH (25U)
#define K566_RTU_GPR_PRIMEMERRIDX0_PRIMEMERRMEIDX0(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_PRIMEMERRIDX0_PRIMEMERRMEIDX0_SHIFT)) & K566_RTU_GPR_PRIMEMERRIDX0_PRIMEMERRMEIDX0_MASK)
/*! @} */

/*! @name SECMEMERR0 - Secondary Error Interface Memory Identifier Core0 */
/*! @{ */

#define K566_RTU_GPR_SECMEMERR0_SECMEMERRMEM0_MASK (0x7FFFU)
#define K566_RTU_GPR_SECMEMERR0_SECMEMERRMEM0_SHIFT (0U)
#define K566_RTU_GPR_SECMEMERR0_SECMEMERRMEM0_WIDTH (15U)
#define K566_RTU_GPR_SECMEMERR0_SECMEMERRMEM0(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SECMEMERR0_SECMEMERRMEM0_SHIFT)) & K566_RTU_GPR_SECMEMERR0_SECMEMERRMEM0_MASK)

#define K566_RTU_GPR_SECMEMERR0_SECMEMERRMEMV0_MASK (0x80000000U)
#define K566_RTU_GPR_SECMEMERR0_SECMEMERRMEMV0_SHIFT (31U)
#define K566_RTU_GPR_SECMEMERR0_SECMEMERRMEMV0_WIDTH (1U)
#define K566_RTU_GPR_SECMEMERR0_SECMEMERRMEMV0(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SECMEMERR0_SECMEMERRMEMV0_SHIFT)) & K566_RTU_GPR_SECMEMERR0_SECMEMERRMEMV0_MASK)
/*! @} */

/*! @name SECMEMERRIDX0 - Secondary Error Interface Index Core0 */
/*! @{ */

#define K566_RTU_GPR_SECMEMERRIDX0_SECMEMERRMEIDX0_MASK (0x1FFFFFFU)
#define K566_RTU_GPR_SECMEMERRIDX0_SECMEMERRMEIDX0_SHIFT (0U)
#define K566_RTU_GPR_SECMEMERRIDX0_SECMEMERRMEIDX0_WIDTH (25U)
#define K566_RTU_GPR_SECMEMERRIDX0_SECMEMERRMEIDX0(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SECMEMERRIDX0_SECMEMERRMEIDX0_SHIFT)) & K566_RTU_GPR_SECMEMERRIDX0_SECMEMERRMEIDX0_MASK)
/*! @} */

/*! @name PRIMEMERR1 - Primary Error Interface Memory Identifier Core1 */
/*! @{ */

#define K566_RTU_GPR_PRIMEMERR1_PRIMEMERRMEM1_MASK (0x7FFFU)
#define K566_RTU_GPR_PRIMEMERR1_PRIMEMERRMEM1_SHIFT (0U)
#define K566_RTU_GPR_PRIMEMERR1_PRIMEMERRMEM1_WIDTH (15U)
#define K566_RTU_GPR_PRIMEMERR1_PRIMEMERRMEM1(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_PRIMEMERR1_PRIMEMERRMEM1_SHIFT)) & K566_RTU_GPR_PRIMEMERR1_PRIMEMERRMEM1_MASK)

#define K566_RTU_GPR_PRIMEMERR1_PRIMEMERRMEMV1_MASK (0x80000000U)
#define K566_RTU_GPR_PRIMEMERR1_PRIMEMERRMEMV1_SHIFT (31U)
#define K566_RTU_GPR_PRIMEMERR1_PRIMEMERRMEMV1_WIDTH (1U)
#define K566_RTU_GPR_PRIMEMERR1_PRIMEMERRMEMV1(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_PRIMEMERR1_PRIMEMERRMEMV1_SHIFT)) & K566_RTU_GPR_PRIMEMERR1_PRIMEMERRMEMV1_MASK)
/*! @} */

/*! @name PRIMEMERRIDX1 - Primary Error Interface Index Core1 */
/*! @{ */

#define K566_RTU_GPR_PRIMEMERRIDX1_PRIMEMERRMEIDX1_MASK (0x1FFFFFFU)
#define K566_RTU_GPR_PRIMEMERRIDX1_PRIMEMERRMEIDX1_SHIFT (0U)
#define K566_RTU_GPR_PRIMEMERRIDX1_PRIMEMERRMEIDX1_WIDTH (25U)
#define K566_RTU_GPR_PRIMEMERRIDX1_PRIMEMERRMEIDX1(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_PRIMEMERRIDX1_PRIMEMERRMEIDX1_SHIFT)) & K566_RTU_GPR_PRIMEMERRIDX1_PRIMEMERRMEIDX1_MASK)
/*! @} */

/*! @name SECMEMERR1 - Secondary Error Interface Memory Identifier Core1 */
/*! @{ */

#define K566_RTU_GPR_SECMEMERR1_SECMEMERRMEM1_MASK (0x7FFFU)
#define K566_RTU_GPR_SECMEMERR1_SECMEMERRMEM1_SHIFT (0U)
#define K566_RTU_GPR_SECMEMERR1_SECMEMERRMEM1_WIDTH (15U)
#define K566_RTU_GPR_SECMEMERR1_SECMEMERRMEM1(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SECMEMERR1_SECMEMERRMEM1_SHIFT)) & K566_RTU_GPR_SECMEMERR1_SECMEMERRMEM1_MASK)

#define K566_RTU_GPR_SECMEMERR1_SECMEMERRMEMV1_MASK (0x80000000U)
#define K566_RTU_GPR_SECMEMERR1_SECMEMERRMEMV1_SHIFT (31U)
#define K566_RTU_GPR_SECMEMERR1_SECMEMERRMEMV1_WIDTH (1U)
#define K566_RTU_GPR_SECMEMERR1_SECMEMERRMEMV1(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SECMEMERR1_SECMEMERRMEMV1_SHIFT)) & K566_RTU_GPR_SECMEMERR1_SECMEMERRMEMV1_MASK)
/*! @} */

/*! @name SECMEMERRIDX1 - Secondary Error Interface Index Core1 */
/*! @{ */

#define K566_RTU_GPR_SECMEMERRIDX1_SECMEMERRMEIDX1_MASK (0x1FFFFFFU)
#define K566_RTU_GPR_SECMEMERRIDX1_SECMEMERRMEIDX1_SHIFT (0U)
#define K566_RTU_GPR_SECMEMERRIDX1_SECMEMERRMEIDX1_WIDTH (25U)
#define K566_RTU_GPR_SECMEMERRIDX1_SECMEMERRMEIDX1(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_SECMEMERRIDX1_SECMEMERRMEIDX1_SHIFT)) & K566_RTU_GPR_SECMEMERRIDX1_SECMEMERRMEIDX1_MASK)
/*! @} */

/*! @name PMUEVENTSTAT0 - PMU Event Core0 Group0 */
/*! @{ */

#define K566_RTU_GPR_PMUEVENTSTAT0_PMUEVENT0_MASK (0xFFFFFFFFU)
#define K566_RTU_GPR_PMUEVENTSTAT0_PMUEVENT0_SHIFT (0U)
#define K566_RTU_GPR_PMUEVENTSTAT0_PMUEVENT0_WIDTH (32U)
#define K566_RTU_GPR_PMUEVENTSTAT0_PMUEVENT0(x)  (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_PMUEVENTSTAT0_PMUEVENT0_SHIFT)) & K566_RTU_GPR_PMUEVENTSTAT0_PMUEVENT0_MASK)
/*! @} */

/*! @name PMUEVENTSTAT1 - PMU Event Core0 Group1 */
/*! @{ */

#define K566_RTU_GPR_PMUEVENTSTAT1_PMUEVENT0_MASK (0xFU)
#define K566_RTU_GPR_PMUEVENTSTAT1_PMUEVENT0_SHIFT (0U)
#define K566_RTU_GPR_PMUEVENTSTAT1_PMUEVENT0_WIDTH (4U)
#define K566_RTU_GPR_PMUEVENTSTAT1_PMUEVENT0(x)  (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_PMUEVENTSTAT1_PMUEVENT0_SHIFT)) & K566_RTU_GPR_PMUEVENTSTAT1_PMUEVENT0_MASK)
/*! @} */

/*! @name PMUEVENTSTAT2 - PMU Event Core1 Group0 */
/*! @{ */

#define K566_RTU_GPR_PMUEVENTSTAT2_PMUEVENT1_MASK (0xFFFFFFFFU)
#define K566_RTU_GPR_PMUEVENTSTAT2_PMUEVENT1_SHIFT (0U)
#define K566_RTU_GPR_PMUEVENTSTAT2_PMUEVENT1_WIDTH (32U)
#define K566_RTU_GPR_PMUEVENTSTAT2_PMUEVENT1(x)  (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_PMUEVENTSTAT2_PMUEVENT1_SHIFT)) & K566_RTU_GPR_PMUEVENTSTAT2_PMUEVENT1_MASK)
/*! @} */

/*! @name PMUEVENTSTAT3 - PMU Event Core1 Group1 */
/*! @{ */

#define K566_RTU_GPR_PMUEVENTSTAT3_PMUEVENT1_MASK (0xFU)
#define K566_RTU_GPR_PMUEVENTSTAT3_PMUEVENT1_SHIFT (0U)
#define K566_RTU_GPR_PMUEVENTSTAT3_PMUEVENT1_WIDTH (4U)
#define K566_RTU_GPR_PMUEVENTSTAT3_PMUEVENT1(x)  (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_PMUEVENTSTAT3_PMUEVENT1_SHIFT)) & K566_RTU_GPR_PMUEVENTSTAT3_PMUEVENT1_MASK)
/*! @} */

/*! @name PLL_PD_RGM_REQ - PLL Power Down Request */
/*! @{ */

#define K566_RTU_GPR_PLL_PD_RGM_REQ_CFG_MASK     (0x1U)
#define K566_RTU_GPR_PLL_PD_RGM_REQ_CFG_SHIFT    (0U)
#define K566_RTU_GPR_PLL_PD_RGM_REQ_CFG_WIDTH    (1U)
#define K566_RTU_GPR_PLL_PD_RGM_REQ_CFG(x)       (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_PLL_PD_RGM_REQ_CFG_SHIFT)) & K566_RTU_GPR_PLL_PD_RGM_REQ_CFG_MASK)
/*! @} */

/*! @name PLL_PD_RGM_ACK - PLL Power Down Acknowledgement */
/*! @{ */

#define K566_RTU_GPR_PLL_PD_RGM_ACK_STAT_MASK    (0x1U)
#define K566_RTU_GPR_PLL_PD_RGM_ACK_STAT_SHIFT   (0U)
#define K566_RTU_GPR_PLL_PD_RGM_ACK_STAT_WIDTH   (1U)
#define K566_RTU_GPR_PLL_PD_RGM_ACK_STAT(x)      (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_PLL_PD_RGM_ACK_STAT_SHIFT)) & K566_RTU_GPR_PLL_PD_RGM_ACK_STAT_MASK)
/*! @} */

/*! @name R52_PMC_CPE_PERIPH_BRIDGE_ISOLATION - R52_PMC TO CPE_PERIPH_BRIDGE Isolation */
/*! @{ */

#define K566_RTU_GPR_R52_PMC_CPE_PERIPH_BRIDGE_ISOLATION_CFG_MASK (0x1U)
#define K566_RTU_GPR_R52_PMC_CPE_PERIPH_BRIDGE_ISOLATION_CFG_SHIFT (0U)
#define K566_RTU_GPR_R52_PMC_CPE_PERIPH_BRIDGE_ISOLATION_CFG_WIDTH (1U)
#define K566_RTU_GPR_R52_PMC_CPE_PERIPH_BRIDGE_ISOLATION_CFG(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_R52_PMC_CPE_PERIPH_BRIDGE_ISOLATION_CFG_SHIFT)) & K566_RTU_GPR_R52_PMC_CPE_PERIPH_BRIDGE_ISOLATION_CFG_MASK)
/*! @} */

/*! @name CPE_CLKOUT_MUX - CPE CLKOUT_MUX configuration register */
/*! @{ */

#define K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_MUX_SEL_MASK (0x3FU)
#define K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_MUX_SEL_SHIFT (0U)
#define K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_MUX_SEL_WIDTH (6U)
#define K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_MUX_SEL(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_MUX_SEL_SHIFT)) & K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_MUX_SEL_MASK)

#define K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_DIV_VALUE_MASK (0x3FC0U)
#define K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_DIV_VALUE_SHIFT (6U)
#define K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_DIV_VALUE_WIDTH (8U)
#define K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_DIV_VALUE(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_DIV_VALUE_SHIFT)) & K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_DIV_VALUE_MASK)

#define K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_CLK_EN_MASK (0x4000U)
#define K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_CLK_EN_SHIFT (14U)
#define K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_CLK_EN_WIDTH (1U)
#define K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_CLK_EN(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_CLK_EN_SHIFT)) & K566_RTU_GPR_CPE_CLKOUT_MUX_CFG_CLK_EN_MASK)
/*! @} */

/*! @name LOCK_STEP_CONTROL -  */
/*! @{ */

#define K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_STEP_CONTROL_MASK (0x1U)
#define K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_STEP_CONTROL_SHIFT (0U)
#define K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_STEP_CONTROL_WIDTH (1U)
#define K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_STEP_CONTROL(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_STEP_CONTROL_SHIFT)) & K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_STEP_CONTROL_MASK)

#define K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_EN0_MASK (0x40000000U)
#define K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_EN0_SHIFT (30U)
#define K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_EN0_WIDTH (1U)
#define K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_EN0(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_EN0_SHIFT)) & K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_EN0_MASK)

#define K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_EN1_MASK (0x80000000U)
#define K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_EN1_SHIFT (31U)
#define K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_EN1_WIDTH (1U)
#define K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_EN1(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_EN1_SHIFT)) & K566_RTU_GPR_LOCK_STEP_CONTROL_LOCK_EN1_MASK)
/*! @} */

/*! @name OMU_CAL_DIS_CONTROL -  */
/*! @{ */

#define K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_CAL_DIS_CONTROL_MASK (0x1U)
#define K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_CAL_DIS_CONTROL_SHIFT (0U)
#define K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_CAL_DIS_CONTROL_WIDTH (1U)
#define K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_CAL_DIS_CONTROL(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_CAL_DIS_CONTROL_SHIFT)) & K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_CAL_DIS_CONTROL_MASK)

#define K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_LOCK_EN0_MASK (0x40000000U)
#define K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_LOCK_EN0_SHIFT (30U)
#define K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_LOCK_EN0_WIDTH (1U)
#define K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_LOCK_EN0(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_LOCK_EN0_SHIFT)) & K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_LOCK_EN0_MASK)

#define K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_LOCK_EN1_MASK (0x80000000U)
#define K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_LOCK_EN1_SHIFT (31U)
#define K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_LOCK_EN1_WIDTH (1U)
#define K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_LOCK_EN1(x) (((uint32_t)(((uint32_t)(x)) << K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_LOCK_EN1_SHIFT)) & K566_RTU_GPR_OMU_CAL_DIS_CONTROL_OMU_LOCK_EN1_MASK)
/*! @} */

/*!
 * @}
 */ /* end of group K566_RTU_GPR_Register_Masks */

/*!
 * @}
 */ /* end of group K566_RTU_GPR_Peripheral_Access_Layer */

#endif  /* #if !defined(S32K566_K566_RTU_GPR_H_) */
