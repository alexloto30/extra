/*
** ###################################################################
**     Processor:           S32K566_M7
**     Compiler:            Keil ARM C/C++ Compiler
**     Reference manual:    S32K5 RM Rev 3
**     Version:             rev. 2.7, 2026-09-09
**     Build:               b260908
**
**     Abstract:
**         Peripheral Access Layer for S32K566_M7
**
**     Copyright 1997-2016 Freescale Semiconductor, Inc.
**     Copyright 2016-2026 NXP
**
**     NXP Confidential and Proprietary. This software is owned or controlled
**     by NXP and may only be used strictly in accordance with the applicable
**     license terms. By expressly accepting such terms or by downloading,
**     installing, activating and/or otherwise using the software, you are
**     agreeing that you have read, and that you agree to comply with and are
**     bound by, such license terms. If you do not agree to be bound by the
**     applicable license terms, then you may not retain, install, activate
**     or otherwise use the software.
**
**     http:                 www.nxp.com
**     mail:                 support@nxp.com
**
** ###################################################################
*/

/*!
 * @file S32K566_SSI_2_SLAVE.h
 * @version 2.7
 * @date 2026-09-09
 * @brief Peripheral Access Layer for S32K566_SSI_2_SLAVE
 *
 * This file contains register definitions and macros for easy access to their
 * bit fields.
 *
 * This file assumes LITTLE endian system.
 */

/**
* @page misra_violations MISRA-C:2012 violations
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.3, local typedef not referenced
* The SoC header defines typedef for all modules.
*
* @section [global]
* Violates MISRA 2012 Advisory Rule 2.5, local macro not referenced
* The SoC header defines macros for all modules and registers.
*
* @section [global]
* Violates MISRA 2012 Advisory Directive 4.9, Function-like macro
* These are generated macros used for accessing the bit-fields from registers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.1, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.2, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.4, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 5.5, identifier clash
* The supported compilers use more than 31 significant characters for identifiers.
*
* @section [global]
* Violates MISRA 2012 Required Rule 21.1, defined macro '__I' is reserved to the compiler
* This type qualifier is needed to ensure correct I/O access and addressing.
*/

/* Prevention from multiple including the same memory map */
#if !defined(S32K566_SSI_2_SLAVE_H_)  /* Check if memory map has not been already included */
#define S32K566_SSI_2_SLAVE_H_

#include "S32K566_COMMON.h"

/* ----------------------------------------------------------------------------
   -- SSI_2_SLAVE Peripheral Access Layer
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup SSI_2_SLAVE_Peripheral_Access_Layer SSI_2_SLAVE Peripheral Access Layer
 * @{
 */

/** SSI_2_SLAVE - Register Layout Typedef */
typedef struct SSI_2_SLAVE_Struct {
  __I  uint32_t STATUS;                            /**< SSI Responder Module Status, offset: 0x0 */
  __I  uint32_t MISSION_STATUS;                    /**< Mission Status, offset: 0x4 */
  uint8_t RESERVED_0[32];
  __IO uint32_t CLR_PARITY_ERR;                    /**< Clear parity error signals, offset: 0x28 */
  __IO uint32_t TEST_CTRL_STATUS;                  /**< Functional test control and status, offset: 0x2C */
  __IO uint32_t TEST_VECTOR;                       /**< Test Vector, offset: 0x30 */
  __I  uint32_t TEST_ERR_VECTOR;                   /**< Test Error Vector, offset: 0x34 */
  __IO uint32_t MISSION_FAULT_CTRL;                /**< Mission Fault Control, offset: 0x38 */
} SSI_2_SLAVE_Type, *SSI_2_SLAVE_MemMapPtr;

/** Number of instances of the SSI_2_SLAVE module. */
#define SSI_2_SLAVE_INSTANCE_COUNT               (1u)

/* SSI_2_SLAVE - Peripheral instance base addresses */
/** Peripheral SSI_2_SLAVE base address */
#define IP_SSI_2_SLAVE_BASE                      (0x405F0000u)
/** Peripheral SSI_2_SLAVE base pointer */
#define IP_SSI_2_SLAVE                           ((SSI_2_SLAVE_Type *)IP_SSI_2_SLAVE_BASE)
/** Array initializer of SSI_2_SLAVE peripheral base addresses */
#define IP_SSI_2_SLAVE_BASE_ADDRS                { IP_SSI_2_SLAVE_BASE }
/** Array initializer of SSI_2_SLAVE peripheral base pointers */
#define IP_SSI_2_SLAVE_BASE_PTRS                 { IP_SSI_2_SLAVE }

/* ----------------------------------------------------------------------------
   -- SSI_2_SLAVE Register Masks
   ---------------------------------------------------------------------------- */

/*!
 * @addtogroup SSI_2_SLAVE_Register_Masks SSI_2_SLAVE Register Masks
 * @{
 */

/*! @name STATUS - SSI Responder Module Status */
/*! @{ */

#define SSI_2_SLAVE_STATUS_AUX_IDLE_MASK         (0x40000000U)
#define SSI_2_SLAVE_STATUS_AUX_IDLE_SHIFT        (30U)
#define SSI_2_SLAVE_STATUS_AUX_IDLE_WIDTH        (1U)
#define SSI_2_SLAVE_STATUS_AUX_IDLE(x)           (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_STATUS_AUX_IDLE_SHIFT)) & SSI_2_SLAVE_STATUS_AUX_IDLE_MASK)

#define SSI_2_SLAVE_STATUS_PRI_IDLE_MASK         (0x80000000U)
#define SSI_2_SLAVE_STATUS_PRI_IDLE_SHIFT        (31U)
#define SSI_2_SLAVE_STATUS_PRI_IDLE_WIDTH        (1U)
#define SSI_2_SLAVE_STATUS_PRI_IDLE(x)           (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_STATUS_PRI_IDLE_SHIFT)) & SSI_2_SLAVE_STATUS_PRI_IDLE_MASK)
/*! @} */

/*! @name MISSION_STATUS - Mission Status */
/*! @{ */

#define SSI_2_SLAVE_MISSION_STATUS_MISSION_FAULT_MASK (0x1U)
#define SSI_2_SLAVE_MISSION_STATUS_MISSION_FAULT_SHIFT (0U)
#define SSI_2_SLAVE_MISSION_STATUS_MISSION_FAULT_WIDTH (1U)
#define SSI_2_SLAVE_MISSION_STATUS_MISSION_FAULT(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_MISSION_STATUS_MISSION_FAULT_SHIFT)) & SSI_2_SLAVE_MISSION_STATUS_MISSION_FAULT_MASK)

#define SSI_2_SLAVE_MISSION_STATUS_SLICE_LOST_MASK (0x2U)
#define SSI_2_SLAVE_MISSION_STATUS_SLICE_LOST_SHIFT (1U)
#define SSI_2_SLAVE_MISSION_STATUS_SLICE_LOST_WIDTH (1U)
#define SSI_2_SLAVE_MISSION_STATUS_SLICE_LOST(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_MISSION_STATUS_SLICE_LOST_SHIFT)) & SSI_2_SLAVE_MISSION_STATUS_SLICE_LOST_MASK)

#define SSI_2_SLAVE_MISSION_STATUS_PWR_CTRL_PAR_ERR_MASK (0x4U)
#define SSI_2_SLAVE_MISSION_STATUS_PWR_CTRL_PAR_ERR_SHIFT (2U)
#define SSI_2_SLAVE_MISSION_STATUS_PWR_CTRL_PAR_ERR_WIDTH (1U)
#define SSI_2_SLAVE_MISSION_STATUS_PWR_CTRL_PAR_ERR(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_MISSION_STATUS_PWR_CTRL_PAR_ERR_SHIFT)) & SSI_2_SLAVE_MISSION_STATUS_PWR_CTRL_PAR_ERR_MASK)

#define SSI_2_SLAVE_MISSION_STATUS_CTRL_LOGIC_FAILED_MASK (0x8U)
#define SSI_2_SLAVE_MISSION_STATUS_CTRL_LOGIC_FAILED_SHIFT (3U)
#define SSI_2_SLAVE_MISSION_STATUS_CTRL_LOGIC_FAILED_WIDTH (1U)
#define SSI_2_SLAVE_MISSION_STATUS_CTRL_LOGIC_FAILED(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_MISSION_STATUS_CTRL_LOGIC_FAILED_SHIFT)) & SSI_2_SLAVE_MISSION_STATUS_CTRL_LOGIC_FAILED_MASK)

#define SSI_2_SLAVE_MISSION_STATUS_SM_FAULT_MASK (0x10U)
#define SSI_2_SLAVE_MISSION_STATUS_SM_FAULT_SHIFT (4U)
#define SSI_2_SLAVE_MISSION_STATUS_SM_FAULT_WIDTH (1U)
#define SSI_2_SLAVE_MISSION_STATUS_SM_FAULT(x)   (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_MISSION_STATUS_SM_FAULT_SHIFT)) & SSI_2_SLAVE_MISSION_STATUS_SM_FAULT_MASK)
/*! @} */

/*! @name CLR_PARITY_ERR - Clear parity error signals */
/*! @{ */

#define SSI_2_SLAVE_CLR_PARITY_ERR_CLR_ERRS_MASK (0x1U)
#define SSI_2_SLAVE_CLR_PARITY_ERR_CLR_ERRS_SHIFT (0U)
#define SSI_2_SLAVE_CLR_PARITY_ERR_CLR_ERRS_WIDTH (1U)
#define SSI_2_SLAVE_CLR_PARITY_ERR_CLR_ERRS(x)   (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_CLR_PARITY_ERR_CLR_ERRS_SHIFT)) & SSI_2_SLAVE_CLR_PARITY_ERR_CLR_ERRS_MASK)
/*! @} */

/*! @name TEST_CTRL_STATUS - Functional test control and status */
/*! @{ */

#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_MODE_MASK (0x1U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_MODE_SHIFT (0U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_MODE_WIDTH (1U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_MODE(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_MODE_SHIFT)) & SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_MODE_MASK)

#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_LOAD_MASK (0x2U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_LOAD_SHIFT (1U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_LOAD_WIDTH (1U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_LOAD(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_LOAD_SHIFT)) & SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_LOAD_MASK)

#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_START_MASK (0x4U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_START_SHIFT (2U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_START_WIDTH (1U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_START(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_START_SHIFT)) & SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_START_MASK)

#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_UNPAUSE_MASK (0x8U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_UNPAUSE_SHIFT (3U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_UNPAUSE_WIDTH (1U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_UNPAUSE(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_UNPAUSE_SHIFT)) & SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_UNPAUSE_MASK)

#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_BURN_IN_MODE_MASK (0x10U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_BURN_IN_MODE_SHIFT (4U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_BURN_IN_MODE_WIDTH (1U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_BURN_IN_MODE(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_BURN_IN_MODE_SHIFT)) & SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_BURN_IN_MODE_MASK)

#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_DONE_MASK (0x20U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_DONE_SHIFT (5U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_DONE_WIDTH (1U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_DONE(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_DONE_SHIFT)) & SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_DONE_MASK)

#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_PASS_FAIL_B_MASK (0x40U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_PASS_FAIL_B_SHIFT (6U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_PASS_FAIL_B_WIDTH (1U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_PASS_FAIL_B(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_PASS_FAIL_B_SHIFT)) & SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_PASS_FAIL_B_MASK)

#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_ERROR_VALID_MASK (0x80U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_ERROR_VALID_SHIFT (7U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_ERROR_VALID_WIDTH (1U)
#define SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_ERROR_VALID(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_ERROR_VALID_SHIFT)) & SSI_2_SLAVE_TEST_CTRL_STATUS_TEST_ERROR_VALID_MASK)
/*! @} */

/*! @name TEST_VECTOR - Test Vector */
/*! @{ */

#define SSI_2_SLAVE_TEST_VECTOR_TEST_INPUT_MASK  (0xFFFFFFFFU)
#define SSI_2_SLAVE_TEST_VECTOR_TEST_INPUT_SHIFT (0U)
#define SSI_2_SLAVE_TEST_VECTOR_TEST_INPUT_WIDTH (32U)
#define SSI_2_SLAVE_TEST_VECTOR_TEST_INPUT(x)    (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_TEST_VECTOR_TEST_INPUT_SHIFT)) & SSI_2_SLAVE_TEST_VECTOR_TEST_INPUT_MASK)
/*! @} */

/*! @name TEST_ERR_VECTOR - Test Error Vector */
/*! @{ */

#define SSI_2_SLAVE_TEST_ERR_VECTOR_TEST_ERROR_BIT_MASK (0xFFFFFFFFU)
#define SSI_2_SLAVE_TEST_ERR_VECTOR_TEST_ERROR_BIT_SHIFT (0U)
#define SSI_2_SLAVE_TEST_ERR_VECTOR_TEST_ERROR_BIT_WIDTH (32U)
#define SSI_2_SLAVE_TEST_ERR_VECTOR_TEST_ERROR_BIT(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_TEST_ERR_VECTOR_TEST_ERROR_BIT_SHIFT)) & SSI_2_SLAVE_TEST_ERR_VECTOR_TEST_ERROR_BIT_MASK)
/*! @} */

/*! @name MISSION_FAULT_CTRL - Mission Fault Control */
/*! @{ */

#define SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_SLICE_LOST_MASK (0x1U)
#define SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_SLICE_LOST_SHIFT (0U)
#define SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_SLICE_LOST_WIDTH (1U)
#define SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_SLICE_LOST(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_SLICE_LOST_SHIFT)) & SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_SLICE_LOST_MASK)

#define SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_PWR_CTRL_PE_MASK (0x2U)
#define SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_PWR_CTRL_PE_SHIFT (1U)
#define SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_PWR_CTRL_PE_WIDTH (1U)
#define SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_PWR_CTRL_PE(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_PWR_CTRL_PE_SHIFT)) & SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_PWR_CTRL_PE_MASK)

#define SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_CTRL_LOGIC_FAILURE_MASK (0x4U)
#define SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_CTRL_LOGIC_FAILURE_SHIFT (2U)
#define SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_CTRL_LOGIC_FAILURE_WIDTH (1U)
#define SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_CTRL_LOGIC_FAILURE(x) (((uint32_t)(((uint32_t)(x)) << SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_CTRL_LOGIC_FAILURE_SHIFT)) & SSI_2_SLAVE_MISSION_FAULT_CTRL_REPORT_CTRL_LOGIC_FAILURE_MASK)
/*! @} */

/*!
 * @}
 */ /* end of group SSI_2_SLAVE_Register_Masks */

/*!
 * @}
 */ /* end of group SSI_2_SLAVE_Peripheral_Access_Layer */

#endif  /* #if !defined(S32K566_SSI_2_SLAVE_H_) */
